// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while(t--){
        int m;
        cin >> m;
        string s[15];
        for(int i = 0; i < m; i++){
            cin >> s[i];
        }
        string res = ""; 
        for(int i = 3; i <= 60; i++){
            for(int j = 0; j <= 60-i; j++){
                string test = s[0].substr(j, i);
                bool flag = true;
                for(int k = 1; k < m; k++){
                    if(s[k].find(test) == string :: npos){  
                        flag = false;
                        break;
                    }
                }
                if(flag && test.length() > res.length()){   
                    res = test;
                }
                else if(flag && test.length() == res.length() && test < res){   
                    res = test;
                }
            }
        }
        if(res == "") cout << "no significant commonalities\n";
        else cout << res << '\n';
    }
    return 0;
}