// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define _CRT_SECURE_NO_WARNINGS
#define MAX 510
#define EPS 1e-7
using namespace std;
struct Point{
    double x, y;
    Point(const double &_, const double &__):x(_), y(__) {}
    Point() {}
    Point operator +(const Point &a)const {
        return Point(x + a.x, y + a.y);
    }
    Point operator -(const Point &a)const {
        return Point(x - a.x, y - a.y);
    }
    Point operator *(const double &a)const {
        return Point(x * a, y * a);
    }
    Point operator /(const double &a)const {
        return Point(x / a, y / a);
    }
    void Read() {
        scanf("%lf%lf", &x, &y);
    }
}point[MAX];
inline double Calc(const Point &p1, const Point &p2)
{
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
inline Point Change(const Point &v)
{
    return Point(-v.y, v.x);
}
int points;
bool v[MAX];
int stacktt1[MAX], top;
inline int GetAns(const Point &p1, const Point &p2)
{
    double dis = Calc(p1, p2) / 2;
    if(dis > 1.0)   return 0;
    Point o = Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2) + (Change(p1 - p2) / (dis * 2)) * sqrt(1 - dis * dis);
    int re = 0;
    for(int i = 1; i <= top; ++i)
        re += Calc(point[stacktt1[i]], o) <= 1.0 + EPS;
    return re + 1;
}
int main()
{
    while(scanf("%d", &points), points) {
        for(int i = 1; i <= points; ++i)
            point[i].Read();
        int ans = 1;
        for(int i = 1; i <= points; ++i) {
            top = 0;
            for(int j = 1; j <= points; ++j)
                if(i != j && Calc(point[i], point[j]) < 2.0)
                    stacktt1[++top] = j;
            for(int j = 1; j <= top; ++j)
                ans = max(ans, GetAns(point[i], point[stacktt1[j]]));
        }
        printf("%d\n", ans);
    }
    return 0;
}