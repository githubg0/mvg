// Dynamic Programming->Priority Queue,Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAX 1000001
int n,k;
int pre1,pre2,lst1,lst2,len_max,len_min;    
int num[MAX],Increase[MAX],Decrease[MAX],Max[MAX],Min[MAX];      
void in_max(int i)
{
    while( pre1<=lst1 && num[ Increase[lst1] ]<num[i] )
        --lst1;
    Increase[++lst1]=i;
    
    if( i>=k )
    {
        if(Increase[pre1]<=i-k)
            pre1++;
        Max[len_max++]=num[ Increase[pre1] ];
    }
}
void in_min(int i)
{
    while( pre2<=lst2 && num[ Decrease[lst2] ]>num[i] )
        --lst2;
    Decrease[++lst2]=i;
    
    if( i>=k )
    {
        if(Decrease[pre2]<=i-k)
            pre2++;
        Min[len_min++]=num[ Decrease[pre2] ];
    }
}
int main()
{
    int i;
    while( ~scanf("%d%d",&n,&k) )
    {
        
        pre1=pre2=len_max=len_min=0;
        lst1=lst2=-1;
        
        for(i=1;i<=n;++i)
        {
            scanf("%d",&num[i]);
            in_max(i);
            in_min(i);
        }
        
        for( i=0;i<len_min-1;++i )
            printf("%d ",Min[i]);
        printf("%d\n",Min[len_min-1]);
        for( i=0;i<len_max-1;++i )
            printf("%d ",Max[i]);
        printf("%d\n",Max[len_max-1]);
    }
    return 0;
}