// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#pragma warning(disable : 4996)
int main()
{
	freopen("in.txt", "r", stdin);
	char ch[15] = {0}; 
	map<string, string> Map;
	string a, b, str, pat;
	while (scanf("%s", ch) != EOF)
	{
		a = string(ch);
		if(a == "END")
		{
			break;
		}
		else if(a == "START")
		{
			continue;
		}
		else
		{
			scanf("%s", ch);
			b = string(ch);
			Map[b] = a;
		}
	}
	
	getchar();
	while (getline(cin, str))
	{
		if(str == "END")
		{
			break;
		}
		else if(str == "START")
		{
			str.clear();
			continue;
		}
		else
		{
			for (int i = 0; i < str.size(); i++)
			{
				if(str[i] >= 'a' && str[i] <= 'z')
				{
					pat.push_back(str[i]);
				}
				else
				{
					if(Map.find(pat) == Map.end())
					{
						printf("%s", pat.c_str());
					}
					else
					{
						printf("%s", Map[pat].c_str());
					}
					printf("%c", str[i]);
					pat.clear();
				}
			}
			str.clear();
			printf("\n");
		}
	}
	return 0;
}