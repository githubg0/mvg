// Data Structure->Stack,Basic Algorithm->Simulation,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxx 100010
int head[maxx*2],par[2*maxx];
int l[maxx],r[maxx];
int ans[maxx];
int vis[maxx];
int cnt,toa;
int n,m;
stack <int >ss;
struct node {
    int s,next;
}edge[maxx*2];
void  add(int x,int y){
  edge[toa].s=x;edge[toa].next=head[y];head[y]=toa++;
}
int lowbit (int x){
   return x&-x;
}
int sum(int x){
   int r=0;
   while(x>0){
    r+=par[x];
    x-=lowbit(x);
   }
   return r;
}
void update(int x,int a){
   while(x<2*maxx){
    par[x]+=a;
    x+=lowbit(x);
   }
}
void dfs(int root){
    cnt=1;
   while(!ss.empty())
    ss.pop();
    memset(vis,0,sizeof(vis));
   ss.push(root);
   while(!ss.empty()){
    int u=ss.top();
    if(!vis[u]){
        l[u]=cnt++;
        vis[u]=1;
    }
    int flag=0;
    for(int i=head[u];i!=-1;i=edge[i].next){
        if(!vis[edge[i].s]){
            flag=1;
            head[u]=edge[i].next;
            ss.push(edge[i].s);
            break;
        }      
    }
    if(flag) continue;
    if(vis[u]){
        r[u]=cnt++;
        ss.pop();
    }
   }
}
void slove (){
   for(int i=1;i<=n;i++){
     ans[i]=sum(r[i]-1)-sum(l[i]);
     update(l[i],1);
   }
}
int main(){
    while(scanf("%d%d",&n,&m)&&(n||m)){
        memset(head,-1,sizeof(head));
        memset(par,0,sizeof(par));
        toa=0;
        int a,b;
        for(int i=0;i<n-1;i++){
            scanf("%d%d",&a,&b);
            add(a,b);
            add(b,a);
        }
        dfs(m);
        slove();
        for(int i=1;i<n;i++)
            printf("%d ",ans[i]);
        printf("%d\n",ans[n]);
    }
}