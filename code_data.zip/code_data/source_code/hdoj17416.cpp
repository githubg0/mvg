// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

struct edge
{
    int v,last;
}ed[4000010];
int n,m,num=0,tot=0,ans=0,cnt=0;
int head[100010],book[100010],match[100010],mp[330][330];
int fx[8]={2,2,1,-1,-2,-2,1,-1},fy[8]={1,-1,2,2,1,-1,-2,-2};
void add(int u,int v)
{
    num++;
    ed[num].v=v;
    ed[num].last=head[u];
    head[u]=num;
}
inline int dfs(int u)
{
    for(int i=head[u];i;i=ed[i].last)
    {
        int v=ed[i].v;
        if(book[v]!=tot)
        {
            book[v]=tot;
            if(!match[v] || dfs(match[v]))
            {
                match[v]=u,match[u]=v;
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            scanf("%d",&mp[i][j]),cnt+=(!mp[i][j]);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        if((i+j)&1)
        {
            if(mp[i][j]) continue ;
            int S=(i-1)*m+j;
            for(int k=0;k<8;k++)
            {
                int x1=i+fx[k],y1=j+fy[k];
                if(x1>=1 && x1<=n && y1>=1 && y1<=m && !mp[x1][y1])
                    add(S,(x1-1)*m+y1);
            }
        }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        if((i+j)&1)
        {
            int S=(i-1)*m+j;
            if(mp[i][j]) continue ;
            tot++;
            if(!match[S]) ans+=dfs(S);
        }
    printf("%d\n",cnt-ans);
    return 0;
}