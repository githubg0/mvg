// Dynamic Programming->Dynamic Programming (DP) on Intervals
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define PI acos(-1.0)
#define maxn 55
#define INF 1<<25
typedef long long ll;
using namespace std;
int cal[maxn][3];
int num[maxn];
int tot;
int dp_max[maxn][maxn];
int dp_min[maxn][maxn];
int tt=0;
int aa[maxn];
int init()
{
    for(int i=0; i<tot; i++)
        for(int j=0; j<tot; j++)
        {
            if(i==j)
                dp_max[i][j]=dp_min[i][j]=num[i];
            else
            {
                dp_max[i][j]=-INF;
                dp_min[i][j]=INF;
            }
        }
}
int dp(int i,int j)
{
    for(int k=i; k!=j; k=(k+1)%tot)
    {
        if(dp_max[i][k]==-INF)
            dp(i,k);
        if(dp_max[(k+1)%tot][j]==-INF)
            dp((k+1)%tot,j);
        if(cal[(k+1)%tot][0]=='t')
        {
            dp_max[i][j]=max(dp_max[i][j],dp_max[i][k]+dp_max[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_min[i][k]+dp_min[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_min[i][k]+dp_max[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_max[i][k]+dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_min[i][k]+dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_min[i][k]+dp_max[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_max[i][k]+dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_max[i][k]+dp_max[(k+1)%tot][j]);
        }
        if(cal[(k+1)%tot][0]=='x')
        {
            dp_max[i][j]=max(dp_max[i][j],dp_max[i][k]*dp_max[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_min[i][k]*dp_min[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_min[i][k]*dp_max[(k+1)%tot][j]);
            dp_max[i][j]=max(dp_max[i][j],dp_max[i][k]*dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_min[i][k]*dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_min[i][k]*dp_max[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_max[i][k]*dp_min[(k+1)%tot][j]);
            dp_min[i][j]=min(dp_min[i][j],dp_max[i][k]*dp_max[(k+1)%tot][j]);
        }
    }
}
int main()
{
    int ans=-INF;
    scanf("%d",&tot);
    for(int i=0; i<tot; i++)
        scanf("%s%d",cal[i],&num[i]);
    init();
    for(int i=0; i<tot; i++)
    {
        dp(i,(i-1+tot)%tot);
        if(dp_max[i][(i-1+tot)%tot]>ans)
        {
            ans=dp_max[i][(i-1+tot)%tot];
            tt=0;
            aa[tt]=i;
        }
        else if(dp_max[i][(i-1+tot)%tot]==ans)
        {
            aa[++tt]=i;
        }
    }
    printf("%d\n",ans);
    printf("%d",aa[0]+1);
    for(int i=1;i<=tt;i++)
    printf(" %d",aa[i]+1);
    printf("\n");
    return 0;
}