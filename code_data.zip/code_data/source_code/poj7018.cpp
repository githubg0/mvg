// Dynamic Programming->Priority Queue,Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:36777216")
#pragma GCC optimize ("O2")
using namespace std;
#define RD(x) scanf("%d",&x)
#define RD2(x,y) scanf("%d%d",&x,&y)
#define RD3(x,y,z) scanf("%d%d%d",&x,&y,&z)
#define clr0(x) memset(x,0,sizeof(x))
#define clr1(x) memset(x,-1,sizeof(x))
#define eps 1e-9
const double pi = acos(-1.0);
typedef long long LL;
typedef unsigned long long ULL;
const int modo = 1e9 + 7;
const int INF = 0x3f3f3f3f;
const int inf = 0x3fffffff;
const LL _inf = 1e18;
const int maxn = 1005,maxm = 10005;
struct edge{
    int v,w,next;
    edge(){};
    edge(int vv,int ww,int nnext):v(vv),w(ww),next(nnext){};
}e[maxm<<1];
int head[maxn],inq[maxn][2],dist[maxn][2],cnt[maxn][2];
int n,m,ecnt;
void init()
{
    clr1(head);
    ecnt = 0;
    for(int i = 1;i <= n;++i)
        dist[i][0] = dist[i][1] = inf;
    
    clr0(inq),clr0(cnt);
}
void add(int u,int v,int w)
{
    e[ecnt] = edge(v,w,head[u]);
    head[u] = ecnt++;
}
typedef pair<int,int> p2;
struct cmp {
     bool operator() (const p2 &a, const p2 &b)
     {
         return dist[a.first][a.second] > dist[b.first][b.second];
     }
};
void spfa(int src,int dst)
{
    priority_queue<p2 , vector<p2> , cmp> q;
    q.push(make_pair(src,0));
    dist[src][0] = 0,cnt[src][0] = 1;
    while(!q.empty()){
        int u = q.top().first,flag = q.top().second;
        q.pop();
        if(inq[u][flag])    continue;
        inq[u][flag] = 1;
        for(int i = head[u];i != -1;i = e[i].next){
            int v = e[i].v,w = e[i].w;
            if(!inq[v][0] && dist[v][0] > dist[u][flag] + e[i].w){
                if(dist[v][0] != inf){
                    dist[v][1] = dist[v][0];
                    cnt[v][1] = cnt[v][0];
                    q.push(make_pair(v,1));
                }
                dist[v][0] = dist[u][flag] + e[i].w;
                cnt[v][0] = cnt[u][flag];
                q.push(make_pair(v,0));
            }else if(!inq[v][0] && dist[v][0] == dist[u][flag] + e[i].w){
                cnt[v][0] += cnt[u][flag];
            }else if(!inq[v][1] && dist[v][1] > dist[u][flag] + e[i].w){
                dist[v][1] = dist[u][flag] + e[i].w;
                cnt[v][1] = cnt[u][flag];
                q.push(make_pair(v,1));
            }else if(!inq[v][1] && dist[v][1] == dist[u][flag] + e[i].w){
                cnt[v][1] += cnt[u][flag];
            }
        }
    }
    
    if(dist[dst][1] == dist[dst][0] + 1)
        printf("%d\n",cnt[dst][1] + cnt[dst][0]);
    else printf("%d\n",cnt[dst][0]);
}
int main(){
    int u,v,w,_,s,t;
    RD(_);
    while(_--){
        RD2(n,m);
        init();
        while(m--){
            RD3(u,v,w);
            add(u,v,w);
        }
        RD2(s,t);
        spfa(s,t);
    }
    return 0;
}