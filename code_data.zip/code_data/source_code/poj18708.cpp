// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define max_V 1000
using namespace std;
int V;
vector<int> G[max_V];
int match[max_V];
bool used[max_V];
void add_edge(int u ,int v)
{
    G[u].push_back(v);
    G[v].push_back(u);
}
bool dfs(int v)
{
    used[v]=1;
    for(int i=0;i<G[v].size();i++)
    {
        int u = G[v][i];
        int w=match[u];
        if(w<0||(!used[w]&&dfs(w)))
        {
            match[v]=u;
            match[u]=v;
            return 1;
        }
    }
    return 0;
}
int bi_match()
{
   int res =0;
   memset(match,-1,sizeof(match));
for(int v=0;v<V;v++)
{
    if(match[v]<0)
    {
        memset(used,0,sizeof(used));
        if(dfs(v))res++;
    }
}
return res;
}
int main()
{
    int n,k,a,b;
    scanf("%d%d",&n,&k);
    V=2*n;
    for(int i=0;i<k;i++)
    {
        scanf("%d%d",&a,&b);
        add_edge(a-1,n+b-1);
    }
    printf("%d\n",bi_match());
    return 0;
    }