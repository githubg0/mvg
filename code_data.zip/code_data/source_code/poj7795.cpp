// Data Structure->Segment Tree,Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Max = 100000;
typedef long long LL;
typedef struct node
{
    LL x1,y1;
    LL x2,y2;
    int Id;
    bool operator < (const node &b)const
    {
        if(b.x1>=x1&&b.x1<=x2)
        {
            double y = (double)((y2-y1)*(b.x1- x1))/(x2-x1)+y1;
            return y>(double)b.y1;
        }
        if(b.x2>=x1&&b.x2<=x2)
        {
            double y = (double)((y2-y1)*(b.x2-x1))/(x2-x1)+y1;
            return y>(double)b.y2;
        }
        return min(y1,y2)==min(b.y1,b.y2)?x2<b.x1:min(y1,y2)>min(b.y1,b.y2);
    }
}Point ;
Point P[Max];
typedef struct Node
{
    LL sum1;
    LL sum2;
    bool flag1,flag2;
}Tree;
Tree Tr[Max*8];
int n;
LL a[Max*3];
int Hash[Max*3];
int num ;
int Bound(int l,int r,int d)
{
    while(l<=r)
    {
        int mid = (l+r)>>1;
        if(Hash[mid]==d)
        {
            return mid;
        }
        if(Hash[mid]>d)
        {
            r = mid-1;
        }
        else
        {
            l = mid+1;
        }
    }
    return 0;
}
void PushUp(int st)
{
    Tr[st].sum1 = Tr[st<<1].sum1+Tr[st<<1|1].sum1;
    Tr[st].sum2 = Tr[st<<1].sum2+Tr[st<<1|1].sum2;
}
void PushDown(int st)
{
    if(Tr[st].flag1)
    {
        Tr[st<<1].sum1 = Tr[st<<1|1].sum1 = Tr[st].sum1;
        Tr[st<<1].flag1 = Tr[st<<1|1].flag1 = true;
        Tr[st].flag1 = false;
    }
    if(Tr[st].flag2)
    {
        Tr[st<<1].sum2 = Tr[st<<1|1].sum2 =Tr[st].sum2;
        Tr[st<<1].flag2 = Tr[st<<1|1].flag2 = true;
        Tr[st].flag2= false;
    }
}
void BuildTree(int L,int R,int st)
{
    Tr[st].flag1 = false;
    Tr[st].flag2 = false;
    if(L == R)
    {
        Tr[st].sum1 = Hash[L]-Hash[L-1];
        Tr[st].sum2 = 0;
        return ;
    }
    int mid = (L+R)>>1;
    BuildTree(L,mid,st<<1);
    BuildTree(mid+1,R,st<<1|1);
    PushUp(st);
}
void Cover1(int L,int R,int st,int l,int r)
{
    if(l==L&&r==R) 
    {
        Tr[st].flag1= true;
        Tr[st].sum1 = 0 ;
        return ;
    }
    PushDown(st);
    int mid = (L+R) >> 1;
    if(r<=mid) Cover1(L,mid,st<<1,l,r);
    else if(l>mid) Cover1(mid+1,R,st<<1|1,l,r);
    else
    {
        Cover1(L,mid,st<<1,l,mid);
        Cover1(mid+1,R,st<<1|1,mid+1,r);
    }
    PushUp(st);
}
void Cover2(int L,int R,int st,int l,int r)
{
    if(l==L&&r==R) 
    {
        Tr[st].flag2 = true;
        Tr[st].sum2 = 0 ;
        return ;
    }
    PushDown(st);
    int mid = (L+R) >> 1;
    if(r<=mid) Cover2(L,mid,st<<1,l,r);
    else if(l>mid) Cover2(mid+1,R,st<<1|1,l,r);
    else
    {
        Cover2(L,mid,st<<1,l,mid);
        Cover2(mid+1,R,st<<1|1,mid+1,r);
    }
    PushUp(st);
}
void Update(int L,int R,int st,int x,int d)
{
    if(L == R) 
    {
        Tr[st].sum2 = d;
        return ;
    }
    PushDown(st);
    int mid = (L+R)>>1;
    if(x<=mid) Update(L,mid,st<<1,x,d);
    else Update(mid+1,R,st<<1|1,x,d);
    PushUp(st);
}
LL Query1(int L,int R,int st,int l,int r)
{
    if(l==L&&r==R) return Tr[st].sum1;
    PushDown(st);
    int mid = (L+R)>>1;
    if(r<=mid) return Query1(L,mid,st<<1,l,r);
    else if(l>mid) return Query1(mid+1,R,st<<1|1,l,r);
    else return Query1(L,mid,st<<1,l,mid)+Query1(mid+1,R,st<<1|1,mid+1,r);
}
LL Query2(int L,int R,int st,int l,int r)
{
    if(l==L&&r==R) return Tr[st].sum2;
    PushDown(st);
    int mid = (L+R)>>1;
    if(r<=mid) return Query2(L,mid,st<<1,l,r);
    else if(l>mid) return Query2(mid+1,R,st<<1|1,l,r);
    else return Query2(L,mid,st<<1,l,mid)+Query2(mid+1,R,st<<1|1,mid+1,r);
}
int main()
{
    while(~scanf("%d",&n))
    {
        num = 0;
        for(int i = 0; i<n;i++)
        {
            scanf("%lld %lld %lld %lld",&P[i].x1,&P[i].y1,&P[i].x2,&P[i].y2);
            a[num++] = P[i].x1; a[num++] = P[i].x2;
            P[i].Id = i;
        }
        sort(P,P+n);
        sort(a,a+num);
        int ant = 1;
        Hash[1]=a[0];
        Hash[0]=a[0];
        for(int i = 1;i<num;i++)
        {
            if(a[i]!=a[i-1])
            {
                Hash[++ant] = a[i];
            }
        }
        BuildTree(1,ant,1);
        for(int i = 0;i<n;i++)
        {
            int L = Bound(1,ant,P[i].x1);
            int R = Bound(1,ant,P[i].x2);
            a[P[i].Id] = Query1(1,ant,1,L+1,R)+Query2(1,ant,1,L,R);
            Cover1(1,ant,1,L+1,R);
            Cover2(1,ant,1,L,R);
            if(P[i].y1>P[i].y2)
            {
                Update(1,ant,1,R,a[P[i].Id]);
            }
            else
            {
                Update(1,ant,1,L,a[P[i].Id]);
            } 
        }
        for(int i = 0;i<n;i++)
        {
            printf("%lld\n",a[i]);
        }
    }
    return 0;
}