// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int sign=0;
int ssign=0;
int lsign=0;
int a[65]={0};
bool ss[65]={0};
int n;
int now;
bool dfs(int c,int cur,int pos){
	if(c==n) return true;
	int i;
	for(int i=pos;i<n;i++){
		if(ss[i]) continue;
		if(cur+a[i]<now){
			ss[i]=1;
			if(dfs(c+1,cur+a[i],i+1))return 1;
			ss[i]=0;
			if(cur==0) return 0;
			while(a[i]==a[i+1] && i+1<n) i++;
		}
		else if(cur+a[i]==now){
			ss[i]=1;
			if(dfs(c+1,0,0)) return 1;
			ss[i]=0;
			return 0;
		}
	}
	return 0;
}
bool judge(int x,int y){
	if(x<y) return false;
	else return true;
}
int main()
{
	int sum=0;
	int max1=0;
	while(cin>>n){
		max1=0;
		sum=0;
		sign=0;
		ssign=0;
		lsign=0;
		memset(a,0,sizeof(int)*65);
		memset(ss,0,65);
		if(n==0) break;
		int x;
		for(int i=0;i<n;i++){
			cin>>x;
			a[i]=x;
			sum+=x;
			if(x>max1) max1=x;
		}
		sort(a,a+n,judge);
		for(now=max1;now<=sum;now++){
			memset(ss,0,65);
			if(sum%now!=0) continue;
			if(dfs(0,0,0)){
				sign=now;
				break;
			}
		}
		cout<<sign<<endl;
	}
	return 0;
	
}