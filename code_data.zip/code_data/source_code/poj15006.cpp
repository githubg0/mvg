// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Max = 30;
int kase;
int p,q;
int vis[Max][Max]; 
 int dir[8][2] = {{-1,-2},{1,-2},{-2,-1},{2,-1},{-2,1},{2,1},{-1,2},{1,2}};
int path[Max*Max][2]; 
int flag;
void dfs(int x, int y, int step)
{
	if(step == p*q) 
	{
		cout<<"Scenario #"<<++kase<<":"<<endl;
		for(int i=0; i<p*q; i++)
		{
			printf("%c%d",path[i][1]+'A',path[i][0]+1); 
		}
		cout<<endl<<endl;
		flag = 1;
		return;
	}
	for(int d=0; d<8; d++)
	{
		int nx,ny; 
		nx = x + dir[d][0];
		ny = y + dir[d][1];
		if(!vis[nx][ny] && nx >= 0 && nx < p && ny >= 0 && ny < q)
		{
			vis[nx][ny] = 1;
			path[step][0] = nx;
			path[step][1] = ny;
			dfs(nx, ny, step+1);
			vis[nx][ny] = 0; 
			if(flag)
				return;
		}
	}
}
int main()
{
	int t;
	while(scanf("%d",&t) != EOF)
	{
		kase = 0;
		while(t--)
		{
			flag = 0;
			memset(vis, 0, sizeof(vis));
			scanf("%d %d",&p,&q);
			path[0][0] = 0;
			path[0][1] = 0;
			vis[0][0] = 1;
			dfs(0,0,1);
			if(!flag)
			{
				cout<<"Scenario #"<<++kase<<":"<<endl;
				cout<<"impossible"<<endl<<endl;
			}
		}
	}
	return 0;
}