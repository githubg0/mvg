// Math and Computational Geometry->Number Theory,Math and Computational Geometry->Euler's Totient Function,Math and Computational Geometry->Fermat's Little Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
using namespace std;
LL gcd(LL a, LL b) {
    return b ? gcd(b, a % b) : a;
}
long long mult_mod(long long a,long long b,long long c)
{
    a%=c;
    b%=c;
    long long ret=0;
    while(b)
    {
        if(b&1){ret+=a;ret%=c;}
        a<<=1;
        if(a>=c)a%=c;
        b>>=1;
    }
    return ret;
}
long long pow_mod(long long x,long long n,long long mod)
{
    if(n==1)return x%mod;
    x%=mod;
    long long tmp=x;
    long long ret=1;
    while(n)
    {
        if(n&1) ret=mult_mod(ret,tmp,mod);
        tmp=mult_mod(tmp,tmp,mod);
        n>>=1;
    }
    return ret;
}
LL phi(LL n){
    LL ret = n;
    for(LL i=2;i*i<=n;i+=(i==2)?1:2){
        if(!(n%i)){
            ret=ret/i*(i-1);
            while(n%i==0) n/=i;
        }
    }
    if(n>1) ret=ret/n*(n-1);
    return ret;
}
int main(){
    
    LL p,q,time=1;
    while(~scanf("%I64d/%I64d",&p,&q)){
        LL temp=gcd(p,q);
        p/=temp;
        q/=temp;
        LL i=1;
        while(q%2==0){
            q/=2;
            i++;
        }
        LL a=phi(q);
        LL j=-1;
        LL k;
        for(k=2;k*k<=a;k++){
            if(a%k==0){
                if(pow_mod(2,k,q)==1){
                    if(j==-1){
                        j=k;
                    }
                    else if(j>k){
                        j=k;
                    }
                    break;
                }
                else{
                    LL temp=a/k;
                    if(pow_mod(2,temp,q)==1){
                        if(j==-1){
                            j=temp;
                        }
                        else if(j>temp){
                            j=temp;
                        }
                    }
                }
            }
        }
        if(j==-1)
            j=a;
        printf("Case #%I64d: %I64d,%I64d\n",time,i,j);
        time++;
    }
    return 0;
}