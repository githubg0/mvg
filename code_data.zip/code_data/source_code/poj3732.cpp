// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=16100;
bool vis[MAXN>>1][MAXN>>1];
struct seg
{
    int l,r;
    int color;
}tree[MAXN<<2];
struct Node
{
    int x,y1,y2;
}p[MAXN>>1];
bool cmp(Node a,Node b)
{
    return a.x<b.x;
}
void build(int l,int r,int k)
{
    tree[k].l=l;
    tree[k].r=r;
    tree[k].color=0;
    if(l==r)
        return;
    int mid=(l+r)>>1;
    build(l,mid,k<<1);
    build(mid+1,r,k<<1|1);
}
void pushdown(int k)
{
    tree[k<<1].color=tree[k<<1|1].color=tree[k].color;
    tree[k].color=-1;
}
void query(int l,int r,int k,int val)
{
    if(tree[k].color!=-1)
    {
        vis[tree[k].color][val]=1;
        return;
    }
    if(tree[k].l==tree[k].r)
        return;
    if(tree[k].color!=-1)
        pushdown(k);
    int mid=(tree[k].l+tree[k].r)>>1;
    if(l<=tree[k<<1].r)
        query(l,r,k<<1,val);
    if(r>=tree[k<<1|1].l)
        query(l,r,k<<1|1,val);
}
void update(int l,int r,int k,int val)
{
    if(tree[k].l>=l&&tree[k].r<=r)
    {
        tree[k].color=val;
        return;
    }
    if(tree[k].color!=-1)
        pushdown(k);
    if(l<=tree[k<<1].r)
        update(l,r,k<<1,val);
    if(r>=tree[k<<1|1].l)
        update(l,r,k<<1|1,val);
}
int main()
{
    int t,n,i,j,k;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(i=1;i<=n;i++)
        {
            scanf("%d%d%d",&p[i].y1,&p[i].y2,&p[i].x);
            p[i].y1=2*p[i].y1;
            p[i].y2=2*p[i].y2;
        }
        build(0,MAXN,1);
        sort(p+1,p+n+1,cmp);
        memset(vis,0,sizeof(vis));
        for(i=1;i<=n;i++)
        {
            query(p[i].y1,p[i].y2,1,i);
            update(p[i].y1,p[i].y2,1,i);
        }
        int ans=0;
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
            if(vis[i][j])
            for(k=1;k<=n;k++)
            {
                if(vis[i][k]&&vis[j][k])
                    ans++;
            }
        printf("%d\n",ans);
    }
    return 0;
}