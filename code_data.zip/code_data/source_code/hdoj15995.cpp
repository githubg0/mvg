// Data Structure->Segment Tree,Basic Algorithm->Simulation,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int m,n;
int book[200000+10];
int Max[200010<<2];
int tmpa,tmpb;
char tmpc;
#define lson (q<<1)
#define rson (q<<1|1)
#define mid ((l+r)>>1)
void build_tree(int q,int l,int r)
{
    if(l==r)
    {
        Max[q]=book[l];
        return;
    }
    int m=mid;
    build_tree(lson,l,m);
    build_tree(rson,m+1,r);
    Max[q]=max(Max[lson],Max[rson]);
}
int query(int q,int l,int r,int a,int b)
{
    if(l>=a && b>=r )
    return Max[q];
    int m=mid;
    int tmp=0;
    if(a<=m) tmp=max(tmp,query(lson,l,m,a,b));
    if(b>m)  tmp=max(tmp,query(rson,m+1,r,a,b));
    return tmp;
}
void update(int q,int l,int r,int number,int k)
{
    if(l==r)
    {
        Max[q]=k;
        return;
    }
    int m=mid;
    if(number<=m) update(lson,l,m,number,k);
    else update(rson,m+1,r,number,k);
    Max[q]=max(Max[lson],Max[rson]);
}
int main()
{
    while(~scanf("%d %d",&m,&n))
    {
        for(int i=1;i<=m;i++)
            scanf("%d",&book[i]);
        getchar();
        build_tree(1,1,m);
        for(int i=0;i<n;i++)
        {
            scanf("%c %d %d",&tmpc,&tmpa,&tmpb);
            getchar();
            if(tmpc=='U')
            {
                update(1,1,m,tmpa,tmpb);
            }else
            {
                printf("%d\n",query(1,1,m,tmpa,tmpb));
            }
        }
    }
    return 0;
}