// Data Structure->Stack,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 10
using namespace std;
int n,m,ans;
int sx,sy,ex,ey;
long long stw,stb,curstw,curstb;
int mp[maxn][maxn];
int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};
char s[maxn];
struct Node
{
    int x,y;
    int step,bomb;
    long long statew;
    long long stateb;
    friend bool operator <(const Node&xx,const Node&yy)
    {
        return xx.step>yy.step;
    }
} cur,now;
vector<Node>vis[maxn][maxn];  
priority_queue<Node>q;
bool isok(int tx,int ty)  
{
    int i,j,sz;
    sz=vis[tx][ty].size();
    for(i=0; i<sz; i++)
    {
        if(vis[tx][ty][i].stateb==curstb&&vis[tx][ty][i].statew==curstw) return false ;
    }
    return true ;
}
bool bfs()
{
    int i,j,t,nx,ny,nstep,nbomb,tx,ty;
    long long nstw,nstb,tstw,tstb;
    while(!q.empty()) q.pop();
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=m; j++)
        {
            vis[i][j].clear();
        }
    }
    cur.x=sx;
    cur.y=sy;
    cur.step=0;
    cur.bomb=0;
    cur.stateb=stb;
    cur.statew=stw;
    vis[sx][sy].push_back(cur);
    q.push(cur);
    while(!q.empty())
    {
        now=q.top();
        q.pop();
        nx=now.x;
        ny=now.y;
        nstep=now.step;
        nbomb=now.bomb;
        nstb=now.stateb;
        nstw=now.statew;
        for(i=0; i<4; i++)
        {
            tx=nx+dx[i];
            ty=ny+dy[i];
            t=(tx-1)*m+ty-1;
            if(tx<1||tx>n||ty<1||ty>m) continue ;
            if(nbomb==0&&(nstw&(1LL<<t))) continue ; 
            curstb=nstb;
            curstw=nstw;
            cur.bomb=nbomb;
            if(nstb&(1LL<<t)) curstb=nstb&~(1LL<<t); 
            if(nstw&(1LL<<t)) curstw=nstw&~(1LL<<t); 
            if(isok(tx,ty))
            {
                cur.x=tx;
                cur.y=ty;
                if(tx==ex&&ty==ey)  
                {
                    ans=nstep+1;
                    return true ;
                }
                cur.bomb=nbomb;
                if(nstb&(1LL<<t)) cur.bomb+=mp[tx][ty];
                if(nstw&(1LL<<t)) cur.bomb--;
                cur.stateb=curstb;
                cur.statew=curstw;
                cur.step=nstep+1;
                if(nstw&(1LL<<t)) cur.step++;
                vis[tx][ty].push_back(cur);
                q.push(cur);
            }
        }
    }
    return false ;
}
int main()
{
    int i,j,t;
    while(scanf("%d%d",&n,&m),n||m)
    {
        memset(mp,0,sizeof(mp));
        stw=stb=0;
        for(i=1; i<=n; i++)
        {
            scanf("%s",s);
            for(j=1; j<=m; j++)
            {
                t=(i-1)*m+j-1;
                if(s[j-1]=='S') sx=i,sy=j;
                else if(s[j-1]=='D') ex=i,ey=j;
                else if(s[j-1]=='X')
                {
                    mp[i][j]=-1;
                    stw=(1LL<<t)|stw;
                }
                else if(s[j-1]>='1'&&s[j-1]<='9')
                {
                    mp[i][j]=s[j-1]-'0';
                    stb=(1LL<<t)|stb;
                }
            }
        }
        if(bfs()) printf("%d\n",ans);
        else printf("-1\n");
    }
    return 0;
}