// Graph Algorithm->Maximum Flow Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f
#define ll long long
#define maxn 2000
#define maxm 200000
using namespace std;
struct node1{
    int x,y,high,f;
}pill[maxn];
string s[maxn];
struct Edge{
int to,next;int cap,flow;
}edge[maxm];
int tol,n,m;
int head[maxn];
int gap[maxn],dep[maxn],pre[maxn],cur[maxn];
bool judge(node1 p){int x=p.x,y=p.y;
  for(int i=0;i<=s[0].size()+1;i++)if(sqrt((x-0)*(x-0)+(y-i)*(y-i))<=m*1.0){return true;}
  for(int i=0;i<=n+1;i++)if(sqrt((x-i)*(x-i)+(y-0)*(y-0))<=m*1.0){return true;}
  for(int i=0;i<=s[0].size()+1;i++)if(sqrt((x-n-1)*(x-n-1)+(y-i)*(y-i))<=m*1.0){return true;}
  for(int i=0;i<=n+1;i++)if(sqrt((y-s[0].size()-1)*(y-s[0].size()-1)+(x-i)*(x-i))<=m*1.0){return true;}
  return false;
}
void init(){tol=0;memset(head,-1,sizeof(head));memset(edge,0,sizeof(edge));}
void addedge(int u,int v,int w,int rw){
    edge[tol].to=v;edge[tol].cap=w;edge[tol].next=head[u];edge[tol].flow=0;head[u]=tol++;
    edge[tol].to=u;edge[tol].cap=rw;edge[tol].next=head[v];edge[tol].flow=0;head[v]=tol++;
}
int sap(int s,int t,int N){
    memset(gap,0,sizeof(gap));memset(dep,0,sizeof(dep));memset(pre,0,sizeof(pre));
    memcpy(cur,head,sizeof(head));
    int u=s;pre[u]=-1;gap[0]=N;int ans=0;
    while(dep[s]<N){
        if(u==t){
            int minn=inf;for(int i=pre[u];i!=-1;i=pre[edge[i^1].to])
            if(minn>edge[i].cap-edge[i].flow)
                minn=edge[i].cap-edge[i].flow;
            for(int i=pre[u];i!=-1;i=pre[edge[i^1].to]){
                edge[i].flow+=minn;edge[i^1].flow-=minn;
            }u=s;ans+=minn;continue;
        }
        bool flag=false;int v;
        for(int i=cur[u];i!=-1;i=edge[i].next){
            v=edge[i].to;
            if(edge[i].cap-edge[i].flow && dep[v]+1==dep[u]){
                flag=true;cur[u]=pre[v]=i;break;
            }
        }if(flag){u=v;continue;}
        int minn=N;
        for(int i=head[u];i!=-1;i=edge[i].next)
        if(edge[i].cap-edge[i].flow && dep[edge[i].to]<minn){
            minn=dep[edge[i].to];cur[u]=i;
            }
        gap[dep[u]]--;if(!gap[dep[u]])return ans;
        dep[u]=minn+1;gap[dep[u]]++;if(u!=s)u=edge[pre[u]^1].to;
        }
        return ans;
}
int main(){
    int test;scanf("%d",&test);int tes=0;
    while(test--){init();for(int i=0;i<maxn;i++)s[i].clear();
    scanf("%d%d",&n,&m);int l=0,k=0;memset(pill,0,sizeof(pill));
    for(int i=0;i<2*n;i++)cin>>s[i];
    for(int i=0;i<n;i++){
    for(int j=0;j<s[i].size();j++){if(s[i][j]>'0'){
        pill[l].x=i+1;pill[l].y=j+1;pill[l].high=s[i][j]-'0';
    if(s[i+n][j]=='L')pill[l].f=1;else pill[l].f=0;
    l++;} }
        }int s=0,t=l+l+1;
        for(int i=0;i<l;i++){for(int j=0;j<l;j++){
        double dis=sqrt((pill[i].x-pill[j].x)*(pill[i].x-pill[j].x)+(pill[i].y-pill[j].y)*(pill[i].y-pill[j].y));
        if(dis<=m*1.0)addedge(j+1+l,i+1,pill[j].high,0);}
        }for(int i=0;i<l;i++){if(judge(pill[i])){addedge(i+l+1,t,pill[i].high,0);}
        }
        for(int i=0;i<l;i++){addedge(i+1,i+1+l,pill[i].high,0);if(pill[i].f==1){k++;addedge(s,i+1,1,0);}}
        int ans=sap(s,t,t+1);ans=k-ans;printf("Case #%d: ",++tes);
        if(ans==0)cout<<"no lizard was left behind."<<endl;
        else if(ans==1)cout<<"1 lizard was left behind."<<endl;
        else printf("%d lizards were left behind.\n",ans);
    }
}