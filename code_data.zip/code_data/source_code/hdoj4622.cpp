// Basic Algorithm->Depth First Search (DFS),Math and Computational Geometry->Euler's Totient Function,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100005
#define maxm 40005
#define eps 1e-10
#define mod 1000000007
#define INF 999999999
#define lowbit(x) (x&(-x))
#define mp mark_pair
#define ls o<<1
#define rs o<<1 | 1
#define lson o<<1, L, mid
#define rson o<<1 | 1, mid+1, R
typedef long long LL;
using namespace std;
LL powmod(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base%mod;base=base*base%mod;b/=2;}return res;}
void scanf(int &__x){__x=0;char __ch=getchar();while(__ch==' '||__ch=='\n')__ch=getchar();while(__ch>='0'&&__ch<='9')__x=__x*10+__ch-'0',__ch = getchar();}
LL gcd(LL _a, LL _b){if(!_b) return _a;else return gcd(_b, _a%_b);}
int phi[maxn];
int p[maxn];
int res, a, b;
void init(void)
{
	phi[1] = 1;
	for(int i = 2; i <= 100000; i++) if(!phi[i])
		for(int j = i; j <= 100000; j += i) {
			if(!phi[j]) phi[j] = j;
			phi[j] = phi[j] / i *(i-1);
		}
}
void dfs(int pos, int dep, int mul, int flag)
{
	if(pos == dep) {
		res += a/mul*flag;
		return;
	}
	dfs(pos+1, dep, mul, flag);
	dfs(pos+1, dep, mul*p[pos], -flag);
}
void work(int __)
{
	if(a > b) swap(a, b);
	int cnt, n;
	LL ans = 0;
	for(int i = 1; i <= a; i++) ans += phi[i];
	for(int i = a+1; i <= b; i++) {
		cnt = res = 0, n = i;
		for(int j = 2; j * j <= n; j++)
			if(n % j == 0) {
				p[cnt++] = j;
				while(n % j == 0) n/=j;
			}
		if(n > 1) p[cnt++] = n;
		dfs(0, cnt, 1, 1);
		ans += res;
	}
	printf("Case %d: %I64d\n", __, ans);
}
int main(void)
{
	int _, c, d, k, __;
	init();
	while(scanf("%d", &_)!=EOF) {
		__ = 0;
		while(_--) {
			scanf("%d%d%d%d%d", &a, &b, &c, &d, &k);
			if(k == 0) {
				printf("Case %d: 0\n", ++__);
				continue;
			}
			a = b/k, b = d/k;
			work(++__);
		}
	}
	return 0;
}