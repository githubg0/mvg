// Math and Computational Geometry->Inverse Element
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define fo(i,a,b) for(int i=a;i<=b;++i)
#define fod(i,a,b) for(int i=a;i>=b;--i)
const int N=105;
typedef long long LL;
using namespace std;
int t,n,m,num,l,mo,f[N][N*N],cs[N*N][N],pr[N][2];
LL ksm(LL k,LL n)
{
    LL s=1;
    for(;n;n>>=1,k=k*k%mo) if(n&1) s=s*k%mo;
    return s;
}
void exgcd(LL a,LL b,LL &x,LL &y)
{
    if(b==0) {x=1,y=0;return;}
    exgcd(b,a%b,y,x);
    y-=(a/b)*x;
}
LL ny(int k)
{
    LL x,y;
    exgcd(k,mo,x,y);
    return (x%mo+mo)%mo;
}
void make(int n)
{
    num=0;
    int n1=sqrt(n);
    fo(i,2,n1)
    {
        if(n%i==0)
        {
            pr[++num][0]=i;
            while(n%i==0) pr[num][1]++,n/=i;
        }
    }
    if(n>1) pr[++num][0]=n,pr[num][1]=1;
}
int pv[N];
void mul(LL &s,LL v)
{
    if(v!=0) fo(i,1,num) while(v%pr[i][0]==0) v/=pr[i][0],pv[i]++;
    s=s*v%mo;
}
void dvi(LL &s,LL v)
{
    fo(i,1,num) while(v%pr[i][0]==0) v/=pr[i][0],pv[i]--;
    s=s*ny(v)%mo;
}
LL get(LL s)
{
    fo(i,1,num) s=s*ksm(pr[i][0],pv[i])%mo;
    return s;
}
int main()
{
    cin>>t;
    while(t--)
    {
        scanf("%d%d%d%d",&n,&m,&l,&mo);
        if(n==m) {printf("%d\n",1%mo);continue;}
        cs[0][0]=1%mo;
        make(mo);
        fo(i,1,m*l)
        {
            cs[i][0]=1%mo;
            int r=min(i,l);
            fo(j,1,r) cs[i][j]=((LL)cs[i-1][j]+cs[i-1][j-1])%mo;
        }
        f[0][0]=1;
        fo(i,1,m)
        {
            int r=min(i*l,n-m);
            f[i][0]=1;
            fo(j,1,r) 
            {
                f[i][j]=(LL)f[i][j-1]*i%mo;
                if(j>l) f[i][j]=(f[i][j]-(LL)cs[j-1][l]*f[i-1][j-1-l]%mo*i%mo+mo)%mo;
            }
        }
        memset(pv,0,sizeof(pv));
        LL v=1,ans=0;int r=min(n-m,l*m);
        fo(i,1,r)
        {
            ans=(ans+ksm(n-m,n-i-m)*f[m][i]%mo*get(v)%mo)%mo;
            mul(v,n-m-i),dvi(v,i);
        }
        v=1;memset(pv,0,sizeof(pv));
        fo(j,0,m-1) mul(v,n-j),dvi(v,j+1); 
        ans=ans*get(v)%mo;
        printf("%lld\n",ans);
    }
}