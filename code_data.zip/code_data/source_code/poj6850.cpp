// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x3f3f3f3f
#define Max 110
int max(int a,int b)
{
	return a>b?a:b;
}
int min(int a,int b)
{
	return a<b?a:b;
}
double dp[100][100];
int n;
double rec[201];
void init()
{
    int i,j;
    memset(dp,0,sizeof(dp));
    memset(rec,0,sizeof(rec));
    rec[0]=0;
    dp[0][0]=1;
    for(i=1;i<100;i++)
    {
        for(j=1;j<=i;j++)
        {
            dp[i][j]=dp[i-1][j]*j+dp[i-1][j-1];
            rec[i]+=dp[i][j];
          
        }
    }
}
int main()
{
    init();
    while(scanf("%d",&n),n)
    {
       
       printf("%d %.0lf\n",n,rec[n]);
    }
}