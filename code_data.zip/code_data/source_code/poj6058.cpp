// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0
int main(void)
{
	int scenario=1;
	int n,r;
	map<string,int> mymap;
	int matrix[202][202];
	int path[202];
	int visit[202];
	string start,end1;
	int len;
	while(cin>>n>>r &&n&&r)
	{
		mymap.clear();
		memset(path,0,sizeof(path));
		memset(visit,0,sizeof(visit));
		int index(0);
		for(int i=0;i<n;++i)
		{
			for(int j=0;j<n;++j)
			{
				matrix[i][j]=INF;
			}
			matrix[i][i]=10000;
		}
		for(int i=0;i<r;++i)
		{
			cin>>start>>end1>>len;
			if(mymap.find(start)==mymap.end())
			{
				mymap.insert( make_pair(start,index++));
			}
			if(mymap.find(end1)==mymap.end())
			{
				mymap.insert( make_pair(end1,index++));
			}
			matrix[mymap[start]][mymap[end1]]=len;
			matrix[mymap[end1]][mymap[start]]=len;
		}
		cin>>start>>end1;
		int a=mymap[start],b=mymap[end1];
		for(int i=0;i<n;++i)
		{
			path[i]=matrix[a][i];
		}
		visit[a]=1;
		for(int i=0;i<n;++i)
		{
			int minimum(INF);
			int index(i);
			for(int j=0;j<n;++j)
				if(!visit[j] && minimum<path[j] && path[j]> INF)
				{
					minimum=path[j];
					index=j;
				}
			visit[index]=1;
			for(int j=0;j<n;++j)
				if(!visit[j] && (matrix[index][j]>INF) && (path[j]<min(matrix[index][j],path[index])))
					path[j]=min(matrix[index][j],path[index]);
		}
			printf("Scenario #%d\n%d tons\n\n",scenario++,path[b]);
	}
	return 0;
}