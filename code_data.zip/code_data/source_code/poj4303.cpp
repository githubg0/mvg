// Basic Algorithm->Recurrence,Data Structure->Disjoint Set Union (DSU),Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
#define maxn 700
using namespace std;
int N,M,T,X,Y;
int ans;
int parent[maxn];
int relate[maxn];
char str[10];
int indata[2*maxn];
int dp[maxn][maxn];
int path[maxn][maxn];
int setname[maxn];
int find(int *parent,int k);
int backpack()
{
	int i,j,k,t,m;
	k=0;
	memset(dp,0,sizeof(dp));
	memset(path,0,sizeof(path));
	memset(indata,0,sizeof(indata));
	memset(setname,0,sizeof(setname));
	for(i=1;i<=X+Y;i++)
		find(parent,i);
	for(i=1;i<=X+Y;i++)
		if(parent[i]==-1)
			setname[k++]=i;
	for(i=0;i<k;i++)
		for(j=indata[2*i]=1;j<=X+Y;j++)
			if(parent[j]==setname[i])
				if(relate[j]==0)
					indata[2*i]++;
				else
					indata[2*i+1]++;
	dp[0][indata[0]]++;path[0][indata[0]]=1;
	dp[0][indata[1]]++;path[0][indata[1]]=2;
	
       for(i=1;i<k;i++)
		for(j=X;j>=0;j--)
		{
			if(j>=indata[2*i] && dp[i-1][j-indata[2*i]] )
				dp[i][j]+=dp[i-1][j-indata[2*i]],path[i][j]=1;
			if(j>=indata[2*i+1] && dp[i-1][j-indata[2*i+1]] )
				dp[i][j]+=dp[i-1][j-indata[2*i+1]],path[i][j]=2;
		}
	if(dp[k-1][X]!=1)
		return 0;
	ans=0;
	m=X;
	i=k-1;
	while(i>=0)
	{
		if(path[i][m]==1)
			t=0,m=m-indata[2*i];
		else
			t=1,m=m-indata[2*i+1];
		for(j=1;j<=X+Y;j++)
			if(parent[j]==setname[i] || j==setname[i])
				if(relate[j]==t)
					dp[0][ans++]=j;		
		i--;
	}
	sort(dp[0],dp[0]+ans);
	return 1;
		
		
}
void swap(int *a,int *b)
{
	int t;
	t=*a;
	*a=*b;
	*b=t;
}
int find(int *parent,int k)
{
	if(parent[k]==-1)
		return k;
	int t=parent[k];
	parent[k]=find(parent,parent[k]);
	relate[k]=(relate[k]+relate[t])%2;
	return parent[k];
}
int main()
{
	int i;
	int e,r,ee,rr,cnt;
	
	
	while(scanf("%d%d%d",&N,&X,&Y))
	{
		if(X==0 && Y==0 && N==0)
			break;
		memset(parent,-1,sizeof(parent));
		memset(relate, 0,sizeof(relate));
		for(i=0;i<N;i++)
		{
			scanf("%d%d%s",&e,&r,str);
			if(r<e)swap(&r,&e);
			ee=find(parent,e);
			rr=find(parent,r);
			if(ee==rr)
				continue;
			if(str[0]=='y')
			{
				parent[rr]=ee,relate[rr]=(relate[e]+relate[r])%2;
			}
			else
				parent[rr]=ee,relate[rr]=(1+relate[r]+relate[e])%2;
		}
		if(X==Y)
		{
			printf("no\n");
			continue;
		}
		if(backpack()==0)
			printf("no\n");
		else
		{
			for(i=0;i<ans;i++)
				printf("%d\n",dp[0][i]);
			printf("end\n");
		}
	} 
  return 0;  
}