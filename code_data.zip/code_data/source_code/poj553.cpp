// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int A[1100],B[1100],NumA[1100],NumB[1100];
int cmp(int a,int b)
{
    return a > b;
}
int main()
{
    int N;
    while(~scanf("%d",&N) && N)
    {
        for(int i = 0; i < N; ++i)
            scanf("%d",&A[i]);
        for(int i = 0; i < N; ++i)
            scanf("%d",&B[i]);
        sort(A,A+N);
        sort(B,B+N,cmp);
        memset(NumA,0,sizeof(NumA));
        memset(NumB,0,sizeof(NumB));
        
        for(int i = 0; i < N; ++i)  
        {
            for(int j = 0; j < N; ++j)  
            {
                if(A[i] > B[j] && !NumA[i] && !NumB[j])
                {
                    NumA[i] = 1;
                    NumB[j] = 1;
                    break;
                }
            }
        }
        
        for(int i = 0; i < N; ++i)
        {
            for(int j = 0; j < N; ++j)
            {
                if(A[i] == B[j] && !NumA[i] && !NumB[j])
                {
                    NumA[i] = 2;
                    NumB[j] = 2;
                    break;
                }
            }
        }
        int ans = 0;
        for(int i = 0; i < N; ++i)
            if(NumA[i] == 1)
                ans += 200;
            else if(NumA[i] == 2)
                continue;
            else
                ans -= 200;
        printf("%d\n",ans);
    }
    return 0;
}