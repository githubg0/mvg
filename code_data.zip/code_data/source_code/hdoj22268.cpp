// Math and Computational Geometry->Greatest Common Divisor (GCD)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[100005],n;
int pre[100005],s[100005];
int gcd(int a,int b)
{
    if(b==0)
        return a;
     else return gcd(b,a%b);
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(int i=0; i<n; i++)
            scanf("%d",&a[i]);
        pre[0]=a[0];
        for(int i=1; i<n; i++)
        {
            pre[i]=gcd(pre[i-1],a[i]);
        }
        s[n-1]=a[n-1];
        for(int i=n-2; i>=0; i--)
        {
            s[i]=gcd(s[i+1],a[i]);
        }
        int ans=max(s[1],pre[n-2]);
        for(int i=1; i<n-1; i++)
        {
            ans=max(ans,gcd(pre[i-1],s[i+1]));
        }
        printf("%d\n",ans);
    }
    return 0;
}