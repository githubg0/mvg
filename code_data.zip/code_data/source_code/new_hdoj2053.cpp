// Basic Algorithm->Memorization,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef struct Node
{
   int x;
   int y;
   int step;
}Node;
int dx[4]={0,1,0,-1};
int dy[4]={1,0,-1,0};
bool visited[202][202];
int dp[202][202];      
char maptt1[202][202];
int m,n;
bool inmap(int x,int y)
{
  return x>=0&&x<m&&y>=0&&y<n;
}
int min(int x,int y)
{
  if(x<y)return x;
  else return y;
}
int minstep=0x7fffffff;
void  bfs(int x,int y)
{
 
 queue<Node>q;
 Node p;
 p.x=x;
 p.y=y;
 p.step=0;
 q.push(p);
 
 while(!q.empty())
 {
	 p=q.front();
	 q.pop();
	 int i;
	 for(i=0;i<4;i++)
	 {
		 Node temp;
		 temp.x=p.x+dx[i];
		 temp.y=p.y+dy[i];
         if(maptt1[temp.x][temp.y]!='#' && inmap(temp.x,temp.y))
		 {
            if(p.step+1<dp[temp.x][temp.y])
			{
				dp[temp.x][temp.y]=p.step+1;
				temp.step=p.step+1;
				if(maptt1[temp.x][temp.y]=='x')
					temp.step++;
			
				if(maptt1[temp.x][temp.y]=='r')
				   	minstep=min(temp.step,minstep);
		
				q.push(temp);
			}
		 }
	 }
 }
}
int main()
{
    while(cin>>m>>n)
	{
		int i,j,c,d;
		for(i=0;i<m;i++)
			for(j=0;j<n;j++)
			{
			   cin>>maptt1[i][j];
			   if(maptt1[i][j]=='a')
			   {
				   c=i;
				   d=j;
			   }
			  dp[i][j]=0x7fffffff;
			}
		
		bfs(c,d);
		if(minstep!=0x7fffffff)
		  cout<<minstep<<endl;
		else
			cout<<"Poor ANGEL has to stay in the prison all his life."<<endl;
		minstep=0x7fffffff;
	}
	return 0;
}