// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 200020
#define lson i*2,l,m
#define rson i*2+1,m+1,r
using namespace std;
int maxv[maxn*4],id[maxn*4];
int h,w,n,m,cnt;
void PushUp(int i)
{
	maxv[i]=max(maxv[i*2],maxv[i*2+1]);
}
void build(int i,int l,int r)
{
	if(l==r)
	{
		maxv[i]=w;
		id[i]=++cnt;
		return ;
	}
	int m=(l+r)/2;
	build(lson);
	build(rson);
	PushUp(i);
}
int update(int wi,int i,int l,int r)
{
	if(wi>maxv[i])
		return -1;
	if(l==r)
	{
		maxv[i]-=wi;
		return id[i];
	}
	int ans=-1;
	int m=(l+r)/2;
	if(maxv[i*2]>=wi)
		ans=update(wi,lson);
	else if(maxv[i*2+1]>=wi)
		ans=update(wi,rson);
	PushUp(i);
	return ans;
}
int main()
{
	while(scanf("%d%d%d",&h,&w,&n)!=EOF)
	{
		cnt=0;
		m=min(h,n);
		build(1,1,m);
		while(n--)
		{
			int wi;
			scanf("%d",&wi);
			printf("%d\n",update(wi,1,1,m));
		}
	}
	return 0;
}