// Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

const int maxn = 50;
const int inf = 0x3f3f3f3f;
using namespace std;
struct note{
    int to, w;
    note(int to1, int w1){
        to = to1, w = w1;
    }
};
vector <note> maps[maxn];
int need[maxn], work[maxn], ans;
void init(){
    for(int i=0; i<=24; i++)
        maps[i].clear();
    for(int i=1; i<=24; i++){
        maps[i-1].push_back(note(i, 0));	
        maps[i].push_back(note(i-1, -work[i]));
        
        if(i>=8)
            maps[i-8].push_back(note(i, need[i]));	
        else
            maps[16+i].push_back(note(i, need[i]-ans)); 
    }
    maps[0].push_back(note(24, ans));	
}
bool spfa(){
    int dis[maxn], cnt[maxn];
    
    bool vis[maxn];
    for(int i=0; i<=24; i++)
        dis[i] = -inf, vis[i] = false, cnt[i] = 1;
    dis[0] = 0, vis[0] = true, cnt[0] = 1;
    queue <int> q;
    q.push(0);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        vis[u] = false;
        for(int i=0, len = maps[u].size(); i<len; i++){
            int v = maps[u][i].to, w = maps[u][i].w;
            if(dis[v] < dis[u] + w){
                dis[v] = dis[u] + w;
                if(!vis[v]){
                    cnt[v]++;
                    if(cnt[v] > 24)
                        return false; 
                    vis[v] = true;
                    q.push(v);
                }
            }
        }
    }
    if(dis[24] == ans)
        return true;
    return false;
}
int main()
{
    int t;
    scanf("%d", &t);
    while(t--){
        for(int i=1; i<=24; i++){
            scanf("%d", &need[i]);
        }
        int n;
        scanf("%d", &n);
        for(int i=1; i<=n; i++){
            int j;
            scanf("%d", &j);
            work[j+1]++;
        }
        for(ans=0; ans<=n; ans++){ 
            init();
            if(spfa()){
                break;
            }
        }
        if(ans > n)
            printf("No Solution\n");
        else
            printf("%d\n", ans);
    }
    return 0;
}