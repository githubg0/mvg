// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int A[100100],B[100100],T[1000100],ha[100100];
int update(int root,int l,int r,int x){
    if(l==r){
        T[root]++;
        return 0;
    }
    int ans=0,mid=(l+r)/2;
    if(x<=mid) ans+=update(root*2,l,mid,x);
    else ans+=T[root*2]+update(root*2+1,mid+1,r,x);
    T[root]=T[root*2]+T[root*2+1];
    return ans;
}
int main(){
    int i,n,x,y;
    while(scanf("%d%d%d",&n,&x,&y)!=EOF){
        memset(T,0,sizeof(T));
        for(i=1;i<=n;i++){
            scanf("%d",&A[i]);
            B[i]=A[i];
        }
        sort(B+1,B+1+n);
        int k=0;
        ha[k++]=B[1];
        for(i=2;i<=n;i++){
            if(B[i]!=B[i-1]) ha[k++]=B[i];
        }
        long long sum=0;
        for(i=n;i>=1;i--){
                int a=lower_bound(ha,ha+k,A[i])-ha;
                sum+=update(1,0,100005,a);
        }
        if(x>y) printf("%lld\n",sum*y);
        else printf("%lld\n",sum*x);
    }
    return 0;
}