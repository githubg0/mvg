// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1000050;
const int INF = 0x3f3f3f3f;
int n,k;
int num[maxn];
struct elem
{
	int k,num;
}que[maxn];
int l,r;
void getmin()
{
	memset(que,0,sizeof que);
	que[0].k=-INF;
	l=1,r=1;
	for(int i=1;i<=k;i++)
    {
		while(que[r].k>=num[i] && r>=l)
            r--;
		que[++r].k=num[i];
		que[r].num=i;
    }
	for(int i=k;i<=n;i++)
	{
        while(que[r].k>=num[i] && r>=l)
            r--; 
        que[++r].k=num[i];
		que[r].num=i;
        while(que[l].num<=i-k)
            l++;  
        printf("%d ",que[l].k);
    }
}
void getmax()
{
	memset(que,0,sizeof que);
	que[0].k=INF;
	l=1,r=1;
	for(int i=1;i<=k;i++)
    {
		while(que[r].k<=num[i] && r>=l)
            r--;
		que[++r].k=num[i];
		que[r].num=i;
    }
	for(int i=k;i<=n;i++)
	{
        while(que[r].k<=num[i] && r>=l)
            r--;
        que[++r].k=num[i];
		que[r].num=i;
        while(que[l].num<=i-k)
            l++;
        printf("%d ",que[l].k);
    }
}
int main()
{
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",num+i);
	getmin();
	printf("\n");
	getmax();
    return 0;
}