// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define N 10005
int T,n;
int a[N],b[N],c[N];
double G(double x)
{
	int i;
	double Max,t ;
	Max=a[1]*x*x+b[1]*x+c[1];
	for(i=2;i<=n;i++){
		t=a[i]*x*x+b[i]*x+c[i];
		if(Max<t) 
			Max=t;
	}
	return Max;
}
int main(){
	int i;
	double l,r,mid1,mid2,ans1,ans2;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(i = 1; i <= n; ++i)
			scanf("%d %d %d",&a[i],&b[i],&c[i]);
		l=0.0,r=1000.0 ;
		do{
			mid1=(r+l)/2;
			mid2=(mid1+r)/2;
			ans1=G(mid1);
			ans2=G(mid2);
			if(ans1>ans2) 
				l=mid1;
			else 
				r=mid2;
		}while(fabs(ans1-ans2)>1e-8);
		printf("%0.4f\n",ans1) ;
	}
	return 0;
}