// Basic Algorithm->Recurrence
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=10;
int n,mod;
int temp[N][N];
int res[N][N],a[N][N];
void mul(int a[][N],int b[][N])
{
    memset(temp,0,sizeof(temp));
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            for(int k=0;k<N;k++)
                temp[i][j]=(temp[i][j]+a[i][k]*b[k][j]%mod)%mod;
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            a[i][j]=temp[i][j];
    return ;
}
void fun(int nn)
{
    memset(res,0,sizeof(res));
    for(int i=0;i<N;i++)
        res[i][i]=1;
    while(nn){
        if(nn&1)
            mul(res,a);
        mul(a,a);
        nn>>=1;
    }
    return ;
}
int main()
{
    while(~scanf("%d %d",&n,&mod)){
        memset(a,0,sizeof(a));
        for(int i=0;i<N;i++)
            scanf("%d",&a[0][i]);
        for(int i=1;i<N;i++)
            a[i][i-1]=1;
        if(n<10) printf("%d\n",n%mod);
        else {
            fun(n-9);
            int ans=0;
            for(int i=0;i<N;i++)
                ans+=res[0][i]*(9-i)%mod;
            printf("%d\n",ans%mod);
        }
    }
    return 0;
}