// Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 22000
using namespace std;
inline int min1(int x,int y){
    return x<y?x:y;
}
inline int read(){
    int x=0;char ch=getchar();
    while (ch<'0'||ch>'9') ch=getchar();
    while (ch<='9'&&ch>='0'){
        x=x*10+ch-'0';ch=getchar();
    }
    return x;
}
map<int,int> mm;
int a[N],a1[N],k,n,k1,rank0[N<<1],rank1[N],st[N],count1[N],tmp[N],sa[N],height[N],fmin1[N][200];
inline int query(int l,int r){
    int k=0;while ((1<<(k+1))<=(r-l+1))++k;
    return min(fmin1[l][k],fmin1[r-(1<<k)+1][k]);
}
bool check(int len){
    int l=2,r=l+k;
    while (r<=n){
        int tmp=query(l,r);
        if (tmp>=len) return true;
        ++l;++r;
    }
    return false;
}
inline bool judge(int len){
    int tmp=0;
    for (int i=1;i<=n;++i){
        if (height[i]>=len) {
            if (++tmp==k1-1) return true;
        }else tmp=0;
    }
    if (tmp>=k1-1)return true;else return false;
}
int main(){
    
    
    n=read();k1=read();
    for (int i=1;i<=n;++i) a[i]=read(),a1[i]=a[i];
    sort(a1+1,a1+n+1);
    for (int i=n;i>=1;--i) mm[a1[i]]=i;
    for (int i=1;i<=n;++i) a[i]=mm[a[i]]; 
    
    memset(rank0,0,sizeof(rank0));
    memset(rank1,0,sizeof(rank1));
    memset(st,0,sizeof(st));
    for (int i=1;i<=n;++i) st[a[i]]=1;
    for (int i=1;i<=n;++i) st[i]+=st[i-1];
    for (int i=1;i<=n;++i) rank0[i]=st[a[i]];
    k=0;
    for (int p=1;k!=n;p<<=1){
        memset(count1,0,sizeof(count1));
        for (int i=1;i<=n;++i) count1[rank0[i+p]]++;
        for (int i=1;i<=n;++i) count1[i]+=count1[i-1];
        for (int i=n;i>=1;--i) tmp[count1[rank0[i+p]]--]=i;
        memset(count1,0,sizeof(count1));
        for (int i=1;i<=n;++i) count1[rank0[i]]++;
        for (int i=1;i<=n;++i) count1[i]+=count1[i-1];
        for (int i=n;i>=1;--i) sa[count1[rank0[tmp[i]]]--]=tmp[i];
        memcpy(rank1,rank0,sizeof(rank0)>>1);
        rank0[sa[1]]=k=1;
        for (int i=2;i<=n;++i){
            if(rank1[sa[i-1]]!=rank1[sa[i]]||rank1[sa[i]+p]!=rank1[sa[i-1]+p]) ++k;
            rank0[sa[i]]=k;
        } 
    }
    k=0;
    for (int i=1;i<=n;++i){
        if (rank0[i]==1) {
            height[1]=0;continue;
        }
        k=k==0?0:k-1;
        while (a[i+k]==a[sa[rank0[i]-1]+k]) ++k;
        height[rank0[i]]=k;
    }
    
    for (int i=1;i<=n;++i) fmin1[i][0]=height[i];
    for (int i=1;(1<<i)<=n-1;++i){
        for (int j=2;j+(1<<i)-1<=n;++j){
            fmin1[j][i]=min1(fmin1[j][i-1],fmin1[j+(1<<(i-1))][i-1]);
        }
    }
    int l=1,r=n,ans=0;
    while (l<r){
        int mid=(l+r)>>1;
        if (judge(mid)) ans=mid,l=mid+1;else r=mid;
    }
    printf("%d",ans);
    return 0;
}