// Math and Computational Geometry->Basis of Linear Space
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
using namespace std;
const int N = 1e3+10; 
struct node
{
	ll nu,ma;
	node(){}
	node(ll nu,ll ma):nu(nu),ma(ma){}
}a[N];
ll base[70];
bool cmp(const node& a,const node& b)
{
	return a.ma>b.ma;
}
bool insert(ll x)
{
	for(int i=62;i>=0;i--)
	{
		if(x&(1LL<<i))
		{
			if(!base[i])
			{
				base[i]=x;
				break;
			}
			x^=base[i];
		}
	}
	return x>0;
	
}
int main(void)
{
	int n;
	ll ans;
	while(~scanf("%d",&n))
	{
		ans=0;
		for(int i=62;i>=0;i--) base[i]=0;
		for(int i=1;i<=n;i++)
			scanf("%lld%lld",&a[i].nu,&a[i].ma);
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++)
			if(insert(a[i].nu)) ans+=a[i].ma;
		printf("%lld\n",ans);
	
	}
	return 0;
}