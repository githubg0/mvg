// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define min(a,b) (a<b?a:b)
#define MAXN 1010
int maptt1[MAXN][MAXN];
bool vis[MAXN];
int d[MAXN];
int n;    
int dijkstra(){
    int i,j,k,temp;
    memset(vis,0,sizeof(vis));
    for(i=1;i<=n;i++)
        d[i] = maptt1[1][i];
    for(i=1;i<=n;i++){
        temp = -1;
        k = 0;
        for(j=1;j<=n;j++){
            if(!vis[j]&&d[j]>temp){
                temp = d[j];
                k = j;
            }
        }
        vis[k] = 1;
        for(j=1;j<=n;j++){
            if(!vis[j]&&d[j]<min(d[k],maptt1[k][j])){
                d[j] = min(d[k],maptt1[k][j]);
            }
        }
    }
    return d[n];
}
int main(){
    int plans;
    cin>>plans;
    int m,i,j;
    int v1,v2,v3;
    int index = 1;
    while(plans--){
        cin>>n>>m;
        for(i=0;i<=n;i++)
            for(j=0;j<=n;j++)
                maptt1[i][j] = 0;
        for(i=1;i<=m;i++){
            cin>>v1>>v2>>v3;
            maptt1[v1][v2] = maptt1[v2][v1] = v3;
        }
        cout<<"Scenario #"<<index++<<":"<<endl;
        cout<<dijkstra()<<endl;
        cout<<endl;
    }
    return 0;
}