// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M 1010
const int inf=1<<30;
struct point
{
    int p,j;
} a[M];
int n;
string s;
int vis[M];
int cmp(point a,point b)
{
    return a.p>b.p||(a.p==b.p&&a.j<b.j);
}
int main()
{
    freopen("in.txt","r",stdin);
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n>>s;
        for(int i=0;i<n;i++)
            cin>>a[i].p>>a[i].j;
        sort(a,a+n,cmp);
        if(s[0]=='J')
            for(int i=0;i<n;i++)
                vis[i]=i%2==0?1:0;
        else
            for(int i=0;i<n;i++)
                vis[i]=i%2==0?0:1;
        for(int i=n-1;i>=0;i--) if(vis[i])
        {
            int tmp=i;
            vis[i]=0;
            for(int j=i+1;j<n;j++)
            {
                if(!vis[j]&&a[j].j>=a[tmp].j)
                    tmp=j;
            }
            vis[tmp]=1;
        }
        int x=0,y=0;
        for(int i=0;i<n;i++)
            if(vis[i]) y+=a[i].j;
            else x+=a[i].p;
        cout<<x<<" "<<y<<endl;
    }
    return 0;
}