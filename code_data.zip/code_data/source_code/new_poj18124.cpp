// Graph Algorithm->Bellman-Ford Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment (linker,"/STACK:102400000,102400000")
#define maxn 550
#define MAXN 2005
#define mod 1000000009
#define INF 0x3f3f3f3f
#define pi acos(-1.0)
#define eps 1e-6
#define lson rt<<1,l,mid
#define rson rt<<1|1,mid+1,r
#define FRE(i,a,b)  for(i = a; i <= b; i++)
#define FREE(i,a,b) for(i = a; i >= b; i--)
#define FRL(i,a,b)  for(i = a; i < b; i++)
#define FRLL(i,a,b) for(i = a; i > b; i--)
#define mem(t, v)   memset ((t) , v, sizeof(t))
#define sf(n)       scanf("%d", &n)
#define sff(a,b)    scanf("%d %d", &a, &b)
#define sfff(a,b,c) scanf("%d %d %d", &a, &b, &c)
#define pf          printf
#define DBG         pf("Hi\n")
typedef long long ll;
using namespace std;
struct Edge
{
    int u,v,w;
}edge[maxn*10];
int n,m,w,num;
int dist[maxn];
bool Bellman_Ford()
{
    int i,j;
    FRL(i,0,n+2)
        dist[i]=INF;
    dist[1]=0;
    FRL(i,1,n)
    {
        bool flag=false;
        FRL(j,0,num)
        {
            int u=edge[j].u;
            int v=edge[j].v;
            if (dist[v]>dist[u]+edge[j].w)
            {
                flag=true;
                dist[v]=dist[u]+edge[j].w;
            }
        }
        if (!flag) return true;
    }
    FRL(i,0,num)
        if (dist[ edge[i].v ]>dist[ edge[i].u ]+edge[i].w)
            return false;
    return true;
}
int main()
{
    int i,j,cas;
    sf(cas);
    while (cas--)
    {
        num=0;
        int u,v,t;
        sfff(n,m,w);
        FRL(i,0,m)
        {
            sfff(u,v,t);
            edge[num].u=u;
            edge[num].v=v;
            edge[num].w=t;
            num++;
            edge[num].u=v;
            edge[num].v=u;
            edge[num].w=t;
            num++;
        }
        FRL(i,0,w)
        {
            sfff(u,v,t);
            edge[num].u=u;
            edge[num].v=v;
            edge[num].w=-t;
            num++;
        }
        if (Bellman_Ford())
            pf("NO\n");
        else
            pf("YES\n");
    }
    return 0;
}