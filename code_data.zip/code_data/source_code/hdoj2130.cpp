// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 55;
const int dir[6][3] = {{0, 0, 1}, {0, 0, -1}, {-1, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, -1, 0}};
struct node
{
	int x, y, z;
	int ceng;
}que[50000];
int maze[N][N][N];
int a, b, c, t;
int num;
int head, tail;
int Scan()
{
	int res = 0 , ch;
	while( !( ( ch = getchar() ) >= '0' && ch <= '9' ) )
	{
		if( ch == EOF )  return 1 << 30 ;
	}
	res = ch - '0' ;
	while( ( ch = getchar() ) >= '0' && ch <= '9' )
		res = res * 10 + ( ch - '0' ) ;
	return res ;
}
int BFS()
{
	node cur;
	cur.x = 1, cur.y = 1, cur.z = 1, cur.ceng = 0;
	maze[cur.x][cur.y][cur.z] = 0;
	que[tail++] = cur;
	while(head < tail)
	{
		node temp = que[head++];
		if(temp.ceng > t) 
			return -1;
		if(temp.x == a && temp.y == b && temp.z == c && temp.ceng <= t)
			return temp.ceng;
		for(int i = 0; i < 6; ++i)
		{
			node now;
			now.x = temp.x + dir[i][0]; now.y = temp.y + dir[i][1]; now.z = temp.z + dir[i][2];
			if(maze[now.x][now.y][now.z])
			{
				now.ceng = temp.ceng + 1;
				que[tail++] = now;
				maze[now.x][now.y][now.z] = 0;
			}
		}
	}
	return -1;
}
int main()
{
	int ncase;
	ncase = Scan();
	while(ncase--)
	{
		num = head = tail = 0;
		memset(maze, 0, sizeof(maze));
		a = Scan(), b = Scan(), c = Scan(), t = Scan();
		for(int i = 1; i <= a; ++i)
			for(int j = 1; j <= b; ++j)
				for(int k = 1; k <= c; ++k)
				{
					maze[i][j][k] = Scan() ^ 1;
					num += maze[i][j][k];
				}
		if(maze[a][b][c] == 0 || num < a + b + c - 3) 
		{
			printf("-1\n");
			continue;
		}
		printf("%d\n", BFS());
	}
	return 0;
}