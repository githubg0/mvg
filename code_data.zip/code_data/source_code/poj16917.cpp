// Basic Algorithm->Arbitrary-Precision Arithmetic
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 1003
#define LL long long
using namespace std;
int f[N][N],n,c[N];
void calc(int x,int y,int z)
{
	for (int i=0;i<=f[y][0];i++)
	 f[x][i]=f[y][i];
	memset(c,0,sizeof(c));
	for (int i=1;i<=f[z][0];i++)
	 c[i]=f[z][i]*2;
	int t=f[z][0];
	for (int i=1;i<=t;i++)
	 c[i+1]+=c[i]/10,c[i]%=10;
	while (c[t+1]) {
		t++;
		c[t+1]+=c[t]/10;
		c[t]%=10;
	}
	c[0]=t;
	for (int i=1;i<=max(t,f[x][0]);i++) f[x][i]+=c[i];
    f[x][0]=max(t,f[x][0]);
    for (int i=1;i<=f[x][0];i++) f[x][i+1]+=f[x][i]/10,f[x][i]%=10;
    while (f[x][f[x][0]+1]){
    	f[x][0]++;  
    	f[x][f[x][0]+1]+=f[x][f[x][0]]/10;
    	f[x][f[x][0]]%=10;
	}
}
int main()
{
  f[1][1]=0; f[1][0]=1;
  f[2][1]=1; f[2][0]=1;
  for (int i=3;i<=1000;i++) {
  	calc(i,i-1,i-2);
  }
  while (scanf("%d",&n)!=EOF){
  	 for (int i=f[n][0];i>=1;i--)
  	  printf("%d",f[n][i]);
  	 printf("\n");
  }
}