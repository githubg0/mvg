// Data Structure->Binary Indexed Tree (BIT)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define lowbit(x) x&(-x)
using namespace std;
const int M=200500;
const int h=32050;
int n;
int s[M],ans[M]; 
inline int read()
{
	int x=0;char ch=getchar();
	while (ch>'9'||ch<'0') ch=getchar();
	while (ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x;
}
inline void add(int p,int x)
{
	for (int i=p;i<=h;i+=lowbit(i)) s[i]+=x;
	return ;
}
inline int query(int p)
{
	int ans=0;
	for (int i=p;i>0;i-=lowbit(i)) ans+=s[i];
	return ans;
}
signed main()
{
	while (~scanf("%d",&n))
	{
		for (int i=1;i<=n;i++)
		{
			int x=read(),y=read();
			add(++x,1);ans[query(x)]++;
		}
		for (int i=1;i<=n;i++) printf("%d\n",ans[i]);
	}
	return 0;
}