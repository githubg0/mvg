// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL __int64_t
#define pi acos(-1.0)
const int mod=1e9+7;
const int INF=0x3f3f3f3f;
const double eqs=1e-8;
const int MAXN=40000+10;
int n, m;
double d[2000], a[2000], b[2000];
bool check(double L)
{
        for(int i=0;i<n;i++){
                d[i]=a[i]-L*b[i];
        }
        sort(d,d+n);
        double tmp=0;
        for(int i=m;i<n;i++){
                tmp+=d[i];
        }
        return tmp>=0;
}
int main()
{
        int i;
        while(scanf("%d%d",&n,&m)!=EOF&&n+m){
                for(i=0;i<n;i++){
                        scanf("%lf",&a[i]);
                }
                for(i=0;i<n;i++){
                        scanf("%lf",&b[i]);
                }
                double low=0.0, high=1.0, mid;
                while(high-low>eqs){
                        mid=(low+high)/2;
                        if(check(mid)){
                                low=mid;
                        }
                        else high=mid;
                }
                printf("%.0f\n",low*100);
        }
        return 0;
}