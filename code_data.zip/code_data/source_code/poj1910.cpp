// Dynamic Programming->Dynamic Programming (DP) on Intervals
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INT_MIN     (-2147483647 - 1) 
#define INT_MAX       2147483647
vector<int>ans;
int high;
int n;
char e[60];
int v[60];
int opt_max[60][60];
int opt_min[60][60];
void dp(int i,int j)
{
	if(i==j)
	{
		opt_max[i][j]=v[i];
		opt_min[i][j]=v[i];
		return;
	}
	for(int k=i;k!=j;k=(k+1)%n)
	{
		if(opt_max[i][k]==INT_MIN)
		{
			dp(i,k);
		}
		if(opt_max[(k+1)%n][j]==INT_MIN)
		{
			dp((k+1)%n,j);
		}
		if(e[(k+1)%n]=='t')
		{
			opt_max[i][j]=max(opt_max[i][j],opt_max[i][k]+opt_max[(k+1)%n][j]);
			opt_min[i][j]=min(opt_min[i][j],opt_min[i][k]+opt_min[(k+1)%n][j]);
		}
		if(e[(k+1)%n]=='x')
		{
			opt_max[i][j]=max(opt_max[i][j],opt_max[i][k]*opt_max[(k+1)%n][j]);
			opt_max[i][j]=max(opt_max[i][j],opt_min[i][k]*opt_min[(k+1)%n][j]);
			opt_max[i][j]=max(opt_max[i][j],opt_max[i][k]*opt_min[(k+1)%n][j]);
			opt_max[i][j]=max(opt_max[i][j],opt_min[i][k]*opt_max[(k+1)%n][j]);
			opt_min[i][j]=min(opt_min[i][j],opt_max[i][k]*opt_max[(k+1)%n][j]);
			opt_min[i][j]=min(opt_min[i][j],opt_min[i][k]*opt_min[(k+1)%n][j]);
			opt_min[i][j]=min(opt_min[i][j],opt_max[i][k]*opt_min[(k+1)%n][j]);
			opt_min[i][j]=min(opt_min[i][j],opt_min[i][k]*opt_max[(k+1)%n][j]);
		}
	}
}
int main()
{
	
	while(~scanf("%d",&n))
	{
		getchar();
		high=INT_MIN;
		ans.clear();
		for(int i=0;i<n;i++)
		{
			cin>>e[i];
			scanf("%d",&v[i]);
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				opt_max[i][j]=INT_MIN;
				opt_min[i][j]=INT_MAX;
			}
		}
		for(int i=0;i<n;i++)
		{
			if(opt_max[i][(i-1+n)%n]==INT_MIN)
			{
				dp(i,(i-1+n)%n);
			}
			if(high==INT_MIN)
			{
				ans.push_back(i+1);
				high=opt_max[i][(i-1+n)%n];
				continue;
			}
			if(opt_max[i][(i-1+n)%n]==high)
			{
				ans.push_back(i+1);
				continue;
			}
			if(opt_max[i][(i-1+n)%n]>high)
			{
				ans.clear();
				ans.push_back(i+1);
				high=opt_max[i][(i-1+n)%n];
			}
		}
		printf("%d\n",high);
		for(int i=0;i<ans.size()-1;i++)
		{
			printf("%d ",ans[i]);
		}
		printf("%d\n",ans.back());
	}
	return 0;
}