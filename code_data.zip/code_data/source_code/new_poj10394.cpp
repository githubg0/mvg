// Graph Algorithm->Floyd-Warshall Algorithm,Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Dinic's Algorithm,Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
using namespace std;
const int maxv = 300;
const int maxe = 91000;
int K, C, M, n, src, dst;
int mmap[maxv][maxv];
struct Edge {
    int from, to, cap, next;
} edge[maxe];
int cnt, head[maxv];
void edgeinit() {
    cnt = 0;
    memset(head, -1, sizeof head);
}
void addedge(int from, int to, int cap) {
    edge[cnt].from = from;
    edge[cnt].to = to;
    edge[cnt].cap = cap;
    edge[cnt].next = head[from];
    head[from] = cnt++;
    ;
    edge[cnt].from = to;
    edge[cnt].to = from;
    edge[cnt].cap = 0;
    edge[cnt].next = head[to];
    head[to] = cnt++;
}
class Dinic {
private:
    int s, t, n, depth[maxv], cur[maxe]; 
public:
    void init(int _s, int _t) {
        s = _s, t = _t;
    }
    int Dfs(int u, int dist) {
        if (u == t)
            return dist;
        for (int& i = cur[u]; i != -1; i = edge[i].next) {
            if (depth[edge[i].to] == depth[u] + 1 && edge[i].cap != 0) {
                int delta = Dfs(edge[i].to, min(dist, edge[i].cap));
                if (delta > 0) {
                    edge[i].cap -= delta;
                    edge[i ^ 1].cap += delta;
                    return delta;
                }
            }
        }
        return false;
    }
    int Bfs() {
        queue<int> Q;
        memset(depth, 0, sizeof depth);
        depth[s] = 1;
        Q.push(s);
        while (!Q.empty()) {
            int u = Q.front();
            Q.pop();
            for (int i = head[u]; i != -1; i = edge[i].next) {
                if (edge[i].cap > 0 && depth[edge[i].to] == 0) {
                    depth[edge[i].to] = depth[u] + 1;
                    Q.push(edge[i].to);
                }
            }
        }
        if (depth[t] > 0)
            return true;
        return false;
    }
    int maxFlow() {
        int ans = 0;
        while (Bfs()) {
            for (int i = 0; i < cnt; i++)
                cur[i] = head[i];
            while (int delta = Dfs(s, INF))
                ans += delta;
        }
        return ans;
    }
} DC;
void init() {
    src = 0; 
    dst = K + C + 1; 
    n = K + C;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            mmap[i][j] = (i == j ? 0 : INF);
}
void Floyd() {
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                mmap[i][j] = min(mmap[i][j], mmap[i][k] + mmap[j][k]);
}
bool solve2(int limit) {
    edgeinit();
    DC.init(src, dst);
    for (int i = 1; i <= C; i++)
        addedge(src, K + i, 1);
    for (int i = 1; i <= K; i++)
        addedge(i, dst, M);
    for (int i = 1; i <= C; i++)
        for (int j = 1; j <= K; j++)
            if (mmap[i + K][j] <= limit)
                addedge(i + K, j, 1);
    return DC.maxFlow() == C;
}
void solve() {
    int l = 0, r = 0;
    for (int i = 1; i <= n; i++)
        for (int j = i + 1; j <= n; j++)
            if (mmap[i][j] < INF)
                r = max(r, mmap[i][j]);
    while (l < r) {
        int m = l + (r - l) / 2;
        if (solve2(m))
            r = m;
        else
            l = m + 1;
    }
    cout << r << endl;
}
int main(void) {
    while (cin >> K >> C >> M) {
        init();
        int temp;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                cin >> temp, mmap[i][j] = (i != j && temp == 0 ? INF : temp);
        Floyd();
        solve();
    }
    return 0;
}