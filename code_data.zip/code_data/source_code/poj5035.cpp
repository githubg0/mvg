// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int p,q,maptt1[9][9],use[9][9],ansx[9*9],ansy[9*9],ans,movex[8]={-1,1,-2,2,-2,2,-1,1},movey[8]={-2,-2,-1,-1,1,1,2,2};
bool isborder(int x,int y)
{
    if(x>0&&x<=p&&y>0&&y<=q)
	return false;
    return true;
}
bool DFS(int x,int y,int res)
{
    if(!res)
    {
	return true;
    }
    for(int i=0;i<8;i++)
    {
	int itx=x+movex[i];
	int ity=y+movey[i];
	if(isborder(itx,ity)||use[itx][ity])
	    continue;
	use[itx][ity]=1;
	if(DFS(itx,ity,res-1))
	{
	    ansx[ans]=itx;
	    ansy[ans++]=ity;
	    return true;
	}
	use[itx][ity]=0;
    }
    return false;
}
int main()
{
    int cas,cass=1;
    scanf("%d",&cas);
    while(cas--)
    {
	ans=0;
	scanf("%d%d",&p,&q);
	int flag=0;
	for(int i=1;i<=p;i++)
	{
	    for(int j=1;j<=q;j++)
	    {
		memset(use,0,sizeof(use));
		use[i][j]=1;
		if(DFS(i,j,p*q-1))
		{
		    ansx[ans]=i;
		    ansy[ans++]=j;
		    flag=1;
		    break;
		}
	    }
	    if(flag)
		break;
	}
	printf("Scenario #%d:\n",cass++);
	if(!flag)
	    printf("impossible\n");
	else
	{
	    for(int i=ans-1;i>=0;i--)
		printf("%c%d",ansy[i]+'A'-1,ansx[i]);
	    printf("\n");
	}
	printf("\n");
    }
    return 0;
}