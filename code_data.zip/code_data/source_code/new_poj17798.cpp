// Data Structure->Segment Tree
#include <iostream>    
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
    
    
    
    
    
    
     
    
    
    
  
  
    
#define ll long long
using namespace std;  
struct node{
	int l; int r;
	bool val;
	bool flag;
	bool inv;
};
node tree[540000];
void build_tree(int n,int l,int r){
	tree[n].l=l; tree[n].r=r;
	tree[n].val=0; tree[n].flag=1; tree[n].inv=0;
	if(l==r)return;
	int mid=(l+r)/2;
	build_tree(n*2,l,mid);
	build_tree(n*2+1,mid+1,r);
}
void update(int n,int l,int r,int type ){
	if(tree[n].l==l&&tree[n].r==r){
		if(type==1){
			tree[n].val=1;
			tree[n].inv=0;tree[n].flag=1;
		}
		if(type==0){
			tree[n].val=0;
			tree[n].inv=0;tree[n].flag=1;
		}
		if(type==2)tree[n].inv^=1;
		return;
	}
	if(tree[n].l==tree[n].r)return;
	int mid=(tree[n].l+tree[n].r)/2;
	if(tree[n].flag){
		update(n*2,tree[n].l,mid,tree[n].val);
		update(n*2+1,mid+1,tree[n].r,tree[n].val);
		tree[n].flag=0;
	}
	if(tree[n].inv){
		tree[n*2].inv^=tree[n].inv;
		tree[n*2+1].inv^=tree[n].inv; 
		tree[n].inv=0;
	}
	
	if(r<=mid){
		update(n*2,l,r,type);
	}else{
		if(l<=mid){
			update(n*2,l,mid,type);
			update(n*2+1,mid+1,r,type);
		}else{
			update(n*2+1,l,r,type);
		}
	}
}
bool query(int n,int pos){
	if(tree[n].flag){
		if(tree[n].inv)return !tree[n].val;
		return tree[n].val;
	}
	int mid=(tree[n].l+tree[n].r)/2;
	if(pos<=mid){
		return tree[n].inv^query(n*2,pos);
	}else{
		return tree[n].inv^query(n*2+1,pos);
	}
}
bool output(){
	bool s=query(1,0);
	bool fir=1;
	if(s){
		fir=0;
		printf("[0,");
	}
	
	for(int i=1;i<=132000;i++){
		if(query(1,i)!=s){
			if(s){
				printf("%d",i/2);
				if(i%2){
					printf("]");
				}else{
					printf(")");
				}
			}else{
				if(!fir)printf(" ");
				fir=0;
				if(i%2){
					printf("(");
				}else{
					printf("[");
				}
				printf("%d,",i/2);
			}
			s=!s;
		}
	}
	if(fir)return 0;
	printf("\n");
	return 1;
}
int main(){
	char oper,c;
	build_tree(1,0,132000);
	while(~scanf("%c ",&oper)){
		char lb,rb;
		int ln,rn;
		scanf("%c%d%c%d%c%c",&lb,&ln,&c,&rn,&rb,&c);
		ln=ln*2; if(lb=='(')ln++;
		rn=rn*2; if(rb==')')rn--;
		if(ln>rn)continue;
		if(oper=='U'){
			update(1,ln,rn,1);
		}else if(oper=='I'){
			update(1,0,ln-1,0);
			update(1,rn+1,132000,0);
		}else if(oper=='D'){
			update(1,ln,rn,0);
		}else if(oper=='C'){
			update(1,0,ln-1,0);
			update(1,rn+1,132000,0);
			update(1,ln,rn,2);
		}else if(oper=='S'){
			update(1,ln,rn,2);
		}	
	}
	if(!output()){
		printf("empty set\n");
	}
	return 0;
}