// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=25;
int n,p,t;
int ans;
int cap[8],vis[N];
struct order{
    int sta,des,num;
    bool operator <(const order &pos) const{
    if(sta!=pos.sta) return sta<pos.sta;
    else return des<pos.des;
    }
}orders[N];
void search(int cur)
{
    if(cur==t)
    {
        int sum=0;
        for(int i=0;i<=p;i++)
        sum+=cap[i];
        ans=max(ans,sum);
        return;
    }
    int flag=1;
    for(int j=orders[cur].sta;j<orders[cur].des;j++)
    {
        if(cap[j]+orders[cur].num>n)
        {
        flag=0;
        break;  
        }
    }
    if(flag==1)
    {
    for(int i=orders[cur].sta;i<orders[cur].des;i++)
    cap[i]+=orders[cur].num;
    search(cur+1);
    for(int i=orders[cur].sta;i<orders[cur].des;i++)
    cap[i]-=orders[cur].num;    
    }
    search(cur+1);
}
int main()
{
    while(scanf("%d%d%d",&n,&p,&t)!=EOF&&(n||p||t))
    {
        ans=0;
        memset(cap,0,sizeof(cap));
        for(int i=0;i<t;i++)
        scanf("%d%d%d",&orders[i].sta,&orders[i].des,&orders[i].num);
        sort(orders,orders+t);
        search(0);
        printf("%d\n",ans)
        ;
    }
    return 0;
}