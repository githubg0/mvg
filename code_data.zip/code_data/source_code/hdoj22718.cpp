// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX = 1e5+100;
const int N = 5e6+100;
int n,m;
int a[MAX];
int root[MAX],nxt[N][3];
int tot;
int newnode()
{
    memset(nxt[tot],-1,sizeof*nxt[tot]);
    return tot++;
}
void add(int u,int fa,int x)
{
    int now1=root[u];
    int now2=root[fa];
    for(int i=31;i>=0;i--)
    {
        
        int d=((x>>i)&1);
        nxt[now1][d]=newnode();
        nxt[now1][!d]=nxt[now2][!d];
        now1=nxt[now1][d];
        now2=nxt[now2][d];
    }
}
int query(int l,int r,int x)
{
    int ans=0;
    int now1=root[r];
    int now2=root[l];
    for(int i=31;i>=0;i--)
    {
        int d=((x>>i)&1);
        
        if(nxt[now1][!d]>nxt[now2][!d])
        {
            
            ans+=(1<<i);
            d=!d;
        }
        now1=nxt[now1][d];
        now2=nxt[now2][d];
    }
    ans=max(ans,x^a[l]);
    return ans;
}
int main()
{
    tot=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        root[i]=newnode();
        add(i,i-1,a[i]);
    }
    scanf("%d",&m);
    for(int i=0;i<m;i++)
    {
        int b,l,r;
        scanf("%d%d%d",&b,&l,&r);
        int ans=query(l,r,b);
        printf("%d\n",ans);
    }
    return 0;
}