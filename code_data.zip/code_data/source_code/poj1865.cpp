// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int row,col;
queue<int> q;
char s[104][104];
int visit[105][105];
int d1[]={-1,1,0,0,-1,-1,1,1},
    d2[]={0,0,-1,1,-1,1,-1,1};
int r1,c1,r2,c2;
struct spe
{
    char ch;
    char s[105][105];
};
struct spe2
{
    vector<spe> v;
};
spe2 p[104][104];
char ch = 'a',previ;
void dfs(int r,int c,char ch)
{
    q.push(r);
    q.push(c);
    s[r][c] = ch;
    visit[r][c] = 1;
    int rr,cc;
    r1 = min(r1,r);
    c1 = min(c1,c);
    r2 = max(r2,r);
    c2 = max(c2,c);
    for( int i = 0 ; i < 8 ; i++ )
    {
        rr = r+d1[i];
        cc = c+d2[i];
        if( visit[rr][cc] == 0 && s[rr][cc] == '1' )
            dfs(rr,cc,ch);
    }
}
bool judge( int h,int w )
{
    char ss[104][104];
    for( int i = r1 ; i <= r2 ; i++ )
        for( int j = c1 ; j <= c2 ; j++ )
            ss[i][j] = '0';
    int x,y;
    while( !q.empty() )
    {
        x = q.front();  q.pop();
        y = q.front();  q.pop();
        ss[x][y] = '1';
    }
    spe temp;
    temp.ch = ch;
    if( h <= w )
    {
        for( int i = 1 ,rr = r1; i <= h ; i++,rr++ )
        {
            for( int j = 1,cc = c1 ; j <= w ; j++,cc++ )
                temp.s[i][j] = ss[rr][cc];
            temp.s[i][w+1] ='\0';
        }
    }
    else
    {
        swap(h,w);
        for( int i = 1,cc = c1 ; i <= h ; i++,cc++ )
        {
            for( int j = 1,rr = r1 ; j <= w ; j++,rr++  )
                temp.s[i][j] = ss[rr][cc];
            temp.s[i][w+1] = '\0';
        }
    }
    if( p[h][w].v.size() == 0 )
    {
        if( h == w )
        {
            spe temp2;
            for( int i = 1 ; i <= h ; i++  )
                for( int j = 1 ; j <= w ; j++ )
                    temp2.s[i][j] = temp.s[j][i];
            temp2.ch = temp.ch;
            p[h][w].v.push_back(temp2);
        }
        p[h][w].v.push_back(temp);
        return true;
    }
    int len = p[h][w].v.size();
    for( int k = 0 ; k < len ; k++ )
    {
        previ = p[h][w].v[k].ch;
        bool flag = true;
        for( int i = 1 ; i <= h ; i++ )
            for( int j = 1 ; j <= w ; j++ )
                if( temp.s[i][j] != p[h][w].v[k].s[i][j] )
                {
                    flag = false;
                    goto first;
                }
        first:
            if( flag )
                return false;
        flag = true;
        for( int i = 1,rr = h ; i <= h ; i++,rr-- )
            for( int j = 1,cc = 1 ; j <= w ; j++,cc++ )
                if( temp.s[rr][cc] != p[h][w].v[k].s[i][j] )
                {
                    flag = false;
                    goto two;
                }
        two:
            if( flag )
                return false;
        flag = true;
        for( int i = 1,rr = 1 ; i <= h ; i++,rr++ )
            for( int j = 1,cc = w ; j <= w ; j++,cc-- )
                if( temp.s[rr][cc] != p[h][w].v[k].s[i][j] )
                {
                    flag = false;
                    goto three;
                }
        three:
            if( flag )
                return false;
                flag = true;
        for( int i = 1,rr = h ; i <= h ; i++,rr-- )
            for( int j = 1,cc = w ; j <= w ; j++,cc-- )
                if( temp.s[rr][cc] != p[h][w].v[k].s[i][j] )
                {
                    flag = false;
                    goto four;
                }
        four:
            if( flag )
                return false;
    }
    if( h == w )
        {
            spe temp2;
            for( int i = 1 ; i <= h ; i++  )
                for( int j = 1 ; j <= w ; j++ )
                    temp2.s[i][j] = temp.s[j][i];
            temp2.ch = temp.ch;
            p[h][w].v.push_back(temp2);
        }
    p[h][w].v.push_back(temp);
    return true;    
}
int main()
{
    memset(visit,0,sizeof visit);
    scanf("%d %d",&col,&row);
    for( int i = 1 ; i <= row ; i++ )
        scanf("%s",s[i]+1);
    for( int i = 1 ; i <= row ; i++ )
        for( int j = 1 ; j <= col ; j++ )
            if( s[i][j] == '1' && visit[i][j] == 0 )
            {
                r1 = r2 = i,c1 = c2 = j;
                dfs(i,j,'1');
                int h = r2-r1+1,w = c2-c1+1;
                if( judge(h,w) )
                    s[i][j] = ch++;
                else s[i][j] = previ;
            }
    memset(visit,0,sizeof visit);
    for( int i = 1 ; i <= row ; i++ )
        for( int j = 1 ; j <= col ; j++ )
            if( s[i][j] != '0' )
                dfs(i,j,s[i][j]);
    for( int i = 1 ; i <= row ; i++ )
        printf("%s\n",s[i]+1);
	return 0;
}