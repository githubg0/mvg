// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

long long  dg[120];
long long  dp[20][2];
int dfs(int len,int six,int limit)
{
    if(len == 0)
        return 1;
    if(!limit &&dp[len][six])
        return dp[len][six];
    long long  ans = 0;
    long long  up;
    if(limit)
        up = dg[len];
    else
        up = 9;
    for(int i = 0; i <= up; i ++)
    {
        if(i == 4)
            continue;
        if(six&&i == 2)
            continue;
        ans += dfs(len-1,i == 6, limit&&i == up);
    }
                 if(!limit)
                   dp[len][six] = ans;
        return ans;
}
int solve(int num)
{
       
    int n = 0;
    while(num)
    {
        dg[++n]= num % 10;
        num /= 10;
    }
    return dfs(n,0,1);
}
int main()
{
    int i,j,n,m;
    while(scanf("%d %d",&n, &m)&&(m+n))
    {
    printf("%d\n",solve(m)-solve(n-1));
    }
    return 0;
}