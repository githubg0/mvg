// Graph Algorithm->Strongly Connected Components
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=102;
vector<int>g[maxn],gre[maxn];
int ord[maxn];
bool vis[maxn];
int out[maxn];
int in[maxn];
int belong[maxn];
int ans[maxn];
int color;
int no;
int n;
void dfs1(int u)
{
    vis[u]=1;
    for(int i=0;i<g[u].size();i++)
    {
        int v=g[u][i];
        if(!vis[v])
            dfs1(v);
    }
    ord[no++]=u;
}
void dfs2(int u)
{
    vis[u]=1;
    belong[u]=color;
    for(int i=0;i<gre[u].size();i++)
    {
        int v=gre[u][i];
        if(!vis[v])
        {
            dfs2(v);
        }
    }
}
void kosaraju()
{
    color=1,no=1;
    memset(in,0,sizeof(vis));
    memset(out,0,sizeof(out));
    memset(vis,0,sizeof(vis));
    for(int i=1;i<=n;i++)
        if(!vis[i])
        dfs1(i);
    memset(vis,0,sizeof(vis));
    for(int i=no-1;i>=1;i--)
    {
        int v=ord[i];
        if(!vis[v])
        {
            dfs2(v);
            color++;
        }
    }
    
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<g[i].size();j++)
        {
            if(belong[i]==belong[g[i][j]])
                continue;
            out[belong[i]]++;
            in[belong[g[i][j]]]++;
        }
    }
    int  inzero=0,outzero=0;
    for(int i=1;i<color;i++)
    {
        if(!in[i])
            inzero++;
        if(!out[i])
            outzero++;
    }
    if(color==2)
        printf("1\n0\n");
    else
        printf("%d\n%d\n",inzero,max(inzero,outzero));
}
int main()
{
    scanf("%d",&n);
    int to;
    for(int i=1;i<=n;i++)
    {
        while(scanf("%d",&to)&&to)
        {
            g[i].push_back(to);
            gre[to].push_back(i);
        }
    }
    kosaraju();
    return 0;
}