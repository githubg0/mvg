// Data Structure->Stack
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const long long INF = (1 << 60);
const int MAX_N = 100000 + 100;
struct Node
{
    int l;
    long long h;
};
long long arr[MAX_N],  sum[MAX_N];
int main()
{
    int n;
    while(scanf("%d", &n) != EOF)
    {
        stack <Node> S;
        Node temp, tmp;
        long long _max = 0, k, h;
        int l, r;
        sum[0] = 0;
        scanf("%lld", &arr[0]);
        sum[0] = arr[0];
        for(int i = 1; i < n; i++)
        {
            scanf("%lld", &arr[i]);
            sum[i] = sum[i - 1] + arr[i];
        }
        for(int i = 0; i < n; i++)
        {
            temp.l = i, temp.h = arr[i];
            while(!S.empty() && temp.h <= S.top().h)
            {
                tmp = S.top();
                S.pop();
                if(tmp.l != 0)
                    k = tmp.h * (sum[i - 1] - sum[tmp.l - 1]);
                else
                    k = tmp.h * sum[i - 1];
                if(_max < k)
                {
                    _max = k;
                    l = tmp.l + 1;
                    r = i;
                }
                temp.l = tmp.l;
            }
            S.push(temp);
        }
        while(!S.empty())
        {
            tmp = S.top();
            S.pop();
            if(tmp.l != 0)
                k = tmp.h * (sum[n - 1] - sum[tmp.l - 1]);
            else
                k = tmp.h * sum[n - 1];
            if(_max <= k)
            {
                _max = k;
                l = tmp.l + 1;
                r = n;
            }
        }
        printf("%lld\n%d %d\n", _max, l, r);
    }
    return 0;
}