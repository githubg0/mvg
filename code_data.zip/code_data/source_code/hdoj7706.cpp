// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef pair<int,int> PII;
typedef long long LL;
const int N=1e4+10;
struct Edge{
    int v;
    int next;
}edge[N<<1];
int head[N],tol;
int n;
void init(){
    tol=0;
    memset(head,-1,sizeof(head));
}
void add(int u,int v){
   edge[tol].v=v;
   edge[tol].next=head[u];
   head[u] = tol++;
}
void input(){
    int u,v;
    scanf("%d",&n);
    init();
    for(int i=1;i<n;i++){
        scanf("%d%d",&u,&v);
        add(u,v);
        add(v,u);
    }
}
bool vis[N];
int dp[N];
vector<int>ans;
void DFS(int u){
    int v;
    dp[u] = 1;
    int sum = 0;
    int Max = 0;
    for(int i=head[u];~i;i=edge[i].next){
        v = edge[i].v;
        if(vis[v]) continue;
        vis[v] = true;
        DFS(v);
        sum += dp[v];
        Max = max(Max,dp[v]);
    }
    dp[u] = sum + dp[u];
    Max = max(Max,n-dp[u]);
    if(Max <= (n/2)) ans.push_back(u);
}
void solve(){
    memset(vis,false,sizeof(vis));
    vis[1]=true;
    ans.clear();
    DFS(1);
}
void print()
{
    sort(ans.begin(),ans.end());
    int sz = ans.size();
    for(int i=0;i<sz;i++)
        printf("%d\n",ans[i]);
}
int main()
{
    input();
    solve();
    print();
    return 0;
}