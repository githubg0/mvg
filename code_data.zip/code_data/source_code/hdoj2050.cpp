// Basic Algorithm->Greedy Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 10000005;
using namespace std;
int Primgh[10000][10000];                        
bool refer[10005];                               
void Initial(int n, int m)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        refer[i] = false;
        for (j = 1; j <= n; j++)
        {
            if (i == j) {
                Primgh[i][j] = 0;
            }
            else Primgh[i][j] = maxn;
        }
    }
    int u, v, w;
    for (i = 1; i <= m; i++)
    {
        cin >> u >> v >> w;
        Primgh[u][v] = w;
        Primgh[v][u] = w;
    }
}
int Prim_Alg(int n, int m)
{
    Initial(n, m);
    int i, j, k;
    int ans = 0;
    
    refer[1] = true;
    
    
    for (i = 1; i <= n-1; i++)
    {
        int minlen = maxn;
        
        int rcd = 1;
        
        for (j = 1; j <= n; j++)
        {
            if (!refer[j]) continue;
            
            int len1 = maxn;
            
            int rcd1 = 1;
            
            
            for (k = 1; k <= n; k++)
            {
                if (!refer[k])
                {
                    if (Primgh[j][k] < len1) {
                        len1 = Primgh[j][k];
                        rcd1 = k;
                    }
                }
            }
            if (len1 < minlen) {
                
                minlen = len1;
                rcd = rcd1;
            }
        }
        
        
        
        
        refer[rcd] = true;
        
        rcd = 1;
        
        ans += minlen;
    }
    return ans;
}
int main()
{
    int n, m;
    while (scanf("%d", &n) != EOF)
    {
        if (n == 0) break;
        m = n * (n-1) / 2;
        cout << Prim_Alg(n, m) << endl;
    }
    return 0;
}