// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL long long
const LL INF = 0x3f3f3f3f3f3f3f3f;
const double pi = acos(-1.0);
const double eps = 1e-8;
int t, n, m;
int s[100050], nt[100050], e[100050];
LL l[100050], dis[100050],c[100050];
int x[100050], visit[100050], y[100050],  w[100050];
struct node
{
	int id;
	LL dis;
	friend bool operator < (node a, node b)
	{
		return a.dis > b.dis;
	}
};
LL Dijkstra()
{
	memset(visit, 0, sizeof visit);
	priority_queue<node>q;
	node pre, nt1;
	for (int i = 1; i <= m; i++)
	{
		if (dis[i] == 0)
		{
			pre.id = i, pre.dis = 0;
			q.push(pre);
		}
	}
	while (!q.empty())
	{
		pre = q.top();
		q.pop();
		visit[pre.id] = 1;
		for (int i = s[pre.id]; ~i; i=nt[i])
		{
			int ee = e[i];
			if (visit[ee]) continue;
			if (dis[ee]>dis[pre.id] + l[i])
			{
				dis[ee] = dis[pre.id] + l[i];
				nt1.id = ee;
				nt1.dis = dis[ee];
				q.push(nt1);
			}
		}
	}
	LL sum = 0;
	for (int i = 1; i <= m; i++)
	{
		if (w[i] == 2)
		{
			if (dis[i] ==INF) return -1;
			sum += dis[i];
		}
	}
	return sum;
}
int main()
{
	scanf("%d",&t);
	int cas = 1;
	while (t--) 
	{
		scanf("%d%d", &n, &m);
		for (int i = 1; i <= n; i++) scanf("%d", &x[i]);
		for (int i = 1; i <= n; i++) scanf("%d", &y[i]);
		for (int i = 1; i <= n; i++) scanf("%lld", &c[i]);
		for (int i = 1; i <= m; i++) scanf("%d", &w[i]);
		int cnt = 1;
		for (int i = 1; i <= m; i++) dis[i] = INF;
		memset(s, -1, sizeof s);
		for (int i = 1; i <= n; i++)
		{
			nt[cnt] = s[y[i]], e[cnt] = x[i], l[cnt] = c[i], s[y[i]] = cnt++;
			if (w[y[i]] == 0) dis[y[i]] = 0;
		}
		printf("Case #%d: %lld\n", cas++,Dijkstra());
	}
}