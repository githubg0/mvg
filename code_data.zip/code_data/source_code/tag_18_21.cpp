// Math and Computational Geometry->Sprague-Grundy Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
typedef pair<int,int> P;
const int N=100+10;
const int M=1e4+10;
const int INF_int=1e9;
const long long INF_ll=1e18;
const double EPS=1e-10;
int sg[1<<20],T,n,x,st,f,m;
bool vis[N];
void get_sg()
{
  int sum,now;
  for(int i=1;i<(1<<20);++i)
  {
    fill(vis,vis+N-1,0);
      for(int j=0;j<20;++j)
      {
        now=1<<j;
        if(now&i)
        {
          sum=i-now;
          now>>=1;
          while(now&i) now>>=1;
          if(now==0) continue;
          sum+=now;
          vis[sg[sum]]=1;
        }
      }
      for(int j=0;j<=100;++j)
      {
         if(vis[j]==0)
         {
            sg[i]=j;
            break;
         }
      }
  }
}
int main()
{
scanf("%d",&T);
  get_sg();
while(T--)
{
  scanf("%d",&n);
  f=0;
  for(int i=1;i<=n;++i)
  {
    scanf("%d",&m);
    st=0;
    for(int i=1;i<=m;++i)
    {
      scanf("%d",&x);
       st+=1<<(20-x);
    }
    f^=sg[st];
  }
  if(f) printf("YES\n");
  else printf("NO\n");
}
return 0;
}