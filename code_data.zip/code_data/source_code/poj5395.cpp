// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char oil[102][102];
int ans,color[101][101];
void Search(int x,int y)
{
	for(int m=x-1;m<=x+1;m++)
		for(int n=y-1;n<=y+1;n++)
			{
				if(m==x&&n==y||(oil[m][n]=='@'&&color[m][n]))   continue;
			    if(oil[m][n]=='@'&&!color[m][n])
				{
					color[m][n]=color[x][y];
					Search(m,n);
				}            
		    }
}
int main()
{
	int i,j,row,col;
	while(cin>>row>>col&&row&&col)
	{
		memset(color,0,sizeof(color));
		memset(oil,'$',sizeof(oil));
		ans=0;
		for(i=1;i<=row;i++)
			for(j=1;j<=col;j++)
				cin>>oil[i][j];
		for(i=1;i<=row;i++)
			for(j=1;j<=col;j++)
				if(oil[i][j]=='@'&&!color[i][j])
				{
					    ans++;
						color[i][j]=ans;
				        Search(i,j);
				}
		cout<<ans<<endl;
	}
	return 0;
}