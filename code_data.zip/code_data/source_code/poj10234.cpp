// Data Structure->Segment Tree,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define PI acos(-1.0)
#define Max 2005
#define inf 1<<28
#define LL(x) (x<<1)
#define RR(x) (x<<1|1)
#define FOR(i,s,t) for(int i=(s);i<=(t);++i)
#define ll long long
using namespace std;
int a[50],b[50];
int v[200];
bool cmp(int a,int b)
{
    return a>b;
}
bool cmp1(int a,int b)
{
    if(a%10!=b%10)return (a%10)<(b%10);
    return (a/10)<(b/10);
}
int main()
{
    int T;
    int n,m;
    cin>>T;
    while(T--)
    {
        cin>>n>>m;
        int t;
        memset(v,0,sizeof(v));
        memset(a,0,sizeof(a));
        memset(b,0,sizeof(b));
        int num1=0;
        for(int i=0;i<n;i++)
        {
            cin>>t;
            if(!v[t])
            {
                a[num1++]=t;
                v[t]=1;
            }
        }
        memset(v,0,sizeof(v));
        int num2=0;
        for(int i=0;i<m;i++)
        {
            cin>>t;
            if(!v[t])
            {
                v[t]=1;
                b[num2++]=t;
            }
        }
        sort(a,a+num1,cmp);
        sort(b,b+num2,cmp);
        int mm=0;
        int index=-1;
        int k;
        for(int i=0;i<num1;i++)
        {
            for(int j=0;j<num2;j++)
            {
                if(a[i]==b[j])
                {
                    for(k=1;k+i<num1&&k+j<num2;k++)
                    {
                        if(a[i+k]!=b[j+k])
                        break;
                    }
                    if(mm<k)
                    {
                        mm=k;
                        index=i;
                    }
                }
            }
        }
        int ans[105];
        int ans1=0;
        if(!mm)
        {
            cout<<"NONE"<<endl;
            continue;
        }
        bool flag=0;
        for(int i=index;i<index+mm;i++)
        {
            ans[ans1++]=a[i];
            if(flag)
            cout<<" ";
            cout<<a[i];
            flag=1;
        }
        cout<<endl;
        sort(ans,ans+ans1,cmp1);
        cout<<ans[0];
        for(int i=1;i<ans1;i++)
        cout<<" "<<ans[i];
        cout<<endl;
    }
    return 0;
}