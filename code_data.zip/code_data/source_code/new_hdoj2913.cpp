// Basic Algorithm->Recurrence
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,mod;
int a[6] = {1,2,4,6,9,15};
struct node
{
    int maptt1[4][4];
}unit,s;
void initial()
{
    int i;
    memset(s.maptt1,0,sizeof(node));
    for(i = 1; i < 4; i ++)
    s.maptt1[i][i-1] = 1;
    s.maptt1[0][0] = s.maptt1[0][2] = s.maptt1[0][3] = 1;
    memset(unit.maptt1,0,sizeof(node));
    for(i = 0; i < 4; i ++)
    unit.maptt1[i][i] = 1;
}
node Mul(node a,node b)
{
    node c;
    int i,j,k;
    for(i = 0; i < 4; i ++)
    for(j = 0; j < 4; j ++)
    {
        c.maptt1[i][j] = 0;
        for(k = 0; k < 4; k ++)
        c.maptt1[i][j] += (a.maptt1[i][k]*b.maptt1[k][j])%mod;
        c.maptt1[i][j] %= mod;
    }
    return c;
}
void Matrix()
{
    while(n)
    {
        if(n&1) unit = Mul(unit,s);
        n >>= 1;
        s = Mul(s,s);
    }
    int ans = 0;
    for(int i = 0; i < 4; i ++)
    ans += (unit.maptt1[0][i]*a[5-i])%mod;
    printf("%d\n",ans%mod);
}
int main()
{
    while(~scanf("%d%d",&n,&mod))
    {
        if(n <= 5)
        {
            printf("%d\n",a[n]%mod);
            continue;
        }
        n -= 5;
        initial();
        Matrix();
    }
    return 0;
}