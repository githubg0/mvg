// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char a[55];
int adgenum;
int head[10005];
int vis[1005];
struct Edge
{
	char from,to;
	int next;
}edge[100005];
void addedge(char u,char v)
{
	Edge E={u,v,head[u]};
	edge[adgenum]=E;
	head[u]=adgenum++;
}
void bfs(char u)
{
	queue<int>q;
	q.push(u);
	memset(vis,0,sizeof(vis));
	vis[u]=1;
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		for(int i=head[u];i!=-1;i=edge[i].next)
		{
			char v=edge[i].to;
			if(v=='m')
			{
				printf("Yes.\n");
				return;
			}
			if(vis[v]==0)
			{
				vis[v]=1;
				q.push(v);
			}
		}
	}
	printf("No.\n");
}
int main()
{
	int t;
	while(scanf("%s",a)!=EOF)
	{
		t=0;
		memset(head,-1,sizeof(head));
		adgenum=0;
		while(a[0]!='0')
		{
			int len=strlen(a);
			addedge(a[0],a[len-1]);
			scanf("%s",a);
		}
		bfs('b');
	}
	return 0;
}