// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXM=100010;
const int bit=4;
const int INF=0x3f3f3f3f;
const int maxm=60*30;
const long long MOD=998244353;
int a[32][32];
int dp[32][32][2710];
int n,m;
int main()
{
    int T;
    scanf("%d",&T);
    int cas=1;
    while(T--)
    {
        scanf("%d%d",&n,&m);
        for (int i=0;i<n;i++)
            for (int j=0;j<m;j++)
            scanf("%d",&a[i][j]);
        memset(dp,INF,sizeof(dp));
        int sum=a[0][0];
        dp[0][0][sum]=sum*sum;
        for (int i=0;i<n;i++)
        {
            for (int j=0;j<m;j++)
            {
                if (i+1<n)
                {
                    for (int k=0;k<=maxm;k++)
                    {
                        if (dp[i][j][k]==INF) continue;
                        int now=k+a[i+1][j];
                        int y=a[i+1][j];
                        dp[i+1][j][now]=min(dp[i+1][j][now],dp[i][j][k]+y*y);
                    }
                }
                if (j+1<m)
                {
                    for (int k=0;k<maxm;k++)
                    {
                        if (dp[i][j][k]==INF) continue;
                        int now=k+a[i][j+1];
                        int y=a[i][j+1];
                        dp[i][j+1][now]=min(dp[i][j+1][now],dp[i][j][k]+y*y);
                    }
                }
            }
        }
        int x=n+m-1;
        int ans=INF;
        for (int k=0;k<maxm;k++)
        {
            if (dp[n-1][m-1][k]==INF) continue;
            ans=min(ans,x*dp[n-1][m-1][k]-k*k);
        }
        printf("Case #%d: %d\n",cas,ans);
        cas++;
    }
    return 0;
}