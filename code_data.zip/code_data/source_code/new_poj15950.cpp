// Basic Algorithm->Memorization
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int s[1000],cnt;
int sg[11500];
int cal(int x)
{
	if(sg[x]!=-1) 
		return sg[x];
	bool f[11500];
	memset(f,0,sizeof(f));
	for(int i=1;i<=cnt;++i)
		if(x-s[i]>=0)
	{
		int tt=cal(x-s[i]);
		f[tt]=true;
	}	
	for(int i=0;i<=10001;++i)
		if(!f[i])
			return sg[x]=i;
}
int main ()
{
	int k,m,l,temp;
	while(scanf("%d",&k)!=EOF)
	{
		if(k==0) break;
		cnt=0;
		for(int i=1;i<=k;++i)
		{
			scanf("%d",&m);
			s[++cnt]=m;
		}
		memset(sg,-1,sizeof(sg));
		sg[0]=0;
		string ans="";
		scanf("%d",&m);
		for(int i=1;i<=m;++i)
		{
			scanf("%d",&l);
			int res=0;
			while(l--)
			{
				scanf("%d",&temp);
				res=res^cal(temp);
			}
			if(res)
				ans+="W";
			else ans+="L";
		}
		cout<<ans<<endl;
	}
	return 0;
}