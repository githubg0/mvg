// Math and Computational Geometry->Basis of Linear Space
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int maxn = 10005;
LL a[maxn],n;
const int base = 60;
LL b[base+1],c[base+1];
template <typename T>
void cal() {
    for( int i = 0;i <= base;i++ ) b[i] = 0;
    for (int i = 0; i < n; ++i) {
        T x = a[i];
        for (int j = base; j >= 0; --j) {
            if (x >> j & (T)1) {
                if (b[j]) x ^= b[j];
                else {
                    b[j] = x;
                    for (int k = j - 1; k >= 0; --k) if (b[k] && (b[j] >> k & (T)1)) b[j] ^= b[k];
                    for (int k = j + 1; k <= base; ++k) if (b[k] >> j & (T)1) b[k] ^= b[j];
                    break;
                }
            }
        }
    }
}
int main(){
    int T;
    scanf("%d",&T);
    int ca = 0;
    while(T--) {
        bool flag = false;
        printf("Case #%d:\n",++ca);
        scanf("%lld", &n);
        for (int i = 0; i < n; i++) {
            scanf("%lld", &a[i]);
            if( a[i] == 0 ) flag = true;
        }
        cal<LL>();
        int tot = 0;
        for (int i = 0; i <= base; i++) {
            if( b[i] ) c[tot++] = b[i];
        }
        int q;
        scanf("%d",&q);
        for( int i = 1;i <=q ;i++ ){
            LL x;
            LL cur = 0;
            scanf("%lld",&x);
            if( tot < n || flag ) x--;
            if( x >= (1LL<<tot) ){
                cur = -1;
            }else{
                for( int j = 0; j <= base;j++ ){
                    if( x>>j&1 ){
                        cur ^= c[j];
                    }
                }
            }
            printf("%lld\n",cur);
        }
    }
    return 0;
}