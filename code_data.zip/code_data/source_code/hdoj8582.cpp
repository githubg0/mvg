// Data Structure->Segment Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 500000
struct node
{
    int l;
    int r;
    int maxans;
}tree[maxn*4+5];
int n,m,q;
void build(int id,int tl,int tr)
{
    int mid=(tl+tr)/2;
    tree[id].l=tl;
    tree[id].r=tr;
    if(tl==tr)
    {
        tree[id].maxans=m;
        return ;
    }
    build(id*2,tl,mid);
    build(id*2+1,mid+1,tr);
    tree[id].maxans=max(tree[id*2].maxans,tree[id*2+1].maxans);
}
int f=0;
void query(int id,int x)
{
    int tl=tree[id].l;
    int tr=tree[id].r;
    if(f==-1)
        return ;
    if(tree[id].maxans<x)
    {
        f=-1;
        return ;
    }
    if(tl==tr&&tree[id].maxans>=x)
    {
        tree[id].maxans-=x;
        f=tl;
        return ;
    }
    if(tl==tr)
    {
        f=-1;
        return ;
    }
    if(tree[id*2].maxans>=x)
        query(id*2,x);
    else if(tree[id*2+1].maxans>=x)
        query(id*2+1,x);
    tree[id].maxans=max(tree[id*2].maxans,tree[id*2+1].maxans);
}
int main()
{
    while(scanf("%d%d%d",&n,&m,&q)!=EOF)
    {
        build(1,1,q);
        while(q--)
        {
            int x;
            scanf("%d",&x);
            f=0;
            query(1,x);
            if(f>n)
                printf("-1\n",f);
            else
             printf("%d\n",f);
        }
    }
return 0;
}