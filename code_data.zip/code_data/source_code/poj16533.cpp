// Basic Algorithm->Depth First Search (DFS),Data Structure->Link List,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std; 
struct node
{
      int x,y,w,next;
}line[900005];
int _link[10005],m,n,x,y,z,ans;
bool used[10005];
void DFS1(int dis,int x)
{
      if (dis>ans) { ans=dis; y=x; }
      int k;
      k=_link[x];
      used[x]=true;
      while (k)
      {
            if (!used[line[k].y]) DFS1(dis+line[k].w,line[k].y);
            k=line[k].next;
      }
      return;
}
void DFS2(int dis,int x)
{
      if (dis>ans) ans=dis;
      int k;
      k=_link[x];
      used[x]=true;
      while (k)
      {
            if (!used[line[k].y]) DFS1(dis+line[k].w,line[k].y);
            k=line[k].next;
      }
      return;
}
int main()
{
      freopen("input.txt","r",stdin);
      freopen("output.txt","w",stdout); 
      m=0; n=0;
      memset(_link,0,sizeof(_link));
      while (~scanf("%d%d%d",&x,&y,&z))
      {
            if (x>n) n=x;
            if (y>n) n=y;
            m++;
            line[m].x=x; line[m].y=y; line[m].w=z;
            line[m].next=_link[x]; _link[x]=m;
            m++;
            line[m].y=y; line[m].y=x; line[m].w=z;
            line[m].next=_link[y]; _link[y]=m;
      }      
      ans=0;
      memset(used,false,sizeof(used));
      y=1;
      DFS1(0,1); 
      memset(used,false,sizeof(used));
      DFS2(0,y);
      printf("%d\n",ans);
      return 0;   
}