// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=100000+1000;
const int inf=1000000000;
double a[maxn][5];
int main()
{
    int n;
    while(~scanf("%d",&n))
    {
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<5;j++)
            {
                scanf("%lf",&a[i][j]);
            }
        }
        double ans=0;
        for(int i=0;i<(1<<5);i++)
        {
            double maxi=-inf,mini=inf;
            for(int j=0;j<n;j++)
            {
                double t=0;
                for(int k=0;k<5;k++)
                {
                    if((1<<k)&i)
                    t+=a[j][k];
                    else
                    t-=a[j][k];
                }
                if(t>maxi)
                maxi=t;
                if(t<mini)
                mini=t;
            }
            ans=max(ans,maxi-mini);
        }
        printf("%.2f\n",ans);
    }
    return 0;
}