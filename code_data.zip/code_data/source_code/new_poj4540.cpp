// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>  
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
  
   
  
  
  
  
using namespace std;  
#define lch(i) ((i)<<1)  
#define rch(i) ((i)<<1|1)  
#define sqr(i) ((i)*(i))  
#define pii pair<int,int>  
#define mp make_pair  
#define FOR(i,b,e) for(int i=b;i<=e;i++)  
#define FORE(i,b,e) for(int i=b;i>=e;i--)  
#define ms(a)   memset(a,0,sizeof(a))  
const int maxnum =10005;
const int INF = 25000005;
int tol,n,m;
int dp[maxnum];
int w[505],c[505];
int main()  
{  
	
	int t;
	cin>>t;
	
	while(t--){
		scanf("%d%d%d",&m,&tol,&n);
		
		tol-=m;
		ms(w);ms(c);
		FOR(i,1,n){
			scanf("%d%d",&w[i],&c[i]);
			
		}
		dp[0]=0;
		FOR(i,1,tol) dp[i]=INF;
		FOR(i,1,n){
			FOR(j,c[i],tol){
					dp[j]=min(dp[j],dp[j-c[i]]+w[i]);
				
			}
		}
		if(dp[tol]==INF)printf("This is impossible.\n");
		else
			printf("The minimum amount of money in the piggy-bank is %d.\n",dp[tol]);
	}
	
	return 0;
}