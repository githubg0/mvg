// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 1e9
using namespace std;
const int maxn = 25;
const int maxm = 2005;
struct Edge
{
    int to,next,flow,cap;
}edge[maxm];
int head[maxn],level[maxn],cur[maxn];
int n,m,cnt;
void init()
{
    cnt = 0;
    memset(head,-1,sizeof(head));
}
void add_edge(int from,int to,int cap)
{
    edge[cnt].cap = cap;
    edge[cnt].to = to;
    edge[cnt].flow = 0;
    edge[cnt].next = head[from];
    head[from] = cnt++;
}
bool bfs(int s,int t)
{
    queue<int> que;
    memset(level,-1,sizeof(level));
    level[s] = 0;
    que.push(s);
    while(que.size()){
        int u = que.front();
        que.pop();
        for(int i = head[u];~i;i = edge[i].next){
            int v = edge[i].to;
            if(level[v] == -1 && edge[i].cap > edge[i].flow){
                level[v] = level[u] + 1;
                que.push(v);
            }
        }
    }
    return level[t] == -1 ? false : true;
}
int dfs(int u,int t,int low)
{
    if(u == t) return low;
    int ret = 0,temp;
    for(int &it = cur[u];~it && ret < low;it = edge[it].next){
        int v = edge[it].to;
        if(level[v] == level[u] + 1 && edge[it].cap > edge[it].flow){
            if(temp = dfs(v,t,min(low - ret,edge[it].cap - edge[it].flow))){
                ret += temp;
                edge[it].flow += temp;
                edge[it ^ 1].flow -= temp;
            }
        }
    }
    if(!ret) level[u] = -1;
    return ret;
}
int dinic(int s,int t)
{
    int maxflow = 0,temp;
    while(bfs(s,t)){
        memcpy(cur,head,sizeof(head));
        while(temp = dfs(s,t,INF)) maxflow += temp;
    }
    return maxflow;
}
int main(void)
{
    int a,b,c,t,ncase = 0;
    cin >> t;
    while(t--){
        cin >> n >> m;
        init();
        for(int i = 0;i < m;i++){
            cin >> a >> b >> c;
            add_edge(a-1,b-1,c);
            add_edge(b-1,a-1,0);
        }
        int ans = dinic(0,n-1);
        cout << "Case " << ++ncase << ": " <<  ans << endl;
    }
    return 0;
}