// Sorting->Heap Sort
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 100000;
const int INF = 0x7fffffff;
struct BinaryHeap{
    int heap[MAXN], id[MAXN], pos[MAXN], n, counter;
    BinaryHeap() : n(0), counter(0) {}
    BinaryHeap(int arraytt1[], int offset) : n(0), counter(0) {
        for (int i = 0; i < offset; ++i) {
          heap[++n] = arraytt1[i];
          pos[n] = id[n] = n;
        }
        for (int i = n/2; i >= 1; --i) {
          down(i);
        }
    } 
    void push(int v) {
        heap[++n] = v;
        id[n] = ++counter;
        pos[id[n]] = n;
        up(n);
    }
    int pop() {
        swap(heap[1], heap[n]);
        swap(id[1], id[n--]);
        pos[id[1]] = 1;
        down(1);
        return id[n+1];
    }
    int top() {
        return heap[1];
    }
    void up(int i) {
        int x = heap[i], y = id[i];
        for (int j = i/2; j >= 1; j /= 2) {
          if (heap[j] < x) {
            heap[i] = heap[j];
            id[i] = id[j];
            pos[id[i]] = i; 
            i = j;
          }
          else {
            break;
          }
        }
        heap[i] = x;
        id[i] = y;
        pos[y] = i;
    }
    void down(int i) {
        int x = heap[i], y = id[i];
        for (int j = i*2; j <= n; j *= 2) {
          j += j < n && heap[j] < heap[j+1];
          if (heap[j] > x) {
            heap[i] = heap[j];
            id[i] = id[j];
            pos[id[i]] = i;
            i = j;
          }
          else {
            break;
          }
        }
        heap[i] = x;
        id[i] = y;
        pos[y] = i;
    } 
    void erase() {
        n = 0;
    }
    bool isEmpty() {
        return n == 0;
    }
}pq;
int a[MAXN];
int main()
{
    freopen("in.txt", "r", stdin);
    int n;
    cin>>n;
    for (int i = 0; i < n; ++i) cin>>a[i]; 
    pq = BinaryHeap(a, n);
    while (!pq.isEmpty()) {
        cout<<pq.top()<<" ";
        pq.pop();
    }
    return 0;
}