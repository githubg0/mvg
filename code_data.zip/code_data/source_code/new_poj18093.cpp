// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
#define M 10005
int k,n,m;
int cow[105];
int ans[1005];
bool vis[1005];
vector<int>mp[M]; 
void dfs(int s)
{
    vis[s]=true;
    ans[s]++;
    int len=mp[s].size();
    for(int i=0;i<len;i++)
    {
        if(!vis[mp[s][i]])
            dfs(mp[s][i]);
    }
}
int main()
{
    cin>>k>>n>>m;
    int i,j,s,e;
    for(i=1;i<=k;i++)
        cin>>cow[i];
    for(i=1;i<=m;i++)
    {
        cin>>s>>e;
        mp[s].push_back(e);
    }
    for(i=1;i<=k;i++)
    {
        memset(vis,false,sizeof(vis));
        dfs(cow[i]);
    }
    int ok=0;
    for(i=1;i<=n;i++)
    {
        if(ans[i]==k)
            ++ok;
    }
    cout<<ok<<endl;
    return 0;
}