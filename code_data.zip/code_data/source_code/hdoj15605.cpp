// Graph Algorithm->Floyd-Warshall Algorithm,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Graph Algorithm->Min-Cost Max-Flow
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 1000000
#define eps 1e-8
#define MAXN (200+10)
#define MAXM (100000+10)
#define Ri(a) scanf("%d", &a)
#define Rl(a) scanf("%lld", &a)
#define Rf(a) scanf("%lf", &a)
#define Rs(a) scanf("%s", a)
#define Pi(a) printf("%d\n", (a))
#define Pf(a) printf("%.2lf\n", (a))
#define Pl(a) printf("%lld\n", (a))
#define Ps(a) printf("%s\n", (a))
#define W(a) while((a)--)
#define CLR(a, b) memset(a, (b), sizeof(a))
#define MOD 1000000007
#define LL long long
#define lson o<<1, l, mid
#define rson o<<1|1, mid+1, r
#define ll o<<1
#define rr o<<1|1
#define PI acos(-1.0)
#pragma comment(linker, "/STACK:102400000,102400000")
#define fi first
#define se second
using namespace std;
struct Edge{
    int from, to, cap, flow, cost, next;
};
Edge edge[MAXM];
int head[MAXN], edgenum;
int dist[MAXN], pre[MAXN];
bool vis[MAXN];
void init(){CLR(head, -1), edgenum = 0;}
void addEdge(int u, int v, int w, int c)
{
    Edge E1 = {u, v, w, 0, c, head[u]};
    edge[edgenum] = E1;
    head[u] = edgenum++;
    Edge E2 = {v, u, 0, 0, -c, head[v]};
    edge[edgenum] = E2;
    head[v] = edgenum++;
}
bool BFS(int s, int t)
{
    queue<int> Q;
    CLR(pre, -1); CLR(dist, INF); dist[s] = 0; CLR(vis, false); vis[s] = true; Q.push(s);
    while(!Q.empty())
    {
        int u = Q.front(); Q.pop();
        vis[u] = false;
        for(int i = head[u]; i != -1; i = edge[i].next)
        {
            int v = edge[i].to;
            if(dist[v] > dist[u] + edge[i].cost && edge[i].cap > edge[i].flow)
            {
                dist[v] = dist[u] + edge[i].cost; pre[v] = i;
                if(!vis[v])
                {
                    vis[v] = true;
                    Q.push(v);
                }
            }
        }
    }
    return pre[t] != -1;
}
void MCMF(int s, int t, int &cost, int &flow)
{
    cost = flow = 0;
    while(BFS(s, t))
    {
        int Min = INF;
        for(int i = pre[t]; i != -1; i = pre[edge[i^1].to])
            Min = min(Min, edge[i].cap - edge[i].flow);
        for(int i = pre[t]; i != -1; i = pre[edge[i^1].to])
        {
            edge[i].flow += Min;
            edge[i^1].flow -= Min;
            cost += edge[i].cost * Min;
        }
        flow += Min;
    }
}
int Map[MAXN][MAXN];
void Floyd(int n)
{
    for(int k = 0; k <= n; k++)
        for(int i = 0; i <= n; i++)
            for(int j = 0; j <= n; j++)
                Map[i][j] = min(Map[i][k] + Map[k][j], Map[i][j]);
}
int main()
{
    int n, m, k;
    while(scanf("%d%d%d", &n, &m, &k) != EOF)
    {
        if(n == 0 && m == 0 && k == 0) break;
        for(int i = 0; i <= n; i++)
            for(int j = 0; j <= n; j++)
                Map[i][j] = (i == j) ? 0 : INF;
        for(int i = 1; i <= m; i++)
        {
            int x, y, z;
            Ri(x); Ri(y); Ri(z);
            if(Map[x][y] > z)
                Map[x][y] = Map[y][x] = z;
        }
        Floyd(n); int s = 2*n+1, t = 2*n+2; 
        init();
        for(int i = 1; i <= n; i++)
        {
            addEdge(i, i+n, 1, -INF);
            if(Map[0][i] != INF) {addEdge(0, i, INF, Map[0][i]); addEdge(i+n, t, INF, Map[0][i]);}
            for(int j = i+1; j <= n; j++) if(Map[i][j] != INF)
                addEdge(i+n, j, 1, Map[i][j]);
        }
        addEdge(s, 0, k, 0); addEdge(0, t, k, 0);
        int cost, flow;
        MCMF(s, t, cost, flow);
        Pi(cost + n * INF);
    }
    return 0;
}