// Basic Algorithm->Enumerate
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int const MAX = 105;
int const INF = 0x3fffffff;
int num[MAX][MAX], b[MAX];
int n;
int MaxSum1() {
    int ma = -INF, cur = 0;
    for (int i = 1; i <= n; i ++) {
        cur += b[i];       
        if(cur > ma) {      
            ma = cur;
        }
        if(cur < 0) {
            cur = 0;
        }
    }
    return ma;
}
int MaxSum2() {
    int ma = -INF;                      
    for (int i = 1; i <= n; i ++) {
        memset(b, 0, sizeof(b));
        for (int j = i; j <= n; j ++) {
            for (int k = 1; k <= n; k ++) {
                b[k] += num[j][k];        
            }
            ma = max(ma, MaxSum1());
        }
    }                      
    return ma;
}
int main() {
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++) {
        for (int j = 1; j <= n; j ++) {
            scanf("%d", &num[i][j]);
        }
    }
    printf("%d\n", MaxSum2());
}