// Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
	long long l,r,h,add;
	int cover;
};
#define lson 2*u
#define rson 2*u+1
const int maxSize=40000;
int n;
long long a[maxSize*2+5];
long long sum=0;
node N[maxSize*16+5],M[maxSize+5];
void build(int u,int begin,int end1)
{
	int mid;
	N[u].l=begin;	N[u].r=end1;	N[u].add=0;	N[u].h=0; N[u].cover=-1;
	if (begin==end1)
	{
		return ;
	}
	mid=(begin+end1)/2;
	build(lson,begin,mid);
	build(rson,mid+1,end1);
}
void pushdown(int u)
{
	if (N[u].add!=0)
	{
		N[lson].h=N[u].add;
		N[rson].h=N[u].add;
		N[lson].add=N[u].add;
		N[rson].add=N[u].add;
		N[lson].cover=0;
		N[rson].cover=0;
		N[u].add=0;
	}
}
void pushup(int u)
{
	N[u].h=max(N[lson].h,N[rson].h);
	if (N[lson].cover==0 && N[rson].cover==0 && N[lson].h==N[rson].h)
		N[u].cover=0;
	else
		N[u].cover=-1;
}
void update(int u,int begin,int end1,int h)
{
	int mid;
	if (N[u].l==begin && N[u].r==end1)
	{
		if (h>N[u].h)
		{
			N[u].h=h;
			N[u].add=h;
			N[u].cover=0;
			return ;
		}
		else if (N[u].cover==0)
			return ;
	}
	pushdown(u);
	mid=(N[u].l+N[u].r)/2;
	if (end1<=mid)
		update(lson,begin,end1,h);
	else if (begin>mid)
		update(rson,begin,end1,h);
	else
	{
		update(lson,begin,mid,h);
		update(rson,mid+1,end1,h);
	}
	pushup(u);
}
void query(int u)
{
	int mid;
	if (N[u].cover==0)
	{
		sum+=N[u].h*(a[N[u].r+1]-a[N[u].l]);
		return ;
	}
	pushdown(u);
	mid=(N[u].l+N[u].r)/2;
	query(lson);
	query(rson);
}
int main()
{
	int i,size;
	freopen("a.txt","r",stdin);
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		scanf("%lld%lld%lld",&M[i].l,&M[i].r,&M[i].h);
		a[i*2+1]=M[i].l;	a[i*2+2]=M[i].r;	
	}
	sort(a+1,a+n*2+1);			
	size=unique(a+1,a+1+2*n)-a-1;		
	for (i=0;i<n;i++)		
	{
		M[i].l=lower_bound(a+1,a+1+size,M[i].l)-a;
		M[i].r=lower_bound(a+1,a+1+size,M[i].r)-a;
	}
	build(1,1,size-1);
	for (i=0;i<n;i++)
		update(1,M[i].l,M[i].r-1,M[i].h);
	query(1);
	printf("%lld\n",sum);
	return 0;
}