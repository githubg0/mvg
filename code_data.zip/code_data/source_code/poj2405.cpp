// Math and Computational Geometry->Convex Hull Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef double PointType;
struct point
{
    PointType x,y;
    int num;
};
point data[1005],stacktt1[1005],MinA;
int top;
PointType Direction(point pi,point pj,point pk) 
{
    return (pj.x-pi.x)*(pk.y-pi.y)-(pk.x-pi.x)*(pj.y-pi.y);
}
PointType Dis(point a,point b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
bool cmp(point a,point b)
{
    PointType k=Direction(MinA,a,b);
    if(k>0) return 1;
    if(k<0) return 0;
    return Dis(MinA,a)>Dis(MinA,b);
}
void Graham_Scan(point *a,int numa)
{
    for(int i=0; i<numa; i++)
        if(a[i].y<a[0].y||(a[i].y==a[0].y&&a[i].x<a[0].x))
            swap(a[i],a[0]);
    MinA=a[0],top=0;
    sort(a+1,a+numa,cmp);
    stacktt1[top++]=a[0],stacktt1[top++]=a[1],stacktt1[top++]=a[2];
    for(int i=3; i<numa; i++)
    {
        while(Direction(stacktt1[top-2],stacktt1[top-1],a[i])<0)
            top--;
        stacktt1[top++]=a[i];
    }
}
bool judgeline(int n)
{
    for(int i=2; i<n; i++)
        if(Direction(data[i-2],data[i-1],data[i]))
            return 0;
    return 1;
}
int main()
{
    int n,t,m;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(int i=0; i<n; i++)
            scanf("%lf%lf",&data[i].x,&data[i].y);
        if(n<6||judgeline(n))
        {
            puts("NO");
            continue;
        }
        Graham_Scan(data,n);
        int f=1;
        for(int i=0,j=0; i<top; i++)
        {
            int num=0;
            if(i<top-1)
            {
                for(int j=0; j<n; j++)
                    if(!Direction(stacktt1[i],stacktt1[i+1],data[j]))
                        num++;
            }
            else
                for(int j=0; j<n; j++)
                    if(!Direction(stacktt1[i],stacktt1[0],data[j]))
                        num++;
            if(num<3)
            {
                f=0;
                break;
            }
        }
        puts(f?"YES":"NO");
    }
    return 0;
}