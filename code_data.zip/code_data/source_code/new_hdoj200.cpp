// Basic Algorithm->Depth First Search (DFS),Dynamic Programming->Tree-Based Dynamic Programming,Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,len;
int dp[105][105];
int bug[105],p[105],vis[105],head[105];
struct node
{
    int now,next;
} tree[105];
void add(int x,int y)
{
    tree[len].now = y;
    tree[len].next = head[x];
    head[x] = len++;
}
void dfs(int root)
{
    int cost,i,j,k,son;
    vis[root] = 1;
    cost = (bug[root]+19)/20;
    for(i = cost; i<=m; i++)
        dp[root][i] = p[root];
    for(i = head[root]; i!=-1; i = tree[i].next)
    {
        son = tree[i].now;
        if(!vis[son])
        {
            dfs(son);
            for(j = m; j>=cost; j--)
            {
                for(k = 1; j+k<=m; k++)
                {
                    if(dp[son][k])
                        dp[root][j+k] = max(dp[root][j+k],dp[root][j]+dp[son][k]);
                }
            }
        }
    }
}
int main()
{
    int i,j,x,y;
    while(~scanf("%d%d",&n,&m),n+m>0)
    {
        for(i = 1; i<=n; i++)
            scanf("%d%d",&bug[i],&p[i]);
        len = 0;
        memset(vis,0,sizeof(vis));
        memset(head,-1,sizeof(head));
        for(i = 1; i<n; i++)
        {
            scanf("%d%d",&x,&y);
            add(x,y);
            add(y,x);
        }
        if(!m)
        {
            printf("0\n");
            continue;
        }
        memset(dp,0,sizeof(dp));
        dfs(1);
        printf("%d\n",dp[1][m]);
    }
    return 0;
}