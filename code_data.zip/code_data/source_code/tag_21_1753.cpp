// Math and Computational Geometry->Pigeonhole Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1e5 + 10;
struct node
{
    int l,r;
    bool operator<(const node& rhs)const
    {
        if(l != rhs.l) return l < rhs.l;
        return r < rhs.r;
    }
}s[maxn];
int a[maxn];
int main()
{
    int T;
    scanf("%d",&T);
    for(int kase = 1;kase <= T;++kase){
        int n,m;
        scanf("%d%d",&n,&m);
        for(int i = 0 ;i < n;i++)
        {
            scanf("%d%d",&s[i].l,&s[i].r);
        }
        for(int i = 0;i < m;i++){
            scanf("%d",&a[i]);
        }
        int ans = 0;
        sort(s,s+n);
      
        sort(a,a+m);
        int j = 0;
        priority_queue<int,vector<int>,greater<int> > Q;
        for(int i = 0;i < m;++i)
        {
           while(j < n && s[j].l <= a[i])
           {
               Q.push(s[j++].r);
           }
           
           while(!Q.empty())
           {
               int x = Q.top();
             
               if(x>=a[i]) break;
               Q.pop();
           }
           
           ans = max(ans,n-(int)Q.size()+1);
           if(!Q.empty()) Q.pop();  
        }
        if(ans>n)
            printf("Case #%d: IMPOSSIBLE!\n",kase);
        else
            printf("Case #%d: %d\n",kase,ans);
    }
    return 0;
}