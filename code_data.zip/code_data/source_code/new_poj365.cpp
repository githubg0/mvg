// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

   
  
  
#define UP(i,x,y) for(int i=x;i<=y;i++)  
#define DOWN(i,x,y) for(int i=x;i>=y;i--)  
#define MEM(a,x) memset(a,x,sizeof(a))
#define W(a) while(a) 
#define ll long long  
#define INF 0x3f3f3f3f  
#define EXP 1e-10  
#define lowbit(x) (x&-x)
 
using namespace std;
vector<int> b[110],p[110],pp;
int dp[110][500];
int main(){
	int t;cin>>t;
	while(t--){
		MEM(dp,0x3f);
		for(int i=0;i<500;i++){
			dp[0][i]=0;
		}
		int n;double ans=-INF; 
		cin>>n;
		for(int i=1;i<=n;i++){
			int m;cin>>m;
			for(int j=1;j<=m;j++){
				int B,P;
				cin>>B>>P;
				b[i].push_back(B);
				p[i].push_back(P);
				pp.push_back(P); 
			}
		}
		sort(pp.begin(),pp.end());
		for(int i=0;i<pp.size();i++){
			int x=pp[i];
			int ok,flag=INF;
			for(int j=1;j<=n;j++){
				ok=0;
				for(int k=0;k<b[j].size();k++){
					if(b[j][k]>=x&&dp[j][x]>dp[j-1][x]+p[j][k]){
						ok=1;
						dp[j][x]=dp[j-1][x]+p[j][k];
						flag=min(flag,b[j][k]);
					}
				}
				if(ok==0){
					break;
				}
			}
			if(ok==0)continue;
			double tans=double(flag)/dp[n][x];
			if(tans>ans)ans=tans;
		}
		cout<<fixed<<setprecision(3)<<ans<<endl;
		for(int i=1;i<=n;i++){
			b[i].clear();p[i].clear();
		}
		pp.clear();
	} 
	return 0;
}