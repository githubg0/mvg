// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 210
#define M 1000010
using namespace std;
int a[N],dp[N][2];
bool status[M],ch[N];
int n;
int main()
{
    
    int dfs(int k);
    int m;
    while(scanf("%d %d",&n,&m)!=EOF)
    {
        if(!n&&!m)
        {
            break;
        }
        int Top = 1;
        memset(status,false,sizeof(status));
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&a[Top]);
            if(!status[a[Top]])
            {
                status[a[Top]] = true;
                Top++;
            }
        }
        Top-=1;
        n = Top;
        sort(a+1,a+n+1);
        memset(status,false,sizeof(status));
        for(int i=1;i<=m;i++)
        {
            int x;
            scanf("%d",&x);
            status[x] = true;
        }
        memset(ch,false,sizeof(ch));
        memset(dp,0,sizeof(dp));
        int res = 0;
        for(int i=1;i<=n;i++)
        {
            if(!ch[i])
            {
                res+=dfs(i);
            }
        }
        printf("%d\n",res);
    }
    return 0;
}
int dfs(int k)
{
    bool uv = true;
    ch[k] = true;
    for(int i=1;i<=n;i++)
    {
        if(k==i)
        {
            continue;
        }
        if(status[abs(a[i]-a[k])]&&!ch[i])
        {
            uv = false;
            break;
        }
    }
    if(uv)
    {
        dp[k][0] = 0;
        dp[k][1] = a[k];
        return max(dp[k][0],dp[k][1]);
    }
    for(int i=1;i<=n;i++)
    {
        if(k==i)
        {
            continue;
        }
        if(status[abs(a[i]-a[k])]&&!ch[i])
        {
            dfs(i);
            dp[k][0]+=max(dp[i][0],dp[i][1]);
            dp[k][1]+=dp[i][0];
        }
    }
    dp[k][1]+=a[k];
    return max(dp[k][0],dp[k][1]);
}