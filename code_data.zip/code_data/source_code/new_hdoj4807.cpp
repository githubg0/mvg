// Data Structure->Queue,Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
       int w,fail,son[27]; 
}T[500005];
int t,n,i,l,m,h,k,ans;
char s[1000005];
bool used[500005];
queue<int> myqueue;
int main()
{  
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
        scanf("%d",&t);
        while (t--)
        {
              scanf("%d",&n);
              memset(T[0].son,0,sizeof(T[0].son));
              T[0].w=T[0].fail=0;
              m=0;
              while (n--)
              {
                    scanf("%s",s);
                    h=0;
                    l=strlen(s);
                    for (i=0;i<l;i++)
                    {
                          k=s[i]-'a';
                          if (!T[h].son[k])
                          { 
                                 T[h].son[k]=++m; 
                                 memset(T[m].son,0,sizeof(T[m].son));
                                 T[m].w=T[m].fail=0;
                          } 
                          h=T[h].son[k];
                    }
                    T[h].w++;
              }
              while (!myqueue.empty()) myqueue.pop();
              for (i=0;i<26;i++)
                 if (T[0].son[i]) myqueue.push(T[0].son[i]);
              while (!myqueue.empty())
              {
                    h=myqueue.front();
                    myqueue.pop();
                    for (i=0;i<26;i++)
                    if (T[h].son[i])
                    {
                            myqueue.push(T[h].son[i]);
                            k=T[h].fail;
                            while (k && !T[k].son[i]) k=T[k].fail;
                            T[T[h].son[i]].fail=T[k].son[i];
                    }
              }   
              scanf("%s",s);
              l=strlen(s);
              memset(used,false,sizeof(used));
              used[0]=true;
              h=ans=0;
              for (i=0;i<l;i++)
              {
                    k=s[i]-'a';
                    while (h && !T[h].son[k]) h=T[h].fail;
                    h=T[h].son[k];
                    k=h;
                    while (k && !used[k])
                    {
                          if (T[k].w) ans+=T[k].w;
                          used[k]=true; 
                          k=T[k].fail;
                    }
              }
              printf("%d\n",ans);
        }     
        return 0;
}