// Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int x,y,step;
    int state;
} q[1<<20],head,rear;
int vis[25][25][16384];                  
int viss[25][25];                        
int dir[4][2]= {-1,0,0,1,1,0,0,-1};
int bit[3][3];                           
int m,n,len;
void init()
{
    bit[0][1]=0;
    bit[1][2]=1;
    bit[2][1]=2;
    bit[1][0]=3;                         
    memset(vis,0,sizeof(vis));
    memset(viss,0,sizeof(viss));
    return ;
}
void bfs()
{
    int a=0,b=1;
    q[0]=head;
    while(a<b)
    {
        head=q[a++];
        if(head.x==1&&head.y==1)
        {
            cout<<head.step<<endl;
            return ;
        }
        for(int i=0; i<4; i++)
        {
            rear.x=head.x+dir[i][0];
            rear.y=head.y+dir[i][1];
            if(rear.x<1||rear.y<1||rear.x>m||rear.y>n||viss[rear.x][rear.y])
                continue;
            int j,t,tx=head.x,ty=head.y,tstate=head.state;
            rear.state=head.state%(1<<((len-2)*2));                    
            rear.state=rear.state*4+bit[head.x-rear.x+1][head.y-rear.y+1];
            for(j=1; j<len; j++)               
            {
                t=tstate%4;
                tstate/=4;
                tx+=dir[t][0];
                ty+=dir[t][1];
                if(tx==rear.x&&ty==rear.y)
                    break;
            }
            if(j<len||vis[rear.x][rear.y][rear.state])
                continue;
            vis[rear.x][rear.y][rear.state]=1;
            rear.step=head.step+1;
            q[b++]=rear;
        }
    }
    cout<<-1<<endl;
    return ;
}
int main()
{
    int i,j,nn,test=0;
    int snake[8][2];
    while(scanf("%d%d%d",&m,&n,&len)&&(m||n||len))
    {
        init();
        int a,b;
        for(i=0; i<len; i++)
            scanf("%d%d",&snake[i][0],&snake[i][1]);
        scanf("%d",&nn);
        while(nn--)
        {
            scanf("%d%d",&a,&b);
            viss[a][b]=1;
        }
        head.state=0;
        for(i=len-1; i>=1; i--)
            head.state=head.state*4+bit[snake[i][0]-snake[i-1][0]+1][snake[i][1]-snake[i-1][1]+1];       
        head.x=snake[0][0];
        head.y=snake[0][1];
        head.step=0;
        vis[head.x][head.y][head.state]=1;
        printf("Case %d: ",++test);
        bfs();
    }
    return 0;
}