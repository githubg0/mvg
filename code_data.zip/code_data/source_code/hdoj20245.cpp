// Basic Algorithm->Recursion,Basic Algorithm->Greedy Algorithm,Graph Algorithm->Lowest Common Ancestor (LCA),Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
vector<int> nodegift[50001],sorted[100001];
int fa[50001],n[100001],p[50001],s[100001],ans[50001];
inline void Sort(int x,int ftr){
    int i;
    for(i=nodegift[x].size();i--;)
        sorted[nodegift[x][i]].push_back(x);
    for(i=p[x];i;i=n[i])
        if(s[i]!=ftr)
            Sort(s[i],x);
}
inline int find(int x){
    return fa[x]!=fa[fa[x]]?fa[x]=find(fa[x]):fa[x];
}
vector<int> query[50001];
inline void Tarjan(int x,int ftr){
    int i;
    fa[x]=x;
    for(i=p[x];i;i=n[i])
        if(s[i]!=ftr)
            Tarjan(s[i],x);
    for(i=query[x].size();i--;)
        --ans[find(query[x][i])];
    fa[x]=ftr;
    ans[ftr]+=ans[x];
}
int main(){
    int i,N,m,j,a,b;
    while(~scanf("%d%d",&N,&m)){
        
        memset(p,0,sizeof(int)*(N+1));
        memset(ans,0,sizeof(int)*(N+1));
        for(i=N;i;--i){
            vector<int>().swap(nodegift[i]);
            vector<int>().swap(query[i]);
        }
        
        for(i=N;--i;){
            scanf("%d%d",&a,&b);
            n[i]=p[a],p[a]=i,s[i]=b;
            n[i+N]=p[b],p[b]=i+N,s[i+N]=a;
        }
        while(m--){
            scanf("%d%d",&a,&b);
            nodegift[a].push_back(b);
        }
        for(i=100000;i;--i)vector<int>().swap(sorted[i]);
        
        Sort(1,0);
        for(i=100000;i;--i){
            for(j=sorted[i].size();j--;)
                ++ans[sorted[i][j]];
            for(j=sorted[i].size()-1;j>0;--j)
                query[sorted[i][j]].push_back(sorted[i][j-1]);
        }
        
        Tarjan(1,0);
        
        for(i=1;i<N;++i)printf("%d ",ans[i]);
        printf("%d\n",ans[N]);
    }
}