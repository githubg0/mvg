// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
int main(){
    int t,k;
    char a[1010];
    int Min,count;
    scanf("%d",&t);
    count=0;
    while (t--) {
        scanf("%s",a);
        k=0;
        Min=9999;
        for (int i=0; i<strlen(a); i++) {
            for (int j=i+1; j<strlen(a); j++) {
                if(a[i]==a[j]){
                    Min=min(Min,j-i);
                }
            }
        }
        count++;
        if(strlen(a)==1){
            printf("Case #%d: -1\n",count);
        }
        else if(Min==9999){
            printf("Case #%d: -1\n",count);
        }
        else
            printf("Case #%d: %d\n",count,Min);
    }
    return 0;
}