// Data Structure->Link List,Data Structure->Hashing
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define mod 99991
typedef struct node
{
  char s[80];
  struct node *next;
  node()
  {
      next=0;
  }
}hashtable;
int cnt=0;
hashtable *Hash[mod];
void strcut(char *train,char *s1,char *s2,int k,int n)
{
    int p=0,q=0;
    for(;p<k;p++)
        s1[p]=train[p];
    s1[p]='\0';
    for(;p<n;p++)
        s2[q++]=train[p];
    s2[q]='\0';
    return;
}
char strcat(char *s1,char *s2,char *str)
{
    int i=0,p=0;
    for(i=0;s1[i]!='\0';i++)
       str[p++]=s1[i];
       for(i=0;s2[i]!='\0';i++)
       str[p++]=s2[i];
    str[p]='\0';
}
void strres(char *s1,char *s2,int len)
{
    int p=0;
    s2[len]='\0';
    for(int i=len-1;i>=0;i--)
        s2[i]=s1[p++];
        return ;
}
void strcopy(char *s1,char *s2)
{
    int i,p=0;
    for(i=0;s1[i]!='\0';i++)
    {
        s2[i]=s1[i];
    }
    s2[i]='\0';
    return;
}
void hash1(char *ps)
{
    int i;
    int key=0;
    char *s=ps;
    for(i=0;s[i]!='\0';i++)
    {
        key+=s[i]*(i+1);
    }
    key%=mod;
    if(!Hash[key])
    {
        hashtable *t=new hashtable;
        strcopy(s,t->s);
        Hash[key]=t;
        cnt++;
    }
    else
    {
        hashtable *tt=Hash[key];
        if(!strcmp(tt->s,s)) return;
        else
        {
            while(tt->next)
            {
                if(!strcmp(tt->next->s,s))
                    return;
                tt=tt->next;
            }
            hashtable *tmp=new hashtable;
            strcopy(s,tmp->s);
            tt->next=tmp;
            cnt++;
        }
    }
    return ;
}
int main()
{
    
    int n;
    int i,j;
    scanf("%d",&n);
    while(n--)
    {
        char train[80];
        cnt=0;
        memset(Hash,0,sizeof(Hash));
        scanf("%s",train);
        int len = strlen(train);
        if(len==1)
        {
            printf("1\n");continue;
        }
        for(i=1;i<=len-1;i++)
        {
            char s1[80],s2[80],s3[80],s4[80],s[80];
            strcut(train,s1,s2,i,len);
            strres(s1,s3,i);
            strres(s2,s4,len-i);
            strcat(s1,s2,s);
            hash1(s);
            
            strcat(s2,s1,s);
            
            hash1(s);
            strcat(s1,s4,s);
            hash1(s);
            
            strcat(s4,s1,s);
            hash1(s);
            
            strcat(s2,s3,s);
            
            hash1(s);
            strcat(s3,s2,s);
            
            hash1(s);
            strcat(s3,s4,s);
            hash1(s);
            strcat(s4,s3,s);
            hash1(s);
        }
        printf("%d\n",cnt);
    }
    return 0;
}