// Data Structure->Stack,Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion,Graph Algorithm->Strongly Connected Components,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
using namespace std;
int n;int m;
const int MAX=1001;
vector<vector<int> >edges(MAX);  
vector<vector<int> >newedge(MAX);
int visited[MAX];             
int low[MAX];
int dfn[MAX];
bool mark[MAX];                
int Strongly_connected_branch[MAX];   
int num;int times;      
stack<int>s;            
bool instack[MAX];
int ind[MAX];         
void tarjan(int u)
{
    low[u]=dfn[u]=times++;
    instack[u]=1;
    s.push(u);
    int len=edges[u].size();
    for(int i=0;i<len;i++)
    {
        int v=edges[u][i];
        if(visited[v]==0)
        {
             visited[v]=1;
               tarjan(v);
            if(low[u]>low[v])low[u]=low[v];
        }
        else if(instack[v]&&low[u]>dfn[v])   
        {
            low[u]=dfn[v];
        }
    }
    if(dfn[u]==low[u])          
    {
        num++;int temp;
         do
        {
             temp=s.top();
             instack[temp]=0;
            s.pop();
            Strongly_connected_branch[temp]=num;
        } while(temp!=u);
    }
}
bool is_no; 
void dfs(int u,int depth)      
{
    if(depth==num)is_no=true;
    int len=newedge[u].size();
    for(int i=0;i<len;i++)
    {
        int v=newedge[u][i];
        if(mark[v]==0)
          {
              mark[v]=1;
              dfs(v,depth+1);
              mark[v]=0;
          }
    }
}
void readin()
{
    scanf("%d%d",&n,&m);
    int from,to;
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&from,&to);
        edges[from].push_back(to);
    }
}
void initialize()       
{
    is_no=num=times=0;
    for(int i=0;i<=n;i++)
    {
        ind[i]=0;
        mark[i]=instack[i]=low[i]=dfn[i]=visited[i]=0;
        edges[i].clear();
        newedge[i].clear();
        Strongly_connected_branch[i]=-1;
    }
}
void solve()
{
    for(int i=1;i<=n;i++)
       if(visited[i]==0)
        {
            visited[i]=1;
            tarjan(i);
        }
     for(int i=1;i<=n;i++)         
    {
        int len=edges[i].size();
       for(int j=0;j<len;j++)
       {
          int v=edges[i][j];
          if(Strongly_connected_branch[v]!=Strongly_connected_branch[i])  
          {
             ind[Strongly_connected_branch[v]]++;
             newedge[Strongly_connected_branch[i]].push_back(Strongly_connected_branch[v]);
          }
       }
    }
    int is_0ind;
    for(int i=1;i<=num;i++)    
    {
       if(ind[i]==0)is_0ind=i;
    }
    mark[is_0ind]=1;
    dfs(is_0ind,1);
    if(is_no)printf("Yes\n");
    else printf("No\n");
}
int main()
{
    int tcase;
    scanf("%d",&tcase);
   while(tcase--)
   {
       initialize();
       readin();
       solve();
   }
   return 0;
}