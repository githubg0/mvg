// Graph Algorithm->Prim's Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
double x[110];
double y[110];
double z[110];
double r[110];
double maptt1[110][110];
double dist[110];
int visit[110];
double prim(int n) {
    for (int i = 1; i <= n; i++)
        dist[i] = maptt1[1][i];
    memset(visit, 0, sizeof (visit));
    visit[1] = 1;
    double len = 0.0;
    for (int i = 1; i < n; i++) {
        double min1 = 100000000;
        int dir;
        for (int j = 2; j <= n; j++) {
            if (min1 > dist[j] && !visit[j]) {
                min1 = dist[j];
                dir = j;
            }
        }
        if(min1==100000000)
            break;
        len += dist[dir];
        visit[dir]=1;
        for (int j = 2; j <= n; j++)
            if (!visit[j] && maptt1[dir][j] < dist[j])
                dist[j] = maptt1[dir][j];
    }
    return len;
}
int main() {
    int n;
    while (cin >> n && n) {
        for (int i = 1; i <= n; i++) {
            cin >> x[i] >> y[i] >> z[i] >> r[i];
            for (int j = 1; j < i; j++) {
                if (sqrt((x[i] - x[j])*(x[i] - x[j])+(y[i] - y[j])*(y[i] - y[j])+
                        (z[i] - z[j])*(z[i] - z[j])) > r[i] + r[j])
                    maptt1[i][j] = maptt1[j][i] = sqrt((x[i] - x[j])*(x[i] - x[j])+(y[i] - y[j])*(y[i] - y[j])+
                        (z[i] - z[j])*(z[i] - z[j])) - r[i] - r[j];
                else
                    maptt1[i][j] = maptt1[j][i] = 0;
            }
        }
        cout << fixed << setprecision(3) << prim(n) << endl;
    }
    return 0;
}