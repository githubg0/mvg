// Data Structure->Queue,Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef struct node
{
    int from,to,cap,flow;
    node(int f = 0,int t = 0,int c = 0,int ff = 0):from(f),to(t),cap(c),flow(ff){}
}node;
const int INF = 1<<30;
const int maxn = 400 + 5;
int n,f,d,s,t,N;
vector<node> edge;
vector<int> G[maxn];
int cur[maxn],di[maxn];
bool vis[maxn];
void addedge(int from,int to,int cap,int flow)
{
    edge.push_back(node(from,to,cap,0));
    edge.push_back(node(to,from,0,0));
    int m = edge.size();
    G[from].push_back(m-2);
    G[to].push_back(m-1);
}
bool BFS()
{
    int x;
    memset(vis,false,sizeof(vis));
    queue<int> q;
    q.push(s);
    vis[s] = true;
    di[s] = 0;
    while(!q.empty())
    {
        x = q.front();
        q.pop();
        for(int i = 0;i < G[x].size(); ++i)
        {
            node &e = edge[G[x][i]];
            if(e.cap > e.flow && !vis[e.to])
            {
                di[e.to] = di[x] + 1;
                vis[e.to] = true;
                q.push(e.to);
            }
        }
    }
    return vis[t];
}
int DFS(int x,int a)
{
    int flow = 0,f;
    if(x == t || a == 0) return a;
    for(int &i = cur[x];i< G[x].size(); ++i)
    {
        node &e = edge[G[x][i]];
        if(di[e.to] == di[x] + 1 && (f = DFS(e.to,min(a,e.cap - e.flow))) > 0)
        {
            e.flow += f;
            edge[G[x][i]^1].flow -= f;
            flow += f;
            a -= f;
            if(a == 0) break;
        }
    }
    return flow;
}
int maxflow()
{
    int flow = 0;
    while(BFS())
    {
        memset(cur,0,sizeof(cur));
        flow += DFS(s,INF);
    }
    return flow;
}
int main()
{
    int x,y,p;
    cin >> n >> f >> d;
    s = 0,t = 400 + 1;
    for(int i = 1;i <= f; ++i) addedge(s,i,1,0); 
    for(int i = 1;i <= d; ++i) addedge(i + 300,t,1,0);
    for(int i = 1;i <= n; ++i) addedge(i + 100,i + 200,1,0);
    for(int i = 1;i <= n; ++i)
    {
        cin >> x >> y;
        for(int j = 0;j < x; ++j)
        {
            cin >> p;
            addedge(p,i + 100,1,0);
        }
        for(int j = 0;j < y; ++j)
        {
            cin>>p;
            addedge(i + 200,p + 300,1,0);
        }
    }
    cout<<maxflow()<<endl;
    return 0;
}