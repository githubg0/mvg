// Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ll long long
const int N = 300+10;
int mp[N][N],vis[N][N],n,m;
int to[4][2]={-1,0,1,0,0,-1,0,1};
struct nd{
    int x,y,h;
    friend bool operator < (nd a,nd b) {
        return a.h>b.h;
    }
};
priority_queue<nd> q;
void init(){
    while(!q.empty()) q.pop();
    nd tp;
    memset(vis,0,sizeof(vis));
    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            if( i==0 || j==0 || i==n-1 || j==m-1 ) {
                vis[i][j]=1;
                tp.x=i,tp.y=j,tp.h=mp[i][j];
                q.push(tp);
            }
        }
    }
}
void bfs() {
    init();
    ll ans=0;
    nd t,tp;
    while(!q.empty()) {
        tp=q.top();
        q.pop();
        for(int i=0;i<4;i++) {
            int xx=tp.x+to[i][0],yy=tp.y+to[i][1];
            if( 0<=xx&&xx<n && 0<=yy&&yy<m && !vis[xx][yy]) {
                vis[xx][yy]=1;
                t.x=xx,t.y=yy,t.h=mp[xx][yy];
                if(t.h<tp.h) ans+=(tp.h-t.h),t.h=tp.h;
                q.push(t);
            }
        }
    }
    cout<<ans<<endl;
}
int main() {
    while(cin>>m>>n) {
        for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
                cin>>mp[i][j];
        bfs();
    }
}