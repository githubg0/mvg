// Dynamic Programming->Priority Queue
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char s[200];
int cnt[27];
int main()
{
	while(scanf("%s",s)!=EOF&&strcmp(s,"END")!=0)
	{
		int len=strlen(s);
		memset(cnt,0,sizeof(cnt));
		for(int i=0; i<len; i++) 
		{
			if(isalpha(s[i]))
				cnt[s[i]-'A']++;
			else
				cnt[26]++;
		}
		int num1=len*8;
		int num2=0;
		double num3;
		priority_queue<int,vector<int>,greater<int> > q;
		for(int i=0; i<27; i++)
		{
			if(cnt[i])
				q.push(cnt[i]);
		}
		while(q.size()>1)
		{
			int a=q.top();
			
			q.pop();
			int b=q.top();
			
			q.pop();
			num2+=a+b;
			
			q.push(a+b);
		}
		if(!num2)
			num2=len;
		while(!q.empty())
			q.pop();
		num3=(num1*1.0)/(num2*1.0);
		printf("%d %d %.1f\n",num1,num2,num3);
	}
}