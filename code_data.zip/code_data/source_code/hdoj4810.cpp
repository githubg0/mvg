// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int ancestor[1001];  
int son[10014];  
void find(int p)
{
    while(p!=ancestor[p])
    {
         p=ancestor[p];
         son[p]++;
    }
}
int main()
{
    int n,a,b,m;
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        for(int i=1;i<=n;i++)
        {
            ancestor[i]=i;
            son[i]=0;
        }
        for(int i=1;i<n;i++)
        {
            scanf("%d%d",&a,&b);
            ancestor[b]=a;
        }
        int sum=0;
        for(int i=1;i<=n;i++)
        {
            find(i);
        }
       for(int i=1;i<=n;i++)
       {
            if(son[i]==m)
            sum++;
       }
            printf("%d\n",sum);
    }
    return 0;
}