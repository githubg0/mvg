// Basic Algorithm->Recurrence
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 
using namespace std;
int dp[255][80],a[80];
void init()
{
    memset(dp,0,sizeof(dp));
    memset(a,0,sizeof(a));
    int i,j;
    int m;
    dp[0][1]=1;
    dp[1][1]=1;
    dp[2][1]=3;
    a[0]=a[1]=a[2]=1;
    for(i=3;i<=250;i++) 
    {
         m=a[i-1];
         for(j=1;j<=m;j++)
             dp[i][j]=dp[i-1][j]+dp[i-2][j]*2;
         for(j=1;j<=m;j++)
         {  
             if(dp[i][j]>9)
             {
                  if(dp[i][m]>9) m++;
                  dp[i][j+1]+=dp[i][j]/10;
                  dp[i][j]%=10;
             }
         }
         a[i]=m;
    }  
}
int main()
{
    int n;                                            
    while(~scanf("%d",&n))
    {
         init();
         int i;
         for(i=a[n];i>=1;i--)
            printf("%d",dp[n][i]);
         printf("\n");
    }
    return 0;
}