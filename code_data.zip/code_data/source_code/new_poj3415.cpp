// Graph Algorithm->Dijkstra's Algorithm,Data Structure->Heap
 
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
 
using namespace std;
typedef long long ll;
const int inf=0x3f3f3f3f;
const int maxn=1000010;
struct qnode
{
    int v,c;
    bool operator < (const qnode &x)const
    {
        return x.c<c;
    }
};
struct Edge
{
    int v,cost;
};
vector<Edge>E[maxn];
bool vis[maxn];
int dis[maxn];
int s,t;
int n,m;
void dijk(int n,int start)
{
    memset(vis,false,sizeof(vis));
    for(int i=1; i<=n; i++) dis[i]=inf;
    priority_queue<qnode>que;
    while(!que.empty()) que.pop();
    dis[s]=0;
    que.push(qnode {start,0});
    qnode tmp;
    while(!que.empty())
    {
        tmp=que.top();
        que.pop();
        int u=tmp.v;
        if(vis[u]) continue;
        vis[u]=true;
        for(int i=0; i<E[u].size(); i++)
        {
            int v=E[u][i].v;
            int cost=E[u][i].cost;
            int tt=cost;
                tt=max(dis[u],cost);
            if(dis[v]>tt)
            {
                dis[v]=tt;
                que.push(qnode {v,dis[v]});
            }
        }
    }
    if(dis[t]==inf) puts("-1");
    else printf("%d\n",dis[t]);
}
void addedge(int u,int v,int w)
{
    E[u].push_back(Edge {v,w});
}
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=0; i<m; i++)
    {
        int u,v,c;
        scanf("%d%d%d",&u,&v,&c);
        addedge(u,v,c);
        addedge(v,u,c);
    }
    int Q;
    scanf("%d",&Q);
    while(Q--)
    {
        scanf("%d%d",&s,&t);
        if(s==t)
        {
            printf("0\n");
            continue;
        }
        dijk(n,s);
    }
    return 0;
}