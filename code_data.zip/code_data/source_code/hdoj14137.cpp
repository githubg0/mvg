// Data Structure->Stack,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment (linker,"/STACK:102400000,102400000") 
#define maxn 50005
using namespace std;
typedef long long LL;
int read()
{
	char c;int sum=0,f=1;c=getchar();
	while(c<'0' || c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0' && c<='9'){sum=sum*10+c-'0';c=getchar();}
	return sum*f;
}
int n,m,q;
struct node{
	int to,val;
};
vector<node> edge[maxn];
int val[maxn];
int dis[2][maxn];
int st,ed,ans,id,res;
int maxa[maxn][32],mina[maxn][32],ln[maxn],l;
void init()
{
	ans=-1;
	for(int i=1;i<=n;i++)
	edge[i].clear();
}
void dfs(int x,int fa,int sum)
{
	if(sum>ans)
	{
		ans=sum;
		st=x;
	}
	int lens=edge[x].size();
	for(int i=0;i<lens;i++)
	{
		node nex=edge[x][i];
		if(nex.to==fa) continue;
		dfs(nex.to,x,sum+nex.val);
	}
}
void dfs2(int x,int fa,int sum,int f)
{
	dis[f][x]=sum;
	int lens=edge[x].size();
	for(int i=0;i<lens;i++)
	{
		node nex=edge[x][i];
		if(nex.to==fa) continue;
		dfs2(nex.to,x,sum+nex.val,f);
	}
}
void rmq()
{
	for(int i=1;i<=n;i++)
	maxa[i][0]=mina[i][0]=val[i];
	for(int j=1;(1<<j)<=n;j++)
	for(int i=1;i+(1<<j)<=n+1;i++)
	{
		maxa[i][j]=max(maxa[i][j-1],maxa[i+(1<<j-1)][j-1]);
		mina[i][j]=min(mina[i][j-1],mina[i+(1<<j-1)][j-1]);
	}
}
int query(int l,int r)
{
	int k=ln[r-l+1];
	return max(maxa[l][k],maxa[r-(1<<k)+1][k])-min(mina[l][k],mina[r-(1<<k)+1][k]);
}
int main()
{
	for(int i=1;i<=50000;i++)
	ln[i]=(1<<l+1==i)?++l:l;
	while(n=read(),m=read(),n&&m)
	{
		init();
		for(int i=1;i<n;i++)
		{
			int u=read(),v=read(),w=read();
			edge[u].push_back((node){v,w});
			edge[v].push_back((node){u,w});
		}
		dfs(1,0,0);
		ed=st;ans=-1;
		dfs(st,0,0);
		dfs2(st,0,0,0);dfs2(ed,0,0,1);
		for(int i=1;i<=n;i++)
		val[i]=max(dis[1][i],dis[0][i]);
		rmq();
		while(m--)
        {
            q=read();
            ans=id=1;
            for(int i=1;i<=n;i++)
            {
                while(id<=i)
                {
                    res=query(id,i);
                    if(res>q) id++;
                    else break;
                }
                ans=max(ans,i-id+1);
            }
            printf("%d\n",ans);
        }
	}
	return 0;
}