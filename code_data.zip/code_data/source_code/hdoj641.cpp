// Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
	int x, y;
	int time;
	int step;
	friend bool operator < (node a, node b)
	{
		return a.step > b.step;
	}
};
int n, m;
int mm[15][15];
int mov[][2] = { 0,1,1,0,0,-1,-1,0 };
node tt;
bool bfs()
{
	priority_queue<node>q;
	q.push(tt);
	while (q.size())
	{
		tt = q.top(); q.pop();
		for (int i = 0; i < 4; i++)
		{
			int xx = tt.x + mov[i][0];
			int yy = tt.y + mov[i][1];
			if (xx < 0 || yy < 0 || xx >= n || yy >= m || mm[xx][yy]==0)
				continue;
			
			node a;
			a.time=tt.time + 1;
			a.step=tt.step + 1;
			if (a.time >= 6)continue;
			if (mm[xx][yy] == 4) { a.time = 0; mm[xx][yy] = 0; }
			if (mm[xx][yy] == 3)return true;
			a.x = xx;
			a.y = yy;
			q.push(a);
		}
	}
	return false;
}
int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		
		cin >> n >> m;
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < m; j++)
			{
				cin >> mm[i][j];
				if (mm[i][j] == 2)
				{
					tt.x = i;
					tt.y = j;
					tt.time = 0;
					tt.step = 0;
				}
			}
		}
		if (bfs())
		{
			cout << tt.step + 1 << endl;
		}
		else
			cout << "-1" << endl;
	}
	system("pause");
	return 0;
}