// Basic Algorithm->Simulation,Basic Algorithm->Simulated Annealing (SA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define clr(a,b) memset(a,b,sizeof(a))
#define eps 1e-9
#define inf 1e99
#define MAX_N 105
typedef long long ll;
struct Point
{
    double x,y,z;
    void input()
    {
        scanf("%lf%lf%lf",&x,&y,&z);
    }
} q[MAX_N];
int n;
double dist(Point a,Point b) 
{
    return sqrt(pow(abs(a.x-b.x),2)+pow(abs(a.y-b.y),2)+pow(abs(a.z-b.z),2));
}
double Search()
{
    double ans=inf,t=100.0;
    Point s;
    int k=0;
    while(t>eps)
    {
        for(int i=0;i<n;i++)
        {
            if(dist(s,q[i])>dist(s,q[k])){k=i;}
        }
        double d=dist(s,q[k]);
        ans=min(d,ans);
        
        s.x+=(q[k].x-s.x)/d*t;
        s.y+=(q[k].y-s.y)/d*t;
        s.z+=(q[k].z-s.z)/d*t;
        t*=0.98;
    }
    return ans;
}
int main()
{
    while(~scanf("%d",&n)&&n)
    {
        double x,y;
        for(int i=0; i<n; i++)
        {
            q[i].input();
        }
        printf("%.5f\n",Search());
    }
    return 0;
}