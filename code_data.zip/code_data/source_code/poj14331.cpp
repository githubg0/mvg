// Basic Algorithm->Greedy Algorithm,Basic Algorithm->Simulation,Basic Algorithm->Simulated Annealing (SA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define N     1005
#define INF   0x3fffffff
#define eps   1e-8 
#define delta 0.98 
#define T     100  
using namespace std;
int dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
struct point{
    double x,y;
    point(){}
    point(double x,double y):x(x),y(y){}
}P[N];
double dis(point a,point b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
double getSum(point p[],int n,point t)
{
    double sum=0;
    while(n--) sum+=dis(p[n],t);
    return sum;
}
double solve(point p[],int n)
{
    point z;
    point  s   = p[0]; 
    double t   = T;    
    double ans = INF;  
    while(t>eps)
    {
        bool fuck = 1;
        while(fuck)
        {
            fuck = 0;
            for(int i=0; i<4; i++)
            {
                z.x = s.x+dir[i][0]*t;
                z.y = s.y+dir[i][1]*t;
                double tmp = getSum(p,n,z);
                if(ans>tmp)
                {
                    ans = tmp;
                    s   = z;
                    fuck= 1;
                }
            }
        }
        t*=delta;
    }
    return ans;
}
int main()
{
    int n;
    while(scanf("%d",&n)!=EOF)
    {
        for(int i=0; i<n; i++)
        {
            scanf("%lf%lf",&P[i].x,&P[i].y);
        }
        printf("%.0f\n",solve(P,n));
    }
    return 0;
}