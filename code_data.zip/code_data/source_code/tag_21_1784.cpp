// Math and Computational Geometry->Pigeonhole Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX_N = 100000, INF = 0x3f3f3f3f;
int N;
struct node
{
	int mysum, myfirst, mysecond;
	node() { mysum = 0; myfirst = INF; mysecond = INF; }
};
bool Cmp(const node &n1, const node &n2) {
	if (n1.myfirst == n2.myfirst)
		return n1.mysecond < n2.mysecond;
	else return n1.myfirst < n2.myfirst;
}
int main(){
	
	
	scanf("%d", &N);
	vector<node> mynode(N);
	int i, temp, sum = 0;
	for (i = 0; i < N; i++){
		scanf("%d", &temp);
		sum = (sum + temp) % N;
		if (0 == sum) break;
		if (0 == mynode[sum].mysum) {
			mynode[sum].mysum++;
			mynode[sum].myfirst = i + 1;
		}
		else {
			if (1 == mynode[sum].mysum) {
				mynode[sum].mysum++;
				mynode[sum].mysecond = i + 1;
			}
		}
	}
	if (0 == sum)
		printf("%d %d\n", 1, i+1);
	else {
		sort(mynode.begin(), mynode.end(), Cmp);
		for (int i = 0; i < N; i++) {
			if (2 == mynode[i].mysum) {
				printf("%d %d\n", mynode[i].myfirst + 1, mynode[i].mysecond);
				break;
			}
		}
	}
	return 0;
}