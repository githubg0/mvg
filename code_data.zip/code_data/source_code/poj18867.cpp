// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)) {if (ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    return x*f;
}
const int M=1000010;
const int N=10000; 
struct node{
    int y,next;
}data[4*N];
int h[N],num,dfn[N],low[N],stackf[N],q[N],top,s,b[N],n,m,id[N][2];
inline void insert1(int x,int y){
    data[++num].y=y;data[num].next=h[x];h[x]=num;
}
inline void tarjan(int x){
    dfn[x]=low[x]=++num;stackf[x]=1;q[++top]=x;
    for (int i=h[x];i;i=data[i].next){
        int y=data[i].y;
        if(!dfn[y]) tarjan(y),low[x]=min(low[x],low[y]);else if (stackf[y]) low[x]=min(low[x],dfn[y]);
    }
    if (dfn[x]==low[x]){
        int y;++s;
        do{y=q[top--];stackf[y]=0;b[y]=s;}while(y!=x);
    }
}
int main(){
    freopen("poj3678.in","r",stdin);
    n=read();m=read();
    for (int i=0;i<n;++i) id[i][0]=i<<1,id[i][1]=i<<1|1;
    for (int i=1;i<=m;++i){static int x,y,c;static char s[10];
        x=read();y=read();c=read();scanf("%s",s+1);
        if(s[1]=='A'){
            if(c) insert1(id[x][0],id[x][1]),insert1(id[y][0],id[y][1]);
            else insert1(id[x][1],id[y][0]),insert1(id[y][1],id[x][0]);
        }
        if (s[1]=='O'){
            if (c)insert1(id[x][0],id[y][1]),insert1(id[y][0],id[x][1]);
            else insert1(id[x][1],id[x][0]),insert1(id[y][1],id[y][0]);
        }
        if (s[1]=='X'){
            if (c){
                insert1(id[x][0],id[y][1]),insert1(id[y][0],id[x][1]);
                insert1(id[x][1],id[y][0]),insert1(id[y][1],id[x][0]);
            }else{
                insert1(id[x][0],id[y][0]),insert1(id[y][0],id[x][0]);
                insert1(id[x][1],id[y][1]),insert1(id[y][1],id[x][1]);
            }
        }
    }num=0;
    for (int i=0;i<n<<1;++i) if (!dfn[i]) tarjan(i);
    for (int i=0;i<n;++i) if (b[id[i][0]]==b[id[i][1]]) {puts("NO");return 0;}
    puts("YES");
    return 0;
}