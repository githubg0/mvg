// Graph Algorithm->Kruskal's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 5005;
const int maxm = 101;
struct node{
     int x,y,dis;
}a[maxn];
bool cmp(node p, node q){
    return p.dis<q.dis;
}
int n,i,j,k,tot,dist;
int root[maxm];
int Find(int p){
   while (p != root[p]) p=root[p];
   return p;
}
void Merge(int p, int q){
   while (p != root[p]) p=root[p];
   int z;
   while (q != root[q]) {
      z = root[q];
      root[q] = p;
      q = z;
   }
   root[q] = p;
}
void kruskal(){
    for (i=1; i<=k; i++) {
        if (Find(a[i].x) != Find(a[i].y)) {
            dist += a[i].dis;
            Merge(a[i].x,a[i].y);
        }
    }
}
int main(){
    std::ios::sync_with_stdio(false);
    while ( cin >> n && n){
        k = n*(n-1)/2;
        for (i=1; i<=k; i++) cin >> a[i].x >> a[i].y >> a[i].dis;
        for (i=1; i<=n; i++) root[i] = i;
        sort(a+1,a+k+1,cmp);
        tot = dist = 0;
        kruskal();
        for (i=1; i<=n; i++) if (root[i]==i) tot++;
        if (tot!=1) cout << 0 << endl;
        else cout << dist << endl;
    }
    return 0;
}