// Graph Algorithm->Dijkstra's Algorithm
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3fffffff
#define N 25
int dis[N],pre[N],first[N],used[N];
int n,top,len = 0,start;
struct res{
    int id,dist;
}p[N];
struct edge{
    int y,w,next;
}e[N*N];
void add(int x,int y,int w){
    e[top].y = y;
    e[top].w = w;
    e[top].next = first[x];
    first[x] = top++;
}
int cmp(struct res a,struct res b){
    return a.dist < b.dist;
}
void dijkstra(){
    int i,j,min1,now=0;
    for(i = 1;i<=n;i++)
        dis[i] = INF;
    dis[start] = 0;
    memset(used, 0, sizeof(used));
    for(i = 1;i<=n;i++){
        min1 = INF;
        for(j = 1;j<=n;j++)
            if(!used[j] && dis[j]<min1){
                min1 = dis[j];
                now = j;
            }
        used[now] = 1;
        for(j = first[now];j!=-1;j=e[j].next)
            if(!used[e[j].y] && dis[now]+e[j].w < dis[e[j].y]){
                dis[e[j].y] = dis[now]+e[j].w;
                pre[e[j].y] = now;
            }
    }
}
void print_dist(int x){
    while(x){
        printf("\t%d",x);
        x = pre[x];
    }
    putchar('\n');
}
void print(){
    int i;
    for(i = 0;i<len;i++)
        p[i].dist = dis[p[i].id];
    sort(p, p+len, cmp);                
    printf("Org\tDest\tTime\tPath\n");
    for(i = 0;i<len;i++){
        printf("%d\t%d\t%d",p[i].id,start,p[i].dist);
        print_dist(p[i].id);
    }
}
int main(){
    int i,j,w;
    scanf("%d",&n);
    memset(first, -1, sizeof(first));
    top = 0;
    for(i = 1;i<=n;i++)
        for(j = 1;j<=n;j++){
            scanf("%d",&w);
            if(w!=-1)
                add(j,i,w);
        }
    scanf("%d",&start);
    while(scanf("%d",&j) !=EOF)
        p[len++].id = j;
    dijkstra();
    print();
    return 0;
}