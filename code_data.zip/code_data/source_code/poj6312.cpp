// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define edl putchar('\n')
#define ll long long
#define clr(a,b) memset(a,b,sizeof a)
#define rep(i,m,n) for(int i=m ; i<=n ; i++)
#define fep(i,n) for(int i=0 ; i<n ; i++)
inline int read() { int x=0;char c=getchar();while(c<'0' || c>'9')c=getchar();while(c>='0' && c<='9'){ x=x*10+c-'0';c=getchar(); }return x;}
#define read read()
using namespace std;
struct node {
    node *ch[10];
    bool end1;
    node() {
        end1 = false;
        fep(i,10) ch[i] = NULL;
    }
} *root;
bool insert(string s) {
    int len = int(s.length());
    node *t = root;
    fep(i,len) {
        int c = s[i] - '0';
        if(t->ch[c] == NULL) t->ch[c] = new node;
        else if(t->ch[c]->end1) return false;
        t = t->ch[c];
    }
    t->end1 = true;
    return true;
}
void clear(node *t = root) {
    if(t == NULL) return ;
    fep(i,10) clear(t->ch[i]);
    delete(t);
    t = NULL;
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("in.txt","r",stdin);
#endif
    int t = read, n;
    string s[10007];
    while(t--) {
        bool flag = true;
        clear();
        root = new node;
        n = read;
        fep(i,n) cin >> s[i];
        sort(s, s+n);
        fep(i,n) {
            if(!insert(s[i])) flag = false;
        }
        if(flag) puts("YES");
        else puts("NO");
    }
    return 0;
}