// Math and Computational Geometry->Inverse Element,Basic Algorithm->Memorization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 30040
#define mod 1000000007
int n,m,pos[maxn],a[maxn];
long long int num[maxn],ans,ppow[maxn];
long long int fast_pow(long long int x,long long int p)
{
    if(ppow[x]!=-1)return ppow[x];
    long long int ans=1,k=x;
    while(p>0)
    {
        if(p&1)ans*=x;
        x*=x;
        x%=mod;
        ans%=mod;
        p>>=1;
    }
    ppow[k]=ans;
    return ans;
}
struct mo
{
    int l;int r;int id;long long int ans;
}p[maxn];
bool mo_cmp(mo a,mo b)
{
    return pos[a.l]==pos[b.l] ? a.r<b.r : a.l<b.l;
}
bool id_cmp(mo a,mo b)
{
    return a.id<b.id;
}
int main()
{
    int t;
    scanf("%d",&t);
    memset(ppow,-1,sizeof(ppow));
    while(t--)
    {
        scanf("%d%d",&n,&m);
        int unit=sqrt(n);
        memset(num,0,sizeof(num));
        ans=1;
        for(int i=0;i<=n;i++)pos[i]=i/unit;
        for(int i=1;i<=n;i++)scanf("%d",&a[i]);
        for(int i=0;i<m;i++)
        {
            scanf("%d%d",&p[i].l,&p[i].r);
            p[i].id=i;
        }
        sort(p,p+m,mo_cmp);
        int l=1,r=0;
        for(int i=0;i<m;i++)
        {
            while(r<p[i].r)
            {
                r++;num[a[r]]++;
                ans*=(r-l+1);ans%=mod;
                ans*=fast_pow( num[a[r]] , mod-2 );ans%=mod;
            }
            while(l>p[i].l)
            {
                l--;num[a[l]]++;
                ans*=(r-l+1);ans%=mod;
                ans*=fast_pow( num[a[l]] , mod-2 );ans%=mod;
            }
            while(l<p[i].l)
            {
                ans*=fast_pow( (long long int )(r-l+1) , mod-2 );ans%=mod;
                ans*=num[a[l]];ans%=mod;
                num[a[l]]--;l++;
            }
            while(r>p[i].r)
            {
                ans*=fast_pow( (long long int )(r-l+1) , mod-2 );ans%=mod;
                ans*=num[a[r]];ans%=mod;
                num[a[r]]--;r--;
            }
            p[i].ans=ans%mod;
        }
        sort(p,p+m,id_cmp);
        for(int i=0;i<m;i++)
        {
            printf("%lld\n",p[i].ans);
        }
    }
}