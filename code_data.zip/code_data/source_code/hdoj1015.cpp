// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 1e5+10;
typedef pair<int,int>p;
vector<p >vec[maxn];
int vis[maxn];
int main(){
    int n,m,u,v,val;
    scanf("%d%d",&n,&m);
    memset(vis,0,sizeof(vis));
    for(int i = 1;i <= m;i++){
        scanf("%d%d%d",&u,&v,&val);
        vec[u].push_back(p(val,v));
        vec[v].push_back(p(val,u));
    }
    priority_queue<p,vector<p>,greater<p> >pq;
    vis[1] = 1;
    for(int i = 0;i < vec[1].size();i++){
        pq.push(vec[1][i]);
    }
    int ans = 0;
    while(!pq.empty()){
        p now = pq.top();
        pq.pop();
        if(!vis[now.second]){
            vis[now.second] = 1;
            ans += now.first;
            for(int i = 0;i < vec[now.second].size();i++){
                if(!vis[vec[now.second][i].second])
                    pq.push(vec[now.second][i]);
            }
        }
    }
    printf("%d\n",ans);
}