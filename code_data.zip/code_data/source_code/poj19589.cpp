// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

    
    
    
    
    using namespace std;
    #define MAXN 40000
    int n,m,ans,in,out;
    int fa[500],f[500];
    bool flag;
    struct Edge{
        int a,b,len;
    }edge[MAXN];
    int find(int x)
    {
        if(x!=fa[x])
            fa[x]=find(fa[x]);
        return fa[x];
    }
    bool cmp(Edge a,Edge b)
    {
        return a.len<b.len;
    }
    int main()
    {
        while(scanf("%d",&n)!=EOF&&n)
        {
            int num=0;
            memset(f,0,sizeof(f));
            for(int i=0;i<n;i++)
            {
                scanf("%d",&in);
                f[i+1]-=in;
            }
            for(int i=0;i<n;i++)
            {
                scanf("%d",&out);
                f[i+1]+=out;
                if(f[i+1]<0)num++;
            }
            scanf("%d",&m);
            int a,b,c;
            for(int i=0;i<m;i++)
            {
                scanf("%d%d%d",&a,&b,&c);
                edge[i].a=a;
                edge[i].b=b;
                edge[i].len=c;
            }
            sort(edge,edge+m,cmp);
            int f1,f2;
            for(int i=0;i<=n;i++)
                fa[i]=i;
            flag=false;
            for(int i=0;i<m;i++)
            {
                f1=find(edge[i].a);
                f2=find(edge[i].b);
                if(f1!=f2)
                    {
                        fa[f1]=f2;
                        f[f2]+=f[f1];
                        if(f[f2]>=0)
                        {
                            if(f[f2]-f[f1]<0||f[f1]<0)
                                num--;
                        }
                        else if(f[f2]<0)
                        {
                            if(f[f2]-f[f1]<0&&f[f1]<0)
                                num--;
                        }
                        if(num==0)
                        {
                                flag=true;
                                ans=edge[i].len;
                        }
                    }
                if(flag)
                    break;
            }
            if(flag)
                printf("%d\n",ans);
            else
                printf("No Solution\n");
        }
        return 0;
    }