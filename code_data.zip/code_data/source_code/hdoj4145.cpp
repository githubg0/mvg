// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define M mp[f.x][f.y][f.z]
#define N vis[f.x][f.y][f.z]
#define P f.x>=0&&f.x<a
#define Q f.y>=0&&f.y<b
#define R f.z>=0&&f.z<c
int mp[51][51][51];
int vis[51][51][51];
int ta,tb,tc,a,b,c,sum;
struct node
{
    int x;
    int y;
    int z;
    int ans;
}ls[400010],t,f;
int bhx[]={1,-1,0,0,0,0};
int bhy[]={0,0,1,-1,0,0};
int bhz[]={0,0,0,0,1,-1};
void bfs(int u,int v,int w)
{
    int top=0,tl=0,i;
    t.x=u,t.y=v,t.z=w,t.ans=0;
    ls[top++]=t;
    vis[t.x][t.y][t.z]=1;
    while(tl<top)
    {
        t=ls[tl++];
        if(t.x==ta&&t.y==tb&&t.z==tc)
        {
            if(t.ans<sum)
            {
                printf("%d\n",t.ans);
            }
            else
            {
                printf("-1\n");
            }
            return ;
        }
        for(i=0;i<6;i++)
        {
            f.x=t.x+bhx[i];
            f.y=t.y+bhy[i];
            f.z=t.z+bhz[i];
            if(M==0&&N==0&&P&&Q&&R)
            {
                f.ans=t.ans+1;
                ls[top++]=f;
                N=1;
            }
        }
    }
    printf("-1\n");
    return ;
}
int main()
{
    int i,j,k,t;
    scanf("%d",&t);
    while(t--)
    {
        memset(vis,0,sizeof(vis));
        scanf("%d%d%d%d",&a,&b,&c,&sum);
        ta=a-1,tb=b-1,tc=c-1;
        for(i=0;i<a;i++)
        {
            for(j=0;j<b;j++)
            {
                for(k=0;k<c;k++)
                {
                    scanf("%d",&mp[i][j][k]);
                }
            }
        }
        bfs(0,0,0);
    }
    return 0;
}
