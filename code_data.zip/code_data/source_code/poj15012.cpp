// Data Structure->Stack,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
stack<int>s;
int dir[8][2]={{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
int t,p,q,matrix[8][8];
bool flag=false;
bool check(){
    for(int i=1; i<=q; i++)
        for(int j=1; j<=p; j++)if(!matrix[i][j])return false;
    return true;
}
void dfs(int x,int y){
    if(flag)return;
    bool tmp=false;
    matrix[x][y]=1;
    for(int i=0; i<8; i++){
        int a=x+dir[i][0];
        int b=y+dir[i][1];
        if(a>=1&&a<=q&&b>=1&&b<=p&&matrix[a][b]==0)
        {
           dfs(a,b);
           matrix[a][b]=0;
           tmp=true;
        }
    }
    if(!tmp&&check())flag=true;
    if(flag){ s.push(y); s.push(x); }
}
int main(){
    scanf("%d",&t);
    for(int i=1;i<=t;i++){
         scanf("%d %d",&p,&q);
         memset(matrix,0,sizeof(matrix));
         flag=false;
         dfs(1,1);
         printf("Scenario #%d:\n",i);
         if(flag){
             while(!s.empty()){
                 char r=s.top()-1+'A';
                 s.pop();
                 printf("%c%d",r,s.top());
                 s.pop();
             }
             printf("\n");
         }
         else
             printf("impossible\n");
         if(i!=t)printf("\n"); 
    }
    return 0;
}