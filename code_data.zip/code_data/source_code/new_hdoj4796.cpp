// Data Structure->Trie,Data Structure->Aho-Corasick Algorithm
#include<algorithm>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1000000+5,maxm=50+5; 
int n,cas,tot,head,tail,q[500000+5];
char s[maxn],word[maxm];
struct trie{
  int cnt,fail,nxt[26];
}tr[500000+5];
inline void init(void){
    for(int i=0;i<=tot;tr[i].fail=-1,tr[i].cnt=0,i++)
        for(int j=0;j<26;j++)
            tr[i].nxt[j]=0;
    tot=0;
}
inline void insert(char *word){
    int p=0,len=strlen(word);
    for(int i=0;i<len;i++){
        if(!tr[p].nxt[word[i]-'a'])
            tr[p].nxt[word[i]-'a']=++tot;
        p=tr[p].nxt[word[i]-'a'];
    }
    tr[p].cnt++;
}
inline void buildACM(void){
    head=0,tail=0;q[0]=0;
    while(head<=tail){
        int id=q[head++],p=-1;
        for(int i=0;i<26;i++)
            if(tr[id].nxt[i]){
                if(id){
                    p=tr[id].fail;
                    while(p!=-1){
                        if(tr[p].nxt[i]){
                            tr[tr[id].nxt[i]].fail=tr[p].nxt[i];
                            break;
                        }
                        p=tr[p].fail;
                    }
                    if(p==-1) tr[tr[id].nxt[i]].fail=0;
                }
                else
                    tr[tr[id].nxt[i]].fail=0;
                q[++tail]=tr[id].nxt[i];
            }
    }
}
inline int query(void){
    int i=0,ans=0,index,len=strlen(s),p=0;
    while(s[i]){
        index=s[i]-'a';
        while(!tr[p].nxt[index]&&p) p=tr[p].fail;
        p=tr[p].nxt[index];
        int tmp=p;
        while(tmp&&tr[tmp].cnt!=-1)
            ans+=tr[tmp].cnt,tr[tmp].cnt=-1,tmp=tr[tmp].fail;
        i++;
    }
    return ans;
}
signed main(void){
    scanf("%d",&cas);
    while(cas--){
        tot=500000;init();
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
            scanf("%s",word),insert(word);
        buildACM();
        scanf("%s",s);
        printf("%d\n",query());
    }
    return 0;
}