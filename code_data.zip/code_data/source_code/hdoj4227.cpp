// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
using namespace std;
typedef long long ll;
const ll INF=1e12;
const int MAXN=1e6+5;
int trie[MAXN][27];
int cnt[MAXN],tot=1;
void iinsert(char *str)
{
    int len=strlen(str),p=0;
    for(int i=0;i<len;i++){
        int ch=str[i]-'a';
        if(!trie[p][ch])
            trie[p][ch]=++tot;
        p=trie[p][ch];
    }
    cnt[p]++;
}
int isearch(char *str)
{
    int ans=0;
    int len=strlen(str),p=0;
    for(int i=0;i<len;i++)
    {
        int ch=str[i]-'a';
        p=trie[p][ch];
        if(!p)
            return ans;
         ans+=cnt[p];
    }
    return ans;
}
int main()
{
    char s[MAXN];
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%s",s);
        iinsert(s);
    }
    for(int i=1;i<=m;i++){
        scanf("%s",s);
        printf("%d\n",isearch(s));
    }
    return 0;
}