// Graph Algorithm->Hamilton Circuit / Hamilton Path
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1e4+5;
const int maxm=1e5+5;
int n,m,start;
int first[maxn];
int from[2*maxm],to[2*maxm];
int nxt[2*maxm];
int deg[maxn];
int len[maxn];
bool vis[maxn];
int two[maxn];
int ans[maxn],alen;
void addedge(int f,int t,int ind){
        nxt[ind]=first[f];
        to[ind]=t;
        from[ind]=f;
        first[f]=ind;
        deg[f]++;
}
void collect(int s,int f){
        vis[s]=true;
        for(int p=first[s];p!=0;p=nxt[p]){
                int t=to[p];
                if(deg[t]==2){
                        two[s]=t;
                }
                else if(deg[t]>2){
                        if(!vis[t]){
                                collect(t,f);
                        }
                }
        }
        len[f]++;
}
void dfs(int s,bool in){
        vis[s]=true;
     
        if(deg[s]>2&&!vis[two[s]]){
                dfs(two[s],false);
        }
        for(int p=first[s];p!=0;p=nxt[p]){
                int t=to[p];
                if(vis[t])continue;
                if(deg[s]==2){
                        dfs(t,false);
                }
                else if(!in&&deg[t]>2){
                        dfs(t,true);
                }
        }
        ans[alen++]=s;
    
}
int main(){
        scanf("%d%d",&n,&m);
        for(int i=1;i<=m;i++){
                int f,t;
                scanf("%d %d",&f,&t);
                addedge(f,t,2*i);
                addedge(t,f,2*i+1);
        }
        for(int i=1;i<=n;i++){
                if(deg[i]>2&&!vis[i]){
                        collect(i,i);
                        if((len[i]&1)!=0){
                                puts("-1");
                                return 0;
                        }
                }
        }
        memset(vis,0,sizeof(vis));
        dfs(1,0);
        if(alen!=n){
                puts("-1");
                return 0;
        }
        for(int i=0;i<n;i++){
                printf("%d ",ans[i]);
        }
        puts("");
        return 0;
}