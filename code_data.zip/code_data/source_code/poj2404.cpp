// Math and Computational Geometry->Convex Hull Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double eps = 1e-8;
struct Point
{
    double x, y;
} pnt[1005];
int stk[1005], top;
int dblcmp(double k)
{
    if (fabs(k) < eps) return 0;
    return k > 0 ? 1 : -1;
}
double multi(Point p0, Point p1, Point p2)
{
    return (p1.x-p0.x)*(p2.y-p0.y)-(p1.y-p0.y)*(p2.x-p0.x);
}
double getDis(Point a, Point b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
bool cmp(const Point& a, const Point& b)
{
    int d = dblcmp(multi(pnt[0], a, b));
    if (!d) return getDis(pnt[0], a) < getDis(pnt[0], b);
    return d > 0;
}
int main()
{
    int t, n, i, k;
    double tx, ty;
    scanf ("%d", &t);
    while (t--)
    {
        scanf ("%d", &n);
        scanf ("%lf%lf", &pnt[0].x, &pnt[0].y);
        tx = pnt[0].x;
        ty = pnt[0].y;
        k = 0;
        for (i = 1; i < n; i++)
        {
            scanf ("%lf%lf", &pnt[i].x, &pnt[i].y);
            int d = dblcmp(ty-pnt[i].y);
            if (d > 0)
            {
                k = i;
                tx = pnt[i].x;
                ty = pnt[i].y;
            }
            else if (!d && dblcmp(tx-pnt[i].x) > 0)
            {
                k = i;
                tx = pnt[i].x;
            }
        }
        pnt[k].x = pnt[0].x;
        pnt[k].y = pnt[0].y;
        pnt[0].x = tx;
        pnt[0].y = ty;
        sort(pnt+1, pnt+n, cmp);
        stk[0] = 0;
        stk[1] = 1;
        top = 1;
        for (i = 2; i < n; i++)
        {
            while (top >= 1 && dblcmp(multi(pnt[stk[top-1]], pnt[i], pnt[stk[top]])) >= 0) top--;
            stk[++top] = i;
        }
        if (top <= 1)
        {
            printf ("NO\n");
            continue;
        }
        bool flag = false;
        for (i = 1; i <= top; i++)
            if (stk[i]-stk[i-1] == 1)
            {
                flag = true;
                break;
            }
        for (i = 1; i < n-1; i++)
            if (!dblcmp(multi(pnt[0], pnt[i], pnt[n-1])))
                break;
        if (!flag && i < n-1)
            printf ("YES\n");
        else printf ("NO\n");
    }
    return 0;
}