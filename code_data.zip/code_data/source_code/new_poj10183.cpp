// Data Structure->Stack
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int sigma_size=26;
const int MAXN=100000+100;
const double eps=1e-8;
const int inf=0x3fffffff;
const int mod=1000000000+7;
#define L(x) (x<<1)
#define R(x) (x<<1|1)
int n;
struct node{
	int w,h;
}p[MAXN];
stack<node>s;
int main()
{
	while(~scanf("%d",&n) && n!=-1){
		for(int i=1;i<=n;i++)
			scanf("%d%d",&p[i].w,&p[i].h);
		int ans=0;
		for(int i=1;i<=n;i++){
			if(s.empty())
				s.push(p[i]);
			else{
				node temp=s.top();
				if(p[i].h>temp.h)
					s.push(p[i]);
				else{
					int len=0;
					while(!s.empty() && s.top().h>=p[i].h){
						temp=s.top(); s.pop();
						len+=temp.w;
						ans=max(ans,len*temp.h);
					}
					temp.w=len+p[i].w;
					temp.h=p[i].h;
					s.push(temp);
				}
			}
		}
		int len=0;
		while(!s.empty()){
			node temp=s.top(); s.pop();
			len+=temp.w;
			ans=max(ans,len*temp.h);
		}
		printf("%d\n",ans);
	}
	return 0;
}