// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 10000 + 5;
typedef struct PRO
{
    int p, d;
}pro;
int cmp(pro a, pro b)
{
    if (a.p == b.p) return a.d > b.d;
    return a.p > b.p;
}
int main()
{
    
    int n, flag[maxn], mi, k;
    pro product[maxn];
    __int64_t sum;
    while (cin >> n) {
        memset (product, 0, sizeof(product));
        memset (flag, 0, sizeof(flag));
        sum = 0;
        for (int i = 0; i < n; i++) {
            cin >> product[i].p >> product[i].d;
        }
        sort (product, product + n, cmp);
        for (int i = 0; i < n; i++) {
            if (!flag[product[i].d]) {
                flag[product[i].d] = 1;
                sum += product[i].p;
            } else {
                for (int j = product[i].d - 1; j > 0; j--) {
                    if (!flag[j]) {
                        flag[j] = 1;
                        sum += product[i].p;
                        break;
                    }
                }
            }
        }
        cout << sum << endl;
    }
    return 0;
}