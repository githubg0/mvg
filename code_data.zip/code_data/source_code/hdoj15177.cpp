// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x7fffffff
#define max3(a,b,c) (max(a,b)>c?max(a,b):c)
#define min3(a,b,c) (min(a,b)<c?min(a,b):c)
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
#define N 2000
int dp[N][N];
int editdis(char AA[], char BB[], int la, int lb)
{
    for(int i = 0; i < la; ++i)
        dp[i][0] = i;
    for(int i = 0; i < lb; ++i)
        dp[0][i] = i;
    for(int i = 1; i <= la; ++i)
    {
        for(int j = 1; j <= lb; ++j)
        {
            int cost = 0;
            if(AA[i-1] == BB[j-1])
                cost = 0;
            else
                cost = 1;
            dp[i][j] = min(min(dp[i-1][j-1] + cost, dp[i-1][j] + 1), dp[i][j-1] + 1);
        }
    }
    return dp[la][lb];
}
char A[N][50];
char B[N];
int t;
int n, m;
int LLE;
int main()
{
    scanf("%d", &t);
    int cnt = 0;
    while(t--)
    {
        cnt++;
        scanf("%d%d", &n, &m);
        for(int i = 0; i < n; ++i)
            scanf("%s", A[i]);
        printf("Case #%d:\n", cnt);
        for(int i = 0; i < m; ++i)
        {
            int ans = 0;
            scanf("%s%d", B, &LLE);
            int lb = strlen(B);
            for(int j = 0; j < n; ++j)
            {
                int la = strlen(A[j]);
                if(abs(la - lb) <= LLE)
                {
                    int tp = editdis(A[j], B, la, lb);
                    if(tp <= LLE)
                        ans ++;
                }
            }
            printf("%d\n", ans);
        }
    }
}