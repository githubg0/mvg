// Basic Algorithm->Binary Search,Sorting->Quick Sort,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<algorithm>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
#define Mn 1010
#define Mm 2000005
#define mod 1000000007
#define CLR(a,b) memset((a),(b),sizeof((a)))
#define CLRS(a,b,Size) memset((a),(b),sizeof((a[0]))*(Size+1))
#define CPY(a,b) memcpy ((a), (b), sizeof((a)))
#pragma comment(linker, "/STACK:102400000,102400000")
#define ul u<<1
#define ur (u<<1)|1
using namespace std;
typedef long long ll;
const double eps=1e-6;
struct edge {
    int v,next;
    double w;
}e[Mm];
int tot,head[Mn];
void addedge(int u,int v,double w) {
    e[tot].v=v;
    e[tot].w=w;
    e[tot].next=head[u];
    head[u]=tot++;
}
double dis[Mn],a[Mn];
int vis[Mn],st,n;
bool dfs(int u,double x) {
    vis[u]=st;
    for(int i=head[u];~i;i=e[i].next) {
        int v=e[i].v;
        if(dis[v]>dis[u]+e[i].w*x-a[u]) {
            dis[v]=dis[u]+e[i].w*x-a[u];
            if(vis[v]==st) return true;
            if(dfs(v,x)) return true;
        }
    }
    vis[u]=0;
    return false;
}
bool check(double x) {
    CLR(vis,0);
    CLR(dis,0);
    for(st=1;st<=n;st++) {
        if(dfs(st,x)) return true;
    }
    return false;
}
int main() {
    int m,u,v;
    double w;
    while(~scanf("%d%d",&n,&m)) {
        CLR(head,-1);tot=0;
        for(int i=1;i<=n;i++){
            scanf("%lf",&a[i]);
        }
        for(int i=0;i<m;i++) {
            scanf("%d%d%lf",&u,&v,&w);
            addedge(u,v,w);
        }
        double l=0.0,r=10000.0;
        while((r-l)>eps) {
            double mid=(l+r)/2;
            if(check(mid)) l=mid;
            else r=mid;
        }
        printf("%.2f\n",l);
    }
    return 0;
}