// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#pragma comment(linker, "/STACK:1024000000,1024000000")
#define eps 1e-10
#define inf 0x3f3f3f3f
#define PI pair<int, int>
typedef long long LL;
const int maxn = 2e4 + 5;
int head[maxn], kill[maxn];
int main() {
	int n, m;
	while(scanf("%d%d", &n, &m) == 2 && n && m) {
		for(int i = 0; i < n; ++i) scanf("%d", &head[i]);
		for(int i = 0; i < m; ++i) scanf("%d", &kill[i]);
		sort(head, head + n);
		sort(kill, kill + m);
		int cnt = 0, cost = 0;
		for(int i = 0; i < m; ++i) {
			if(kill[i] >= head[cnt]) {
				++cnt;
				cost += kill[i];
				if(cnt >= n) break;
			}
		}
		if(cnt < n) printf("Loowater is doomed!\n");
		else printf("%d\n", cost);
	}
	return 0;
}