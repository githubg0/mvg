// Sorting->Topological Sort
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int nodeRelation[100][100];
int inDegree[100];
int topSort(int N);
int main()
{
	int N, M;
	int master, prentice;
	int i;
	int result;
	scanf("%d%d", &N, &M);
	while (N != 0)
	{
		memset(nodeRelation, 0, sizeof(nodeRelation));
		memset(inDegree, 0, sizeof(inDegree));
		for (i = 0; i < M; i ++)
		{
			scanf("%d%d", &master, &prentice);
			
			if (nodeRelation[master][prentice] == 0)
			{
				nodeRelation[master][prentice] = 1;
				inDegree[prentice] ++;
			}
		}
		result = topSort(N);
		if (result == 1)
			printf("YES\n");
		else
			printf("NO\n");
		scanf("%d%d", &N, &M);
	}
	return 0;
}
int topSort(int N)
{
	int i, j, k;
	for (i = 0; i < N; i ++)
	{
		for (j = 0; j < N; j ++)
		{
			if (inDegree[j] == 0)
			{
				inDegree[j] --;
				for (k = 0; k < N; k ++)
				{
					if (nodeRelation[j][k] == 1)
						inDegree[k] --;
				}
				break;
			}
		}
		if (j == N)
			return 0;
	}
	return 1;
}