// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXNODE 25
#define MAXCOST 9999
using namespace std;
int main()
{
    void InputCost(int Cost[][MAXNODE]);
    void Dijkstra(int Cost[][MAXNODE],int f,int Distance[],int e);
    int Cost[MAXNODE][MAXNODE];
    int cnt;
    int kkk = 0; 
    int n,k;
    int i,f,e,Distance[MAXNODE];
    while(cin>>n)  
   {
        memset(Cost,0x3f,sizeof(Cost));
        while(n--)
        {
            cin>>k;
            Cost[1][k] = 1;
            Cost[k][1] = 1;
        }
        InputCost(Cost);
        cin>>cnt; 
        ++kkk;
        printf("Test Set #%d\n",kkk);
        while(cnt--)
        {
            cin>>f>>e;
            Dijkstra(Cost,f,Distance,e);
        }
        putchar(10);
   }
    return 0;
}
void InputCost(int Cost[][MAXNODE]) 
{
    int n,k;
    for(int i = 2 ; i <= 19 ; i++)
    {
        scanf("%d",&n);
        for(int j = 0 ; j < n ; j++)
        {
            scanf("%d",&k);
            Cost[i][k] = 1;
            Cost[k][i] = 1;
        }
    }
}
void Dijkstra(int Cost[][MAXNODE],int f,int Distance[],int e)
{
    int s[MAXNODE];
    int mindis,dis;
    int i,j,u;
    for(i=1;i<=20;i++)   
    {
        Distance[i]=Cost[f][i];
        s[i]=0;
    }
    s[f]=1;   
    for(i=1;i<=20;i++)
    {
        mindis=MAXCOST;
        for(j=1;j<=20;j++)
        {
            if(s[j]==0 && Distance[j]<mindis)  
            {
                u=j;
                mindis=Distance[j];
            }
        }
        s[u]=1;   
        for(j=1;j<=20;j++)
        {
            if(s[j]==0)
            {
                dis=Distance[u]+Cost[u][j];
                Distance[j]=(Distance[j]<dis)?Distance[j]: dis;   
            }
        }
    }
    printf("%d to %d: %d\n",f,e,Distance[e]);
}