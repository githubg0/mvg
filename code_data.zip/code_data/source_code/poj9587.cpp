// Basic Algorithm->Breadth First Search (BFS),Data Structure->Queue,Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 800000
using namespace std;
struct T
{
	int num1,num2,step;
}q[MAXN];
bool vis[20500][105];
int n;
int head,tail;
bool add(int num1,int num2,int step)
{
	if(num1 == n||num2 == n)
	{
		return true;
	}
	if(num1 < num2)
		swap(num1,num2);
		if(num1 == num2||num1 >= n + 101|| num2 >= 101)
		return false;
	if(!vis[num1][num2])
	{
		vis[num1][num2] = 1;
		tail++;
		q[tail].num1 = num1;
		q[tail].num2 = num2;
		q[tail].step = step;
	}
	return false;
}
int main()
{
	scanf("%d",&n);
	head = tail = -1;
	add(1,0,0);
	int num1,num2,step;
	int ans;
	while(head < tail)
	{
		++head;
		num1 = q[head].num1,num2 = q[head].num2,step = q[head].step + 1;
		if(add(num1+num1,num2,step) || add(num1,num2+num2,step) || add(num1,num1+num2,step) || add(num2,num1+num2,step) || add(num1,num1+num1,step) || add(num2,num2+num2,step) || add(num1 - num2,num2,step) || add(num1,num1 - num2,step))
		{
			ans = step;
			break;
		}
	}
	printf("%d\n",ans);
}