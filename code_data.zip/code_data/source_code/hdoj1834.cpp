// Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define max_n 10010
typedef long long LL;
using namespace std;
int p[max_n],k;
void getp(int n)
{
	k=0;
	for(int i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
			p[k++]=i; 
			while(n%i==0)
				n/=i;
		}
	}
	if(n>1) p[k++]=n; 
}
int nop(int m) 
{
	int top=0,sum=0;
	int que[max_n];
	que[top++]=-1;  
	for(int i=0;i<k;i++)
	{
		int t=top;
		for(int j=0;j<t;j++)
			que[top++]=que[j]*p[i]*(-1); 
	}
	for(int i=1;i<top;i++)
		sum+=m/que[i]; 
	return sum; 
}
int main()
{
	int n,m,t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		LL ans=n;
		for(int i=2;i<=m;i++)
		{
			getp(i);
			ans+=n-nop(n);
		}
		printf("%lld\n",ans);
	}
	return 0;
}