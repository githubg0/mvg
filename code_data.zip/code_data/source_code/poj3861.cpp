// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 10000
bool is_prime[maxn];
bool vis[maxn];
int num[maxn];
int start,end1;
int n;
void bfs(int x)
{
    queue<int>P;
    P.push(x);
    while(!P.empty())
    {
        int t=P.front();
        if(t==end1)
            return ;
        vis[t]=true;
        P.pop();
        char ch[5];
        sprintf(ch,"%d",t);
        for(int j=0;j<4;j++)
        {
            for(int k=0;k<10;k++)
            {
                int temp;
                if(j==0&&k==0)
                    continue;
                if(j==0)
                    temp=k*1000+(ch[1]-'0')*100+(ch[2]-'0')*10+(ch[3]-'0');
                else if(j==1)
                    temp=k*100+(ch[0]-'0')*1000+(ch[2]-'0')*10+(ch[3]-'0');
                else if(j==2)
                    temp=k*10+(ch[0]-'0')*1000+(ch[1]-'0')*100+(ch[3]-'0');
                else if(j==3)
                    temp=k+(ch[0]-'0')*1000+(ch[1]-'0')*100+(ch[2]-'0')*10;   
                if(is_prime[temp]&&!vis[temp]&&temp<10000)
                {
                    num[temp]=num[t]+1;
                    vis[temp]=true;
                    P.push(temp);
                } 
            }
        }
    }
}
int main()
{
    for(int i=0;i<10000;i++)
        is_prime[i]=true;
    is_prime[0]=is_prime[1]=false; 
    for(int i=2;i<100;i++)
        if(is_prime[i])
            for(int j=2;i*j<10000;j++)
                is_prime[i*j]=false;
    cin>>n;
    while(n--)
    {
        cin>>start>>end1;
        memset(vis,false,sizeof(vis));
        memset(num,0,sizeof(num));
        bfs(start);
        if(num[end1]==0&&start!=end1)
            cout<<"impossible"<<endl;
        else
            cout<<num[end1]<<endl;
    }
    return 0;
}