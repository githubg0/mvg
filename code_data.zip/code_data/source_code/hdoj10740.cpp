// Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
#define REP( i , a , b ) for ( int i = a ; i < b ; ++ i )
#define REV( i , a , b ) for ( int i = a - 1 ; i >= b ; -- i )
#define FOR( i , a , b ) for ( int i = a ; i <= b ; ++ i )
#define FOV( i , a , b ) for ( int i = a ; i >= b ; -- i )
#define CLR( a , x ) memset ( a , x , sizeof a )
#define CPY( a , x ) memcpy ( a , x , sizeof a )
const int MAXN = 1050 ;
const int MAXQ = 500005 ;
const int MAXE = 500005 ;
const int INF = 0x3f3f3f3f ;
struct Edge {
	int v , c , n ;
	Edge () {}
	Edge ( int v , int c , int n ) : v ( v ) , c ( c ) , n ( n ) {}
} ;
struct Line {
	int u , v , c ;
	Line () {}
	Line ( int u , int v , int c ) : u ( u ) , v ( v ) , c ( c ) {}
} ;
struct NetWork {
	Edge E[MAXE] ;
	int H[MAXN] , cntE ;
	int d[MAXN] , cur[MAXN] , num[MAXN] , pre[MAXN] ;
	int Q[MAXQ] , head , tail ;
	int s , t , nv , flow ;
	int n , m , k ;
	
	Line L[MAXE] ;
	int color[MAXN] ;
	int ans[MAXE] ;
	int cnt ;
	
	void init () {
		cntE = 0 ;
		CLR ( H , -1 ) ;
	}
	
	void addedge ( int u , int v , int c ) {
		E[cntE] = Edge ( v , c , H[u] ) ;
		H[u] = cntE ++ ;
		E[cntE] = Edge ( u , 0 , H[v] ) ;
		H[v] = cntE ++ ;
	}
	
	void rev_bfs () {
		CLR ( d , -1 ) ;
		CLR ( num , 0 ) ;
		head = tail = 0 ;
		Q[tail ++] = t ;
		d[t] = 0 ;
		num[d[t]] = 1 ;
		while ( head != tail ) {
			int u = Q[head ++] ;
			for ( int i = H[u] ; ~i ; i = E[i].n ) {
				int v = E[i].v ;
				if ( ~d[v] )
					continue ;
				d[v] = d[u] + 1 ;
				Q[tail ++] = v ;
				num[d[v]] ++ ;
			}
		}
	}
	int ISAP () {
		CPY ( cur , H ) ;
		rev_bfs () ;
		flow = 0 ;
		int u = pre[s] = s , i ;
		while ( d[s] < nv ) {
			if ( u == t ) {
				int f = INF , pos ;
				for ( i = s ; i != t ; i = E[cur[i]].v )
					if ( f > E[cur[i]].c ) {
						f = E[cur[i]].c ;
						pos = i ;
					}
				for ( i = s ; i != t ; i = E[cur[i]].v ) {
					E[cur[i]].c -= f ;
					E[cur[i] ^ 1].c += f ;
				}
				flow += f ;
				u = pos ;
			}
			for ( i = cur[u] ; ~i ; i = E[i].n )
				if ( E[i].c && d[u] == d[E[i].v] + 1 )
					break ;
			if ( ~i ) {
				cur[u] = i ;
				pre[E[i].v] = u ;
				u = E[i].v ;
			}
			else {
				if ( 0 == ( -- num[d[u]] ) )
					break ;
				int mmin = nv ;
				for ( i = H[u] ; ~i ; i = E[i].n )
					if ( E[i].c && mmin > d[E[i].v] ) {
						cur[u] = i ;
						mmin = d[E[i].v] ;
					}
				d[u] = mmin + 1 ;
				num[d[u]] ++ ;
				u = pre[u] ;
			}
		}
		return flow ;
	}
	
	void bfs () {
		CLR ( color , 0 ) ;
		head = tail = 0 ;
		Q[tail ++] = s ;
		color[s] = 1 ;
		while ( head != tail ) {
			int u = Q[head ++] ;
			for ( int i = H[u] ; ~i ; i = E[i].n ) {
				if ( color[E[i].v] || !E[i].c )
					continue ;
				color[E[i].v] = 1 ;
				Q[tail ++] = E[i].v ;
			}
		}
	}
	
	void solve () {
		int sum = 0 ;
		int u , v , c ;
		scanf ( "%d%d%d" , &n , &m , &k ) ;
		s = 1 ;
		t = n + 1 ;
		nv = t + 1 ;
		init () ;
		FOR ( i , 1 , m ) {
			scanf ( "%d%d%d" , &u , &v , &c ) ;
			L[i] = Line ( u , v , c ) ;
			addedge ( u , v , c ) ;
		}
		FOR ( i , 1 , k ) {
			scanf ( "%d%d" , &v , &c ) ;
			addedge ( v , t , c ) ;
			sum += c ;
		}
		ISAP () ;
		printf ( "%d\n" , sum - flow ) ;
		bfs () ;
		cnt = 0 ;
		FOR ( i , 1 , m )
			if ( color[L[i].u] && !color[L[i].v] )
				ans[cnt ++] = i ;
		printf ( "%d" , cnt ) ;
		REP ( i , 0 , cnt )
			printf ( " %d" , ans[i] ) ;
		printf ( "\n" ) ;
	}
} x ;
int main () {
	int T , cas = 0 ;
	scanf ( "%d" , &T ) ;
	while ( T -- ) {
		printf ( "Case %d: " , ++ cas ) ;
		x.solve () ;
	}
	return 0 ;
}