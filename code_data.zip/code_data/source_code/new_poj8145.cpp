// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define bug puts("here");
using namespace std;
int vis[330][330];
int fx[]={0,0,0,1,-1};
int fy[]={0,1,-1,0,0};
struct Node{
	int x,y,t;
};
queue<Node>que;
int bfs(){
	int k;
	Node tmp,now,nx;
	if(vis[0][0]==0) return -1; 
	else if(vis[0][0]==-1) return 0;
	tmp.x=tmp.y=tmp.t=0;
	que.push(tmp);
	while(!que.empty()){
		now=que.front();
		que.pop();
		for(k=1;k<5;k++){
			nx.x=now.x+fx[k];
			nx.y=now.y+fy[k];
			nx.t=now.t+1;
			if(nx.x<0 || nx.y<0) continue;
			if(vis[nx.x][nx.y]==-1)  return nx.t;
			if(nx.t>=vis[nx.x][nx.y]) continue;
			vis[nx.x][nx.y]=0;
			que.push(nx);
		}
	}
	return -1;
} 
int main(){
	int m,k,t,x,y,xx,yy;
	scanf("%d",&m); 
	memset(vis,-1,sizeof(vis));
	while(m--){
		scanf("%d%d%d",&x,&y,&t);
		for(k=0;k<5;k++){
			xx=x+fx[k];
			yy=y+fy[k];
			if(xx<0 || yy<0) continue;
			if(vis[xx][yy]==-1) vis[xx][yy]=t;
			else vis[xx][yy]=min(vis[xx][yy],t);
		}
	}
	printf("%d\n",bfs());
	return 0;
}