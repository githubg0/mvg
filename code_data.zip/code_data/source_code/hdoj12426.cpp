// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M(a) memset(a,0,sizeof(a))
const int MAXN = 1e5 + 10;
typedef long long int ll;
int n, m;
typedef struct edge {
    int u, v;
    ll w;
    int next;
} edge;
edge graph[MAXN * 2];
int color[MAXN], cnt, lim;
int indegree[MAXN], head[MAXN];
int stand[MAXN], splt;
ll mymap[700][700];
ll node[700][2];
ll zz, ee, ze;
map<ll, int> mp;
void addEdge(int u, int v, int w) {
    graph[cnt].u = u;
    graph[cnt].v = v;
    graph[cnt].w = w;
    graph[cnt].next = head[u];
    head[u] = cnt++;
}
void solve() {
    for(int i = 1; i <= n; i++) {
        if(indegree[i] > lim)
            stand[i] = splt++;
    }
    for(int i = 0; i < cnt; i += 2) { 
        int u = graph[i].u;
        int v = graph[i].v;
        ll w = graph[i].w;
        if(color[u]^color[v])   
            ze += w;
        else if(color[u])  
            ee += w;
        else    
            zz += w;
        if(indegree[u] > lim) {
            node[stand[u]][color[v]] += w;
        }
        if(indegree[v] > lim) {
            node[stand[v]][color[u]] += w;
        }
        if(indegree[u] > lim && indegree[v] > lim) {
            mymap[stand[u]][stand[v]] += w;
            mymap[stand[v]][stand[u]] += w;
        }
    }
}
void Change(int d) {
    if(indegree[d] > lim) {
        int u = stand[d];
        for(int i = 0; i < splt; i++) { 
            if(mymap[u][i]) {
                node[i][color[d]] -= mymap[u][i];
                node[i][color[d] ^ 1] += mymap[u][i];
            }
        }
        if(color[d]) {
            color[d] = 0;
            ze -= node[u][0];
            ze += node[u][1];
            ee -= node[u][1]; 
            zz += node[u][0]; 
        } else {
            color[d] = 1;
            ze -= node[u][1];
            ze += node[u][0];
            ee += node[u][1]; 
            zz -= node[u][0]; 
        }
    } else {
        for(int i = head[d]; i != -1; i = graph[i].next) {
            int v = graph[i].v;
            ll w = graph[i].w;
            if(color[d]^color[v]) {
                ze -= w;
                if(color[v])
                    ee += w;
                else
                    zz += w;
            } else if(color[v]) {
                ee -= w;
                ze += w;
            } else {
                zz -= w;
                ze += w;
            }
            if(indegree[v] > lim) { 
                node[stand[v]][color[d]] -= w;
                node[stand[v]][color[d] ^ 1] += w;
            }
        }
        color[d] ^= 1;
    }
}
int main() {
    int q;
    ll cas = 0;
    while(scanf("%d%d", &n, &m) != EOF) {
        cas++;
        memset(head, -1, sizeof(head));
        memset(stand, -1, sizeof(stand));
        mp.clear();
        cnt = splt = 0;
        lim = (int)sqrt(1.0 * m);
        M(node);
        M(indegree);
        M(mymap);
        zz = ze = ee = 0;
        for(int i = 1; i <= n; i++) {
            scanf("%d", &color[i]);
        }
        int a, b, c;
        for(int i = 0; i < m; i++) {
            scanf("%d%d%d", &a, &b, &c);
            if(a > b)
                swap(a, b);
            ll tmp = (ll)a * 100000 + b;
            if(!mp[tmp]) {
                indegree[a]++;
                indegree[b]++;
                addEdge(a, b, c);
                addEdge(b, a, c);
                mp[tmp] = cnt - 1;
            } else {
                int id = mp[tmp];
                graph[id].w += c;
                graph[id ^ 1].w += c;
            }
        }
        solve();
        printf("Case %lld:\n", cas);
        scanf("%d", &q);
        char str[50];
        
        for(int i = 0; i < q; i++) {
            scanf("%s", str);
            if(strcmp(str, "Asksum") == 0) {
                int d, e;
                scanf("%d%d", &d, &e);
                if(d == e && d == 1) {
                    printf("%lld\n", ee);
                } else if(d == e && d == 0) {
                    printf("%lld\n", zz);
                } else {
                    printf("%lld\n", ze);
                }
            } else if(strcmp(str, "Change") == 0) {
                int d;
                scanf("%d", &d);
                Change(d);
            }
        }
    }
    return 0;
}