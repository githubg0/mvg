// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct seq
{
    char s[2][110];
    int l;
}a[20],f[20];
int n,n1,ovl[20][2][20][2],dp[1<<17][20][2];
bool out[20];
char temp[110];
void in()
{
    int i,j;
    for (i=1;i<=n;i++)
    {
        scanf("%s",a[i].s[0]+1);
        a[i].l=strlen(a[i].s[0]+1);
        strcpy(temp+1,a[i].s[0]+1);
        for (j=1;j<=a[i].l;j++)
          a[i].s[1][j]=temp[a[i].l-j+1];
    }
}
bool inc(char* s1,int l1,char* s2,int l2)
{
    if (l1>l2) return 0;
    int i,j;
    bool flag;
    for (i=1;i+l1-1<=l2;i++)
    {
        flag=1;
        for (j=1;j<=l1;j++)
          if (s1[j]!=s2[i+j-1])
          {
            flag=0;
            break;
          }
        if (flag) return 1;
    }
    return 0;
}
int cal (char* s1,int l1,char* s2,int l2)
{
    int i,j;
    bool flag;
    for (i=max(1,l1-l2+2);i<=l1;i++)
    {
        flag=1;
        for (j=1;i+j-1<=l1;j++)
          if (s2[j]!=s1[i+j-1])
          {
            flag=0;
            break;
          }
        if (flag) return l1-i+1;
    }
    return 0;
}
void pre()
{
    int i,j,x,y;
    n1=0;
    memset(out,0,sizeof(out));
    for (i=1;i<=n;i++)
      for (j=1;j<=n;j++)
        if (i!=j&&(inc(a[i].s[0],a[i].l,a[j].s[0],a[j].l)||inc(a[i].s[0],a[i].l,a[j].s[1],a[j].l))&&(!out[j]))
          out[i]=1;
    for (i=1;i<=n;i++)
      if (!out[i])
        f[n1++]=a[i];
    for (i=0;i<n1;i++)
      for (x=0;x<2;x++)
        for (j=0;j<n1;j++)
          for (y=0;y<2;y++)
            ovl[i][x][j][y]=cal(f[i].s[x],f[i].l,f[j].s[y],f[j].l);
}
void upd(int &x,int y)
{
    if (y>x) x=y;
}
void solve()
{
    int i,j,x,y,mx=(1<<n1)-1,tot=0,k,ans;
    memset(dp,128,sizeof(dp));
    dp[1][0][0]=0;
    for (i=1;i<mx;i++)
      for (j=0;j<n1;j++)
        if (i&(1<<j))
          for (x=0;x<2;x++)
            for (k=0;k<n1;k++)
              if (!(i&(1<<k)))
                for (y=0;y<2;y++)
                  upd(dp[i|(1<<k)][k][y],dp[i][j][x]+ovl[j][x][k][y]);
    for (i=0;i<n1;i++)
      tot+=f[i].l;
    ans=-1;
    for (i=0;i<n1;i++)
      for (x=0;x<2;x++)
        upd(ans,dp[mx][i][x]+ovl[i][x][0][0]);
    printf("%d\n",max(2,tot-ans));
}
int main()
{
    while (scanf("%d",&n)&&n)
    {
        in();
        pre();
        solve();
    }
}