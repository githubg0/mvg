// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int inf=99999999;
int n=1003;
int e[1003][1003];
int start[1003];	
int aim[1003];
int book[1003];
int dis[1003];
void dijstra(int source)
{
	int u,v; 
	for(int i=1;i<=n;i++)
	{
		book[i]=0;
		dis[i]=e[source][i];
	}
	book[source]=1;
	dis[source]=0;
	int minn=inf;
	for(int i=1;i<=n-1;i++)
	{
		minn=inf;
		for(int j=1;j<=n;j++)
		{
			if(book[j]==0&&dis[j]<minn)
			{
				minn=dis[j];
				u=j;
			}
		}
		if(minn==inf)return;
		book[u]=1;
		for(v=1;v<=n;v++)
		{
			if(!book[v]&&dis[v]>minn+e[u][v])
				dis[v]=minn+e[u][v];
		}
	}	
}
int main()
{
	int t,s,d;
	while(scanf("%d%d%d",&t,&s,&d)!=EOF)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				e[i][j]=inf;
			}
		}
		for(int i=1;i<=t;i++)
		{
			int a,b,time;
			scanf("%d%d%d",&a,&b,&time);
			if(time<e[a][b])
			{
				e[b][a]=time;
				e[a][b]=e[b][a];
			}
		}	
		for(int i=1;i<=s;i++)
		{
			scanf("%d",&start[i]);
		}
		for(int i=1;i<=d;i++)
		{
			scanf("%d",&aim[i]);
		}
		int mmm=inf;
		for(int i=1;i<=s;i++)
		{
			dijstra(start[i]);
			for(int j=1;j<=d;j++)
			mmm=min(mmm,dis[aim[j]]);
		}
		printf("%d\n",mmm);	
	}
	return 0;
}