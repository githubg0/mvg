// Dynamic Programming->Longest Decreasing Subsequence (LDS)
#include <cstdio> 
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
 
#define LL long long  
#define INF  99999999
using namespace std;
int n;
int a[5005];
int dp[5005];
int b[5005];
int main(){
    scanf("%d",&n);
    memset(dp,0,sizeof(dp));
    memset(b,0,sizeof(b));
    for(int i = 1; i <= n; i++){
        scanf("%d",&a[i]);
    }
    int ans = -1;
    for(int i = 1 ;i <= n; i++){
        dp[i] = 1;
        for(int j = 1; j < i; j++){
            if(a[i] < a[j])
            dp[i] = max(dp[i], dp[j]+1);
        }
        ans = max(ans, dp[i]);
    }
    
    for(int i = 1; i <= n; i++){
        if(dp[i] == 1) b[i] = 1;
        for(int j = 1; j < i; j++){
            if(a[i] < a[j] && dp[i] == dp[j]+1) b[i] += b[j];
            if(a[i] == a[j] && dp[i] == dp[j]) b[j] = 0; 
        }
    }
    int ans2 = 0;
    for(int i = 0; i <= n; i++){
        if(dp[i] == ans){
            ans2 += b[i];
        }
    }
    cout<<ans<<" "<<ans2<<endl;;
    return 0;
}