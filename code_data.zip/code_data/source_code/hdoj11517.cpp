// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mst(a,b) memset((a),(b),sizeof(a))
#define f(i,a,b) for(int i=(a);i<=(b);++i)
const int maxn = 26;
const int mod = 1e9 + 7;
const int INF = 1e9;
#define ll long long
#define rush() int T;scanf("%d",&T);while(T--)
struct Trie {
    int next[maxn];
};
int n, Count, Max;
Trie word[500010];
void init() {
    Count = Max = 0;
    int len = 50 * n + 2;
    for(int i = 0; i < len; i++)
        for(int j = 0; j < maxn; j++)
            word[i].next[j] = -1;
}
void createTrie(char *str) {
    int now = 0;
    int len = strlen(str);
    if(len > Max)
        Max = len;
    for(int i = 0; i < len; i++) {
        int t = str[i] - 'a';
        if(word[now].next[t] == -1) {
            word[now].next[t] = ++Count; 
            now = Count;
        } else
            now = word[now].next[t];
    }
}
int main() {
    char str[55];
    while(~scanf("%d", &n)) {
        init();
        for(int i = 0; i < n; i++) {
            scanf("%s", str);
            createTrie(str);
        }
        printf("%d\n", n + 2 * Count - Max);
    }
    return 0;
}