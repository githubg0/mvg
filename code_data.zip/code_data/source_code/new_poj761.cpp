// Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int P3 = 3 * 3 * 3, P2 = 3 * 3;
const int MAXM = 10;
const int MAXS = P3 * P3 * P3 * 3;
int s1, s2;
int n, S, m, K, Now, row, ans;
int Map[2][200][MAXM+10], d[2][MAXS+10];
void dfs(int cur, int s1, int s2, int cnt)
{
	if(cur > m + 1) return ;
	if(cur == m+1) {
		d[Now][s1] = max(d[Now][s1], d[Now^1][s2] + cnt);
		ans = max(ans, d[Now][s1]);
		return ;
	}
	if(!Map[0][row][cur])
		dfs(cur+3, 
				s1 * P3 + 2 * P2 + 2 * 3 + 2, 
				s2 * P3 + P2 + 3 + 1, cnt+1);
	if(!Map[1][row][cur])
		dfs(cur+2,
		        s1 * P2 + 2 * 3 + 2,
				s2 * P2, cnt+1);
	dfs(cur+1, s1 * 3 + 1, s2 * 3 + 2, cnt);
	dfs(cur+1, s1 * 3, s2 * 3 + 1, cnt);
	dfs(cur+1, s1 * 3 + 2, s2 * 3 + 2, cnt);
}
int main()
{
	int T; scanf("%d", &T); while(T--) {
		ans = 0; memset(Map, 0, sizeof(Map) + sizeof(d));
		scanf("%d%d%d", &n, &m, &K);
		for(int ii = 1; ii <= K; ii++)
		{
			int x, y; scanf("%d%d", &x, &y);
			for(int i = 0; i < 2; i++)
				for(int j = 0; j < 3; j++)
				{
					if(y - i > 0) Map[1][x+j][y-i] = 1;
					if(y - j > 0) Map[0][x+i][y-j] = 1;
				}
		}
		for(int i = 1; i <= m; i++) Map[1][2][i] = 1, Map[0][1][i] = Map[1][1][i] = 1;
		for(row = 1; row <= n; row++)
		{
			Now = row & 1;
			memset(d[Now], 0, sizeof(d[Now]));
			dfs(1, 0, 0, 0);
		}
		cout << ans << '\n';
	}
}