// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 
using namespace std;
int n1, m;
struct node {
	int fa;
};
node s[1001];
int sum[1001];
void sets()
{
	for (int i = 0;i < n1;++i)
	{
		s[i].fa = i;
	}
}
int find(int r)
{
	int n=r;
	while (n != s[n].fa)
	{
		n = s[n].fa;
	}
	int i = r, j;
	while (i !=n )
	{
		j = s[i].fa;
		s[i].fa = n;
		i = j;
	}
	return n;
}
void join(int p1, int p2)
{
	int x = find(p1);
	int y = find(p2);
	
	if (x != y)
	{
		s[x].fa = y;
	}
}
int main(void)
{
	int n;
	scanf("%d", &n);
	while (n-- > 0)
	{
		memset(sum, 0, sizeof(sum));
		scanf("%d%d", &n1, &m);
		sets();
		while (m-- > 0)
		{
			int p1, p2;
			scanf("%d%d", &p1, &p2);
			join(p1-1, p2-1);
		}
		for (int i = 0;i < n1;++i)
		{
			int x = find(i);
			
			sum[x] = 1;
		}
		int sum1=0;
		for (int i = 0;i < n1;++i)
		{
			sum1 += sum[i];
		}
		cout << sum1 << endl;
	}
}