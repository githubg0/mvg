// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define outstars cout << "***********************" << endl;
#define clr(a,b) memset(a,b,sizeof(a))
#define lson l , mid  , rt << 1
#define rson mid + 1 , r , rt << 1 | 1
#define mk make_pair
#define FOR(i , x , n) for(int i = (x) ; i < (n) ; i++)
#define FORR(i , x , n) for(int i = (x) ; i <= (n) ; i++)
#define REP(i , x , n) for(int i = (x) ; i > (n) ; i--)
#define REPP(i ,x , n) for(int i = (x) ; i >= (n) ; i--)
const int MAXN = 100000 + 50;
const int MAXS = 10000 + 50;
const int sigma_size = 26;
const long long LLMAX = 0x7fffffffffffffffLL;
const long long LLMIN = 0x8000000000000000LL;
const int INF = 0x7fffffff;
const int IMIN = 0x80000000;
const int inf = 1 << 30;
#define eps 1e-8
const long long MOD = 1000000000 + 7;
const int mod = 100000;
typedef long long LL;
const double PI = acos(-1.0);
typedef double D;
typedef pair<int , int> pii;
#define Bug(s) cout << "s = " << s << endl;
int n , dir[MAXN] , f[MAXN];
int calc(int k)
{
    clr(f ,0 );
    int res = 0 , sum = 0;
    for(int i = 0 ; i + k <= n ; i++)
    {
        if((dir[i] + sum) & 1)
        {
            res++;
            f[i] = 1;
        }
        sum += f[i];
        if(i - k + 1 >= 0)
        {
            sum -= f[i - k + 1];
        }
    }
    for(int i = n - k + 1 ; i < n ; i++)
    {
        if((dir[i] + sum) & 1)
        {
            return -1;
        }
        if(i - k + 1 >= 0)
        {
            sum -= f[i - k + 1];
        }
    }
    return res;
}
void solve()
{
    int K = 1 , M = n;
    FORR(k , 1 , n)
    {
        int m = calc(k);
        if(m >= 0 && M > m)
        {
            M = m;
            K = k;
        }
    }
    printf("%d %d\n" , K , M);
}
int main()
{
    char str[5];
    while(~scanf("%d" ,&n))
    {
        for(int i = 0 ; i < n;  i++)
        {
            scanf("%s" , str);
            dir[i] = str[0] == 'B';
        }
        solve();
    }
    return 0;
}