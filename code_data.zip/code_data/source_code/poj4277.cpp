// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n;
char a[20];
int num;
int ans;
int dis[20], nu[20];
int len;
void dfs(int l, int now, int tot)
{
    int i;
    if ( l == len )
        tot = tot+now;
    if ( tot > n )
        return ;
    if ( l == len )
    {
        if ( num == tot )
            ans++;
        if ( num < tot )
        {
            num = tot;
            ans = 1;
            for ( i = 0;i < 20; i++ )
            {
                nu[i] = dis[i];
            }
        }
        return ;
    }
    dis[l-1] = 1;
    dfs(l+1, a[l]-'0', tot+now);
    dis[l-1] = 0;
    dfs(l+1, now*10+a[l]-'0', tot);
}
int main()
{
    int i;
    while ( ~scanf ( "%d %s", &n, a ) )
    {
        len = strlen(a);
        if ( n == 0 && a[0] == '0' && len == 1)
            break;
        num = 0;
        ans = 1;
        int sum = 0;
        for ( i = 0;i < len; i++ )
        {
            sum = sum+a[i]-'0';
        }
        if ( sum > n )
        {
            printf ( "error\n" );
            continue;
        }
        dfs(1, a[0]-'0', 0);
        if ( ans != 1 )
        {
            printf ( "rejected\n" );
            continue;
        }
        printf ( "%d ", num );
        for ( i = 0;i < len; i++ )
        {
            if ( nu[i] == 1 && i != len-1 )
                printf ( "%c ", a[i] );
            else if ( nu[i] == 0 && i != len-1 )
                printf ( "%c", a[i] );
            else
                printf ( "%c\n", a[i] );
        }
    }
}