// Basic Algorithm->Simulation,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MYDD 66
using namespace std;
void SCANF(int *a,int n) {
	memset(a,0,MYDD*sizeof(int));
	for(int j=0; j<n; j++)
		scanf("%d",&a[j]);
}
int MOVE(int n,int *a,int *b,int *c) {
	if(n==0)
		return 1;
	else {
		if(n==a[0])
			return MOVE(n-1,++a,c,b);
		else if(n==c[0])
			return MOVE(n-1,b,a,++c);
	}
	return 0;
}
int main() {
	int t,n,A,B,C;
	int a[MYDD],b[MYDD],c[MYDD];
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		scanf("%d",&A);
		SCANF(a,A);
		scanf("%d",&B);
		SCANF(b,B);
		scanf("%d",&C);
		SCANF(c,C);
		if(MOVE(n,a,b,c))
			puts("true");
		else
			puts("false");
	}
	return 0;
}