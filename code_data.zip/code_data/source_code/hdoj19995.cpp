// Data Structure->Suffix Automata (SAM),Sorting->Sorting
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int N = 4e5+10;
char s[N];
const int LetterSize = 26;
int tot, last,ch[N<<1][LetterSize],fa[N<<1],len[N<<1];
int sum[N<<1],tp[N<<1];
int root=1;
void init()
{
    last = tot = 1;
    len[1] = 0;
    memset(ch,0,sizeof ch);
    memset(fa,0,sizeof fa);
}
void add( int x)
{
    int p = last, np = last = ++tot;
    len[np] = len[p] + 1;
    while( p && !ch[p][x]) ch[p][x] = np, p = fa[p];
    if(p == 0) fa[np] = 1;
    else
    {
        int q = ch[p][x];
        if( len[q] == len[p] + 1)
            fa[np] = q;
        else
        {
            int nq = ++tot;
            memcpy( ch[nq], ch[q], sizeof ch[q]);
            len[nq] = len[p] + 1, fa[nq] = fa[q], fa[q] = fa[np] = nq;
            while( p && ch[p][x] == q)  ch[p][x] = nq, p = fa[p];
        }
    }
}
void toposort()
{
    for(int i = 1; i <= len[last]; i++)   sum[i] = 0;
    for(int i = 1; i <= tot; i++)   sum[len[i]]++;
    for(int i = 1; i <= len[last]; i++)   sum[i] += sum[i-1];
    for(int i = 1; i <= tot; i++)   tp[sum[len[i]]--] = i;
}