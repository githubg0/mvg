// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int G[30][30];
int cases=1;
int N,t,T;
int x,y;
int main(){
    while(cin>>N){
        
        for(int i=1;i<21;i++){
            for(int j=1;j<21;j++){
                G[i][j]=-1;
            }
            G[i][i]=0;
        }
        for(int i=0;i<N;i++){
            cin>>t;
            G[1][t]=G[t][1]=1;
        }
        for(int i=2;i<=19;i++){
            cin>>N;
            for(int j=0;j<N;j++){
                cin>>t;
                G[i][t]=G[t][i]=1; 
            }
        }
        
        
        for(int k=1;k<=20;k++){
            for(int i=1;i<=20;i++){
                for(int j=1;j<=20;j++){
                    if(G[i][k]==-1 || G[k][j]==-1) continue;
                    if(G[i][j]==-1 || G[i][k]+G[k][j]<G[i][j]){
                        G[i][j]=G[i][k]+G[k][j];
                    }
                }
            }
        }
        
        cin>>T;
        cout<<"Test Set #"<<cases<<endl;
        for(int i=0;i<T;i++){
            cin>>x>>y;
            cout<<x<<" to "<<y<<": "<<G[x][y]<<endl;
        }
        cout<<endl;
        cases++;
    }
    return 0;
}