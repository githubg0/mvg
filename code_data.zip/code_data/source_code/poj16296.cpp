// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef struct board{
	int x0;int x1;int y;
}board;
struct board a[1010];
int left_[1010]={0};
int right_[1010]={0};
int max_=0;
int n=0;
const int inf=10000000;
bool cmp(board b1,board b2)
{
	return b1.y>b2.y;
}
int dfs(int x,int y,int level);
int main()
{
	int x=0,y=0;
	int num=0;
	while(scanf("%d",&num)!=EOF)
	{
		while(num--)
		{
			memset(left_,-1,sizeof(left_));
			memset(right_,-1,sizeof(right_));
			scanf("%d%d%d%d",&n,&x,&y,&max_);
			int i=0;
			int x0_temp=0,x1_temp=0,y_temp=0;
			for(i=0;i<n;i++)
			{
				scanf("%d%d%d",&a[i].x0,&a[i].x1,&a[i].y);
			}
			sort(a,a+n,cmp);
			int time=dfs(x,y,0);
			printf("%d\n",time);
		}
	}
	return 0;
}
int dfs(int x,int y,int cnt)
{
	int i=0;
	int x0=0,x1=0,y0=0;
	int time=0;
	int part_left=0,part_right=0;
	for(i=cnt;i<n;i++)
	{
		x0=a[i].x0;x1=a[i].x1;y0=a[i].y;
		if((y>y0)&&x0<=x&&x<=x1)
		{
			break;
		}
	}
	if(i<n)
	{
		if((y-y0)>max_) return inf; 
	}
	else 
	{
		if(y>max_) return inf;
		else return y;
	}
	if(left_[i]==-1)
	{
		left_[i]=dfs(x0,y0,i+1);
		right_[i]=dfs(x1,y0,i+1);
	}
	part_left=(x-x0)+left_[i];
	part_right=(x1-x)+right_[i];
	time=part_left<part_right?part_left:part_right;
	time+=y-y0;
	return time;
}