// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f
#define N 55
#define M 2000
int  maptt1[N][N],dist[N],vis[N];
int  n,m;
void  prim()
{
	int i,j;
	int  mindist,next,outcome=0;
	memset(vis,0,sizeof(vis));
	for(i=1;i<=n;i++)
	dist[i]=maptt1[1][i];
	vis[1]=1;
	for(i=2;i<=n;i++)
	{
		mindist=INF;
		for(j=1;j<=n;j++)
		{
			if(!vis[j]&&mindist>dist[j])
			{
				mindist=dist[j];
				next=j;
			}
		}
		vis[next]=1;
		outcome+=mindist;
		for(j=1;j<=n;j++)
		{
			if(!vis[j]&&dist[j]>maptt1[next][j])
			 dist[j]=maptt1[next][j];
		}
	}
	printf("%d\n",outcome);
	
}
int main()
{
	while(scanf("%d",&n),n)
	{
		int i,j;
		scanf("%d",&m);
		for(i=0;i<=n;i++)
		{
			maptt1[i][i]=0;
		 for(j=i+1;j<=n;j++)
		 {
		 	maptt1[i][j]=maptt1[j][i]=INF;
		 }
	    }
	    int  u,v,w;
		for(i=0;i<m;i++)
		{
			scanf("%d%d%d",&u,&v,&w);
			if(maptt1[u][v]>w)
			maptt1[u][v]=maptt1[v][u]=w;
		}
		prim();
	}
	return  0;
}