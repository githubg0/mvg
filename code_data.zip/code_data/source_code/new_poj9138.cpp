// Data Structure->Binary Indexed Tree (BIT)
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 20000+5
#define M 80000+5
using namespace std;
long long tr[M],sum[M];
struct ask
{
    long long x;
    long long val;
    int pos;
}q[N];
inline int read()
{
    int x=0,f=1;char ch = getchar();
    while(ch < '0' || ch > '9'){if(ch == '-')f=-1;ch = getchar();}
    while(ch >='0' && ch <='9'){x=(x<<1)+(x<<3)+ch-'0';ch = getchar();}
    return x*f;
}
bool cmp1(const ask &a,const ask &b)
{
    return a.x < b.x;
}
bool cmp2(const ask&a,const ask&b)
{
    return a.val > b.val;
}
inline void updata(int k)
{
    tr[k] = tr[k<<1]+tr[k<<1|1];
    sum[k] = sum[k<<1]+sum[k<<1|1];
}
void build(int k,int l,int r)
{
    if(l==r){sum[k]=1,tr[k]=q[l].x;return;}
    int mid = (l+r)>>1;
    build(k<<1,l,mid);
    build(k<<1|1,mid+1,r);
    updata(k);
}
inline void change(int k,int l,int r,int pos)
{
    if(l==r)
    {
        tr[k] = sum[k] = 0;
        return;
    }
    int mid = (l+r)>>1;
    if(pos<=mid)change(k<<1,l,mid,pos);
    else change(k<<1|1,mid+1,r,pos);
    updata(k);
}
int asksum(int k,int l,int r,int x,int y)
{
    if(l==x && r==y)
        return tr[k];
    int mid = (l+r)>>1;
    if(y<=mid)return asksum(k<<1,l,mid,x,y);
    else if(x>mid)return asksum(k<<1|1,mid+1,r,x,y);
    else return asksum(k<<1,l,mid,x,mid)+asksum(k<<1|1,mid+1,r,mid+1,y);
}
int asknum(int k,int l,int r,int x,int y)
{
    if(l==x && r==y)
        return sum[k];
    int mid = (l+r)>>1;
    if(y<=mid)return asknum(k<<1,l,mid,x,y);
    else if(x>mid)return asknum(k<<1|1,mid+1,r,x,y);
    else return asknum(k<<1,l,mid,x,mid)+asknum(k<<1|1,mid+1,r,mid+1,y);
}
int main()
{
    int n = read();
    for(int i=1;i<=n;++i)
        q[i].val=read(),q[i].x=read();
    sort(q+1,q+n+1,cmp1);
    for(int i=1;i<=n;++i)
        q[i].pos = i;
    build(1,1,n);
    sort(q+1,q+n+1,cmp2);
    long long ans = 0;
    for(int i=1;i<=n;++i)
    {
        int num = asknum(1,1,n,1,q[i].pos);
        long long bsum = asksum(1,1,n,1,q[i].pos);
        num--;
        bsum-=q[i].x;
        long long tmp1 = num * q[i].x - bsum;
        long long tmp2 = tr[1]-bsum-q[i].x;
        long long tmp3 = sum[1]-num-1;
        tmp3 *= q[i].x;
        tmp2 -= tmp3;
        tmp1 += tmp2 ;
        ans += q[i].val * tmp1;
        change(1,1,n,q[i].pos);
    }
    cout<<ans<<endl;
}