// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define TIME std::ios::sync_with_stdio(false)
#define LL long long
#define MOD 1000000007
#define MAX 201000
#define INF 0x3f3f3f3f
using namespace std;
int T,N,K;
int number[MAX],step[MAX];
vector<int> maps[MAX];
int dfs(int root){
    int len = maps[root].size();
    if(len == 0) return 1;
    for(int i = 0;i < len;i++){
        if(step[i] == 1) continue;
        step[i] = 1;
        number[root] += dfs(maps[root][i]);
    }
    return number[root];
}
int main() {
    TIME;
    scanf("%d",&T);
    while(T--){
        scanf("%d%d",&N,&K);
        memset(step,0,sizeof(step));
        for(int i = 0;i <= N;i++){
            maps[i].clear();
            number[i] = 1;
        }
        int a,b;
        for(int i = 0;i < N-1;i++){
            scanf("%d%d",&a,&b);
            maps[a].push_back(b);
            maps[b].push_back(a);
        }
        step[1] = 1;
        dfs(1);
        int ans = 0;
        for(int i = 1;i <= N;i++){
            if(number[i] >= K && number[i] <= (N - K)){
                ans++;
            }
        }
        printf("%d\n",ans);
    }
    system("pause");
    return 0;
}