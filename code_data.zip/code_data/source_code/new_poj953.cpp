// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAX 105
#define INFINITY -20000
int maptt1[MAX][MAX];
int main()
{
	int max1 = INFINITY;
	int a[MAX];
	int temp;
	int n;
	cin >> n;
	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
		{
			cin >> maptt1[i][j];
		}
	for(int i = 0; i < n; i++)
	{
		for(int t = i; t < n; t++)
		{
			memset(a, 0, sizeof(a));
			temp = 0;
			for(int j = 0; j < n; j++)
			{
				for(int k = i; k <= t; k++)
				{
					a[j] += maptt1[k][j];
				}
				if(temp + a[j] >= 0)
				{
					temp += a[j];
					if(temp > max1)
						max1 = temp;
				}
				else
				{
					temp = 0;
				}
			}
		}
	}
	cout << max1 << endl;
	system("pause");
	return 0;
}