// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Depth First Search (DFS)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 300
#define inf 100000000
int dis[MAXN][MAXN];
int Map[MAXN][MAXN];
int sign[MAXN];
int K,C,M;
int min(int a,int b)
{
    return a<b?a:b;
}
void Build_Map(int Max_Dis)
{
    int i,j;
    memset(Map,0,sizeof(Map));
    for(i=K+1;i<=K+C;i++) Map[0][i]=1;
    for(i=1;i<=K;i++) Map[i][K+C+1]=M;
    for(i=K+1;i<=K+C;i++)
    {
        for(j=1;j<=K;j++)
        {
            if(dis[i][j]<=Max_Dis)
               Map[i][j]=1;
        }
    }
}
bool BFS()
{
    queue<int> q;
    memset(sign,0,sizeof(sign));
    sign[0]=1;
    q.push(0);
    while(!q.empty())
    {
        int f=q.front();
        q.pop();
        for(int i=0;i<=K+C+1;i++)
        {
            if(!sign[i]&&Map[f][i])
            {
                sign[i]=sign[f]+1;
                q.push(i);
            }
        }
    }
    if(!sign[K+C+1]) return false;
    else return true;
}
int DFS(int v,int sum)
{
    int i,s,t;
    if(v==K+C+1) return sum;
    s=sum;
    for(i=0;sum&&i<=K+C+1;i++)
    {
        if(Map[v][i]&&sign[v]+1==sign[i])
        {
            t=DFS(i,min(Map[v][i],sum));
            Map[v][i]-=t;
            Map[i][v]+=t;
            sum-=t;
        }
    }
    return s-sum;
}
int main()
{
    int i,j,k,n;
    
    scanf("%d%d%d",&K,&C,&M);
    n=K+C;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&dis[i][j]);
            if(dis[i][j]==0)
                dis[i][j]=inf;
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
           if(dis[i][k]!=inf)
           {
            for(j=1;j<=n;j++)
            {
                dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
            }
           }
        }
    }
    int L=0,R=10000;
    while(L<R)
    {
        int mid=(L+R)/2;
        int ans=0;
        Build_Map(mid);
        while(BFS())
            ans+=DFS(0,inf);
        if(ans>=C) R=mid;
        else L=mid+1;
    }
    printf("%d\n",R);
    return 0;
}