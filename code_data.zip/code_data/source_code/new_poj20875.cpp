// Basic Algorithm->Recursion,Data Structure->Link List,Data Structure->Dancing Links,Basic Algorithm->Depth First Search (DFS)
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
 
const int INF=2<<25;
const int MAXNUM=6010;
 
int n,m;
int u[MAXNUM], d[MAXNUM], l[MAXNUM], r[MAXNUM];
int s[MAXNUM], col[MAXNUM];
 
int head;
int p_nodes;
 
void del(int c)
{
    l[ r[c] ] = l[c];
    r[ l[c] ] = r[c];
     
    for(int i=d[c]; i!=c; i=d[i])
    {
        for(int j=r[i]; j!=i; j=r[j])
        {
            u[ d[j] ] = u[j];
            d[ u[j] ] = d[j];
            s[ col[j] ] --;
        }
    }
    return;
}
 
void resume(int c)
{
    for(int i=u[c]; i!=c; i=u[i])
    {
        for(int j=l[i]; j!=i; j=l[j])
        {
            s[ col[j] ] ++;
            d[ u[j] ]=j;
            u[ d[j] ]=j;
        }
    }
     
    r[ l[c] ] =c;
    l[ r[c] ] = c;
    return;
}
 
bool DFS(int depth)
{
    
    
     
    if(r[head] == head)
        return true;
     
    int min1=INF, now;
    for(int t=r[head]; t!=head; t=r[t])
    {
        if(s[t] <=min1 )
        {
            min1=s[t];
            now=t;
        }
    }
     
    del(now);
    int i, j;
    for(i=d[now]; i!=now; i=d[i])
    {
        for(j=r[i]; j!=i; j=r[j])
        {
            del( col[j] );
        }
         
        bool tmp=DFS(depth+1);
         
        for(j=l[i]; j!=i; j=l[j])
        {
            resume(col[j]);
        }
     
        if(tmp==true)
            return true;
             
         
    }
    resume(now);
    return false;
}
 
void init()
{
    memset(u,0,sizeof(u));
    memset(d,0,sizeof(d));
    memset(l,0,sizeof(l));
    memset(r,0,sizeof(r));
    memset(s,0,sizeof(s));
    memset(col,0,sizeof(col));
 
    head=0;
    p_nodes=0;
}
 
void InitLinks()
{
    int i,j;
    r[head]=1;
    l[head]=m;
     
    for(i=1;i<=m;i++)
    {
        l[i]=i-1;
        r[i]=i+1;
        if(i==m)
            r[i]=head;
        u[i]=i;
        d[i]=i;
        s[i]=0;
        col[i]=i;
    }
     
    p_nodes=m;
    for(i=1;i<=n;i++)
    {
        int row_first1=-1;
        for(j=1;j<=m;j++)
        {
            int k;
            scanf("%d", &k);
            if(k==1)
            {
                p_nodes++;
                s[j] ++;
                u[p_nodes] = u[j];
                d[ u[j] ] = p_nodes;
                u[j] = p_nodes;
                d[p_nodes] = j;
                 
                col[p_nodes] = j;
                 
                if(row_first1==-1)
                {
                    l[p_nodes] = r[p_nodes] = p_nodes;
                    row_first1=p_nodes;
                }
                 
                else
                {
                    l[p_nodes] = l[row_first1];
                    r[ l[row_first1] ] = p_nodes;
                    r[p_nodes] = row_first1;
                    l[ row_first1 ]=p_nodes;
                }
            }
        }
    }
}
 
int main()
{
    while(scanf("%d %d", &n, &m) ==2)
    {
        init();
        InitLinks();
        bool ok=true;
        for(int i=1;i<=m;i++)
        {
            if(s[i]==0)
            {
                ok=false;
                break;
            }
        }
        if(ok)
            ok=DFS(1);
         
        if(ok)
            printf("Yes, I found it\n");
        else
            printf("It is impossible\n");
    }
    return 0;
}