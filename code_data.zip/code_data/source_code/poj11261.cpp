// Math and Computational Geometry->Greatest Common Divisor (GCD),Basic Algorithm->Bitwise Operation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL unsigned long long
void gcd(LL a,LL b,LL &d,LL &x,LL &y)
{
    if(b==0)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        gcd(b,a%b,d,y,x);
        y=y-x*(a/b);
    }
    return ;
}
int main()
{ 
  LL a,b,c,d,x,y,k;
  while(cin>>a>>b>>c>>k) 
  {
  	
  	if(a==0&&b==0&&c==0&&k==0)
	  break;
	k=((LL)1)<<k;
	gcd(c,k,d,x,y);  	
  	if((b-a)%d)
  	cout<<"FOREVER"<<endl;
  	else
        {
            x = (b-a)/d*x ;
            k = k/d ;
            x = (x%k+k)%k ;
            cout<<x<<endl;
        }
  }
  return 0;
 }