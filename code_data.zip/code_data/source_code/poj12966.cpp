// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define eps 1e-13
struct Point
{
	double x,y;
	Point()
	{
		x=y=0;
	}
};
typedef Point Vector;
Point P[305],V[100005];
Vector operator + (Vector a,Vector b)
{
	a.x+=b.x;
	a.y+=b.y;
	return a;
}
Vector operator - (Vector a,Vector b)
{
	a.x-=b.x;
	a.y-=b.y;
	return a;
}
Vector operator * (Vector a,double b)
{
	a.x*=b;
	a.y*=b;
	return a;
}
int dcmp(double x)
{
	if(x<=eps&&x>=-eps) return 0;
	if(x>0) return 1;
	return -1;
}
bool operator ==(Point a,Point b)
{
	return dcmp(a.x-b.x)==0 && dcmp(a.y-b.y)==0;
}
bool operator < (Point a,Point b)
{
	return dcmp(a.x-b.x)==-1 || (dcmp(a.x-b.x)==0&&dcmp(a.y-b.y)==-1);
}
bool operator > (Point a,Point b)
{
	return dcmp(a.x-b.x)==1 || (dcmp(a.x-b.x)==0&&dcmp(a.y-b.y)==1);
}
double Dot(Vector a,Vector b)
{
	return a.x*b.x+a.y*b.y;
}
double Cross(Vector a,Vector b)
{
	return a.x*b.y-b.x*a.y;
}
bool jiao(Point a,Point b,Point c,Point d)
{
	double c1=Cross(b-a,c-a),c2=Cross(b-a,d-a),c3=Cross(d-c,a-c),c4=Cross(d-c,b-c);
	return dcmp(c1)*dcmp(c2)<0&&dcmp(c3)*dcmp(c4)<0;
}
Point jiaodian(Point P,Vector v,Point Q,Vector w)
{
	Vector u=P-Q;
	double t=Cross(w,u)/Cross(v,w);
	return P+v*t;
}
bool PointOnLine(Point p,Point a,Point b)
{
	return dcmp(Cross(p-a,p-b))==0 && dcmp(Dot(p-a,p-b))==-1;
}
void jh(Point& a,Point& b)
{
	Point t=a;
	a=b;
	b=t;
}
void kp(int low,int high)
{
	int i=low,j=high;
	Point mid=V[(i+j)/2];
	while(i<j)
	{
		while(V[i]<mid) i++;
		while(V[j]>mid) j--;
		if(i<=j)
		{
			jh(V[i],V[j]);
			i++;
			j--;
		}
	}
	if(j>low) kp(low,j);
	if(i<high) kp(i,high);
}
int main()
{
	int T=0,n,i,j,v,e;
	while(scanf("%d",&n)&&n>0)
	{
		T++;
		for(i=1;i<=n;i++)
		{
			scanf("%lf%lf",&P[i].x,&P[i].y);
			V[i]=P[i];
		}
		v=e=n-1;
		for(i=1;i<n-1;i++)
			for(j=i+1;j<n;j++)
				if(jiao(P[i],P[i+1],P[j],P[j+1])) V[++v]=jiaodian(P[i],P[i+1]-P[i],P[j],P[j+1]-P[j]);
		kp(1,v);
		j=0;
		for(i=1;i<=v;i++)
			if(i==1||!(V[i]==V[i-1])) V[++j]=V[i];
		v=j;
		for(i=1;i<=v;i++)
			for(j=1;j<n;j++)
				if(PointOnLine(V[i],P[j],P[j+1])) e++;
		printf("Case %d: There are %d pieces.\n",T,e-v+2);
	}
	return 0;
}