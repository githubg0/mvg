// Basic Algorithm->Recurrence,Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 1000000000000000+7
using namespace std;
typedef long long ll;
typedef struct aaa
{
    ll m[2][2];
}aaa;
aaa mulM(aaa &x ,aaa& y,ll mod)
{
    aaa temp;
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            temp.m[i][j] = 0;
            for (int k = 0; k < 2; k++)
            {
                temp.m[i][j] = (temp.m[i][j] + x.m[i][k] * y.m[k][j] % mod) % mod;
            }
        }
    }
    return temp;
}
int main()
{
    ll n, mod;
    aaa a;
    a.m[0][0] = 4;
    a.m[0][1] = 0;
    a.m[1][0] = 2;
    a.m[1][1] = 1;
    aaa E;
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            E.m[i][j] = 0;
        }
    }
    E.m[0][1] = 1;
    while (scanf("%lld %lld", &n, &mod) != EOF)
    {
        aaa ans = E; aaa mul = a;
        ll nn = n ;
        if (n & 1)nn--;
        nn /= 2;
        while (nn)
        {
            if (nn & 1)ans = mulM(ans, mul,mod);
            mul = mulM(mul, mul, mod);
            nn >>= 1;
        }
        
        if (n & 1)ans.m[0][0] = (2 * ans.m[0][0] + 1)%mod;
        printf("%I64d\n", ans.m[0][0]);
    }
    return 0;
}