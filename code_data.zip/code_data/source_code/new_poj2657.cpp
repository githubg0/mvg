// Graph Algorithm->Floyd-Warshall Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf (1000000000)
#define MAX_N 64
int kdis[MAX_N][MAX_N];
int nightdis[MAX_N][MAX_N]; 
struct move
{
	int x;
	int y;
}NIGHTMOVE[]={ {-2,1},{2,1},{-2,-1},{2,-1},{1,2},{-1,2},{1,-2},{-1,-2} };
struct move KMOVE[]= { {-1,1},{0,1},{1,1},{-1,0},{1,0},{-1,-1},{0,-1},{1,-1}};
bool valid(int x,int y)
{
	if( x >= 0 && x < 8 && y >= 0 && y < 8)
		return true;
	return false;
}
int nightfloyd()
{
	for(int i=0;i<MAX_N;i++)
		for(int j=0;j<MAX_N;j++)
		{
			nightdis[i][j]=inf;
			kdis[i][j]=inf;
			if( i == j)
			{
				nightdis[i][j]=0;
				kdis[i][j]=0;
			}
		}
	for(int i=0;i<MAX_N;i++)
	{	
		int x =  i %8;
		int y =  i/8;
		for(int m=0;m< 8;m++)
		{
			int mx = x + NIGHTMOVE[m].x;
			int my = y + NIGHTMOVE[m].y;
			int kmx = x + KMOVE[m].x;
			int kmy = y + KMOVE[m].y;
			if(valid(mx,my))
			{
				int j=( my * 8 + mx);
				nightdis[i][j] = 1;
			}
			if(valid(kmx,kmy))
			{
				int j = (kmy *8) + kmx;
				kdis[i][j] = 1;
			}
		}
	}
	for(int k=0;k<MAX_N;k++)
	{
		for(int i=0;i<MAX_N;i++)
		{
			for(int j=0;j<MAX_N;j++)
			{
				
				kdis[i][j] = min(kdis[i][k]+kdis[k][j],kdis[i][j]);
				nightdis[i][j] = min(nightdis[i][k]+nightdis[k][j],nightdis[i][j]);
				
			}
		}
	}
    for(int i=0;i<64;i++)
    {
	    for(int j=0;j<64;j++)
	   {
		  
		  
	   }
    }
}
int K=0;
int I[MAX_N]; 
int get_index(char c,char n)
{
	
	
	return (c - 'A') + ( n -'1') *8;
}
int knight_sum_but_k(int k,int f) 
{
	int sum = 0;
	for(int i=1;i<=K;i++)
	{
		if( i==k)
			continue;
		sum += nightdis[I[i] ][f];
	}
	
	return sum;
}
int king_to(int king,int f)
{
	return kdis[king][f];
}
int knight_to(int night,int f)
{
	return nightdis[night][f];
}
int main()
{
	string str;
	nightfloyd();
	while(cin>>str)
	{
		int minret = inf;
		int L=str.length();
		
		I[0] = get_index(str[0],str[1]);
		for(int l=2;l<L;l += 2)
		{
			K++;
			I[K] = get_index(str[l],str[l+1]);
		}
		
		
		for(int i=0;i<64;i++)
		{
			for(int j=0;j<64;j++)
			{
				for(int k=1;k<=K;k++)
				{
					
					int sum = 0;
					sum += knight_sum_but_k(k,i);
					sum += king_to(I[0],j);
					sum += knight_to(I[k],j);
					sum += knight_to(j,i);
					if(sum < minret)
						minret = sum;
					
				}
			}
		}
		cout<<minret<<endl;
	}
}