// Data Structure->Segment Tree,Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=10000+5;
struct Credit{
	int p,d;
	bool operator < (const Credit &rhs)const{
		return p>rhs.p;
	}
}c[N];
int pa[N];
int find(int x){
	return pa[x]==x?x:pa[x]=find(pa[x]);
}
int merge(int x,int y){
	x=find(x);y=find(y);
	pa[x]=y;
}
int cov[N];
int main(){
	
	int n,l;
	while(~scanf("%d%d",&n,&l)){
		int D=0;
		for(int i=1;i<=n;i++){
			scanf("%d%d",&c[i].p,&c[i].d);
			D=max(D,c[i].d);
		}
		if(!l){
			puts("0");
			continue;
		}
		for(int i=0;i<=D;i++)
		cov[i]=0,pa[i]=i;
		sort(c+1,c+1+n);
		int ans=0;
		for(int i=1;i<=n;i++){
			int s=find(c[i].d);
			if(!s&&cov[s]==l)continue;
			ans+=c[i].p;
			cov[s]++;
			if(cov[s]==l&&s)merge(s,s-1);
		}
		printf("%d\n",ans);
	}
	return 0;
}