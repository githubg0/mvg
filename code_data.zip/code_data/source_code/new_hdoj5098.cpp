// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define max(a,b) (a>b?a:b)
int dp[1010][1010];
struct s
{
	int x,y,w;
}b[1010];
int cmp(const void *a,const void *b)
{
	return (*(struct s *)b).w-(*(struct s *)a).w;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,sx,sy,i,j,k;
		scanf("%d%d%d",&n,&sx,&sy);
		for(i=0;i<n;i++)
		{
			scanf("%d%d%d",&b[i].x,&b[i].y,&b[i].w);
		}
		qsort(b,n,sizeof(b[0]),cmp);
		memset(dp,0,sizeof(dp));
		for(i=0;i<=sx;i++)
		{
			for(j=0;j<=sy;j++)
			{
				for(k=0;k<n;k++)
				{
					if(i>=b[k].x&&j>=b[k].y)
						dp[i][j]=max(dp[i][j],max(dp[i-b[k].x][j]+dp[b[k].x][j-b[k].y]+b[k].w,dp[i][j-b[k].y]+dp[i-b[k].x][b[k].y]+b[k].w));
					if(i>=b[k].y&&j>=b[k].x)
						dp[i][j]=max(dp[i][j],max(dp[i-b[k].y][j]+dp[b[k].y][j-b[k].x]+b[k].w,dp[i][j-b[k].x]+dp[i-b[k].y][b[k].x]+b[k].w));
				}
			}
		}
		printf("%d\n",dp[sx][sy]);
	}
}