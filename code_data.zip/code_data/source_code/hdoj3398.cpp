// Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int xulie[2001];
char Edge[2001][2001];
bool mark[2001];
int i, j;
map<string, int> Name;
void initEdge(int N)
{
    for(j = 1; j<=N; j++)
    {
        for(i = 1; i<=N; i++)
        {
            Edge[j][i] = '0';
        }
    }
    for(i = 1; i<=N; i++)
    {
        mark[i] = false;
    }
}
int main()
{
    int N, n, M, x, y, Index;
    string X,Y;
    while(cin>>M && M!=0)
    {
        int ans = 1;
        initEdge(2000);
        Name.clear();
        while(M--)
        {
            cin>>X>>Y;
            if(Name.end() == Name.find(X))
            {
                Name[X] = ans;
                x = ans++;
            }
            else
            {
                x = Name[X];
            }
            if(Name.end() == Name.find(Y))
            {
                Name[Y] = ans;
                y = ans++;
            }
            else
            {
                y = Name[Y];
            }
            Edge[y][x] = '1';
        }
        int num = 0;
        for(i=1; i<ans; i++)
        {
            Index = 0;
            for(j=1; j<ans;j++)
            {
                if('0' == Edge[i][j])
                {
                    Index++;
                }
            }
            if(Index == ans-1)
            {
                num++;
            }
        }
        if(num > 1)
        {
            cout<<"No"<<endl;
            continue;
        }
        n = ans-1;
        N = n;
        ans = 0;
        while(n--)
        {
            for(j = 1; j<=N; j++)
            {
                Index = 0;
                if(mark[j] != true)
                {
                    for(i = 1; i<=N; i++)
                    {
                        if(Edge[j][i] == '0')
                        {
                            Index++;
                        }
                    }
                }
                if(Index == N)
                {
                    Index = j;
                    mark[j] = true;
                    xulie[ans++] = Index;
                    break;
                }
            }
            if(j != N+1)
            {
                
                for(i = 1; i<=N; i++)
                {
                    Edge[i][Index] = '0';
                }
            }
        }
        Index = -1;
        for(i=1; i<=N;i++)
        {
            for(j=1;j<=N;j++)
            {
                if(Edge[i][j] == '1')
                {
                    Index++;
                }
            }
        }
        if(Index == -1)
        {
            cout<<"Yes"<<endl;
        }
        else
        {
            cout<<"No"<<endl;
        }
    }
}