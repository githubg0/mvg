// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Max = 65;
int n, aveLen, stick[Max];
bool flag, used[Max];
bool cmp(int a, int b){
    return a > b;
}
void dfs(int sticksNum, int now_Len, int Now){
    
    if(flag) return;
    if(now_Len == 0){                    
        int k = 0;
        while(used[k]) k ++;              
        used[k] = true;
        dfs(sticksNum + 1, stick[k], k + 1);
        used[k] = false;
        return;
    }
    if(now_Len == aveLen){                  
        if(sticksNum == n) flag = true;        
        else dfs(sticksNum, 0, 0);
        return;
    }
    for(int i =Now; i < n; i ++)
        if(!used[i] && now_Len + stick[i] <= aveLen){
            if(!used[i-1] && stick[i] == stick[i-1]) continue;
            used[i] = true;
            dfs(sticksNum + 1, now_Len + stick[i], i + 1);
            used[i] = false;
        }
}
int main(){
      freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    while(scanf("%d", &n)!=EOF && n != 0){
        int sum = 0;
        flag = false;
        for(int i = 0; i < n; i ++){
            scanf("%d", &stick[i]);
            sum += stick[i];
        }
        sort(stick, stick + n, cmp);     
        for(aveLen = stick[0]; aveLen < sum; aveLen ++)
            if(sum % aveLen == 0){          
                memset(used, 0, sizeof(used));
                dfs(0, 0, 0);
                if(flag) break;
            }
        printf("%d\n", aveLen);
    }
    return 0;
}