// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define dbg(x) cout<<#x<<" = "<< (x)<< endl
#define dbg2(x1,x2) cout<<#x1<<" = "<<x1<<" "<<#x2<<" = "<<x2<<endl
#define dbg3(x1,x2,x3) cout<<#x1<<" = "<<x1<<" "<<#x2<<" = "<<x2<<" "<<#x3<<" = "<<x3<<endl
#define max3(a,b,c) max(a,max(b,c))
#define min3(a,b,c) min(a,min(b,c))
typedef pair<int,int> pll;
typedef long long ll;
const int inf = 0x3f3f3f3f;
const int _inf = 0xc0c0c0c0;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll _INF = 0xc0c0c0c0c0c0c0c0;
const ll mod =  (int)1e9+7;
ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}
ll ksm(ll a,ll b,ll mod){int ans=1;while(b){if(b&1) ans=(ans*a)%mod;a=(a*a)%mod;b>>=1;}return ans;}
ll inv2(ll a,ll mod){return ksm(a,mod-2,mod);}
void exgcd(ll a,ll b,ll &x,ll &y,ll &d){if(!b) {d = a;x = 1;y=0;}else{exgcd(b,a%b,y,x,d);y-=x*(a/b);}}
const int MAX_N = 100025;
int low[MAX_N],high[MAX_N],dep,C[MAX_N<<1],eid,p[MAX_N],block,col[MAX_N],ans[MAX_N];
bool vis[MAX_N];
void init()
{
    memset(vis,false,sizeof(vis));
    memset(C,0,sizeof(C));
    memset(p,-1,sizeof(p));
    eid = dep = 0;
}
struct edge
{
    int v,next;
}e[MAX_N<<1];
void addedge(int u,int v)
{
    e[eid].v = v;
    e[eid].next = p[u];
    p[u] = eid++;
}
struct node
{
    int l,r,id;
}q[MAX_N];
bool cmp(node a,node b)
{
    return (a.l/block)^(b.l/block)?a.l<b.l:(((a.l/block)&1)?a.r<b.r:a.r>b.r);
}
void add_(int x,int v)
{
    for(;x<MAX_N;x+=x&(-x))
        C[x]+=v;
}
int getsum(int x)
{
    int res = 0;
    for(;x;x-=x&(-x))
        res+=C[x];
    return res;
}
void add(int x)
{
    add_(col[x],1);
}
void del(int x)
{
    add_(col[x],-1);
}
void dfs(int u)
{
    vis[u] = true;
    low[u] = ++dep;
    col[dep] = u;
    for(int i = p[u];i+1;i=e[i].next)
    {
        int v = e[i].v;
        if(vis[v]) continue;
        dfs(v);
    }
    high[u] = dep;
}
int main()
{
    
    
    
    int n,p,a,b;
    while(scanf("%d%d",&n,&p)==2)
    {
        if(!n) break;
        init();
        for(int i = 1;i<n;++i)
        {
            scanf("%d%d",&a,&b);
            addedge(a,b);
            addedge(b,a);
        }
        dfs(p);
        block = n/sqrt(n*2/3);
        for(int i = 1;i<=n;++i) q[i].l = low[i],q[i].r = high[i],q[i].id = i;
        sort(q+1,q+1+n,cmp);
        int l = 0,r = 0;
        col[0] = n +1;
        for(int i = 1;i<=n;++i)
        {
            int ql = q[i].l,qr = q[i].r;
            while(r<qr) add(++r);
            while(l>ql) add(--l);
            while(l<ql) del(l++);
            while(r>qr) del(r--);
            ans[q[i].id] = getsum(q[i].id)-1;
        }
        for(int i = 1;i<=n;++i) i==n?printf("%d\n",ans[i]):printf("%d ",ans[i]);
    }
    
    
    
    return 0;
}