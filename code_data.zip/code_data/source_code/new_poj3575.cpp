// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x7fffffff
#define maxn 105
int n,m;
int w[maxn][maxn];
int point[maxn];
int d[maxn],pre[maxn];
int flag[maxn];
int ans[maxn];
void init(){
	point[n]=0;
	for(int i=0;i<=n;i++){
		w[i][i]=INF;
		for(int j=i+1;j<=n;j++){
			w[i][j]=w[j][i]=INF;
		}
	}
}
void spfa(int v1){
	int i,j,u,k;
	memset(flag,0,sizeof(flag));
	memset(pre,-1,sizeof(pre));
	for(i=1;i<=n;i++) d[i]=-INF;
	d[v1]=0;
	queue<int>q;
	q.push(v1);
	while(!q.empty()){
		u=q.front();
		q.pop();
		flag[u]=0;
		for(j=1;j<=n;j++){
			if(w[u][j]!=INF){
			 
			k=d[u]+w[u][j];
			  if(d[j]<k){
			    	d[j]=k;
				   pre[j]=u;
			    	if(!flag[j]){
				  	flag[j]=1;
				    	q.push(j);
				   }
			  }
			}
		}
	}
}
void print_path(int u){
	if(pre[u]==-1){
		printf("1");
		return ;
	}
	print_path(pre[u]);
	if(u==n) printf("->%d",1);
	else printf("->%d",u);
}
int main(){
	int T,u,v,cas=1;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		++n;
		init();
		for(int i=1;i<n;i++){
			scanf("%d",&point[i]);
		}
		scanf("%d",&m);
		for(int i=0;i<m;i++){
			scanf("%d %d",&u,&v);
			w[u][v]=point[v];
		}
		spfa(1);
		if(cas!=1)printf("\n");
		printf("CASE %d#\n",cas++);
		printf("points : %d\n",d[n]);
		printf("circuit : ");
		print_path(n);
		printf("\n");
	}
	return 0;
}