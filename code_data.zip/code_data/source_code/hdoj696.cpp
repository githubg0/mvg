// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int dir[4][2] = {1, 0, -1, 0, 0, 1, 0, -1};
int dp[105][105];
int mp[105][105];
int n, k,ans;
int dfs(int sx, int sy)
{
    int kk = 0;
    if(!dp[sx][sy])
    {
        for(int i = 1; i <= k; i++)
        {
            for(int s = 0; s < 4; s++)
            {
                int nx = sx + i * dir[s][0];
                int ny = sy + i * dir[s][1];
                if(nx >= 0 && nx < n && ny >= 0 && ny < n && mp[sx][sy] < mp[nx][ny])
                {
                    kk = max(kk, dfs(nx, ny));
                }
            }
        }
        dp[sx][sy]=kk+mp[sx][sy];
    }
    return dp[sx][sy];
}
int main()
{
    while(scanf("%d%d", &n, &k),n!=-1&&k!=-1)
    {
        ans = 0;
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
            {
                scanf("%d", &mp[i][j]);
            }
        }
        ans=dfs(0, 0);
        printf("%d\n", ans);
        memset(dp,0,sizeof(dp));
    }
    return 0;
}