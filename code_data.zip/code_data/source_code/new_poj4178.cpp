// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a,b;
typedef class
{
    public:
        int prime;
        int step;
}number;
bool vist[15000];
number queuett1[15000];
bool JudgePrime(int n)
{
    double m=sqrt(n)+1;
    int i;
    for(i=3;i<=m;i++)
    {
        if(n%i==0) {return false;break;}
    }
    if(i>m) return true;
}
void BFS(void)
{
    int i;  
    int head,tail;
    queuett1[head=tail=0].prime=a;
    queuett1[tail++].step=0;
    vist[a]=true;
    while(head<tail)
    {
        number x=queuett1[head++];
        if(x.prime==b)
        {
            printf("%d\n",x.step);
            return;
        }
        int unit=x.prime%10;       
        int deca=(x.prime/10)%10;  
        for(i=1;i<=9;i+=2)     
        {
            int y=(x.prime/10)*10+i;
            if(y!=x.prime && !vist[y] && JudgePrime(y))
            {
                vist[y]=true;
                queuett1[tail].prime=y;
                queuett1[tail++].step=x.step+1;
            }
        }
        for(i=0;i<=9;i++)     
        {
            int y=(x.prime/100)*100+i*10+unit;
            if(y!=x.prime && !vist[y] && JudgePrime(y))
            {
                vist[y]=true;
                queuett1[tail].prime=y;
                queuett1[tail++].step=x.step+1;
            }
        }
        for(i=0;i<=9;i++)     
        {
            int y=(x.prime/1000)*1000+i*100+deca*10+unit;
            if(y!=x.prime && !vist[y] && JudgePrime(y))
            {
                vist[y]=true;
                queuett1[tail].prime=y;
                queuett1[tail++].step=x.step+1;
            }
        }
        for(i=1;i<=9;i++)     
        {
            int y=x.prime%1000+i*1000;
            if(y!=x.prime && !vist[y] && JudgePrime(y))
            {
                vist[y]=true;
                queuett1[tail].prime=y;
                queuett1[tail++].step=x.step+1;
            }
        }
    }
    printf("Impossible\n");
    return;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&a,&b);
        memset(vist,false,sizeof(vist));
        BFS();
    }
    return 0;
}