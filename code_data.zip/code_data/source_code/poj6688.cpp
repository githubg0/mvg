// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int maxN=20005;
int dp[maxN];
int N;
int head[maxN],tot;
struct Graph
{
    int to,next;
}G[maxN<<1];
void add(int u,int v)
{
    
    G[tot].to=v;
    G[tot].next=head[u];
    head[u]=tot++;
}
void initG()
{
    memset(head,-1,sizeof(head));
    tot=0;
}
int dfs(int u,int pre)
{
    int sum=0;
    for(int i=head[u];i+1;i=G[i].next)
    {
        int v=G[i].to;
        if(v==pre)continue;
        int cnt=dfs(v,u);
        sum+=cnt;
        dp[u]=max(dp[u],cnt);
    }
    dp[u]=max(dp[u],N-sum-1);
    return sum+1;
}
int main()
{
    ios::sync_with_stdio(false);
    int T,u,v,w;
    cin>>T;
    while(T--)
    {
        cin>>N;
        initG();
        memset(dp,0,sizeof(dp));
        for(int i=2;i<=N;i++)
        {
            cin>>u>>v;
            add(u,v);
            add(v,u);
        }
        dfs(1,-1);
        int idx=1;
        for(int i=1;i<=N;i++)idx=dp[idx]>dp[i]?i:idx;
        cout<<idx<<" "<<dp[idx]<<endl;
    }
    return 0;
}