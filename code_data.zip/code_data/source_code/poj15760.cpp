// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 3000000 + 10
#define MAXV 1000 + 10
int n, m;
struct Edge
{
	int v, next;
}edge[MAXN];
int head[2 * MAXV], e, ind, cnt;
int dfn[2 * MAXV], low[2 * MAXV], belong[2 * MAXV];
bool ins[2 * MAXV];
void add(int u, int v)
{
	edge[e].v = v;
	edge[e].next = head[u];
	head[u] = e++;
}
void init()
{
	e = ind = cnt = 0;
	memset(head, -1, sizeof(head));
}
int sta[2 * MAXV], top = 0;
stack <int> s;
void tarjan(int u)
{
	dfn[u] = low[u] = ++ind;
	
	ins[u] = true;
	
	s.push(u);
	
	for (int i = head[u]; i != -1; i = edge[i].next)
	{
		int v = edge[i].v;
		
		if (!dfn[v])                              
		{
			tarjan(v);
			
			low[u] = min(low[u], low[v]);
		}
		else if (ins[v])
		{
			low[u] = min(low[u], dfn[v]);
		}
	}
	
	if (low[u] == dfn[u])
	{
		int x;
		
		do
		{
			x = s.top();
			s.pop();
			ins[x] = false;
			belong[x] = cnt;
		}while (x != u);
		
		cnt++;
	}
}
void solve()
{
	for (int i = 0; i < 2 * n; i++)
	{
		if (!dfn[i])
		{
			tarjan(i);
		}	
	}
	
	bool flag = true;
	
	for (int i = 0; i < n; i++)
	{
		if (belong[i] == belong[i + n])
		{
			flag = false;
			break;
		}
	}
		
	if (flag)
	{
		printf("YES\n");
	}
	else
	{
		printf("NO\n");
	}
}
void input()
{
	int a, b, c;
	char str[10];
	
	scanf("%d %d", &n, &m);
	
	init();
		
	for (int i = 0; i < m; i++)
	{
		scanf("%d %d %d %s", &a, &b, &c, str);
	
		if (str[0] == 'A')
		{
			if (c == 0)
			{
				add(a + n, b);
				add(b + n, a);	
			}
			else
			{
				add(a, a + n);
				add(b, b + n);
				add(a + n, b + n);
				add(b + n, a + n);
			}
		}
		else if (str[0] == 'O')
		{
			if (c == 0)
			{
				add(a + n, a);
				add(b + n, b);
				add(a, b);
				add(b, a);	
			}
			else
			{
				add(a, b + n);
				add(b, a + n);
			}
		}
		else
		{
			if (c == 0)
			{
				add(a, b);
				add(b, a);
				add(a + n, b + n);
				add(b + n, a + n);	
			}
			else
			{
				add(a, b + n);
				add(b + n, a);
				add(a + n, b);
				add(b, a + n);	
			}
		}
	}
	
	solve();
}
int main()
{
	input();
	return 0;
}