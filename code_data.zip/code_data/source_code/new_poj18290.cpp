// Dynamic Programming->Priority Queue,Graph Algorithm->Dijkstra's Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1005;
const int INF = 1000000;
typedef pair<int, int> P;
struct edge {
	int to, cost;
	edge(){}
	edge(int to, int cost): to(to), cost(cost){}
};
int N, M, X;
int dis[maxn][maxn];
vector<edge> Grap[maxn];
void dijkstra(int s) {
	priority_queue<P, vector<P>, greater<P> > que;
	for (int i = 0; i <= N; i++) dis[s][i] = INF;
	dis[s][s] = 0;
	que.push(P(0, s));
	while (!que.empty()) {
		P p = que.top();
		que.pop();
		int v = p.second, len = Grap[v].size();
		
		if (dis[s][v] < p.first) continue;
		for (int i = 0; i < len; i++) {
			edge e = Grap[v][i];
			
			if (dis[s][e.to] > dis[s][v] + e.cost) {
				dis[s][e.to] = dis[s][v] + e.cost;
				que.push(P(e.cost, e.to));
			}
		}
	}
}
void solve() {
	int ans = 0;
	for (int i = 1; i <= N; i++) dijkstra(i);
	for (int i = 1; i <= N; i++) {
		if (i == X) continue;
		int temp = dis[i][X] + dis[X][i];
		if (ans < temp) ans = temp; 
	}
	printf("%d\n", ans);
}
int main() {
	int x, y, t;
	scanf("%d %d %d", &N, &M, &X);
	for (int i = 0; i < M; i++) {
		scanf("%d %d %d", &x, &y, &t);
		Grap[x].push_back(edge(y, t));
	}
	solve();
	return 0;
}