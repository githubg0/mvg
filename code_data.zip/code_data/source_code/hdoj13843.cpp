// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Euler Circuit / Euler Path,Graph Algorithm->Min-Cost Max-Flow
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
#define N 110
#define M 2010
#define inf (1<<20)
int casnum, cas, n, m, s, t, S, T, ans, tot, flow, totflow, cost;
int head[N], pre[N], vis[N], dis[N], din[N], dout[N], temp[N];
struct edge {
	int u, v, w, c, next;
} ed[N * M];
queue<int> qu;
void init() {
	S = 0;
	T = n + 1;
	ans = 0;
	tot = 0;
	totflow = 0;
	flow = 0;
	cost = 0;
	memset(head, -1, sizeof(head));
	memset(din, 0, sizeof(din));
	memset(dout, 0, sizeof(dout));
}
void add(int U, int V, int W, int C) {
	ed[tot].u = U;
	ed[tot].v = V;
	ed[tot].w = W;
	ed[tot].c = C;
	ed[tot].next = head[U];
	head[U] = tot++;
	ed[tot].u = V;
	ed[tot].v = U;
	ed[tot].w = 0;
	ed[tot].c = -C;
	ed[tot].next = head[V];
	head[V] = tot++;
}
int spfa() {
	int i, u, v;
	while (!qu.empty())
		qu.pop();
	for (i = 0; i <= T; i++) {
		vis[i] = 0;
		dis[i] = inf;
		pre[i] = -1;
	}
	qu.push(S);
	vis[S] = 1;
	dis[S] = 0;
	while (!qu.empty()) {
		u = qu.front();
		qu.pop();
		vis[u] = 0;
		for (i = head[u]; ~i; i = ed[i].next) {
			if (!ed[i].w)
				continue;
			v = ed[i].v;
			if (dis[v] > dis[u] + ed[i].c) {
				dis[v] = dis[u] + ed[i].c;
				pre[v] = i;
				if (!vis[v]) {
					vis[v] = 1;
					qu.push(v);
				}
			}
		}
	}
	return dis[T] != inf;
}
void mcmf() {
	int i, tmp;
	while (spfa()) {
		tmp = inf;
		for (i = pre[T]; ~i; i = pre[ed[i].u]) {
			if (tmp > ed[i].w)
				tmp = ed[i].w;
		}
		for (i = pre[T]; ~i; i = pre[ed[i].u]) {
			ed[i].w -= tmp;
			ed[i ^ 1].w += tmp;
			cost += tmp * ed[i].c;
		}
		flow += tmp;
	}
}
struct input {
	int u, v, a, b;
} f[M];
int main() {
	int i, u, v, a, b;
	scanf("%d", &casnum);
	for (cas = 1; cas <= casnum; cas++) {
		scanf("%d%d%d%d", &n, &m, &s, &t);
		init();
		for (i = 1; i <= m; i++) {
			scanf("%d%d%d%d", &u, &v, &a, &b);
			f[i].u = u;
			f[i].v = v;
			f[i].a = a;
			f[i].b = b;
			if (a < b) { 
				ans += a;
				din[v]++;
				dout[u]++;
				add(u, v, 1, f[i].b - f[i].a);
			} else {
				ans += b; 
				add(v, u, 1, f[i].a - f[i].b);
			}
		}
		for (i = 1; i <= n; i++) {
			temp[i] = dout[i] - din[i];
			if (i == s)
				temp[i]--;
			else if (i == t)
				temp[i]++;
			if (temp[i] > 0) {
				add(S, i, temp[i], 0);
				totflow += temp[i];
			} else if (temp[i] < 0)
				add(i, T, -temp[i], 0);
		}
		mcmf();
		printf("Case %d: ", cas);
		if (totflow == flow)
			printf("%d\n", ans + cost);
		else
			printf("impossible\n");
	}
	return 0;
}