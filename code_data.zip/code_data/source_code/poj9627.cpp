// Data Structure->Stack,Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=10010;
int finishtime[MAXN];
int indegree[MAXN];
int outdegree[MAXN];
int sumtime[MAXN];
int main()
{
  int n;
  int t;
  int j;
  int to;
  int i;
    while(scanf("%d",&n)!=EOF)
    {
      vector<int> maptt1[MAXN];
      stack<int> sta;
      memset(sumtime,0,sizeof(sumtime));
      memset(indegree,0,sizeof(indegree));
        for(i=1;i<=n;i++)
	{
	  scanf("%d",&finishtime[i]);
	  scanf("%d",&t);
	  for(j=0;j<t;j++)
	    {
     	      scanf("%d",&to);
	      maptt1[to].push_back(i);
	      indegree[i]++;
      	   }
	}
	  for(i=1;i<=n;i++)
	    {
	      if(indegree[i]==0)
		{
		  sta.push(i);
		}
	    }
	  int currentnode;
	  int flag;
	  int currenttime;
	  while(!sta.empty())
	    {
	      currentnode=sta.top();
	      
	      sta.pop();
	      if(sumtime[currentnode]==0)
		{
		  sumtime[currentnode]=finishtime[currentnode];
		}
	      for(i=0;i<maptt1[currentnode].size();i++)
		{
		  flag=maptt1[currentnode][i];
		  indegree[flag]--;
		  
		  currenttime=sumtime[currentnode]+finishtime[flag];
		  if(currenttime>sumtime[flag])
		    {
		      sumtime[flag]=currenttime;
		      
		    }
		  if(indegree[flag]==0)
		    {
		      sta.push(flag);
		    }
		}
	    }
	  int ans=0;
	  for(i=1;i<=n;i++)
	    {
	      if(sumtime[i]>ans)
		{
		  ans=sumtime[i];
		}
	    }
	  printf("%d\n",ans);
    }
  return 0;
}