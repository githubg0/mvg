// Dynamic Programming->Monotone Queue
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 1000006
using namespace std;
struct N{
    int to,next,h;
}my[maxn<<1];
int head[maxn],tot,dp[maxn][3],dpp[maxn],maxx[maxn],minn[maxn];
void init(){
    memset(head,-1,sizeof(head));
    memset(dp,0,sizeof(dp));
    tot=0;
}
void add(int u,int v,int h){
    my[tot].h=h;my[tot].to=v;my[tot].next=head[u];head[u]=tot++;
    my[tot].h=h;my[tot].to=u;my[tot].next=head[v];head[v]=tot++;
}
void dfs1(int u,int pre){
   
    int biggest=0,bigger=0,tmp=0;
    for(int i=head[u];i!=-1;i=my[i].next){
        int v=my[i].to;
        if(v==pre)continue;
        dfs1(v,u);
        tmp=dp[v][0]+my[i].h;
        if(biggest<=tmp){
            bigger=biggest;
            biggest=tmp;
        }
        else if(bigger<tmp){
            bigger=tmp;
        }
    }
    dp[u][0]=biggest;
    dp[u][1]=bigger;
}
void dfs2(int u,int pre){
    for(int i=head[u];i!=-1;i=my[i].next){
        int v=my[i].to;
        if(v==pre)continue;
        dp[v][2]=max(dp[u][2],dp[v][0]+my[i].h==dp[u][0]?dp[u][1]:dp[u][0])+my[i].h;
        dfs2(v,u);
    }
}
int n,m;
void solve()  {
    int ans=0,i,j,front1,front2,rear1,rear2;
    front1=rear1=0;
    front2=rear2=0;
    for(i=1,j=1;j<=n;j++){
        while(rear1>front1&&dpp[maxx[rear1-1]]<=dpp[j]) rear1--;
        maxx[rear1++]=j;
        while(rear2>front2&&dpp[minn[rear2-1]]>=dpp[j]) rear2--;
        minn[rear2++]=j;
        if(dpp[maxx[front1]]-dpp[minn[front2]]>m){
            ans=max(ans,j-i);
            while(dpp[maxx[front1]]-dpp[minn[front2]]>m){
                i=min(maxx[front1],minn[front2])+1;
                while(rear1>front1&&maxx[front1]<i) front1++;
                while(rear2>front2&&minn[front2]<i) front2++;
            }
        }
    }
    ans=max(ans,j-i);
    printf("%d\n",ans);
}
int main(){
    while(scanf("%d%d",&n,&m)!=EOF){
        init();
        for(int i=2;i<=n;++i){
            int b,c;
            scanf("%d%d",&b,&c);
            add(i,b,c);
        }
        dfs1(1,-1);
        dfs2(1,-1);
        for(int i=1;i<=n;++i)dpp[i]=max(dp[i][0],dp[i][2]);
        solve();
    }
    return 0;
}