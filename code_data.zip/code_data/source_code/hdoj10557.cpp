// Data Structure->Segment Tree,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAXN 200005
int tree[4 * MAXN];
int arr[MAXN];
int merge(int x, int y) {
    return x > y ? x : y;
}
void build(int treeIndex, int lo, int hi) {
    if (lo >= hi) {
        tree[treeIndex] = arr[lo];
        return;
    }
    int mid = lo + (hi - lo) / 2;
    build(2 * treeIndex + 1, lo, mid);
    build(2 * treeIndex + 2, mid + 1, hi);
    tree[treeIndex] = merge(tree[2 * treeIndex + 1], tree[2 * treeIndex + 2]);
}
void update(int treeIndex, int lo, int hi, int arrIndex, int val) {
    if (lo >= hi) {
        tree[treeIndex] = val;
        return;
    }
    int mid = lo + (hi - lo) / 2;
    if (arrIndex > mid) update(2 * treeIndex + 2, mid + 1, hi, arrIndex, val);
    else if (arrIndex <= mid) update(2 * treeIndex + 1, lo, mid, arrIndex, val);
    tree[treeIndex] = merge(tree[2 * treeIndex + 1], tree[2 * treeIndex + 2]);
}
int query(int treeIndex, int lo, int hi, int i, int j) {
    if (lo > j || hi < i) return 0;
    if (i <= lo && j >= hi) return tree[treeIndex];
    int mid = lo + (hi - lo) / 2;
    if (i > mid) return query(2 * treeIndex + 2, mid + 1, hi, i, j);
    else if (j <= mid) return query(2 * treeIndex + 1, lo, mid, i, j);
    int leftQuery = query(2 * treeIndex + 1, lo, mid, i, mid);
    int rightQuery = query(2 * treeIndex + 2, mid + 1, hi, mid + 1, j);
    return merge(leftQuery, rightQuery);
}
int main() {
    int m, n;
    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    build(0, 0, n - 1);
    while (m--) {
        char s[2];
        int a, b;
        scanf("%s %d %d", s, &a, &b);
        if (*s == 'Q') {
            printf("%d\n", query(0, 0, n - 1, a - 1, b - 1));
        } else {
            update(0, 0, n - 1, a - 1, b);
        }
    }
    return 0;
}