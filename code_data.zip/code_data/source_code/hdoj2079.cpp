// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int n,m;
char str[105][105];
int dir[8][2]={{1,0},{1,-1},{1,1},{0,-1},{0,1},{-1,-1},{-1,1},{-1,0}};
void dfs(int x,int y)
{
	int i,dx,dy;
	 for(i=0;i<8;i++)
	 {
	 	dx=x+dir[i][0];  dy=y+dir[i][1];
	 	if(dx>=0 && dx<n && dy>=0 && dy<m && str[dx][dy]=='@' )
	 	{
	 		str[dx][dy]='*';
	 		dfs(dx,dy);
	 	}
	 }
}
int main()
{
	int i,j;
	while(scanf("%d%d",&n,&m)&&n||m)
	{	
	    int count=0;
		for(i=0;i<n;i++)
		    scanf("%s",str[i]); 
	    for(i=0;i<n;i++)
	    {
	    	for(j=0;j<m;j++)
	    	{
	    		if(str[i][j]=='@')
	    		{
	    			++count;
	    			dfs(i,j);
	    		}
	    	}
	    }
	    printf("%d\n",count);
	}
	return 0;
}