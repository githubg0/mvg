// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 2000+10;
int n;
struct node {
    int ID;
    int prior;
};
node heap1[N],heap2[N],heap3[N];
int sz1,sz2,sz3;
void init() {
    memset(heap1,0,sizeof(heap1));
    memset(heap2,0,sizeof(heap2));
    memset(heap3,0,sizeof(heap3));
    sz1 = sz2 = sz3 = 0;
}
void push(node heap[],int b,int id,int &sz) {
    int i = sz++;
    while (i > 0) {
        int p = (i - 1) / 2;
        if (heap[p].prior > b || (heap[p].prior == b && heap[p].ID < id)) break;
        heap[i].prior = heap[p].prior;
        heap[i].ID = heap[p].ID;
        i = p;
    }
    heap[i].prior = b;
    heap[i].ID = id;
}
void pop(node heap[],int &sz) {
    int x = heap[--sz].prior;
    int id = heap[sz].ID;
    int i = 0;
    while (i * 2 + 1 < sz) {
        int a = i * 2 + 1;
        int b = i * 2 + 2;
        if (b < sz && ((heap[a].prior < heap[b].prior) || (heap[a].prior == heap[b].prior && heap[a].ID > heap[b].ID))) {
            a = b;
        }
        if (heap[a].prior < x || (heap[a].prior == x && heap[a].ID > id)) break;
        heap[i].prior = heap[a].prior;
        heap[i].ID = heap[a].ID;
        i = a;
    }
    heap[i].prior = x;
    heap[i].ID = id;
}
int main() {
    while (scanf("%d", &n) != EOF) {
        string s;
        int a,b;
        int id = 1;
        init();
        for (int i = 1;i <= n;++i) {
            cin >> s;
            if (s == "IN") {
                scanf("%d%d", &a, &b);
                if (a == 1) {
                    push(heap1,b,id,sz1);
                    
                    id++;
                }
                if (a == 2) {
                    push(heap2,b,id,sz2);
                    id++;
                }       
                if (a == 3) {
                    push(heap3,b,id,sz3);
                    id++;
                }               
            }
            else {
                scanf("%d", &a);
                if (a == 1) {
                    if (sz1 == 0) printf("EMPTY\n");
                    else {
                        printf("%d\n", heap1[0].ID);
                        pop(heap1,sz1);
                    }
                }
                if (a == 2) {
                    if (sz2 == 0) printf("EMPTY\n");
                    else {
                        printf("%d\n", heap2[0].ID);
                        pop(heap2,sz2);
                    }
                }               
                if (a == 3) {
                    if (sz3 == 0) printf("EMPTY\n");
                    else {
                        printf("%d\n", heap3[0].ID);
                        pop(heap3,sz3);
                    }
                }               
            }
        }
    }
    return 0;
}