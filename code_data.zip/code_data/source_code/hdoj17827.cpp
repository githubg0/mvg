// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAX 10005
using namespace std;
struct edge{
  int u;
  int v;
  int w;
}e[MAX];
bool cmp(edge x,edge y)
{
    return x.w<y.w;
}
int n,m,f[MAX],sum,c;
int getf(int v)
{
    if(f[v]==v)
        return v;
    else
    {
        f[v]=getf(f[v]);
        return f[v];
    }
}
int Merge(int v,int u)
{
    int t1=getf(v);
    int t2=getf(u);
    if(t1!=t2)
    {
        f[t2]=t1;
        return 1;
    }
    return 0;
}
void init()
{
    for(int i=1;i<=n;i++)
    {
        f[i]=i;
    }
}
int main()
{
    int i;
    while(~scanf("%d",&n))
    {
      if(n==0) break;
      if(n==1)
      {
         printf("0\n");
         continue;
      }
      int m=n*(n-1)/2,x;
      for(i=1;i<=m;i++)
      {
        scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].w);
      }
      sort(e+1,e+m+1,cmp);
      init();
      c=sum=0;
      for(i=1;i<=m;i++)
      {
        if(Merge(e[i].u,e[i].v))
         {
             c+=1;
             sum+=e[i].w;
         }
         if(c==n-1)
            break;
      }
      printf("%d\n",sum);
    }
    return 0;
}