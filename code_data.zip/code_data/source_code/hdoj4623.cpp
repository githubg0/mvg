// Basic Algorithm->Recursion,Math and Computational Geometry->Greatest Common Divisor (GCD),Math and Computational Geometry->Inclusion–Exclusion Principle,Math and Computational Geometry->Euler's Totient Function,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef __int64_t ll;
ll prime[100005];
bool flag[100005];
ll phi[100005];
vector<ll>link[100005];
void init()
{
    ll i,j,num=0;
    phi[1]=1;
    for(i=2;i<=100000;i++)
    {
        if(!flag[i])
        {
            prime[num++]=i;
            phi[i]=i-1;
        }
        for(j=0;j<num&&prime[j]*i<=100000;j++)
        {
            flag[prime[j]*i]=true;
            if(i%prime[j]==0)
            {
                phi[i*prime[j]]=phi[i]*prime[j];
                break;
            }
            else
                phi[i*prime[j]]=phi[i]*(prime[j]-1);
        }
    }
    for(j=1;j<=100000;j++)
    {
        ll tmp=j;
        for(i=0;prime[i]*prime[i]<=tmp;i++)
        {
            if(tmp%prime[i]==0)
            {
                link[j].push_back(prime[i]);
                tmp=tmp/prime[i];
                while(tmp%prime[i]==0)
                    tmp=tmp/prime[i];
            }
            if(tmp==1)
                break;
        }
        if(tmp>1)
            link[j].push_back(tmp);
    }
}
ll dfs(ll x,ll b,ll now)
{
    ll i,res=0;
    for(i=x;i<link[now].size();i++)
        res=res+b/link[now][i]-dfs(i+1,b/link[now][i],now);
    return res;
}
int main()
{
    init();
    ll i,a,b,t,T,ans,c,d,k;
    while(scanf("%I64d",&T)!=EOF)
    {
        for(t=1;t<=T;t++)
        {
            ans=0;
            scanf("%I64d%I64d%I64d%I64d%I64d",&a,&b,&c,&d,&k);
            if(k==0||k>b||k>d)
            {
                printf("Case %I64d: 0\n",t);
                continue;
            }
            if(b>d)
                swap(b,d);
            b=b/k,d=d/k;
            for(i=1;i<=b;i++)
                ans=ans+phi[i];
            for(i=b+1;i<=d;i++)
                ans=ans+b-dfs(0,b,i);
            printf("Case %I64d: %I64d\n",t,ans);
        }
    }
    return 0;
}