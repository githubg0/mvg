// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int times[1010],dist[1010],juzhen[1010][1010];
bool used[1010];
queue<int>a;
int main()
{
	int i,j,n,ml,md,MAX=1000000000;
	scanf("%d%d%d",&n,&ml,&md);
	int u,v,w;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			juzhen[i][j]=MAX;
			if(i==j) juzhen[i][j]=0;
		}
			
	for(i=2;i<=n;i++)
		juzhen[i][i-1]=0; 
	for(i=1;i<=n;i++)
		dist[i]=MAX;
	for(i=1;i<=ml;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		if(u>v)
		{
			int t=u;
			u=v;
			v=t;
		}
		juzhen[u][v]=w;
	 } 
	for(i=1;i<=md;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		if(u<v)
		{
			int t=u;
			u=v;
			v=t;
		}
		juzhen[u][v]=-w;
	}
	a.push(1);
	used[1]=1;
	times[1]++;
	dist[1]=0;
	int s;
	while(!a.empty())
	{
		s=a.front();
		a.pop();
		used[s]=0;
		for(i=1;i<=n;i++)
			if(dist[i]>dist[s]+juzhen[s][i])
			{
				dist[i]=dist[s]+juzhen[s][i];
				if(!used[i])
				{
					a.push(i);
					times[i]++;
					used[i]=1;
					if(times[i]>=n)
					{
						printf("-1");
						return 0;
					}
						
				}
			}
	}
	if(dist[n]==MAX)
		printf("-2");
	else
		printf("%d",dist[n]);
}