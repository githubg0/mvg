// Data Structure->Stack
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node{int l,r;};
int main()
{
    ios::sync_with_stdio(false);
    map<char,node> m;
    int n;char a;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a;
        cin>>m[a].l>>m[a].r;
    }
    string s;
    while(cin>>s)
    {
        stack<node> u;
        int count=0;
        int i;
        for(i=0;i<s.size();i++)
        {
            if(s[i]=='(')continue;
            else if(s[i]==')')
            {
                node p,q;
                p=u.top();
                u.pop();
                q=u.top();
                u.pop();
                if(p.l!=q.r)
                {
                    cout<<"error"<<endl;
                    break;
                }
                count+=q.l*p.l*p.r;
                node v={q.l,p.r};
                u.push(v);
            }
            else {
                    u.push(m[s[i]]);
            }
        }
        if(i==s.size())
        {
            cout<<count<<endl;
        }
    }
    return 0;
}