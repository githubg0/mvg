// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100005
#define INF 0x3f3f3f3f
#define LL long long
#define ULL unsigned long long
#define E 1e-8
#define mod 1000000007
#define P pair<int,int>
#define MID(l,r) (l+(r-l)/2)
#define lson(o) (o<<1) 
#define rson(o) (o<<1|1) 
using namespace std;
int M;
int p,v;
struct node
{
    int l,r;
    LL sum;
    bool flag;
}tree[maxn<<2];
void build(int o,int l,int r)
{
    tree[o].l = l;
    tree[o].r = r;
    tree[o].flag = 1;
    if(l == r){
        tree[o].sum = 1;
        return ;
    }
    int m = MID(l,r);
    int lc = lson(o),rc = rson(o);
    build(lc,l,m);
    build(rc,m+1,r);
    tree[o].sum = 1;  
    if(tree[lc].flag==1) tree[o].sum = tree[o].sum*tree[lc].sum % M;
    if(tree[rc].flag==1) tree[o].sum = tree[o].sum*tree[rc].sum % M;
}
void update(int t,int o)
{
    if(tree[o].l == tree[o].r){
        if(t == 1){
            tree[o].flag = 1;
            tree[o].sum  = v;
        }
        else{
            tree[o].flag = 0;
        }
        return ;
    }
    int m = MID(tree[o].l,tree[o].r);
    int lc = lson(o),rc = rson(o);
    if(p <= m) update(t,lc);
    else update(t,rc);
    tree[o].sum = 1;  
    if(tree[lc].flag==1) tree[o].sum = tree[o].sum*tree[lc].sum % M;
    if(tree[rc].flag==1) tree[o].sum = tree[o].sum*tree[rc].sum % M;
}
int main()
{
    int T,cases = 0;
    int n,temp,op,x;
    scanf("%d",&T);
    while(T--){
        printf("Case #%d:\n",++cases);
        scanf("%d %d",&n,&M);
        build(1,1,n);
        for(int i=1;i<=n;++i){
            scanf("%d %d",&op,&x);
            if(op == 1){
                temp = 1;
                p = i;
                v = x;
            }
            else{
                temp = 0;
                p = x;
            }
            update(temp,1);
            printf("%lld\n",tree[1].sum);
        }
    }
}