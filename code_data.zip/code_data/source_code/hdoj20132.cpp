// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
using namespace std;
inline int lowbit(int x){
    return x&-x;
}
int n,m;
int t[50001];
inline int query(int x){
    int sum=0;
    while(x){
        sum+=t[x];
        x-=lowbit(x);
    }
    return sum;
}
inline void update(int x,int v){
    while(x<=n){
        t[x]+=v;
        x+=lowbit(x);
    }
}
int solve(int x){
    if(query(x)-query(x-1)==0){
        return 0;
    }
    int l=1,r=x;
    int mid;
    while(l<r){
        mid=(l+r)>>1;
        if(query(mid)-query(l-1)==mid-l+1){
            l=mid+1;
        }
        else{
            r=mid;
        }
    }
    int sum=0;
    if(query(x)==x){
        sum+=x;
    }
    else{
        sum+=x-l;
    }
    l=x,r=n;
    while(l<r){
        mid=(l+r)>>1;
        if(query(mid)-query(l-1)==mid-l+1){
            l=mid+1;
        }
        else{
            r=mid;
        }
    }
    if(query(n)-query(x-1)==n-x+1){
        sum+=n-x;
    }
    else{
        sum+=l-x-1;
    }
    return sum;
}
stack<int> s;
int main(){
    scanf("%d %d",&n,&m);
    for(int i=1;i<=n;i++){
        update(i,1);
    }
    for(int i=1;i<=m;i++){
        char ch;
        cin>>ch;
        if(ch=='D'){
            int x;
            scanf("%d",&x);
            update(x,-1);
            s.push(x);
        }
        else if(ch=='R'){
            int x=s.top();
            s.pop();
            update(x,1);
        }
        else{
            int x;
            scanf("%d",&x);
            printf("%d\n",solve(x));
        }
    }
    return 0;
}