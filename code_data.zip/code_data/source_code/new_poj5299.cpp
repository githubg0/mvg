// Graph Algorithm->Hungarian (KM) Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxN=128; 
int M,v1,v2;
bool g[maxN][maxN];
bool vis[maxN];
int link[maxN],ans[maxN],match[maxN];
struct Rec
{
	int x1,y1,x2,y2;	
}rec[maxN];
struct Point 
{
	int x,y;
}p[maxN];
bool dfs(int x)
{
	for(int y=1;y<=v2;++y)	
		if(g[x][y]&&!vis[y]){
			vis[y]=true;
			if(link[y]==0||dfs(link[y])){
				link[y]=x;
				match[x]=y;
				return true;
			}
		}
	return false;
}
void hungary()
{
	for(int x=1;x<=v1;++x){
		memset(vis,false,sizeof(vis));
		if(dfs(x))
			++M;
	}	
	return ;
}
int main()
{
	int i,j,n,cases=0;
	while(scanf("%d",&n)==1&&n){
		memset(g,0,sizeof(g));
		for(i=1;i<=n;++i)
			scanf("%d%d%d%d",&rec[i].x1,&rec[i].x2,&rec[i].y1,&rec[i].y2);
		for(i=1;i<=n;++i)
			scanf("%d%d",&p[i].x,&p[i].y);
		for(i=1;i<=n;++i)
			for(j=1;j<=n;++j)
				if(p[j].x>rec[i].x1&&p[j].x<rec[i].x2&&p[j].y>rec[i].y1&&p[j].y<rec[i].y2)
					g[i][j]=1;
		v1=v2=n;
		memset(ans,0,sizeof(ans));
		printf("Heap %d\n",++cases);
		for(i=1;i<=n;++i){
			M=0;
			memset(match,0,sizeof(match));
			memset(link,0,sizeof(link));
			hungary();
			if(match[i]==0) continue;
			int u=i,v=match[i],M0=M;
			g[u][v]=0;
			M=0;
			memset(link,0,sizeof(link));
			memset(match,0,sizeof(match));
			hungary();
			if(M==M0&&match[i]!=0){
				g[u][v]=1;	
				continue;
			}
			ans[i]=v;
			g[u][v]=1;	
		}	
		int flag=0;
		for(i=1;i<=n;++i)
			if(ans[i]!=0){
				flag=1;
				break;
			}
		if(flag==0)
			printf("none");
		else
			for(i=1;i<=n;++i)
				if(ans[i]!=0)
					printf("(%c,%d) ",i-1+'A',ans[i]);
		printf("\n\n");	
	}
	return 0;	
}