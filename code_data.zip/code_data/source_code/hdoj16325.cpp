// Math and Computational Geometry->Euler's Totient Function,Math and Computational Geometry->Fermat's Little Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define LL long long
#define MOD 1000000007
struct Matrix
{
    LL a[3][3];
};
Matrix ori, res;
LL F[3];
void init()
{
    memset(ori.a, 0, sizeof(ori.a));
    memset(res.a, 0, sizeof(res.a));
    for(int i = 0; i < 2; i++)
        res.a[i][i] = 1;
    ori.a[0][1] = ori.a[1][0] = ori.a[1][1] = 1;
}
Matrix muitl(Matrix x, Matrix y)
{
    Matrix z;
    memset(z.a, 0, sizeof(z.a));
    for(int i = 0; i < 2; i++)
    {
        for(int k = 0; k < 2; k++)
        {
            if(x.a[i][k] == 0) continue;
            for(int j = 0; j < 2; j++)
                z.a[i][j] = (z.a[i][j] + (x.a[i][k] * y.a[k][j]) % (MOD-1)) % (MOD-1);
        }
    }
    return z;
}
LL pow_mod(LL a, LL n)
{
    LL ans = 1;
    while(n)
    {
        if(n & 1)
            ans = ans * a % MOD;
        a = a * a % MOD;
        n >>= 1;
    }
    return ans;
}
LL ans[3];
void solve(LL a, LL b, LL n)
{
    init();
    while(n)
    {
        if(n & 1)
            res = muitl(ori, res);
        ori = muitl(ori, ori);
        n >>= 1;
    }
    for(int i = 0; i < 2; i++)
    {
        ans[i] = 0;
        for(int k = 0; k < 2; k++)
            ans[i] = (ans[i] + (res.a[i][k] * F[k]) % (MOD-1)) % (MOD-1);
    }
    LL X = ans[0] % (MOD-1);
    LL Y = ans[1] % (MOD-1);
    LL A = pow_mod(a, X);
    LL B = pow_mod(b, Y);
    printf("%lld\n", A*B%MOD);
}
int main()
{
    LL a, b, n;
    F[0] = F[1] = 1;
    while(scanf("%lld%lld%lld", &a, &b, &n) != EOF)
    {
        if(n == 0)
        {
            printf("%lld\n", a % MOD);
            continue;
        }
        if(n == 1)
        {
            printf("%lld\n", b % MOD);
            continue;
        }
        solve(a, b, n-2);
    }
    return 0;
}