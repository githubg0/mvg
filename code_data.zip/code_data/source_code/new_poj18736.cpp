// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
class Node
{
public:
	int lx,ly;
	bool stand;
	bool horizontal;
	int t;
	 Node()
	{
	}
	 
	 Node(int x,int y,bool s,bool h, int t)
	{
		this->lx = x;
		this->ly = y;
		this->stand = s;
		this->horizontal = h;
		this->t = t;
	}
};
char maptt1[501][501];
int visMat[502][502][3] ;
const int MAX =  1<<30;
bool  TestLie(int lx, int ly, bool hFlag, int r, int c)
{
	if(lx<0 || lx >=r || ly<0 || ly>=c)
	{
		return false;
	}
	if(hFlag == true)
	{
		if(ly < c-1)
		{
			if( (maptt1[lx][ly] != '#') && (maptt1[lx][ly+1] != '#') )
				return true;
		}
	}
	else
	{
		if(lx < r-1)
		{
			if( (maptt1[lx][ly] != '#') && (maptt1[lx+1][ly] != '#') )
				return true;
		}
	}
	return false;
}
bool TestStand(int lx, int ly, int r, int c)
{
	if(lx>=0 && ly>=0 && lx < r && ly < c && maptt1[lx][ly]!='#' && maptt1[lx][ly]!='E')
		return true;
	return false;
}
int BFSearch(int r,int c,Node sNode, int ex,int ey)
{
	int visNum = -1;
	queue<Node> nodeQueue;
	nodeQueue.push(sNode);
	while(nodeQueue.empty() == false)
	{
		Node node = nodeQueue.front();
		nodeQueue.pop();
		
		if(node.stand == true && node.lx == ex && node.ly == ey)
		{
			
			visNum = visMat[node.lx][node.ly][0];
			break;
		}
		
		
		if(node.stand == true)
		{
			
			if(TestLie((node.lx - 2), node.ly, false, r, c)
				&&
				node.t + 1 < visMat[node.lx-2][node.ly][2])
			{
				Node tNode((node.lx-2), node.ly, false, false, (node.t+1));
				nodeQueue.push(tNode);
				visMat[node.lx-2][node.ly][2] = node.t + 1;
			}
			
			if(TestLie((node.lx + 1), node.ly, false, r, c)
				&&
				node.t + 1 < visMat[node.lx+1][node.ly][2])
			{
				Node tNode((node.lx+1), node.ly, false, false, (node.t+1));
				nodeQueue.push(tNode);
				visMat[node.lx+1][node.ly][2] = node.t + 1;
			}
			
			if(TestLie(node.lx, (node.ly - 2), true, r, c)
				&&
				node.t + 1 < visMat[node.lx][node.ly - 2][1])
			{
				Node tNode(node.lx, (node.ly - 2), false, true, (node.t+1));
				nodeQueue.push(tNode);
				visMat[node.lx][node.ly - 2][1] = node.t + 1;
			}
			
			if(TestLie(node.lx, (node.ly + 1), true, r, c)
				&&
				node.t + 1 < visMat[node.lx][node.ly + 1][1])
			{
				Node tNode(node.lx, (node.ly + 1), false, true, (node.t+1));
				nodeQueue.push(tNode);
				visMat[node.lx][node.ly + 1][1] = node.t + 1;
			}
		}
		else
		{
			if(node.horizontal == true)
			{
				
				if(TestLie((node.lx - 1 ), node.ly, true, r, c)
					&&
					node.t + 1 < visMat[node.lx-1][node.ly][1])
				{
					Node tNode((node.lx-1), node.ly, false, true, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx-1][node.ly][1] = node.t + 1;
				}
				
				if(TestLie((node.lx + 1 ), node.ly, true, r, c)
					&&
					node.t + 1 < visMat[node.lx+1][node.ly][1])
				{
					Node tNode((node.lx+1), node.ly, false, true, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx+1][node.ly][1] = node.t + 1;
				}
				
				if(TestStand(node.lx, (node.ly-1), r, c)
					&&
					node.t + 1 < visMat[node.lx][node.ly-1][0])
				{
					Node tNode(node.lx, (node.ly-1), true, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx][node.ly - 1][0] = node.t + 1;
				}
				
				if(TestStand(node.lx, (node.ly+2), r, c)
					&&
					node.t + 1 < visMat[node.lx][node.ly+2][0])
				{
					Node tNode(node.lx, (node.ly+2), true, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx][node.ly + 2][0] = node.t + 1;
				}
			}
			else
			{
				
				if(TestLie(node.lx, (node.ly-1), false, r, c)
					&&
					node.t + 1 < visMat[node.lx][node.ly-1][2])
				{
					Node tNode(node.lx, (node.ly-1), false, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx][node.ly-1][2] = node.t + 1;
				}
				
				if(TestLie(node.lx, (node.ly+1), false, r, c)
					&&
					node.t + 1 < visMat[node.lx][node.ly+1][2])
				{
					Node tNode(node.lx, (node.ly+1), false, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx][node.ly+1][2] = node.t + 1;
				}
				
				if(TestStand( (node.lx-1), node.ly, r, c)
					&&
					node.t + 1 < visMat[node.lx-1][node.ly][0])
				{
					Node tNode((node.lx-1), node.ly, true, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx-1][node.ly][0] = node.t + 1;
				}
				
				if(TestStand((node.lx+2), node.ly, r, c)
					&&
					node.t + 1 < visMat[node.lx+2][node.ly][0])
				{
					Node tNode((node.lx+2), node.ly, true, false, (node.t+1));
					nodeQueue.push(tNode);
					visMat[node.lx+2][node.ly][0] = node.t + 1;
				}
			}
		}
	}
	return visNum;
}
int main()
{
	int r,c;
	scanf("%d%d",&r,&c);
	while(r!=0 && c!=0)
	{
		int ex = 0,ey = 0;
		Node sNode;
		sNode.t = 0;
		
		for(int i=0;i<r;i++)
		{
			scanf("%s",maptt1[i]);
		}
			
			
			
			
			
			
			
			
		
		int flag = 0;
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				if( (maptt1[i][j] == 'X') && ((flag & 1) == 0) )
				{
					flag = flag | 1;
					if( (j+1 < c) && (maptt1[i][j+1] == 'X') )
					{
						sNode.horizontal =true;
						sNode.stand = false;
						sNode.lx = i;
						sNode.ly = j;
						visMat[i][j][1] = 0;
					}
					else if( (i+1<r) && (maptt1[i+1][j] == 'X') )
					{
						sNode.horizontal =false;
						sNode.stand = false;
						sNode.lx = i;
						sNode.ly = j;
						visMat[i][j][2] = 0;
					}
					else
					{
						sNode.stand = true;
						sNode.lx = i;
						sNode.ly = j;
						visMat[i][j][0] = 0;
					}
				}
				else if(maptt1[i][j] == 'O')
				{
					flag = flag | (1<<1);
					ex = i;
					ey = j;
				}
			}
			if(flag == 3)
				break;
		}
		
		for(int i=0;i<r;i++)
			for(int j=0;j<c;j++)
				for(int k=0;k<3;k++)
				{
					visMat[i][j][k] = MAX;
				}
		
				int step = BFSearch(r, c, sNode, ex,ey);
				if(step >= 0)
				{
					printf("%d\n",step);
				}
				else
				{
					printf("Impossible\n");
				}
				scanf("%d%d",&r,&c);
	}
}