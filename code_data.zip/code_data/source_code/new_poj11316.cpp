// Data Structure->Disjoint Set Union (DSU)
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0xfffffff
int N,D,x,y;
struct node{
	bool rep;
	int x,y;
}mp[1005];int pa[1005];
double distants(node a,node b)
{
	return sqrt((double)(a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
int findset(int x)
{
	return pa[x]==x?x:pa[x]=findset(pa[x]);
}
int unite(int x,int y)
{
	int px=findset(x);
	int py=findset(y);
	if(px!=py)
		if(distants(mp[x],mp[y])<=(double)D)
			pa[py]=px;
}
int main()
{
	char op;
	scanf("%d%d",&N,&D);
	for(int i=1;i<=N;i++)
	{
		pa[i]=i;
		scanf("%d%d",&mp[i].x,&mp[i].y);
		mp[i].rep=false;
	}
	while(scanf(" %c",&op)!=EOF)
	{
		int a,b;
		if(op=='O')
		{
			scanf("%d",&a);
			mp[a].rep=true;
			for(int i=1;i<=N;i++)
			{
				if(i!=a && mp[i].rep==true)
					unite(i,a);
			}
		}
		else
		{
			scanf("%d%d",&a,&b);
			if(findset(a)==findset(b))
				printf("SUCCESS\n");
			else
				printf("FAIL\n");
		}
	}
	return 0;
 }