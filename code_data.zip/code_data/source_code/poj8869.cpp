// Math and Computational Geometry->Convex Hull Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define PI 3.1415926
#define INF 0x3f3f3f3f
const double eps=1e-12;
#define _sign(x) ((x)>eps?1:((x)<-eps?2:0))
using namespace std;
const int MAXN = 30;
struct Point {
    double x,y;
    double l;
    int v;
    Point() {}
    Point(double _x,double _y) {
        x = _x;
        y = _y;
    }
    Point operator -(const Point &b)const {
        return Point(x - b.x,y - b.y);
    }
    double operator ^(const Point &b)const {
        return x*b.y - y*b.x;
    }
    double operator *(const Point &b)const {
        return x*b.x + y*b.y;
    }
    void transXY(double B) {
        double tx = x,ty = y;
        x = tx*cos(B) - ty*sin(B);
        y = tx*sin(B) + ty*cos(B);
    }
};
Point L[MAXN],P[MAXN];
int Stack[MAXN],top;
int n;
double dist(Point a,Point b) {
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
int sgn(double x) {
    if(fabs(x)<eps)return 0;
    if(x<0)return -1;
    return 1;
}
bool _cmp(Point p1,Point p2) {
    double tmp = (p1-L[0])^(p2-L[0]);
    if(sgn(tmp) > 0)return true;
    else if(sgn(tmp) == 0 && sgn(dist(p1,L[0]) - dist(p2,L[0])) <= 0)
        return true;
    else return false;
}
void Graham(int m) {
    if(m<=1)return;
    Point p0;
    int k = 0;
    p0 = L[0];
    for(int i = 1; i < m; i++) {
        if( (p0.y > L[i].y) || (p0.y == L[i].y && p0.x > L[i].x) ) {
            p0 = L[i];
            k = i;
        }
    }
    swap(L[k],L[0]);
    sort(L+1,L+m,_cmp);
    if(m == 1) {
        top = 1;
        Stack[0] = 0;
        return;
    }
    if(m == 2) {
        top = 2;
        Stack[0] = 0;
        Stack[1] = 1;
        return ;
    }
    Stack[0] = 0;
    Stack[1] = 1;
    top = 2;
    for(int i = 2; i < m; i++) {
        while(top > 1 && sgn((L[Stack[top-1]]-L[Stack[top-2]])^(L[i]-L[Stack[top-2]])) <= 0)
            top--;
        Stack[top++] = i;
    }
}
int main() {
    
    int ca=1;
    while(cin>>n&&n) {
        for(int i=0; i<n; i++) {
            scanf("%lf%lf%d%lf",&P[i].x,&P[i].y,&P[i].v,&P[i].l);
        }
        int m=0;
        int ans=INF,id=0;
        int num=0;
        double ss=99999999.0;
        for(int i=0; i<(1<<n); i++) {
            double ls=0;
            int sum=0;
            m=0;
            for(int j=0; j<n; j++) {
                if(i&(1<<j)) {  
                    sum+=P[j].v;
                    ls+=P[j].l;
                } else
                    L[m++]=P[j];
            }
            if(sum>ans)continue;
            Graham(m);
            double s=0;
            for(int j=0; j<top; j++) { 
                int u=Stack[j],v=Stack[(j+1)%top];
                s+=dist(L[u],L[v]);
            }
            if(m<=1)s=0;
            if(ls>=s) {
                if(ans>sum) {
                    ans=sum;
                    num=n-m;
                    id=i;
                    ss=ls-s;
                } else if(ans==sum) {
                    if(num>n-m) {
                        ss=ls-s;
                        id=i;
                        num=n-m;
                    }
                }
            }
        }
        if(ca!=1)cout<<endl;
        printf("Forest %d\n",ca++);
        printf("Cut these trees:");
        for(int i=0; i<n; i++) {
            if(id&(1<<i))printf(" %d",i+1);
        }
        printf("\nExtra wood: %.2f\n",ss);
    }
    return 0;
}