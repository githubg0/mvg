// Data Structure->Spanning Tree,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mst(a,b) memset((a),(b),sizeof(a))
#define f(i,a,b) for(int i=(a);i<=(b);++i)
#define rush() int T;scanf("%d",&T);while(T--)
typedef long long ll;
const int maxn= 1005;
const int mod = 1e9+7;
const int INF = 0x3f3f3f3f;
const double eps = 1e-6;
char a[maxn][maxn];
vector<int>vec[maxn];
int vis[maxn];
int dis[maxn];
int num[maxn];
void spfa()
{
    mst(vis,0);
    mst(dis,0x3f);
    dis[0]=0;
    vis[0]=1;
    queue<int>q;
    q.push(0);
    while(q.size())
    {
        int cur=q.front();
        q.pop();
        vis[cur]=0;
        for(int i=0;i<vec[cur].size();i++)
        {
            int nex=vec[cur][i];
            int w=a[cur][nex]-'0';
            if(dis[nex]>dis[cur]+w)
            {
                dis[nex]=dis[cur]+w;
                if(vis[nex]==0)
                {
                    vis[nex]=1;
                    q.push(nex);
                }
            }
        }
    }
}
int main()
{
    int n;
    while(~scanf("%d",&n))
    {
        mst(num,0);
        for(int i=0;i<n;i++)
        {
            scanf("%s",a[i]);
            vec[i].clear();
        }
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<i;j++)
            {
                if(a[i][j]!='0')
                {
                    vec[i].push_back(j);
                    vec[j].push_back(i);
                }
            }
        }
        spfa();
        for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
        {
            if(a[i][j]=='0')    continue;
            int w=a[i][j]-'0';
            if(dis[i]+w==dis[j])
                num[j]++;
        }
        ll ans=1;
        for(int i=1;i<n;i++)
        {
            ans=(ans*num[i])%mod;
        }
        printf("%I64d\n",ans);
    }
    return 0;
}