// Graph Algorithm->Dijkstra's Algorithm,Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
#define MAXN 110
int maptt1[MAXN][MAXN],vis[MAXN],dis[MAXN],dp[11000],p[MAXN];
int n,m;
void disjtra()
{
	memset(vis,0,sizeof(vis));
	memset(dis,INF,sizeof(dis));
	for(int i=0;i<=n;i++)
	dis[i]=maptt1[0][i];
	vis[0]=1;
	for(int i=1;i<=n;i++)
	{
		int minn=INF;
		int flag=0;
		for(int j=0;j<=n;j++)
		{
			if(!vis[j]&&minn>dis[j])
			{
				minn=dis[j];
				flag=j;
			}
		}
		vis[flag]=1;
		for(int j=0;j<=n;j++)
		{
			if(!vis[j]&&dis[flag]+maptt1[flag][j]<dis[j])
			{
				dis[j]=dis[flag]+maptt1[flag][j];
			}
		}
	}
}
int main()
{
	int t,i,j;
	int a,b,c;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		memset(maptt1,INF,sizeof(maptt1));
		while(m--)
		{
			scanf("%d%d%d",&a,&b,&c);
			if(c<maptt1[a][b])
				maptt1[a][b]=maptt1[b][a]=c;
		}
		int sum=0;
		for(i=1;i<=n;i++) 
		{
			scanf("%d",&p[i]);
			sum+=p[i];
		}
		sum/=2;
		disjtra();
		int v=0;
		for(i=1;i<=n;i++)
		{
			if(dis[i]!=INF)
				v+=dis[i];
		}
		memset(dp,0,sizeof(dp));
		for(i=1;i<=n;i++)
		{
			if(dis[i]!=INF)
			{
				for(j=v;j>=dis[i];j--)
					dp[j]=max(dp[j],dp[j-dis[i]]+p[i]);
			}
		}
		int flag=1;
		for(i=0;i<=v;i++) 
		{
			if(dp[i]>sum)
			{
				flag=0;
				break;
			}
		}
		if(flag)
			printf("impossible\n");
		else
			printf("%d\n",i);
	}
	return 0;
}