// Sorting->Quick Sort,Basic Algorithm->Discretization,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[1010], b[1010], c[1010], sum[1010][1010];
map<int ,int > mp;
int n, C, k;
int get(int x)
{
    return lower_bound(c, c + k, x) - c;
}
bool check(int mid)
{
    for(int x1 = 1, x2 = 1; x2 < k; x2++){
        while(c[x2] - c[x1] + 1 > mid)x1++;  
        for(int y1 = 1, y2 = 1; y2 < k; y2++){
            while(c[y2] - c[y1] + 1 > mid)y1++;
            if(sum[x2][y2] - sum[x2][y1 - 1] - sum[x1 - 1][y2] + sum[x1 - 1][y1 - 1] >= C)
            
                return true;
        }
    }
    return false;
}
int main()
{
    cin >> C >> n;
    c[0] = 0;
    k = 1;
    for(int i = 0; i < n; i++){
        cin >> a[i] >> b[i];
        if(!mp[a[i]]){        
            mp[a[i]] = 1;
            c[k++] = a[i];
        }
        if(!mp[b[i]]){
            mp[b[i]] = 1;
            c[k++] = b[i];
        }
    }
    sort(c, c + k);  
    for(int i = 0; i < n; i++){
        int x = get(a[i]), y = get(b[i]);
        sum[x][y]++;
    }
    for(int i = 1; i < k; i++)
        for(int j = 1; j < k; j++)
            sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1]; 
    int l = 1, r = 10000;
    while(l < r){    
        int mid = (l + r) >> 1;
        if(check(mid))r = mid;
        else l = mid + 1;
    }
    cout << r<< endl;
    return 0;
}