// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x3f3f3f3f
#define Max 110
int max(int a,int b)
{
	return a>b?a:b;
}
int min(int a,int b)
{
	return a<b?a:b;
}
int eid,p[110],du[110],rec[110],sumdu,cnt,vst[110];
double sum,c[110];
double ans[110];
struct node
{
    int to,next;
}e[20200];
inline void addedge(int u,int v)
{
    e[eid].to=v;
    e[eid].next=p[u];
    p[u]=eid++;
}
void dfs(int u)
{
    int i;
    rec[cnt++]=u;
    vst[u]=1;
    sum+=c[u],sumdu+=du[u];
    for(i=p[u];i!=-1;i=e[i].next)
    {
        int v=e[i].to;
        if(vst[v])
            continue;
        dfs(v);
    }
}
int main()
{
    int t,n,m,u,v,i,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        memset(du,0,sizeof(du));
        memset(vst,0,sizeof(vst));
        memset(p,-1,sizeof(p));
        for(i=1;i<=n;i++)
            scanf("%lf",&c[i]);
        for(i=1;i<=m;i++)
        {
            scanf("%d%d",&u,&v);
            du[u]++;du[v]++;
            addedge(u,v);
            addedge(v,u);
        }
        for(i=1;i<=n;i++)
        {
            sum=0;sumdu=0;
            cnt=0;
            if(!vst[i])
            {
                dfs(i);
                for(j=0;j<cnt;j++)
                {
                    if(sumdu==0)
                    {
                        ans[rec[j]]=sum;
                        continue;
                    }
                    ans[rec[j]]=sum*du[rec[j]]/sumdu;
                }
            }
        }
        for(i=1;i<=n;i++)
            printf("%.3lf\n",ans[i]);
        puts("");
    }
}