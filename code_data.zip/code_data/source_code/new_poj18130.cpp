// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M 6000
#define N 6005
#define INF 1000000000
struct node
{
    int to, val;
    node * next;
};
node * eg[M];
int n, m, w, flog;
int vis[N], cnt[N], dist[N];
void SPFA(int v)
{
    queue<int> q;
    node * p;
    memset(vis, 0, sizeof(vis));
    memset(cnt, 0, sizeof(cnt));
    for (int i = 1; i <= m + w; i++)
    {
        if (i == v)
            dist[i] = 0;
        else
            dist[i] = INF;
    }
    q.push(v);
    vis[v] = 1;
    while (!q.empty())
    {
        int a = q.front();
        q.pop();
        vis[a] = 0;
        cnt[a]++;
        if (cnt[a] > n)
        {
            flog = 1;
            return;
        }
        p = eg[a];
        while (p)
        {
            if (dist[a] < INF && dist[a] + p->val < dist[p->to])
            {
                dist[p->to] = dist[a] + p->val;
                if (!vis[p->to])
                {
                    q.push(p->to);
                    vis[p->to] = 1;
                }
            }
            p = p->next;
        }
    }
}
int main()
{
    int f;
    cin >> f;
    while (f--)
    {
        node * p; flog = 0;
        scanf("%d %d %d", &n, &m, &w);
        for (int i = 0; i <= n; i++)
        {
            eg[i] = NULL;
        }
        for (int i = 1; i <= m + w; i++)
        {
            int s, e, t;
            scanf("%d %d %d", &s, &e, &t);
            p = new node;
            if (i > m)
                t = -t;
            p->to = e; p->val = t;
            p->next = NULL;
            if (eg[s] == NULL)
                eg[s] = p;
            else
            {
                p->next = eg[s];
                eg[s] = p;
            }
            if (i > m)      
                continue;
            p = new node;
            p->to = s; p->val = t;
            p->next = NULL;
            if (eg[e] == NULL)
                eg[e] = p;
            else
            {
                p->next = eg[e];
                eg[e] = p;
            }
        }
        SPFA(1);
        if (flog)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
        for (int i = 0; i <= n; i++)
        {
            while (eg[i])
            {
                p = eg[i]; eg[i] = p->next;
                delete p;
            }
        }
    }
    return 0;
}