// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX_NUM = 301;
int direction[4][2] = {{-1,0},{1,0},{0,1},{0,-1}};
struct board{
    int height;
    int x,y;
    bool operator<(const board &a) const{
        return height - a.height < 0;
    }
    bool operator<=(const board &a) const{
        return height - a.height <= 0;
    }
    bool operator>(const board &a) const{
        return height - a.height > 0;
    }
    bool operator>=(const board &a) const{
        return height - a.height >= 0;
    }
}bowl[MAX_NUM][MAX_NUM];
bool exist[MAX_NUM][MAX_NUM];
board *heap;
int heap_size;
long long water_level;
int w,h;
void heap_filter_up(){
    int i=heap_size-1,j=(i-1)/2;
    board tmp = heap[i];
    while(i>0){
        if(tmp >= heap[j]){
            break;
        }
        else{
            heap[i] = heap[j];
            i=j;
            j=(i-1)/2;
        }
    }
    heap[i] = tmp;
}
void heap_filter_down(){
    int i=0,j=2*i+1;
    board tmp=heap[0];
    while(j < heap_size){
        if(j < heap_size-1 && heap[j] > heap[j+1]){
            ++j;
        }
        if(tmp <= heap[j]){
            break;
        }
        else{
            heap[i] = heap[j];
            i=j;
            j=2*j+1;
        }
    }
    heap[i] = tmp;
}
void heap_insert(board &a){
    heap[heap_size] = a;
    heap_size++;
    heap_filter_up();
}
void heap_popmin(){
    heap[0] = heap[heap_size-1];
    --heap_size;
    heap_filter_down();
}
board heap_getmin(){
    return heap[0];
}
void heap_setmin(int h){
    heap[0].height = h;
}
void bfs(){
    if(heap_size == 0){
        return;
    }
    board tmp = heap_getmin();
    int x,y;
    for(int i=0;i<4;++i){
        x = tmp.x+direction[i][0];
        y = tmp.y+direction[i][1];
        if(x>=0 && x<h && y>=0 && y<w){
            if(!exist[x][y]){
                
                exist[x][y] = true;
                if(bowl[x][y].height < tmp.height){
                    water_level += (tmp.height - bowl[x][y].height);
                    bowl[x][y].height = tmp.height;
                }
                heap_insert(bowl[x][y]);
            }
        }
    }
    heap_popmin();
    bfs();
}
int main(){
    heap_size = 0;
    water_level = 0;
    heap = new board[MAX_NUM*MAX_NUM];
    memset(bowl,0,sizeof(bowl));
    memset(exist,0,sizeof(exist));
    scanf("%d%d",&w,&h);
    for(int i=0;i<h;++i){
        for(int j=0;j<w;++j){
            scanf("%d",&bowl[i][j].height);
            bowl[i][j].x = i;
            bowl[i][j].y = j;
            if(i==0||j==0||i==h-1||j==w-1){
                heap_insert(bowl[i][j]);
                exist[i][j] = true;
            }
        }
    }
    bfs();
    printf("%lld\n",water_level);
    heap_size = 0;
    delete[] heap;
    return 0;
}