// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x3f3f3f3f
#define Max 110
int max(int a, int b) {
    return a > b ? a : b;
}
int min(int a, int b) {
    return a < b ? a : b;
}
struct node {
    int next, to;
} e[2 * 210 * 210];
int cnt;
int num1[210], num2[210], num[210], eid, p[410], vst[410], dp[210][210];
int t, n, m;
inline void addedge(int u, int v) {
    e[eid].to = v;
    e[eid].next = p[u];
    p[u] = eid++;
}
void dfs(int u) {
    int i, v;
    vst[u] = 1;
    if(u <= m)
        num1[cnt]++;
    else
        num2[cnt]++;
    for(i = p[u]; i != -1; i = e[i].next)    {
        v = e[i].to;
        if(vst[v])
            continue;
        dfs(v);
    }
}
int main() {
    int i, j, k, u, v;
    scanf("%d", &t);
    while(t--)    {
        scanf("%d%d", &m, &n);
        eid = 0, cnt = 1;
        memset(p, -1, sizeof(p));
        memset(vst, 0, sizeof(vst));
        memset(dp, 0, sizeof(dp));   
        memset(num1, 0, sizeof(num1));
        memset(num2, 0, sizeof(num2));
        while(n--)        {
            scanf("%d%d", &u, &v);
            addedge(u, v + m);
            addedge(v + m, u);
        }
        int rec = 0;
        for(i = 1; i <= 2 * m; i++)        {
            if(!vst[i])            {             
                dfs(i);             
                cnt++;
            }
        }
        dp[0][0] = 1;
        for(i = 1; i < cnt; i++)        {   
            for(j = m / 2; j >= 0; j--)            {
                for(k = m / 2; k >= 0; k--)                {
                    if(j - num1[i] >= 0 && k - num2[i] >= 0 && dp[j - num1[i]][k - num2[i]])
                        dp[j][k] = 1;
                }
            }
        }
        for(j = m / 2; j >= 0; j--)        {
            if(dp[j][j])            {
                printf("%d\n", j);
                break;
            }
        }
    }
}