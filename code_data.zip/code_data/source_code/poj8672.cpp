// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int MAXN=102;
double rock[MAXN],sum;
bool vis[MAXN];
int n;
bool dfs(double l,double r,int a)
{
    for(int i=a;i<n;i++)
    {
        if (rock[i]>=l && rock[i]<=r)
        {
            vis[i]=true;
            return true;
        }
		else if(rock[i]<l)
        {
            vis[i]=true;
            if (dfs(l-rock[i],r-rock[i],i+1)!=false)
                return true;
        }
        vis[i] =false;
    }
    return false;
}
int main()
{
	int i,j;
	while(scanf("%d",&n) && n!=0)
	{
		sum=0;
		for(i=0;i<n;i++)
		{
			scanf("%lf",&rock[i]);
			sum+=rock[i];
		}
		memset(vis,0,sizeof(vis));
		
		dfs(sum/2.02,sum*1.02/2.02,0);
		
		int i=0;
		while(vis[i]==0)
			i++;
		printf("%d",i+1);
		for(j=i+1;j<n;j++)
			if(vis[j]!=0)
				printf(" %d",j+1);
		printf("\n");
	}
	return 0;
}