// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define M 2500
using namespace std;
long long a[M+1],n,k[M],b[M+1],l,lo;
void read()
{
    memset(k,0,sizeof(k));
    char c[51];
    scanf("%s",c);
    l=strlen(c);
    for (int i=1;i<=l;i++)
      k[i]=c[l-i]-48;
}
void add()
{
    for (int i=1;i<=lo;i++)
    {
      for (int j=1;j<=l;j++)
      {
          b[i+j-1]+=a[i]*k[j];
          b[i+j]+=b[i+j-1]/10;
          b[i+j-1]%=10;
      }
    }
    lo=-1;
    for (int i=M;i>=1;i--)
    {
      if (b[i]!=0&&lo==-1) lo=i;
      a[i]=b[i];b[i]=0;
    }
}
void write()
{
    int w=M;
    while (w>1&&!a[w]) w--;
    int flag=w;
    for (;w;w--)
      printf("%d",a[w]);
}
int main()
{
    scanf("%d",&n);
    a[1]=1;lo=1;
    for (int i=1;i<=n;i++)
    {
        read();
        add();
    }
    write();
}