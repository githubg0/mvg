// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 1005;
const int M = 10005;
vector<int>G[N];
queue<int>p;
int arr[M*2],vis[N];
int ans,id;
int n,m,x,y;
void init(){
	id=ans=0;
	memset(vis,0,sizeof(vis));
	for(int i=0;i<=n;i++)
	   G[i].clear();
	while(!p.empty()) p.pop();
}
int BFS(){
	while(!p.empty()){
		int u=p.front();
	
		p.pop();
		ans++;
		for(int i=0;i<G[u].size();i++){
			int v=G[u][i];
			if(vis[v]==vis[u]) return 0;
			if(vis[v]) continue;
			vis[v]=-vis[u];
			p.push(v);
		}
	}
	return 1;
}
int main(){
	while(~scanf("%d%d%d%d",&n,&m,&x,&y)){
		init();
		for(int i=0;i<m;i++){
			int u,v;
			scanf("%d%d",&u,&v);
			G[u].push_back(v);
			G[v].push_back(u);
			arr[id++]=v;
			arr[id++]=u;
		}
	     for(int i=0;i<x;i++){
	     	int u;
	     	scanf("%d",&u);
	     	vis[u]=1;
	     	p.push(u);
		 }
		 for(int i=0;i<y;i++){
		 	int u;
	     	scanf("%d",&u);
	     	vis[u]=1;
	     	p.push(u);
		 }
		 int flag=BFS();
		 for(int i=0;i<id;i++){
		 	int u=arr[i];
		 	if(vis[u]) continue;
		 	vis[u]=1;
		 	p.push(u);
		 	flag=flag&&BFS();
		 }
		 if(ans==n&&flag) printf("YES\n");
		 else printf("NO\n");
	}
	return 0;
}