// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int nuenian(int n);
int tianshu(int year,int month,int day);
int main()
{
    int N;
    scanf("%d",&N);
    while(N--)
    {
        int  sum=0, L;
        int day, month, year, hour, minute,second;
        int year1,month1,day1,hour1,minute1,second1;
        scanf("%d:%d:%d",&hour,&minute,&second);
        scanf("%d.%d.%d",&day,&month,&year);
        
        if(year!=2000)       
        {
            sum+=366+365*(year-1-2000)+(year-1-2000)/4-(year-1-2000)/100+(year-1-2000)/400;    
        }
        sum+=tianshu(year,month,day);
        
        year1=sum/1000;
        month1=sum%1000/100+1;    
        day1=sum%1000%100+1;
        L=hour*60*60+minute*60+second;
        
        L=L*125/108;   
        hour1=L/(100*100);
        
        minute1=L%(100*100)/100;
        
        second1=L%(100*100)%100;
        printf("%d:%d:%d %d.%d.%d\n",hour1,minute1,second1,day1,month1,year1);
    }
    return 0;
}
int nuenian(int n)
{
    if((n%4==0&&n%100!=0)||n%400==0)
    return 1;
    else
    return 0;
}
int tianshu(int year,int month,int day)
{
    int i, sum=0;
    for(i=month-1;i>=1;i--)
    {
        if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
        sum+=31;
        if(i==2)
        {
            if(nuenian(year))
            sum+=29;
            else
            sum+=28;
        }
        if(i==4||i==6||i==9||i==11)
        sum+=30;
    }
    sum+=(day-1);
    return sum;
}