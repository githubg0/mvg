// Dynamic Programming->Priority Queue,Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define PB push_back
#define MP make_pair
#define REP(i,n) for(int i=0;i<(n);++i)
#define FOR(i,l,h) for(int i=(l);i<=(h);++i)
#define DWN(i,h,l) for(int i=(h);i>=(l);--i)
#define CLR(vis) memset(vis,0,sizeof(vis))
#define MST(vis,pos) memset(vis,pos,sizeof(vis))
#define MAX3(a,b,c) max(a,max(b,c))
#define MAX4(a,b,c,d) max(max(a,b),max(c,d))
#define MIN3(a,b,c) min(a,min(b,c))
#define MIN4(a,b,c,d) min(min(a,b),min(c,d))
#define PI acos(-1.0)
#define INF 1000000000
#define LINF 1000000000000000000LL
#define eps 1e-8
typedef long long LL;
const int maxn = 1e6 + 6;
int n, m;
int s, t;
struct node {
    int w, to, next;
} a[maxn * 4];
int dis[maxn], head[maxn], vis[maxn];
int edge;
class Dot {
  public:
    LL dis;
    int v;
    Dot() {}
    Dot(int _v, LL _d) {
        v = _v;
        dis = _d;
    }
    bool operator<(const Dot&x)const {
        return dis > x.dis;
    }
};
void init() {
    MST(head, -1);
    edge = 0;
}
void addedge(int u, int v, int d) {
    a[edge].to = v;
    a[edge].w = d;
    a[edge].next = head[u];
    head[u] = edge++;
}
priority_queue<Dot>Q;
void dijkstra(int s) {
    int u, v;
    Dot uu;
    FOR(i, 0, t)dis[i] = INF, vis[i] = 0;
    Q.push(Dot(s, 0));
    dis[s] = 0;
    while(!Q.empty()) {
        uu = Q.top();
        Q.pop();
        u = uu.v;
        if(vis[u])
            continue;
        vis[u] = 1;
        for(int i = head[u]; ~i; i = a[i].next) {
            v = a[i].to;
            if(!vis[v] && dis[v] > dis[u] + a[i].w) {
                dis[v] = dis[u] + a[i].w;
                Q.push(Dot(v, dis[v]));
            }
        }
    }
}
int main() {
    int a, b, c;
    while(~scanf("%d%d", &n, &m)) {
        s = 0, t = n * m * 4 + 1;
        init();
        FOR(i, 0, n)
        REP(j, m) {
            scanf("%d", &c);
            if(i == 0) {
                a = t, b = j * 4 + 2;
            } else {
                if(i == n) {
                    a = (i - 1) * m * 4 + j * 4 + 4, b = s;
                } else {
                    a = i * m * 4 + j * 4 + 2;
                    b = (i - 1) * m * 4 + j * 4 + 4;
                }
            }
            addedge(a, b, c), addedge(b, a, c);
        }
        REP(i, n)
        FOR(j, 0, m) {
            scanf("%d", &c);
            if(j == 0) {
                a = s, b = i * m * 4 + j * 4 + 1;
            } else {
                if(j == m) {
                    a = t, b = i * 4 * m + (j - 1) * 4 + 3;
                } else {
                    a = i * m * 4 + (j - 1) * 4 + 3;
                    b = i * m * 4 + j * 4 + 1;
                }
            }
            addedge(a, b, c), addedge(b, a, c);
        }
        REP(i, n)
        REP(k, 2)
        REP(j, m)
        FOR(l, 1, 2) {
            scanf("%d", &c);
            if(k == 0) {
                a = i * m * 4 + j * 4 + l, b = a + 1;
            } else {
                if(l == 1) {
                    a = i * m * 4 + j * 4 + 1, b = i * m * 4 + j * 4 + 4;
                } else {
                    a = i * m * 4 + j * 4 + 3, b = i * m * 4 + j * 4 + 4;
                }
            }
            addedge(a, b, c), addedge(b, a, c);
        }
        dijkstra(s);
        cout << dis[t] << endl;
    }
    return 0;
}