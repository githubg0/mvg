// Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Lowest Common Ancestor (LCA),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 80010;
const int DEG = 30;
struct Edge
{
    int to,next;
} edge[MAXN*2];
int head[MAXN],tot;
void addedge(int u,int v)
{
    edge[tot].to = v;
    edge[tot].next = head[u];
    head[u] = tot++;
}
void init()
{
    tot = 0;
    memset(head,-1,sizeof(head));
}
int fa[MAXN][DEG];
int pre[MAXN];
int deg[MAXN];
void BFS(int root)
{
    queue<int>que;
    deg[root] = 0;
    fa[root][0] = root;
    pre[root] == root;
    que.push(root);
    while(!que.empty())
    {
        int tmp = que.front();
        que.pop();
        for(int i = 1; i < DEG; i++)
            fa[tmp][i] = fa[fa[tmp][i-1]][i-1];
        for(int i = head[tmp]; i != -1; i = edge[i].next)
        {
            int v = edge[i].to;
            if(v == fa[tmp][0])continue;
            deg[v] = deg[tmp] + 1;
            fa[v][0] = tmp;
            que.push(v);
        }
    }
}
int LCA(int u,int v)
{
    if(deg[u] > deg[v])swap(u,v);
    int hu = deg[u], hv = deg[v];
    int tu = u, tv = v;
    for(int det = hv-hu, i = 0; det ; det>>=1, i++)
        if(det&1)
            tv = fa[tv][i];
    if(tu == tv)return tu;
    for(int i = DEG-1; i >= 0; i--)
    {
        if(fa[tu][i] == fa[tv][i])
            continue;
        tu = fa[tu][i];
        tv = fa[tv][i];
    }
    return fa[tu][0];
}
bool flag[MAXN];
int path[MAXN];
int ans[MAXN];
int n,Q;
int main()
{
    while(scanf("%d%d",&n,&Q) != EOF)
    {
        init();
        memset(flag,0,sizeof(flag));
        for(int i = 1; i<=n; i++)
        {
            scanf("%d",&path[i]);
        }
        for(int i = 0; i<n-1; i++)
        {
            int u,v;
            scanf("%d%d",&u,&v);
            flag[v] = 1;
            addedge(u,v);
            addedge(v,u);
        }
        int root;
        for(int i = 1; i<=n; i++)
        {
            if(!flag[i])
            {
                root=  i;
                break;
            }
        }
        BFS(root);
        for(int i = 0 ; i<Q; i++)
        {
            int op,x,y;
            scanf("%d%d%d",&op,&x,&y);
            if(op == 0)
            {
                path[x] = y;
            }
            else
            {
                int lca = LCA(x,y);
                
                int cnt = 0;
                
                while(x != lca)
                {
                    ans[cnt++] = path[x];
                    x = fa[x][0];
                }
                while(y != lca)
                {
                    ans[cnt++] = path[y];
                    y = fa[y][0];
                }
                ans[cnt++] = path[lca];
                if(cnt < op)
                {
                    printf("invalid request!\n");
                }
                else
                {
                    sort(ans,ans+cnt,greater<int>());
                    printf("%d\n",ans[op-1]);
                }
            }
        }
    }
}