// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define MOD 1000000007
using namespace std;
ll a[100010]={1,1,2};
int n;
vector<int> s[100010];
bool vis[100010];
ll bfs()
{
    memset(vis,0,sizeof(vis));
    queue <int> q;
    q.push(1);
    vis[1] = 1;
    ll ans = 2;
    int i,u,v,yz,gen,sz;
    while(!q.empty())
    {
        u = q.front();
        q.pop();
        yz = gen = 0;
        sz = s[u].size();
        for(i = 0; i < sz; ++i)
        {
            v = s[u][i];
            if(vis[v]) continue;
            if(s[v].size() == 1)
            {
                yz++;
            }
            else
            {
                gen++;
                q.push(v);
            }
            vis[v] = 1;
        }
        if(gen > 2) return 0;
        else if(gen)
        {
            ans = ((ans*2)%MOD*a[yz])%MOD;
        }
        else ans = (ans*a[yz])%MOD;
    }
    return ans;
}
int main()
{
    for(int i=3;i<=100001;i++)
        a[i]=(a[i-1]*i)%MOD;
    int t,k=0;
    scanf("%d",&t);
    while(k++,t--)
    {
        scanf("%d",&n);
        memset(s,0,sizeof(s));
        int u,v;
        for(int i=1;i<n;i++)
        {
            scanf("%d %d",&u,&v);
            s[u].push_back(v);
            s[v].push_back(u);
        }
        if(n == 1) printf("Case #%d: 1\n",k);
        else printf("Case #%d: %I64d\n",k,bfs());
    }
    return 0;
}