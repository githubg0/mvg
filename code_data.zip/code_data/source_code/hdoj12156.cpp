// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100100
using namespace std;
int ans, num, ok, m, n, flag;
int head[maxn], put[maxn], in[maxn];
struct node{
	int to, next;
}edge[maxn];
void add(int u, int v){
	edge[num].to = v;
	edge[num].next = head[u];
	head[u] = num++;
	in[v]++;
}
void topo(){
	priority_queue<int > Q;
	ans = 0;
	for(int j = 1; j <= m; j++){
		if(!in[j]){
			Q.push(j);
		}
	}
	while(!Q.empty()){
		flag = Q.top();
		Q.pop();
		put[ans++] = flag;
		in[flag] = -1;
		for(int j = head[flag]; j != -1; j = edge[j].next){
			if(!(--in[edge[j].to])){
				Q.push(edge[j].to);
			}
		}
	}
}
int main(){
	int t, a, b, c;
	scanf("%d", &t);
	while(t--){
		scanf("%d%d", &m, &n);
		num = 0;
		memset(head, -1, sizeof(head));
		memset(in, 0, sizeof(in));
		for(int i = 0; i < n; i++){
			scanf("%d%d", &a, &b);
			add(b, a);
		}
		topo();
		for(int i = ans-1; i >= 0; i--){
			printf("%d%c", put[i], i == 0 ? '\n' : ' ');
		}
	}
	return 0;
}