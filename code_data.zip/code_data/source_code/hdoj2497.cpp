// Basic Algorithm->Greedy Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0xffffff
using namespace std;
int Map[30][30];
int pre[30];
int dis[30];
int n;
int Prim() {
    int ret = 0;
    for(int i = 1; i <= n;i++) {
        pre[i] = 1;
        dis[i] = Map[i][1];
    }
    
    for(int i = 1;i < n;i++) {
        int Min = INF;
        int num;
        for(int j = 1;j <= n;j++) {
            if(dis[j] == 0)
                continue;
            if(dis[j] < Min) {
                Min = dis[j];
                num = j;
            }
        }
        
        if(Min == INF)
            break;
        ret += dis[num];
        dis[num] = 0;
        pre[num] = num;
        for(int j = 1;j <= n;j++) {
            if(dis[j] != 0 && dis[j] > Map[j][num])
                dis[j] = Map[j][num];
                pre[j] = num;
        }
        
    }
    return ret;
}
int main()
{
    while(scanf("%d",&n) != EOF && n != 0) {
        getchar();
        for(int i = 0;i < 30;i++)
            for(int j = 0;j < 30;j++) {
                Map[i][j] = INF;
                if(i == j)
                    Map[i][j] = Map[j][i] = 0;
            }
        char temp;
        int a;
        int num;
        for(int i = 1;i < n;i++) {
            scanf("%c",&temp);
            a = temp - 'A' + 1;
            int b;
            int length;
            scanf("%d",&num);
            getchar();
            for(int i = 0;i < num;i++) {
                scanf("%c",&temp);
                b = temp - 'A' + 1;
                scanf("%d",&length);
                getchar();
                Map[a][b] = Map[b][a] = length;
            }
        }
        printf("%d\n",Prim());
        
    }
   
   
   
    return 0; 
}