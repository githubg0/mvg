// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=18;
int n,m;
int a[maxn][maxn],b[maxn][maxn],ans[maxn][maxn];
int check(int x)
{
    for(int i=0;i<m;i++)
    {
        if(x&(1<<i))
        {
           ans[0][i]=1;
           b[0][i]^=1;
           if(i>0)
           b[0][i-1]^=1;
           if(i+1<m)
           b[0][i+1]^=1;
           if(n>1)
           b[1][i]^=1;
        }
    }
    for(int i=1;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(b[i-1][j])
            {
                b[i-1][j]=0;
                ans[i][j]=1;
                b[i][j]^=1;
                if(i+1<n)
                b[i+1][j]^=1;
                if(j>0)
                b[i][j-1]^=1;
                if(j+1<m)
                b[i][j+1]^=1;
            }
        }
    }
    for(int j=0;j<m;j++)
        if(b[n-1][j])
           return false;
    return true;
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        int sign=0;
        for(int i=0;i<n;i++)
          for(int j=0;j<m;j++)
             scanf("%d",&a[i][j]);
        for(int i=0;i<(1<<m);i++)
        {
            memcpy(b,a,sizeof(a));
            memset(ans,0,sizeof(ans));
            if(check(i))
            {
                sign=1;
                for(int j=0;j<n;j++)
                {
                    for(int k=0;k<m-1;k++)
                    {
                        printf("%d ",ans[j][k]);
                    }
                    printf("%d\n",ans[j][m-1]);
                }
                break;
            }
        }
        if(sign==0)
        printf("IMPOSSIBLE\n");
    }
    return 0;
}