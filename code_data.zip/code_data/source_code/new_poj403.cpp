// Basic Algorithm->Recursion,Basic Algorithm->Greedy Algorithm,Basic Algorithm->Prune and Search,Basic Algorithm->Depth First Search (DFS)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
bool flag;
int original_size,column_occupy[42],cake[11],n;
void dfs(int remain_cake)
{
    int min_column,min_pos,i,j;
    if (remain_cake==0)
    {
        flag=true;
        return ;
    }
    for (i=1,min_column=42; i<=original_size; i++)
        if (column_occupy[i]<min_column)
        {
            min_column=column_occupy[i];
            min_pos=i;
        }
    for (i=10; i>=1 && flag==false; i--)
    {
        if (cake[i]>0 && min_pos+i-1<=original_size && min_column+i<=original_size)
        {
            for (j=min_pos; j<min_pos+i; j++)
                if (column_occupy[j]>min_column)
                    break;
            if (j==min_pos+i)
            {
                cake[i]--;
                for (j=min_pos; j<min_pos+i; j++)
                    column_occupy[j]+=i;
                dfs(remain_cake-1);
                for (j=min_pos; j<min_pos+i; j++)
                    column_occupy[j]-=i;
                cake[i]++;
            }
            if (remain_cake==n)
                return ;
        }
    }
}
int main()
{
    int test_cases,i,sum_area,tmp;
    scanf("%d",&test_cases);
    while (test_cases--)
    {
        memset(cake,0,sizeof(cake));
        memset(column_occupy,0,sizeof(column_occupy));
        scanf("%d%d",&original_size,&n);
        for (i=1,sum_area=0; i<=n; i++)
        {
            scanf("%d",&tmp);
            cake[tmp]++;
            sum_area+=tmp*tmp;
        }
        if (sum_area!=original_size*original_size)
        {
            printf("HUTUTU!\n");
            continue;
        }
        flag=false;
        dfs(n);
        if (flag)
            printf("KHOOOOB!\n");
        else
            printf("HUTUTU!\n");
    }
    return 0;
}