// Basic Algorithm->Recursion,Basic Algorithm->Recurrence,Dynamic Programming->Tree-Based Dynamic Programming,Dynamic Programming->Knapsack Problem,Basic Algorithm->Depth First Search (DFS)
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
int dp[222][222] , cnt[222] , r[222] ;
struct Edge
{
	int t , next ;
} edge[222] ;
int head[222] , tot ;
void new_edge ( int a , int b )
{
	edge[tot].t = b ;
	edge[tot].next = head[a] ;
	head[a] = tot ++ ;
}
void init ( int n )
{
	int i , j ;
	for ( i = 0 ; i <= n ; i ++ )
		for ( j = 0 ; j <= n ; j ++ )
			dp[i][j] = 0 ;
	for ( i = 0 ; i <= n ; i ++ ) head[i] = -1 , cnt[i] = 0 ;
	tot = 0 ;
}
void dfs ( int u )
{
	if ( head[u] == -1 ) 
	{
		dp[u][1] = r[u] ;
		cnt[u] = 1 ;
		return ;
	}
	int i , j , k ;
	for ( i = head[u] ; i != -1 ; i = edge[i].next )
	{
		int v = edge[i].t ;
		dfs ( v ) ;
		cnt[u] += cnt[v] ;
		for ( j = cnt[u] ; j >= 1 ; j -- )
			for ( k = 1 ; k <= cnt[v] ; k ++ )
				if ( j >= k ) dp[u][j] = max ( dp[u][j] , dp[u][j-k] + dp[v][k] ) ;
	}
	cnt[u] ++ ;
	for ( i = cnt[u] ; i >= 1 ; i -- ) dp[u][i] = dp[u][i-1] + r[u] ;
}
int main ()
{
	int n , m , i , a , b ;
	while ( scanf ( "%d%d" , &n , &m ) != EOF )
	{
		if ( n == 0 && m == 0 ) break ;
		init ( n ) ;
		for ( i = 1 ; i <= n ; i ++ )
		{
			scanf ( "%d%d" , &a , &b ) ;
			new_edge ( a , i ) ;
			r[i] = b ;
		}
		dfs ( 0 ) ;
		printf ( "%d\n" , dp[0][m+1] ) ;
	}
}