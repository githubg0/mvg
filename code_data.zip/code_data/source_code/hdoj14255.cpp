// Basic Algorithm->Bitwise Operation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char ch[1010][1010];
int vh[1010],vl[1010];
int n;
int main()
{
    int t;
    int q=1;
    scanf("%d",&t);
    while (t--)
    {
        scanf("%d",&n);
        memset(vh,0,sizeof(vh));
        memset(vl,0,sizeof(vl));
        for (int i=1; i<=n; i++)
        {
            scanf("%s",ch[i]+1);
            
            
            
            
            
        }
        int k;
        scanf("%d",&k);
        while (k--)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            vh[x]^=1;
            vl[y]^=1;
        }
        int ans=0;
        for (int i=1; i<=n; i++)
        {
            for (int j=1; j<=n; j++)
            {
                if(vh[i]+vl[j]==1)
                {
                    if (ch[i][j]=='b')
                        ans++;
                }
                else if (ch[i][j]=='w')
                    ans++;
            }
        }
        
        
        printf ("Case #%d: %d\n",q++,ans);
    }
    return 0;
}