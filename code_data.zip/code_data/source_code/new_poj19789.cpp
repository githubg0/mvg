// Data Structure->Stack,Data Structure->Queue,Graph Algorithm->Tarjan's Algorithm,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 2100
#define M 21000
#define CC(x,y) memset(x,y,sizeof(x))
using namespace std;
struct node
{
    int y,ne;
} e[M];
struct node1
{
    int y,ne;
} e1[M];
struct node2
{
    int x,y;
} ee[N];
int dfn[N],low[N],instack[N],stacktt1[N],belong[N],i,j,k,m,n,x,y,z,h[N],h1[N],f[N],dis[N],k1,nn;
int a[N],bcnt,num,top,b[N];
void add(int x,int y)
{
    e[k].y=y;
    e[k].ne=h[x];
    h[x]=k++;
}
void tarjan(int x)
{
    int i,j,k;
    dfn[x]=low[x]=++num;
    stacktt1[++top]=x;
    instack[x]=1;
    for (int i=h[x]; i!=-1; i=e[i].ne)
    {
        j=e[i].y;
        if (dfn[j]==0)
        {
            tarjan(j);
            low[x]=min(low[j],low[x]);
        }
        else if (instack[j]) low[x]=min(low[j],low[x]);
    }
    if (dfn[x]==low[x])
    {
        bcnt++;
        do
        {
            j=stacktt1[top--];
            instack[j]=0;
            belong[j]=bcnt;
            b[bcnt]+=a[j];
        }
        while (j!=x);
    }
}
void add1(int x,int y)
{
    e1[k1].y=y;
    e1[k1].ne=h1[x];
    h1[x]=k1++;
}
void build()
{
    for (int i=0; i<n; i++)
        for (int j=h[i]; j!=-1; j=e[j].ne)
        {
            k=e[j].y;
            if (belong[i]!=belong[k])
                add1(belong[i],belong[k]);
        }
}
void spfa()
{
    int i,j,k;
    CC(dis,0);
    queue<int>q;
    while (!q.empty())q.pop();
    q.push(belong[0]);
    CC(f,0);
    f[belong[0]]=1;
    dis[belong[0]]=b[belong[0]];
    while (!q.empty())
    {
        int x=q.front();
        q.pop();
        for (i=h1[x]; i!=-1; i=e1[i].ne)
        {
            int y=e1[i].y;
            if (dis[y]<dis[x]+b[y])
            {
                dis[y]=dis[x]+b[y];
                if (!f[y])
                {
                    f[y]=1;
                    q.push(y);
                }
            }
        }
        f[x]=0;
    }
    int ans=0;
    for (i=1; i<=bcnt; i++)
        ans=max(ans,dis[i]);
    printf("%d\n",ans);
}
void solve()
{
    bcnt=num=top=0;
    int i,j;
    CC(dfn,0),CC(low,0),CC(stacktt1,0),CC(instack,0),CC(belong,0);
    CC(h1,-1); CC(b,0);k1=0;
    n=n*m;
    for (i=0; i<n; i++)
        if (!dfn[i])tarjan(i);
    build();
    spfa();
}
int main()
{
    char s[50][50];
    int tt;
    scanf("%d",&tt);
    while (tt--)
    {
        scanf("%d%d",&n,&m);
        k=0;
        CC(h,-1);
        CC(a,0);
        for (i=0; i<n; i++)
            scanf("%s",s[i]);
        int sum=0;
        for (i=0; i<n; i++)
            for (j=0; j<m; j++)
              if(s[i][j]!='#')
                {
                    if(i+1<n&&s[i+1][j]!='#')add(i*m+j,(i+1)*m+j);
                    if(j+1<m&&s[i][j+1]!='#')add(i*m+j,i*m+j+1);
                    a[i*m+j]=s[i][j]-'0';
                    if(s[i][j]=='*')
                    {
                       a[i*m+j]=0;
                       scanf("%d%d",&x,&y);
                       if(s[x][y]!='#')
                            add(i*m+j,x*m+y);
                    }
                }
        solve();
    }
    return 0;
}