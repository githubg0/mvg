// Math and Computational Geometry->Greatest Common Divisor (GCD),Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 100100
#define MOD 1000000007
#define LL long long
#define INF 0xfffffff
#define fab(a)(a)>0?(a):(-a)
using namespace std;
LL eular(LL n)  
{    
    LL i,res=n;    
    for(i=2;i*i<=n;i++)    
        if(n%i==0)  
        {    
            res=res/i*(i-1);    
            while(n%i==0)  
            n/=i;    
        }    
    if(n>1)   
    res=res/n*(n-1);    
    return res;    
}  
int main()
{
    int n,i,m;
    int t;
    scanf("%d",&t);
    while(t--)
    {
    	scanf("%d%d",&n,&m);
    	LL ans=0;
    	for(i=1;i<=sqrt(n);i++)
    	{
    		if(n%i)
    		continue;
    		if(i>=m)
    		ans+=eular(n/i);
    		if(n/i>=m&&i*i!=n)
    		ans+=eular(i);
		}
		printf("%lld\n",ans);
	}
    return 0;
}