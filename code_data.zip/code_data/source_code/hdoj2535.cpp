// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 26;
const int MAX = 8+2;
struct Trie {
    Trie *next[N];
    int v;
};
Trie *root;
vector<string> str;
void createTrie(string str) {
    int len = str.length();
    Trie *p = root, *q;
    for (int i = 0;i < len;++i) {
        int id = str[i] - '0';
        if (p -> next[id] == NULL) {
            q = new Trie;
            q -> v = 1;
            for (int j = 0;j < N;++j) {
                q -> next[j] = NULL;
            }
            p -> next[id] = q;
            p = p -> next[id];
        }
        else {
            p -> next[id] -> v++;
            p = p -> next[id];
        }
    }
    p -> v = -1;
}
int findTrie(string str) {
    int len = str.length();
    Trie *p = root;
    for (int i = 0;i < len;++i) {
        int id = str[i] - '0';
        p = p -> next[id];
        if (p == NULL) {
            return 0;
        }
        if (p -> v == -1) {
            return -1;
        }
    }
    return -1;
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    string s;
    int cnt = 0;
    while (cin >> s) {
        if (s != "9") {
            str.push_back(s);
        }
        else {
            bool flag = true;
            root = new Trie;
            root -> next[0] = NULL;
            root -> next[1] = NULL;
            root -> v = 1;
            map<string, int> m;
            m.clear();
            for (auto e : str) {
                int judge = findTrie(e);
                if (judge == -1) {
                    ++m[e];
                }
                createTrie(e);
            }
            for (map<string, int>::iterator it = m.begin();it != m.end();++it) {
                if (it -> second > 0) {
                    flag = false;
                    break;
                }
            }
            if (flag) cout << "Set " << ++cnt << " is immediately decodable" << endl;
            else cout << "Set " << ++cnt << " is not immediately decodable" << endl;
            delete root;
            str.clear();
        }
    }
    return 0;
}