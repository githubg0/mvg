// Math and Computational Geometry->Number Theory
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXP=100005;
typedef long long ll;
ll f[MAXP];
ll mul(ll x, ll y, ll p)
{
    ll res=0;
    while(y)
    {
        if(y&1) res=(res+x)%p;
        x=(x<<1)%p;
        y>>=1;
    }
    return res;
}
void exgcd(ll a,ll b,ll &d,ll &x,ll &y)
{
    if (!b)
    {
        d=a;
        x=1;
        y=0;
    }
    else
    {
        exgcd(b,a%b,d,y,x);
        y-=a/b*x;
    }
}
void initp(int p)
{
    f[0]=f[1]=1;
    for(int i=2;i<p;i++)f[i]=(f[i-1]*i)%p;
}
ll comb(ll n,ll m,ll p)
{
    if(m>n) return 0;
    ll ans=f[n];
    ll g,x,y;
    exgcd(f[m],p,g,x,y);
    
    ans=mul(ans,(x%p)%p+p,p);
    exgcd(f[n-m],p,g,x,y);
    
    ans=mul(ans,(x%p)%p+p,p);
    return ans;
}
ll lucas(ll n,ll m,int p)
{
    ll ans=1;
    initp(p);
    if(m>n) return 0;
    while(n && m && ans)
    {
        
        ans=mul(comb(n%p,m%p,p),ans,p);
        n/=p;
        m/=p;
    }
    return ans;
}
void work()
{
    ll n,m,p,ans;
    scanf("%I64d%I64d%I64d",&n,&m,&p);
    ans=lucas(n+m,m,p);
    printf("%I64d\n",ans);
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
        work();
    return 0;
}