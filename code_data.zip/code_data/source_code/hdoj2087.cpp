// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 205;
int n,m,ex,ey;
char maptt1[maxn][maxn];
bool used[maxn][maxn];
int dx[]={-1,0,1,0};
int dy[]={0,-1,0,1};
struct node{
   int x,y,t;
};
queue<node>Q;
node q,p;
bool islegal(int x ,int y){
     if (x<1 || y<1 || x>n || y>m || maptt1[x][y]=='#') return 0;
     return 1;
}
int bfs(){
  while (!Q.empty()){
    p=Q.front();
    Q.pop();
    if (p.x== ex && p.y == ey) return p.t;
    if (maptt1[p.x][p.y]=='x'){ 
        maptt1[p.x][p.y]='.';  
        p.t++;              
        Q.push(p);          
        continue;
    }
    for (int i=0;i<4;i++){
        q=p;
        q.x+=dx[i];
        q.y+=dy[i];
        q.t++;
        if (islegal(q.x,q.y) && !used[q.x][q.y]) {
            used[q.x][q.y]=1;
            Q.push(q);
        }
    }
  }
  return -1;
}
int main(){
    while (cin>>n>>m){
     for (int i=1;i<=n;i++){
      for (int j=1;j<=m;j++){
                 cin>>maptt1[i][j];
                 if (maptt1[i][j]=='r'){
                     p.x=i;
                     p.y=j;
                     p.t=0;
                     Q.push(p);
                 }
                 if (maptt1[i][j]=='a'){
                     ex=i;
                     ey=j;
         }
      }
     }
     memset(used,0,sizeof(used));
     int ans = bfs();
     if (ans==-1) printf("Poor ANGEL has to stay in the prison all his life.\n");
     else printf("%d\n",ans);
    }
    return 0;
}