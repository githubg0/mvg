// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

template <class T>
inline bool rd(T &ret) {
    char c; int sgn;
    if(c=getchar(),c==EOF) return 0;
    while(c!='-'&&(c<'0'||c>'9')) c=getchar();
    sgn=(c=='-')?-1:1;
    ret=(c=='-')?0:(c-'0');
    while(c=getchar(),c>='0'&&c<='9') ret=ret*10+(c-'0');
    ret*=sgn;
    return 1;
}
template <class T>
inline void pt(T x) {
    if (x <0) {
        putchar('-');
        x = -x;
    }
    if(x>9) pt(x/10);
    putchar(x%10+'0');
}
using namespace std;
typedef long long ll;
const int N = 100010;
int n, m;
double dp[N];
int to[N];
double solve(){
	for(int i = 0; i < 6; i++)
		dp[i+n] = 0;
	for(int i = n-1; i >= 0; i--)
	{
		if(to[i]!=-1)
			dp[i] = dp[to[i]];
		else {
			dp[i] = 1.0;
			for(int j = 1; j <= 6; j++)
				dp[i] += dp[i+j] / 6.0;
		}
	}
	return dp[0];
}
void input(){
	memset(to, -1, sizeof to);
	while(m--){
		int x, y;rd(x); rd(y);
		to[x] = y;
	}
	for(int i = n-1; i >= 0; i--){
		if(to[i] == -1)continue;
		if(to[to[i]] != -1)
		to[i] = to[to[i]];
	}
}
int main() {
	while(cin>>n>>m, n+m){
		input();
		printf("%.4f\n", solve());
    }
    return 0;
}