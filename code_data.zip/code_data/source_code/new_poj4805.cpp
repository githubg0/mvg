// Basic Algorithm->Recurrence,Data Structure->Disjoint Set Union (DSU),Dynamic Programming->Knapsack Problem
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 2<<30-1
#define N 605
using namespace std;
typedef long long ll;
int n,p,q;
int pre[N],rating[N];
bool vis[N];
int dp[N][N/2];
int cnt;
int a[N][2];
vector<int> b[N][2];
void build()
{
	for(int i=0;i<=p+q;i++)
	{
		pre[i]=i;
		rating[i]=0;
	}
	memset(vis,false,sizeof(vis));
	cnt=1;
	memset(a,0,sizeof(a));
	for(int i=0;i<N;i++)
	{
		b[i][0].clear();
		b[i][1].clear();
	}
}
int find(int x)
{
	if(x!=pre[x])
	{
		int temp=pre[x];
		pre[x]=find(pre[x]);
		rating[x]=rating[x]^rating[temp];
	}
	return pre[x];
}
int main()
{
	while(scanf("%d%d%d",&n,&p,&q)!=EOF)
	{
		if(n==0&&p==0&&q==0)
		{
			break;
		}
		
		build();
		int x,y;
		char str[5];
		while(n--)
		{
			scanf("%d%d%s",&x,&y,&str);
			int k;
			int rootx=find(x);
			int rooty=find(y);
			if(str[0]=='n')
				 k=1;
			else k=0;
			if(rootx!=rooty)
			{
				pre[rootx]=rooty;
				rating[rootx]=rating[x]^rating[y]^k;
			}
		}
		
		for(int i=1;i<=p+q;i++)
		{
			if(!vis[i])
			{
				int f=find(i);
				for(int j=i;j<=p+q;j++) 
				{
					if(find(j)==f)
					{
						vis[j]=true;
						b[cnt][rating[j]].push_back(j);
						a[cnt][rating[j]]++;
					}
				}
				cnt++; 
			}
		}
		
		memset(dp,0,sizeof(dp));
		dp[0][0]=1;
		for(int i=1;i<cnt;i++)
		{
			for(int j=p;j>=0;j--)
			{
				if(j-a[i][0]>=0)
				{
					dp[i][j]+=dp[i-1][j-a[i][0]];
				}
				if(j-a[i][1]>=0)
				{
					dp[i][j]+=dp[i-1][j-a[i][1]];
				}
			}
		}
		
		if(dp[cnt-1][p]!=1)
		{
			printf("no\n");
		}
		else 
		{
			vector<int> ans;
			ans.clear();
			for(int i=cnt-1;i>=1;i--)
			{
				if(p-a[i][0]>=0&&q-a[i][1]>=0&&dp[i-1][p-a[i][0]]==1)
				{
					for(int j=0;j<b[i][0].size();j++)
					{
						ans.push_back(b[i][0][j]);
					}
					p-=a[i][0];
					q-=a[i][1];
				}
				else if(p-a[i][1]>=0&&q-a[i][0]>=0&&dp[i-1][p-a[i][1]]==1)
				{
					for(int j=0;j<b[i][1].size();j++)
					{
						ans.push_back(b[i][1][j]);
					}
					p-=a[i][1];
					q-=a[i][0];
				}
			}
			sort(ans.begin(),ans.end());
			for(int i=0;i<ans.size();i++)
			{
				printf("%d\n",ans[i]);
			}
			printf("end\n");
		}
	}
    return 0;
}