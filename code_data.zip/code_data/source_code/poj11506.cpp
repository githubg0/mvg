// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 1e9+1
#define max_v  305
int d[max_v][max_v];
int member[max_v];
int v,m; 
void init()
{
	for(int i=0;i<max_v;i++)
	{
		for(int j=0;j<max_v;j++)
		{
			d[i][j]=INF;
		}
		d[i][i]=0;
	}
}
void warshall_floyd()
{
	for(int k=1;k<=v;k++)
		for(int i=1;i<=v;i++)
			for(int j=1;j<=v;j++)
				d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
}
int main()
{
	init();
	cin>>v>>m;
	int num;
	for(int i=0;i<m;i++)
	{
		cin>>num;
		for(int j=0;j<num;j++)cin>>member[j];
		for(int j=0;j<num;j++)
		{
			for(int k=j+1;k<num;k++)
			{
				d[member[j]][member[k]]=1;
				d[member[k]][member[j]]=1;
			}
		}
	}
	warshall_floyd();
	int cnt=INF;
	for(int i=1;i<=v;i++)
	{
		int sum=0;
		for(int j=1;j<=v;j++)sum+=d[i][j];
		if(sum<cnt)cnt=sum;
	}
	int ans=100*cnt/(v-1);
	printf("%d\n",ans);
}