// Dynamic Programming->Priority Queue,Graph Algorithm->Prim's Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define pir pair<int, int>
const int INF = 0x7fffffff;
const int MAXN = 505;
int read(){
    int k = 1, x = 0; char ch = getchar();
    while (ch<'0'||ch>'9') {
      if (ch == '-') k = -1;
      ch = getchar();
    }
    while ('0'<=ch&&ch<='9') {
      x = x * 10 + ch - '0';
      ch = getchar();
    }
    return k * x;
}
int cntEdge;
struct Edge{
    int t, w, next;
}maptt1[1000000];
void addEdge(int x, int y, int z){
    maptt1[++cntEdge].t = y;
    maptt1[cntEdge].w = z;
    maptt1[cntEdge].next = maptt1[x].next;
    maptt1[x].next = cntEdge;
}
int vis[MAXN], dis[MAXN], n;
bool operator < (const pir &x, const pir &y){
    return x.first < y.first;
}
bool cmp(const pir &x, const pir &y){
    return x.first < y.first;
}
int Prim(){
    memset(vis, 0, sizeof vis);
    for (int i = 1; i <= n; ++i) dis[i] = INF;
    dis[1] = 0;
    priority_queue<pir, vector<pir >, greater<pir> > q;
    q.push(make_pair(0, 1));
    int res = 0, tot = 0;
    while (tot <= n-1) {
      pir u = q.top();
      q.pop();
      if (vis[u.second]) continue;
      vis[u.second] = 1, tot++;
      res = max(res, u.first);
      for (int i = maptt1[u.second].next; i != -1; i = maptt1[i].next) {
        if (dis[maptt1[i].t] <= maptt1[i].w) continue;
        dis[maptt1[i].t] = maptt1[i].w;
        q.push(make_pair(dis[maptt1[i].t], maptt1[i].t));
      }
    }
    return res;
}
int main()
{
    int T = read(), x;
    while (T--) {
      n = read();
      for (int i = 1; i <= n; ++i) maptt1[i].next = -1, maptt1[i].w = 0, maptt1[i].t = i; 
      cntEdge = n;
      for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) {
          x = read();
          if (i != j) addEdge(i, j, x);
      }
      printf("%d\n", Prim());
    }
    return 0;
}