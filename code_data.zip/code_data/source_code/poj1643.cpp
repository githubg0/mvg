// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXR = 20;
const int MAXC = 20 + 1;
int neighbors[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
void dfs(char board[][MAXC], int r, int c, const int R, const int C, bool visited[], int p, int &maxp) {
	int i = board[r][c] - 'A';
	if (visited[i]) {
		return;
	}
	visited[i] = true;
	p++;
	if (p > maxp) {
		maxp = p;
	}
	for (int d = 0; d < 4; ++d) {
		int nr = r + neighbors[d][0];
		int nc = c + neighbors[d][1];
		if (0 <= nr && nr < R && 0 <= nc && nc < C) {
			dfs(board, nr, nc, R, C, visited, p, maxp);
		}
	}
	visited[i] = false;
}
int main()
{
	char board[MAXR][MAXC];
	int R, C;
	scanf("%d%d", &R, &C);
	for (int r = 0; r < R; ++r) {
		scanf("%s", board[r]);
	}
	
	
	
	
	bool visited[26];
	for (int i = 0; i < 26; ++i) {
		visited[i] = false;
	}
	int maxp = 0;
	dfs(board, 0, 0, R, C, visited, 0, maxp);
	printf("%d\n", maxp);
	return 0;
}