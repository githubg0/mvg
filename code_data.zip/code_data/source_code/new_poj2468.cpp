// Data Structure->Disjoint Set Union (DSU)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int  INF = 990000000;
const int maxn = 32210 ;
const int MAXN = maxn;
int max(int a, int b)
{
	return a > b ? a : b;
}
int n, m;
int parent[maxn];
int d[maxn];
int find(int x)
{
	if (parent[x] != x)
	{
		int root = find(parent[x]);
		return parent[x] = root;
	}
	else
		return x;
}
void union_set(int x, int y)
{
	int r1 = find(x);
	int r2 = find(y);
	if (r1 != r2)
	{
		parent[r1] = r2;
		d[r2] += d[r1];
	}
}
int main()
{
	
	int i, j;	
	while(scanf("%d %d", &n, &m) != EOF)
	{	
		if (m == 0 && n == 0)
			break;
		for (i = 0; i <= n; i++)
		{
			parent[i] = i;
			d[i] = 1;
		}
		int cnt = 0;
		for (i = 0; i < m; i++)
		{
			vector<int> vec;
			int k;
			scanf("%d", &k);
			while (k--)
			{
				int num;
				scanf("%d", &num);
				vec.push_back(num);
			}
			sort(vec.begin(), vec.end());
			int s = vec[0];
			int root = find(s);
			for (j = 1; j < vec.size(); j++)
			{
				int temp = vec[j];
				int r2 = find(temp);
				if (r2 != root)
				{
					union_set(r2, root);
				}
			}
		}
		printf("%d\n", d[find(0)]);
	}
	
	return 0;
}