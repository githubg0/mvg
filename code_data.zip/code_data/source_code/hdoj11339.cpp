// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

int a,b,c;
const int maxn = 1e5;
using namespace std;
bool used[200][200];
typedef pair<int,int> P;
typedef struct node
{
    P point;
    string result;
    node(P pp,string str)
    {
        point = pp;
        result = str;
    }
} Node;
char way[][10]  = {"FILL(1)","FILL(2)","DROP(1)","DROP(2)","POUR(1,2)","POUR(2,1)"};
void bfs()
{
    used[0][0] = 1;
    Node t = Node(P(0,0),"");
    queue<Node> Q;
    Q.push(t);
    while(Q.size())
    {
        Node n = Q.front();
        Q.pop();
        if(n.point.first == c || n.point.second == c)
        {
            cout<<n.result.size()<<endl;
            for(int i = 0; i < n.result.size(); i++)
                cout<<way[n.result[i]-'0']<<endl;
            return ;
        }
        for(int i = 0; i < 6; i++)
        {
            switch(i)
            {
            case 0:
                if(n.point.first < a && used[a][n.point.second] == 0)
                {
                    used[a][n.point.second] = 1;
                    Q.push(Node(P(a,n.point.second),n.result + "0"));
                }
                break;
            case 1:
                if(n.point.second < b && used[n.point.first][b] == 0)
                {
                    used[n.point.first][b] = 1;
                    Q.push(Node(P(n.point.first,b),n.result + "1"));
                }
                break;
            case 2:
                if(n.point.first > 0 && used[0][n.point.second] == 0)
                {
                    used[0][n.point.second] = 1;
                    Q.push(Node(P(0,n.point.second),n.result + "2"));
                }
                break;
            case 3:
                if(n.point.second > 0 && used[n.point.first][0] == 0)
                {
                    used[n.point.first][0] = 1;
                    Q.push(Node(P(n.point.first,0),n.result + "3"));
                }
                break;
            case 4:
                if(n.point.first > 0 && n.point.second < b)
                {
                    int pa = 0,pb = n.point.second + n.point.first;
                    if(pb > b)
                    {
                        pa = pb - b;
                        pb = b;
                    }
                    if(used[pa][pb] == 0)
                    {
                        Q.push(Node(P(pa,pb),n.result + "4"));
                        used[pa][pb] = 1;
                    }
                }
                break;
            case 5:
                if(n.point.first < a && n.point.second > 0)
                {
                    int pb = 0,pa = n.point.second + n.point.first;
                    if(pa > a)
                    {
                        pb = pa - a;
                        pa = a;
                    }
                    if(used[pa][pb] == 0)
                    {
                        used[pa][pb] = 1;
                        Q.push(Node(P(pa,pb),n.result + "5"));
                    }
                }
                break;
            default:
                break;
            }
        }
    }
    cout<<"impossible"<<endl;
}
int main()
{
    std::ios::sync_with_stdio(false);
    cin>>a>>b>>c;
    bfs();
    return 0;
}