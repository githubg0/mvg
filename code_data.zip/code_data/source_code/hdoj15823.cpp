// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double eps=1e-6;
int dcmp(double x)
{
    if(fabs(x)<eps) return 0;
    return (x<0)?-1:1;
}
struct Point
{
    double x,y;
    Point(double _x=0,double _y=0){x=_x; y=_y;}
};
Point operator+(Point A,Point B){return Point(A.x+B.x,A.y+B.y);}
Point operator-(Point A,Point B){return Point(A.x-B.x,A.y-B.y);}
bool operator==(const Point& a,const Point& b ){return dcmp(a.x-b.x)==0&&dcmp(a.y-b.y)==0;}
double Cross(Point A,Point B){return A.x*B.y-A.y*B.x;}
double Dot(Point A,Point B){return A.x*B.x+A.y*B.y;}
double Length(Point A){return sqrt(Dot(A,A));}
double DistanceToSegment(Point P,Point A,Point B)
{
    if(A==B) return Length(P-A);
    Point v1=B-A,v2=P-A,v3=P-B;
    if(dcmp(Dot(v1,v2))<0) return Length(v2);
    else if(dcmp(Dot(v1,v3))>0) return Length(v3);
    else return fabs(Cross(v1,v2))/Length(v1);
}
const double pi=acos(-1.0);
struct Circle
{
    Point c;
    double r;
    Circle(Point _c=0,double _r=0):c(_c),r(_r){}
    Point point(double a)
    {
        return Point(c.x+cos(a)*r,c.y+sin(a)*r);
    }
};
double a,b,c,d;
Point P1;
Point L[4];
Circle C;
int main()
{
    while(scanf("%lf%lf",&a,&b)!=EOF)
    {
        if(dcmp(a)==0&&dcmp(b)==0) break;
        P1=Point(a,b);
        scanf("%lf%lf%lf",&a,&b,&c);
        C=Circle(Point(a,b),c);
        scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
        if(a>c) swap(a,c);
        if(b>d) swap(b,d);
        L[0]=Point(a,b); L[1]=Point(a,d);
        L[2]=Point(c,d); L[3]=Point(c,b);
        double delta=2.0*pi*0.0001;
        double ans=1e30;
        for(int i=0;i<10000;i++)
        {
			double du=delta*i;
            Point p = Point(C.c.x+cos(du)*C.r,C.c.y+sin(du)*C.r);
            double Part1=DistanceToSegment(p,L[3],L[0]);
			for(int i=0;i<3;i++)
			{
				double temp = DistanceToSegment(p,L[i],L[i+1]);
				Part1=min(Part1,temp);
			}
			double Part2=Length(p-P1);
            ans=min(ans,Part1+Part2);
        }
        printf("%.2lf\n",ans);
    }
    return 0;
}