// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=100005;
long long N,K,a[MAXN];
bool can(long long mid)    
{
	long long sum=0;
	for(int i=0;i<N;i++){
		if(a[i]<=mid) continue;
		long long left=a[i]-mid+K-2;
		sum+= left/(K-1);
	}
	
	if(sum<=mid) return 1;
	else return 0;
}
int main()
{
	while(cin>>N)
	{
		long long lhs=0,rhs=0;
		for(int i=0;i<N;i++)
		{
			scanf("%d",&a[i]);
			rhs=max(rhs,a[i]); 
		}
		cin>>K;
		if(K==1){
			cout<<rhs<<endl;
			continue; 
		}
		while(lhs<rhs)
		{
			long long mid=(rhs+lhs)>>1;
			if(can(mid))rhs=mid;
			else lhs=mid+1;
		}
		cout<<lhs<<endl; 
	}
	return 0;
}