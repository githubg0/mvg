// Dynamic Programming->Bitmask Dynamic Programming (DP)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MOD = 100000000;
const int maxn = 16;
int n, m, a[maxn] = {0}, sta[1 << maxn] = {0}, num = 0, d[maxn][1 << maxn];
void init()
{
    int sum = 1 << n;
    for (int i = 0; i < sum; i++) {
        if (i & (i << 1)) continue;
        sta[num++] = i;
    }
}
bool fit(int a, int b)
{
    if (a & b) return false;
    else return true;
}
void dp()
{
    for (int i = 0; i < num; i++) {
        if (fit (sta[i], a[1])) d[1][i] = 1;
    }
    for (int i = 2; i <= m; i++) {
        for (int j = 0; j < num; j++) {
            if (fit (sta[j], a[i])) {
                for (int k = 0; k < num; k++) {
                    if (fit (sta[j], sta[k]) && fit (sta[k], a[i - 1])) {
                        d[i][j] = (d[i][j] + d[i - 1][k]) % MOD;
                    }
                }
            }
        }
    }
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen ("in.txt", "r", stdin);
    #endif 
    scanf ("%d%d", &m, &n);
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            int tmp;
            scanf ("%d", &tmp);
            if (tmp == 0) {
                a[i] += 1 << (n - j);
            }
        }
    }
    init ();
    dp ();
    int cnt = 0;
     for (int i = 0; i < num; i++) {
        cnt = (cnt + d[m][i]) % MOD;
     }
     printf ("%d\n", cnt);
    return 0;
}