// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
int sx,ex,ans,vis[1000000];
int dx[3]={0,-1,1};
int dy[3]={1,0,0};
struct node
{
	int x,step;
	friend bool operator < (node a,node b)
	{
		return a.step>b.step;
	}
}now,then;
bool juge(int x){
	if(x<0||x>110000||vis[x])
		return false;
	return true;
}
void bfs()
{
	now.x=sx;
	now.step=0;
	memset(vis,0,sizeof(vis));
	priority_queue<node>q;
	vis[sx]=1;
	q.push(now);
	while(!q.empty())
	{
		now=q.top();
		q.pop();
		for(int v=0;v<3;v++){
			then.x=now.x+dx[v]+dy[v]*now.x;
			if(juge(then.x)){
				then.step=now.step+1;
				if(then.x==ex){
					ans=then.step;
					return;
				}
				vis[then.x]=1;
				q.push(then);
			}
		}
	}
}
int main()
{
	while(scanf("%d%d",&sx,&ex)!=EOF)
	{
		if(sx==ex)
		{
			printf("0\n");
			continue;
		}
		ans=INF;
		bfs();
		printf("%d\n",ans);
	}
}