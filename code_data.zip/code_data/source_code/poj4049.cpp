// Data Structure->Stack,Basic Algorithm->Simulation,Graph Algorithm->Euler Circuit / Euler Path,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=16;
int n,k;
int f[maxn];
int ans[1<<maxn],cnt;
bool vis[1<<maxn][2];
void euler(int st)
{
    for(int i=0;i<2;i++)
    {
        if(!vis[st][i])
        {
            vis[st][i]=true;
            euler(((st<<1)+i)%f[n-1]);
            ans[cnt++]=i;
        }
    }
}
int main()
{
    f[0]=1;
    for(int i=1;i<16;i++)
        f[i]=f[i-1]*2;
    while(scanf("%d%d",&n,&k)==2&&n)
    {
        cnt=0;
        memset(ans,0,sizeof(ans));
        memset(vis,0,sizeof(vis));
        euler(0);
        cnt+=n-2;
        cnt-=k;
        int t=0;
        for(int i=0;i<n;i++)
            t=t*2+ans[cnt-i];
        printf("%d\n",t);
    }
    return 0;
}