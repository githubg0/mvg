// Basic Algorithm->Depth First Search (DFS),Data Structure->Disjoint Set Union (DSU),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,x,y;
bool vis[1005];
int fa[1005];
int c[1005];
int link[1005];
int num[1005];
vector<int>G[1005];
int fin(int x)
{
    return fa[x]==x?x:fin(fa[x]);
}
void unio(int i,int j)
{
    i = fin(i);
    j = fin(j);
    if(i != j)
    {
        fa[i] = j;
        num[j] += num[i];
    }
}
bool dfs(int po,int col)
{
    c[po] = col;
    vis[po] = true;
    for(int i = 0; i < G[po].size(); i++)
    {
        int v = G[po][i];
        if(c[v] == col)
            return false;
        else if(!vis[v])
        {
            if(col == 1)
            {
                if(!dfs(v,2))
                    return false;
            }
            else
            {
                if(!dfs(v,1))
                    return false;
            }
        }
    }
    return true;
}
int main()
{
    while(~scanf("%d %d %d %d",&n,&m,&x,&y))
    {
        memset(c,0,sizeof(c));
        memset(vis,false,sizeof(vis));
        for(int i = 1; i <= n; i++)
        {
            fa[i] = i;
            link[i] = 0;
            G[i].clear();
            num[i] = 1;
        }
        int cr,cl;
        for(int i = 0; i < m; i++)
        {
            scanf("%d %d",&cr,&cl);
            G[cr].push_back(cl);
            G[cl].push_back(cr);
            unio(cr,cl);
        }
        for(int i = 0; i < x; i++)
        {
            scanf("%d",&cr);
            c[cr] = 1;
            link[fin(cr)] = cr;
        }
        for(int i = 0; i < y; i++)
        {
            scanf("%d",&cl);
            c[cl] = 2;
            link[fin(cl)] = cl;
        }
        bool dis = true;
        if(n == 1 && c[1] == 0)
            dis = false;
        for(int i = 1; i <= n; i++)
        {
            if(num[fin(i)] == 1 && c[i] == 0)
            {
                dis = false;
                break;
            }
        }
        if(dis)
        {
            for(int i = 1; i <= n; i++)
            {
                int p = fin(i);
                if(link[p] == 0)
                    dis = dfs(p,1);
                else
                    dis = dfs(link[p],c[link[p]]);
                if(!dis)
                    break;
            }
        }
        if(dis)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}