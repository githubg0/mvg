// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 60001
#define LL long long
#define INF 0xfffffff
#define mem(x) memset(x,0,sizeof(x))
#define PI acos(-1)
using namespace std;
struct s
{
	double x1,y1,x2,y2;
}line[MAXN];
struct ss
{
	double x,y;
}p;
double fun(s aa,double xx,double yy)
{
	return (aa.x2-aa.x1)*(yy-aa.y1)-(xx-aa.x1)*(aa.y2-aa.y1);
}
int check(s A,s B)
{
	if(max(A.x1,A.x2)<min(B.x1,B.x2))
	return 0;
	if(max(B.x1,B.x2)<min(A.x1,A.x2))
	return 0;
	if(max(A.y1,A.y2)<min(B.y1,B.y2))
	return 0;
	if(max(B.y1,B.y2)<min(A.y1,A.y2))
	return 0;
	if(fun(B,A.x1,A.y1)*fun(B,A.x2,A.y2)>1e-10)
	return 0;
	if(fun(A,B.x1,B.y1)*fun(A,B.x2,B.y2)>1e-10)
	return 0;
	return 1;
}
int main()
{
	int i,j;
	int n;
    int ans;
	while(scanf("%d",&n)!=EOF)
	{
		for(i=0;i<n;i++)
		scanf("%lf%lf%lf%lf",&line[i].x1,&line[i].y1,&line[i].x2,&line[i].y2);
		scanf("%lf%lf",&p.x,&p.y);
		if(n==0)
		{
			printf("Number of doors = 1\n");
			continue;
		}
		line[n].x1=p.x;line[n].y1=p.y;
		ans=INF;
		for(i=0;i<n;i++)
		{
			line[n].x2=line[i].x1;line[n].y2=line[i].y1;
			int k=0;
			for(j=0;j<n;j++)
			{
				if(i==j)
				continue;
				if(check(line[n],line[j]))
				k++;
			}
			ans=min(ans,k);
			line[n].x2=line[i].x2;line[n].y2=line[i].y2;
			k=0;
			for(j=0;j<n;j++)
			{
				if(i==j)
				continue;
				if(check(line[n],line[j]))
				k++;
			}
			ans=min(ans,k);
		}
		printf("Number of doors = %d\n",ans+1);
	}
	return 0;
}