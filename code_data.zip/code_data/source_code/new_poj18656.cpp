// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int MAXN = (1 << 12) + 10;
const int INF = 1e9;
int dp[MAXN][12];
int dis[12][12];
int main() {
    int n;
    while(cin >> n && n) {
        n++;
        memset(dis, 0x3f, sizeof dis);
        memset(dp, 0x3f, sizeof dp);
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                int x;
                cin >> x;
                dis[i][j] = x;
            }
        }
        for(int k = 0; k < n; k++) {
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++)
                    dis[i][j] = min(dis[i][j], dis[i][k] + dis[k][j]);
            }
        }
        for(int i = 0; i < (1 << n); i++) {
            for(int j = 0; j < n; j++) {
                if(!((i >> j) & 1)) {
                    int s = (1 << j);
                    dp[s][j] = dis[0][j];
                    for(int k = 0; k < n; k++) {
                        if((i >> k) & 1) {
                            dp[i | s][j] = min(dp[i | s][j], dp[i][k] + dis[k][j]);
                        }
                    }
                }
            }
        }
        int ans = INF;
        for(int j = 1; j < n; j++) {
            ans = min(ans, dp[(1 << n) - 2][j] + dis[j][0]);
        }
        cout << ans << endl;
    }
    return 0;
}