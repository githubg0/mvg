// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int INF=0x3f3f3f3f,MAXM=30000,MAXN=200;
const double POW=10000.0;
int last[MAXM+3],n,w[MAXN+3],mw;
bool opt[MAXM+3];
double sum,a[MAXN+3];
bool input(){
    scanf("%d",&n);
    if(n==0)return false;
    sum=0;mw=0;
    for(int i=1;i<=n;i++){
        scanf("%lf",&a[i]);
        sum+=a[i];
    }
    for(int i=1;i<=n;i++){
        w[i]=int(a[i]*POW/sum);
        mw+=w[i];
    }
    return true;
}
int dp(){
    memset(last,0,sizeof(last));
    
    memset(opt,0,sizeof(opt));opt[0]=1;
    for(int i=1;i<=n;i++){
        for(int j=mw;j>=w[i];j--){
            if(!opt[j]&&opt[j-w[i]]){
                opt[j]=1;last[j]=i;
            }
        }
    }
    int ans=INF,rel=0;
    for(int i=1;i<=mw;i++){
        if(opt[i]&&abs(mw-(i<<1))<ans){
            ans=abs(mw-(i<<1));
            rel=i;
        }
    }
    return rel;
}
void output(int x){
    if(!x)return;
    output(x-w[last[x]]);
    printf("%d ",last[x]);
}
int main(){
    while(input()){
        output(dp());
        puts("");
    }
    return 0;
}