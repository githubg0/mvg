// Data Structure->Suffix Automata (SAM)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long 
using namespace std;
const int N=20005;
int n;
int len[N*2];
int ch[N*2][30],fail[N*2];
int root,cnt,last;
void ins(int x)
{
    int p,q,np,nq;
    p=last; last=np=++cnt;
    len[np]=len[p]+1; 
    for (;!ch[p][x]&&p;p=fail[p])
        ch[p][x]=np;
    if (p==0) fail[np]=root;
    else
    {
        q=ch[p][x];
        if (len[q]==(len[p]+1)) fail[np]=q;
        else{
            nq=++cnt;
            len[nq]=len[p]+1;
            for (int i=0;i<=26;i++) ch[nq][i]=ch[q][i];
            fail[nq]=fail[q];
            fail[q]=fail[np]=nq;
            for (;ch[p][x]==q;p=fail[p])
                ch[p][x]=nq;
        }
    }
}
char s[N];
int work()
{
    scanf("%s",s);
    int m=strlen(s);
    last=cnt=root=1;
    for (int i=0;i<m;i++) s[i+m]=s[i];
    for (int i=0;i<m*2;i++) ins(s[i]-'a');
    int ans=1;
    for (int i=0;i<m;i++)
        for (int j=0;j<=26;j++)
            if (ch[ans][j]>0)
            {
                ans=ch[ans][j];
                break;
            } 
    printf("%d\n",len[ans]-m+1);
}
int main()
{
    scanf("%d",&n);
    while (n--)
    {
        memset(ch,0,sizeof(ch));
        memset(len,0,sizeof(len));
        memset(fail,0,sizeof(fail));
        work();
    }
}