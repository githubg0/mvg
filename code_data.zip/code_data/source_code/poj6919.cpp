// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M 10050
#define inf 0x4f4f4f4f
int pri[M],a,b,n,dp[M];
int dfs(int now){
    if(dp[now]!=-inf)return dp[now];
    int ans=-inf,k;
    for(int i=now+1;i<n;i++){
        int temp=pri[i]-pri[now];
        if(temp>b)break;
        if(temp>=a&&(k=dfs(i))>ans){
            ans=k;
        }
    }
    if(ans==-inf)ans=0;
    return dp[now]=pri[now]-ans;
}
int main()
{
    int tcase,i,j,k;
    scanf("%d",&tcase);
    while(tcase--){
        scanf("%d%d%d",&n,&a,&b);
        for(i=0;i<n;i++)
        dp[i]=-inf;
        for(i=0;i<n;i++)
        scanf("%d",&pri[i]);
        sort(pri,pri+n);
        for(i=1,j=0;i<n;i++){
            if(pri[i]!=pri[j])pri[++j]=pri[i];
        }
        int ans=-inf;
        for(i=0;i<n;i++){
            if(pri[i]<=b&&pri[i]>=a&&(k=dfs(i))>=ans){
                ans=k;
            }
        }
        if(ans==-inf)printf("0\n");
        else printf("%d\n",ans);
    }
    return 0;
}