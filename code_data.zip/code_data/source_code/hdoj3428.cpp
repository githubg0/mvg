// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 70;
int n,a[maxn],used[maxn],total,length,stick_num;
bool dfs(int num,int pos,int res){ 
    if(num==stick_num) return true;
    for(int i=pos;i<=n;i++){
        if(used[i]) continue;
        used[i] = true;
        if(a[i]==res){
            if(dfs(num+1,0,length)) return true;
        }
        else if(a[i]<res){
            if(dfs(num,i+1,res-a[i])) return true;
        }
        used[i] = false;
        if (res==length) return false; 
        while (i+1<=n && a[i+1]==a[i]) i++; 
    }
    return false;
}
int main(){
    while (cin>>n && n){
            total=0;
        for (int i=1;i<=n;i++) {
                cin>>a[i];
                total+=a[i];
        }
        sort(a+1,a+n+1,greater<int>()); 
        memset(used,0,sizeof(used));
        for (int i=1;i<=total;i++) if (total%i==0){
             stick_num=total/i;
             length=i;
             if (dfs(0,1,length)) {
                printf("%d\n",i);
                break;
             }
        }
    }
    return 0;
}