// Basic Algorithm->Memorization,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,k;
int maptt1[110][110];
int dp[110][110];
int fangxiang[4][2]={
    {1,0},
    {0,-1},
    {0,1},
    {-1,0}
};
int dfs(int x,int y)
{
    if (dp[x][y])
        return dp[x][y];
        
    int sum=0;
    
    
    for (int i=1; i<=k; ++i)
    {
        for (int j=0; j<4; ++j)
        {
            int tmpx=x+i*fangxiang[j][0];
            int tmpy=y+i*fangxiang[j][1];
            
            if ((tmpx<n && tmpx>=0) && (tmpy<n && tmpy>=0) && maptt1[tmpx][tmpy]>maptt1[x][y])
                sum=max(sum,dfs(tmpx,tmpy));
        }
    }
    
    return dp[x][y]=sum+maptt1[x][y];
    
}
int main()
{
    while (cin>>n>>k && (n!=-1 && k!=-1))
    {
        for (int i=0; i<n; ++i)
            for (int j=0; j<n; ++j)
                cin>>maptt1[i][j];
                
        memset(dp,0,sizeof(dp));
        
        cout<<dfs(0,0)<<endl;
    }
}