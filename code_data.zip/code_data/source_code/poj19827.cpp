// Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int prime=14997;
const int N=100010;
const int K=32;
int n,k;
int cow[N][K];
int sum[N][K];
int c[N+1][K];
int csum[N+1];
vector<int> hash1[prime];
bool cmp(int a,int b)
{
	for(int i=0;i<k;i++)
		if(c[a][i]!=c[b][i])
			return false;
	return true;
}
int main()
{
	
	cin>>n>>k;
	int in;
	for(int i=0;i<n;i++)
	{
		cin>>in;
		for(int j=k-1;j>=0;j--)
		{
			cow[i][j]=in%2;
			in/=2;
		}
	}
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=n;i++)
		for(int j=0;j<k;j++)
			if(cow[i-1][j]==1)
				sum[i][j]=sum[i-1][j]+1;
			else
				sum[i][j]=sum[i-1][j];
	for(int i=1;i<=n;i++)
		for(int j=0;j<k;j++)
		{
			c[i][j]=sum[i][j]-sum[i][0];
			csum[i]+=(c[i][j]);
		}
	for(int i=0;i<=n;i++)
		hash1[abs(csum[i])%prime].push_back(i);
	int ans=0;
	for(int i=0;i<prime;i++)
		for(int j1=0;j1<hash1[i].size();j1++)
			for(int j2=j1+1;j2<hash1[i].size();j2++)
				if(cmp(hash1[i][j1],hash1[i][j2]))
				{
					if(ans<abs(hash1[i][j1]-hash1[i][j2]))
						ans=abs(hash1[i][j1]-hash1[i][j2]);
				}
	cout<<ans<<endl;
	system("pause");
	return 0;
}