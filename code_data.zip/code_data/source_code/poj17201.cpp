// Basic Algorithm->Greedy Algorithm,Basic Algorithm->Memorization,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 1010;
int num[N];
long long dp[N][N];
long long compute(int l,int r)
{
    if(dp[l][r]!=0){
        
        return dp[l][r];
    }
    if(r-l<=1){
        
        dp[l][r]=abs(num[r]-num[l]);
        return dp[l][r];
    }
    else{
        int ansl,ansr;
        ansl=num[l],ansr=num[r];
        if(num[l+1]>=num[r]){
            ansl+=compute(l+2,r)-num[l+1];
        }
        else{
            ansl+=compute(l+1,r-1)-num[r];
        }
        if(num[l]>=num[r-1]){
            ansr+=compute(l+1,r-1)-num[l];
        }
        else{
            ansr+=compute(l,r-2)-num[r-1];
        }
        dp[l][r]=max(ansl,ansr);
    }
    return dp[l][r];
}
int main()
{
    int n;
    int cnt=1;
    while(~scanf("%d",&n) && n!=0){
        memset(dp,0,sizeof(dp));
        for(int i=1;i<=n;i++){
            scanf("%d",&num[i]);
        }
        long long ans=compute(1,n);
        printf("In game %d, the greedy strategy might lose by as many as %lld points.\n",cnt++,ans);
    }
    return 0;
}