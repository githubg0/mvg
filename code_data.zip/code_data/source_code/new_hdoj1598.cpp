// Graph Algorithm->Prim's Algorithm
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define INF 0x3f3f3f3f
int vis[101],n;
struct node{
	double x,y;
	int num;
}edge[101];
double maptt1[101][101],dis[101],sum;
double dist(double x1,double y1,double x2,double y2){
	double l=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	return l;
}
void prime(){
	int i;
	sum=0;
	memset(vis,0,sizeof(vis));
	for(i=1;i<=n;i++)
		dis[i]=maptt1[1][i];
	vis[1]=1;
	for(i=1;i<n;i++){
		double temp=INF;
		int j,k;
		for(j=1;j<=n;j++)
			if(vis[j]==0&&dis[j]<temp)
				temp=dis[k=j];
		sum+=temp;
		vis[k]=1;
		for(j=1;j<=n;j++)
			if(vis[j]==0&&dis[j]>maptt1[k][j])
				dis[j]=maptt1[k][j];	
	}
}
int main(){
	while(scanf("%d",&n)!=EOF){
		for(int i=1;i<=n;i++){
			scanf("%lf%lf",&edge[i].x,&edge[i].y);
			edge[i].num=i;
		}
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++){
				double l=dist(edge[i].x,edge[i].y,edge[j].x,edge[j].y);
				maptt1[i][j]=maptt1[j][i]=l;
			}
		prime();
		printf("%.2lf\n",sum);		
	}
	return 0;
}