// Basic Algorithm->Enumerate
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define NUM 5005
using namespace std;
struct Dot
{
    int x;
    int y;
};
int myCompare( const void *ele1, const void *ele2 )
  {
    Dot *p1, *p2;
    p1 = (Dot*) ele1;
    p2 = (Dot*) ele2;
    if ( p1->x == p2->x )
        return( p1->y - p2->y );
  return ( p1->x - p2->x );
}
Dot dot[NUM];
bool vis[NUM][NUM];
int main()
{
    
    int MAX_NUM = 2;
    int R,C;
    cin>>R>>C;
    int DotNo;
    cin>>DotNo;
    memset(vis, 0, sizeof(bool)*(NUM*NUM));
    for(int i = 0;i<DotNo;i++){
        cin>>dot[i].x>>dot[i].y;
        vis[dot[i].x][dot[i].y] = true;
    }
    qsort(dot, DotNo, sizeof(Dot), myCompare);
    int Dx,Dy,X0,Y0,X1,Y1;
    for( int i = 0;i<DotNo-1;i++){
        for( int j = i+1;j<DotNo;j++){
            Dx = dot[j].x-dot[i].x;
            Dy = dot[j].y-dot[i].y;
            X0 =dot[i].x-Dx;
            Y0 =dot[i].y-Dy;
            if(X0<=R && X0>0 && Y0>0 && Y0<=C){
                continue;
            }
            X1 = dot[i].x+(MAX_NUM-1)*Dx;
            if(X1>R)     
                break;
                
            Y1=dot[i].y+(MAX_NUM-1)*Dy;
            if(Y1<1||Y1>C)
                continue;
            X1 = dot[j].x+Dx;
            Y1=dot[j].y+Dy;
            int steps = 2;
            while (X1 <= R && X1 > 0 && Y1 <=C && Y1 > 0) {
                if(vis[X1][Y1]){
                    steps++;
                    X1 += Dx;
                    Y1 += Dy;
                }
                else
                    {steps = 2;
                    break;
                    }
            }
            if(steps>MAX_NUM){
                MAX_NUM = steps;
            }
        }
        
        
        
    }
    if(MAX_NUM>2)
        cout <<MAX_NUM<<endl;
    else
        cout <<0<<endl;
    return 0;
}