// Sorting->Quick Sort,Dynamic Programming->Longest Increasing Subsequence (LIS)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
using namespace std;
#define max_n 1010
int dp[max_n] = {0};
int pos[max_n] = { 0 };
struct mouse
{
	int weight;
	int speed;
	int num;
}mice[max_n];
bool cmp(mouse a, mouse b)
{
	if (a.weight == b.weight)return a.speed > b.speed;
	return a.weight < b.weight;
}
int main()
{
	int i = 1;
	int ans = 0;
	while (cin>>mice[i-1].weight>>mice[i-1].speed)
	{
		mice[i-1].num =i;
		i++;
	}
	i--;
	sort(mice, mice + i, cmp);
	for (int j = 1; j < i; j++)
	{
		for (int k = 0; k < i; k++)
		{
			if (mice[j].weight > mice[k].weight&&mice[j].speed < mice[k].speed)dp[j] = max(dp[j], dp[k] + 1);
			if (dp[j] > ans)ans = dp[j];
		}
	}
	int p = 0;
	int t = ans;
	mouse temp;
	for (int j = i - 1; j >= 0 && t >= 0; j--)
	{
		if (dp[j] == t&&t == ans) 
		{	t--;
		pos[p++] = j;
		temp.weight = mice[j].weight;
		temp.speed = mice[j].speed;
		continue;
		}
		if (dp[j] == t&&mice[j].weight<temp.weight&&mice[j].speed>temp.speed)
		{
			t--;
			pos[p++] = j;
			temp.weight = mice[j].weight;
			temp.speed = mice[j].speed;
		}
	}
	cout << ans +1<< endl;
	p--;
	while (p>=0)
	{
		cout << mice[pos[p--]].num << endl;
	}
	return 0;
}