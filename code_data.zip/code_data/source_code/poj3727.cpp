// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 
 
 
 
 
 
 
 
 
 
 
 using namespace std;
struct Node
{
	double left, right;
}a[1010];
bool cmp(Node a, Node b)
{
	if(a.right != b.right)
		return a.right < b.right;
	return a.left < b. left;
}
int main()
{
	int n, d, cas = 1;
	
	while(~scanf("%d%d", &n, &d), n||d) {
		int maxi = -1, x, y;
		for(int i = 0; i < n; i++) {
			scanf("%d%d", &x, &y);
			a[i].left = x - sqrt((double)d*d - y*y);
			a[i].right = x + sqrt((double)d*d - y*y);
			maxi = max(maxi, y);
		}
		printf("Case %d: ", cas++);
		if(maxi > d) {
			printf("-1\n");
		}
		else {
			sort(a, a+n, cmp);
			int ans = 1;
			for(int i = 0, j = 1; j < n; j++) {
				if(a[j].left > a[i].right) {
					ans++;
					i = j;
				}
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}