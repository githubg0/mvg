// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Ri(a) scanf("%d", &a)
#define Rl(a) scanf("%lld", &a)
#define Rf(a) scanf("%lf", &a)
#define Rs(a) scanf("%s", a)
#define Pi(a) printf("%d\n", (a))
#define Pf(a) printf("%lf\n", (a))
#define Pl(a) printf("%lld\n", (a))
#define Ps(a) printf("%s\n", (a))
#define W(a) while(a--)
#define CLR(a, b) memset(a, (b), sizeof(a))
#define MOD 100000007
#define inf 0x3f3f3f3f
#define exp 0.00000001
#define  pii  pair<int, int>
#define  mp   make_pair
#define  pb   push_back
using namespace std;
typedef long long ll;
const int maxn=1e5+10;
int n,m;
int dp[maxn],f[maxn];
int main()
{
	int p,cc,v,w;
	while(~Ri(n))
	{ 
	Ri(m);
	CLR(dp,0);
	CLR(f,0);
	for(int i=1;i<=n;i++)
	{
		memcpy(f,dp,sizeof(f));
		Ri(p),Ri(cc);
		for(int j=1;j<=cc;j++)
		{
			Ri(v),Ri(w);
			for(int k=m-p;k>=v;k--)
			f[k]=max(f[k],f[k-v]+w);
		}
		for(int k=m;k>=p;k--)
		dp[k]=max(dp[k],f[k-p]);
	}
	Pi(dp[m]);
	}
	return 0;
}