// Data Structure->Stack
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1e6+10;
int f[maxn];
int main(){
    int T;
    while(scanf("%d",&T)!=EOF){
        stack<int>A,B;
        int sum = 0;
        f[0]=-999999999;
        while(T--){
            char op[20];
            scanf("%s",op);
            if(op[0]=='I'){
                int x; scanf("%d",&x);
                A.push(x);
                sum += x;
                int cur = A.size();
                f[cur] = max(sum, f[cur-1]);
            }else if(op[0]=='D'){
                if(A.size()>=1){
                    sum -= A.top();
                    A.pop();
                }
            }else if(op[0]=='L'){
                if(A.size()>=1){
                    sum -= A.top();
                    B.push(A.top());
                    A.pop();
                }
            }else if(op[0]=='R'){
                if(B.size()>=1){
                    A.push(B.top());
                    sum += B.top();
                    int cur = A.size();
                    f[cur] = max(sum,f[cur-1]);
                    B.pop();
                }
            }else if(op[0]=='Q'){
                int k; scanf("%d",&k);
                printf("%d\n",f[k]);
            }
        }
    }
   return 0;
}