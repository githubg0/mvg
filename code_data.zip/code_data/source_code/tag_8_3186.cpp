// Data Structure->Suffix Array
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 1200000
using namespace std;
int n,tot;
char c[N],s[N];
int sa[N],X[N],Y[N],sum[N],rnk[N],tmp[N],t,hi[N],ans[300],len[300];
void get_rank()
{
    for(int i=1;i<=tot;i++) sum[s[i]]++;
    for(int i=1;i<=127;i++) sum[i]+=sum[i-1];
    for(int i=tot;i>=1;i--) tmp[sum[s[i]]--]=i;
    for(int i=1;i<=tot;i++)
    {
        if(i==1 || s[tmp[i]]!=s[tmp[i-1]]) t++;
        rnk[tmp[i]]=t;
    }
}
void radix_sort(int key[],int order[])
{
    for(int i=0;i<=tot;i++) sum[i]=0;
    for(int i=1;i<=tot;i++) sum[key[i]]++;
    for(int i=1;i<=tot;i++) sum[i]+=sum[i-1];
    for(int i=tot;i>=1;i--) tmp[sum[key[order[i]]]--]=order[i];
    for(int i=1;i<=tot;i++) order[i]=tmp[i];
}
void get_height()
{
    for(int i=1;i<=tot;i++)
    {
        if(rnk[i]==1) continue;
        int j=max(hi[rnk[i-1]]-1,0);int k=sa[rnk[i]-1];
        while(s[i+j]==s[k+j]) j++;
        hi[rnk[i]]=j;
    }
}
void prefix_array()
{
    get_rank();
    for(int j=1;j<=tot;j<<=1)
    {
        for(int i=1;i<=tot;i++)
        {
            X[i]=rnk[i];
            Y[i]=i+j>tot?0:rnk[i+j];
            sa[i]=i;
        }
        radix_sort(Y,sa);
        radix_sort(X,sa);
        t=0;
        for(int i=1;i<=tot;i++)
        {
            if(i==1 || X[sa[i]]!=X[sa[i-1]] || Y[sa[i]]!=Y[sa[i-1]]) t++;
            rnk[sa[i]]=t;
        }
    }
    get_height();
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%s",c);
        ans[i]=tot+1;len[i]=strlen(c);
        for(int j=0;c[j];j++) s[++tot]=c[j];
        s[++tot]=' ';
    }
    s[tot--]='\0';
    prefix_array();
    for(int i=1;i<=n;i++)
    {
        int r=rnk[ans[i]]+1;
        while(r<=tot && hi[r]>=len[i]) r++;
        r--;
        int l=rnk[ans[i]];
        while(l>=1 && hi[l]>=len[i]) l--;
        l++;
        printf("%d\n",r-l+2);
    }
    return 0;
}