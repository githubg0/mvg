// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char a[10][10];
int n,m,t,dx,dy,esc,t1;
int work[4][2]={{0,-1},{0,1},{1,0},{-1,0}};
void dfs(int si,int sj,int t1)
{
   int i,temp;
   if(si>n||sj>m||si<=0||sj<=0) return;
   if(si==dx&&sj==dy&&t1==t) {esc=1;return;}
   temp=(t-t1)-abs(si-dx)-abs(sj-dy);
   if(temp<0||temp%2) return;
   for(i=0;i<4;i++)
   {
	   if(a[si+work[i][0]][sj+work[i][1]]!='X')
	   {
		   a[si+work[i][0]][sj+work[i][1]]='X';
		   dfs(si+work[i][0],sj+work[i][1],t1+1);
		   if(esc) return;
		   a[si+work[i][0]][sj+work[i][1]]='.';
	   }
   }
   return;
}
int main()
{
	int i,j,wall,si,sj;
	while(cin>>n>>m>>t)
	{
		if(n==0&&m==0&&t==0) break;
		wall=0;char temp;
		scanf("%c",&temp);
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=m;j++)
			{
				cin>>a[i][j];
				if(a[i][j]=='D') {dx=i;dy=j;}
				if(a[i][j]=='S') {si=i;sj=j;}
				if(a[i][j]=='X') wall++;
			}
		}
		if(n*m-wall<=t) {cout<<"NO"<<endl;continue;}
		esc=0;t1=0;
		a[si][sj]='X';
		dfs(si,sj,0);
		if(esc) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}