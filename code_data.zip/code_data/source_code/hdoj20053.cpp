// Basic Algorithm->Depth First Search (DFS),Sorting->Topological Sort,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 10010;
vector<int>v[maxn];
int k,a[maxn],cnt[maxn];;
bool ifn[maxn];
ll ss;
ll dfs(int s){
    for(int i=0;i<v[s].size();i++){
        if(!ifn[v[s][i]]){
            k++;
            ifn[v[s][i]]=1;
            ss+=a[v[s][i]];
            dfs(v[s][i]);
        }
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        int n,m;
        scanf("%d%d",&n,&m);
        ll sum=0;
        for(int i=1;i<=n;i++)scanf("%d",&a[i]);
        while(m--){
            int s,e;
            scanf("%d%d",&s,&e);
            v[s].push_back(e);
            v[e].push_back(s);
            cnt[e]++,cnt[s]++;
        }
        queue<int>q;
        while(!q.empty())q.pop();
        for(int i=1;i<=n;i++)
            if(cnt[i]<2)q.push(i),ifn[i]=1;
        while(!q.empty()){
            int p = q.front();q.pop();
            for(int i=0;i<v[p].size();i++){
                cnt[v[p][i]]--;
                if(!ifn[v[p][i]]&&cnt[v[p][i]]<2)q.push(v[p][i]),ifn[v[p][i]]=1;
            }
        }
        for(int i=1;i<=n;i++){
            if(!ifn[i]){
                ifn[i]=1;
                k=1;
                ss=a[i];
                dfs(i);
                if(k%2==1)sum+=ss;
            }
        }
        printf("%lld\n",sum);
        memset(cnt+1,0,sizeof(int)*n);
        for(int i=1;i<=n;i++)v[i].clear();
        memset(ifn+1,0,sizeof(bool)*n);
    }
    return 0;
}