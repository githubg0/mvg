// Basic Algorithm->Blocking,Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M(a, b) memset(a, b, sizeof(a))
#define mid ((l + r) >> 1)
#define ls rt << 1, l, mid
#define rs rt << 1|1, mid + 1, r
#define lowbit(x) (x & (-x))
#define LL long long
#define REP(n) for(int i = 0; i < n; i++)
#define debug 0
#define mod 1000
int n, k, m;
struct Matrix {
	int mat[65][65];														
	void init() {															
		M(mat, 0);
		for (int i = 0; i < 65; i++)
			mat[i][i] = 1;
	}
	void output(int c) {
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < c; j++)
			{
				printf("%d%s", mat[i][j] % m, j != c - 1 ? " " : "\n"); 
			}
		}
	}
};
Matrix operator * (Matrix a, Matrix b) {									
	Matrix c;	
	M(c.mat, 0);
		for (int i = 0; i < 2 * n; i++) {
			for (int j = 0; j < 2 * n; j++)
			{
				for (int k = 0; k < 2 * n; k++)
					c.mat[i][j] += (a.mat[i][k] * b.mat[k][j]) % m;
				c.mat[i][j] %= m;
			}
		}
	return c;
}
Matrix operator + (const Matrix &a, const Matrix &b) {						
	Matrix c;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
			{
				c.mat[i][j] = (a.mat[i][j] + b.mat[i][j]) % m;
			}
		}
		
	return c;
}
Matrix Matrix_fast_mod(Matrix tmp, int b) {									
	Matrix res;
	res.init();																
	while (b) {
		if (b & 1) res = tmp * res;
		tmp = tmp * tmp;
		b >>= 1;
	}
	return res;
}
int main() {
#if debug
	freopen("in.txt", "r", stdin);
#endif 
	
	while (~scanf("%d%d%d", &n, &k, &m)) {
		Matrix ans, b;
		M(b.mat, 0);
		Matrix res;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				scanf("%d", &res.mat[i][j]);
				res.mat[i][j] %= m;
				b.mat[i][j] = res.mat[i][j];								
				res.mat[i][n + j] = res.mat[i][j];							
			}
			b.mat[n + i][i] = b.mat[n + i][n + i] = 1;
		}
		
		b = Matrix_fast_mod(b, k - 1);										
		
		
		ans = res * b;
		ans.output(n);										
	}
	return 0;
}