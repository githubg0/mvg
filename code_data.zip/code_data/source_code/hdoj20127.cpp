// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
#define ll __int64_t
#define ull unsigned __int64_t
#define eps 1e-8
#define NMAX 200000000
#define MOD 530600414
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
#define PI acos(-1)
template<class T>
inline void scan_d(T &ret)
{
    char c;
    int flag = 0;
    ret=0;
    while(((c=getchar())<'0'||c>'9')&&c!='-');
    if(c == '-')
    {
        flag = 1;
        c = getchar();
    }
    while(c>='0'&&c<='9') ret=ret*10+(c-'0'),c=getchar();
    if(flag) ret = -ret;
}
ll a[605],b[1105];
int shu[10] = {6,2,5,5,4,5,6,3,7,6};
ll dp[605][2];
int main()
{
#ifdef GLQ
    freopen("input.txt","r",stdin);
#endif
    int T,cas = 1;
    scanf("%d",&T);
    while(T--)
    {
        int n;
        ll m;
        scanf("%d%I64d",&n,&m);
        memset(a,0,sizeof(a));
        a[0] = 1;
        for(int i = 0; i <= n; i++)
        {
            int lim = i == 0 ? 1 : 0;
            for(int j = lim; j <= 9; j++)
                a[i+shu[j]] = (a[i+shu[j]]+a[i])%m;
        }
        memset(b,0,sizeof(b));
        b[2] = 1;
        for(int i = 3; i <= n; i++)
        {
            for(int s1 = 1; s1 <= 9; s1++) if(i >= shu[s1]+shu[s1-1])
                {
                    int p = i-shu[s1]-shu[s1-1];
                    if(((s1 == 1 && p > 0) || s1 != 1) && p%2 == 0)
                        b[i] = (b[i]+a[p/2])%m;
                }
            if(i >= shu[0]+shu[9]) b[i] = (b[i]+b[i-shu[0]-shu[9]])%m;
        }
        n -= 3;
        memset(dp,0,sizeof(dp));
        dp[0][0] = 1;
        ll ans = 0;
        for(int i = 0; i < n; i++)
        {
            if(dp[i][0])
            {
                for(int s1 = 0; s1 <= 9; s1++)
                    for(int s2 = 0; s2 <= 9; s2++)
                    {
                        if(s1 > s2)
                        {
                            int ha = shu[s1]+shu[s2]+shu[s1-s2];
                            if(s2)
                            {
                                int wo = 2, p = n-i-ha;
                                if(p == 0) wo = 1;
                                if(p >= 0 && p%2 == 0) ans = (ans+a[p/2]*dp[i][0]%m*wo%m)%m;
                            }
                            else
                            {
                                int p = n-i-ha;
                                if(p > 0 && p%2 == 0) ans = (ans+a[p/2]*dp[i][0]%m)%m;
                            }
                            dp[i+ha][0] = (dp[i+ha][0]+dp[i][0])%m;
                        }
                        else if(s1 < s2)
                        {
                            int ha = shu[s1]+shu[s2]+shu[s1-s2+10];
                            if(n-i-ha >= 2)
                            {
                                int wo = n-i-ha == 2 ? 1 : 2;
                                ans = (ans+dp[i][0]*b[n-i-ha]%m*wo%m)%m;
                            }
                            dp[i+ha][1] = (dp[i+ha][1]+dp[i][0])%m;
                        }
                        else
                        {
                            int ha = shu[s1]+shu[s2]+shu[0];
                            int p = n-i-ha;
                            if(s1 != 0 && p > 0 && p%2 == 0) ans = (ans+a[p/2]*dp[i][0]%m)%m;
                            dp[i+ha][0] = (dp[i+ha][0]+dp[i][0])%m;
                        }
                    }
            }
            if(dp[i][1])
            {
                for(int s1 = 0; s1 <= 9; s1++)
                    for(int s2 = 0; s2 <= 9; s2++)
                    {
                        if(s1-1 >= s2)
                        {
                            int ha = shu[s1]+shu[s2]+shu[s1-1-s2];
                            if(s2 != 0 && s1-1-s2 != 0)
                            {
                                int wo = 2, p = n-i-ha;
                                if(p == 0) wo = 1;
                                if(p >= 0 && p%2 == 0) ans = (ans+dp[i][1]*a[p/2]%m*wo%m)%m;
                            }
                            else if((s2 == 0 && s1-1-s2 != 0) || (s2 != 0 && s1-1-s2 == 0))
                            {
                                int p = n-i-ha;
                                if(p > 0 && p%2 == 0) ans = (ans+dp[i][1]*a[p/2]%m)%m;
                            }
                            dp[i+ha][0] = (dp[i+ha][0]+dp[i][1])%m;
                        }
                        else
                        {
                            int ha = shu[s1]+shu[s2]+shu[s1+9-s2];
                            if(s2 == 0 || s1+9-s2 == 0)
                            {
                                int p = n-i-ha;
                                if(p > 2) ans = (ans+dp[i][1]*b[p]%m);
                            }
                            else
                            {
                                int p = n-i-ha;
                                int wo = p == 2 ? 1 : 2;
                                if(p >= 2) ans = (ans+dp[i][1]*b[p]%m*wo%m)%m;
                            }
                            dp[i+ha][1] = (dp[i+ha][1]+dp[i][1])%m;
                        }
                    }
            }
        }
        printf("Case #%d: %I64d\n",cas++,ans);
    }
    return 0;
}