// Basic Algorithm->Recursion,Basic Algorithm->Prune and Search,Basic Algorithm->Recurrence,Basic Algorithm->Depth First Search (DFS)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=300+5;
int dr[]={1,1,-1,-1,2,2,-2,-2};
int dc[]={2,-2,2,-2,1,-1,1,-1};
int vis[maxn][maxn],dist[maxn][maxn];
int ans;
int kase=0;
int R,C;
int sr,sc,er,ec;
void dfs(int r,int c,int len)
{
    if(r<0||r>=R||c<0||c>=C||len>=ans) return;  
    if(r==er&&c==ec) {ans=min(ans,len); return;} 
    if(vis[r][c]==kase && dist[r][c]<=len)         
        return ;
    vis[r][c]=kase;
    dist[r][c]=len;
    for(int d=0;d<8;d++)
    {
        int nr=r+dr[d];
        int nc=c+dc[d];
        dfs(nr,nc,len+1);
    }
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        kase++;
        scanf("%d",&R);
        C=R;
        scanf("%d%d",&sr,&sc);
        scanf("%d%d",&er,&ec);
        ans=R*R;
        dfs(sr,sc,0);
        printf("%d\n",ans);
    }
    return 0;
}