// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 201
using namespace std;
int Map[MAXN][MAXN];
int color[MAXN];
int N, M;
bool judge(int u)
{
    for(int i = 1; i <= N; i++)
    {
        if(Map[u][i] == 0) continue;
        if(color[u] == color[i]) return false;
        if(!color[i])
        {
            color[i] = 3 - color[u];
            if(!judge(i))
                return false;
        }
    }
    return true;
}
int match[MAXN];
bool used[MAXN];
int DFS(int u)
{
    for(int i = 1; i <= N; i++)
    {
        if(Map[u][i] == 0) continue;
        if(!used[i])
        {
            used[i] = true;
            if(match[i] == -1 || DFS(match[i]))
            {
                match[i] = u;
                return 1;
            }
        }
    }
    return 0;
}
void solve()
{
    memset(Map, 0, sizeof(Map));
    int a, b;
    for(int i = 1; i <= M; i++)
    {
        scanf("%d%d", &a, &b);
        Map[a][b] = Map[b][a] = 1;
    }
    memset(color, 0, sizeof(color));
    color[1] = 1;
    if(!judge(1))
    {
        printf("No\n");
        return ;
    }
    int ans = 0;
    memset(match, -1, sizeof(match));
    for(int i = 1; i <= N; i++)
    {
        memset(used, false, sizeof(used));
        ans += DFS(i);
    }
    printf("%d\n", ans / 2);
}
int main()
{
    while(scanf("%d%d", &N, &M) != EOF)
    {
        solve();
    }
    return 0;
}