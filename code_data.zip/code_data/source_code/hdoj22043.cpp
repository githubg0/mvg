// Basic Algorithm->Recursion,Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Divide and Conquer,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int MX = 5e4 + 5;
const int inf = 0x3f3f3f3f;
struct Edge {
    int v, nxt;
} E[MX * 2];
int tot, head[MX];
void init() {
    memset(head, -1, sizeof(head));
    tot = 0;
}
void add(int u, int v) {
    E[tot].v = v;
    E[tot].nxt = head[u];
    head[u] = tot++;
}
int n, k, a[MX];
int vis[MX], sz[MX], maxv[MX], root, Max, max_sta;
void dfs_size(int u, int fa) {
    sz[u] = 1; maxv[u] = 0;
    for (int i = head[u]; ~i; i = E[i].nxt) {
        int v = E[i].v;
        if (vis[v] || v == fa) continue;
        dfs_size(v, u);
        sz[u] += sz[v];
        maxv[u] = max(maxv[u], sz[v]);
    }
}
void dfs_root(int u, int fa, int rt) {
    maxv[u] = max(maxv[u], sz[rt] - maxv[u]);
    if (maxv[u] < Max) {
        Max = maxv[u];
        root = u;
    }
    for (int i = head[u]; ~i; i = E[i].nxt) {
        int v = E[i].v;
        if (vis[v] || v == fa) continue;
        dfs_root(v, u, rt);
    }
}
LL cnt_sta[1 << 10];
int Sta[15];
vector<int>v;
void dfs_sta(int u, int fa, int sta) {
    v.push_back(sta);
    for (int i = head[u]; ~i; i = E[i].nxt) {
        int v = E[i].v;
        if (vis[v] || v == fa) continue;
        dfs_sta(v, u, sta | Sta[a[v]]);
    }
}
LL cal(int rt, int sta) {
    v.clear();
    for (int i = 0; i <= max_sta; i++) cnt_sta[i] = 0;
    dfs_sta(rt, -1, sta | Sta[a[rt]]);
    for (int i = 0; i < v.size(); i++) cnt_sta[v[i]]++;
    LL ret = 0;
    for (int i = 0; i < v.size(); i++) {
        int S = v[i];
        for (int x = S; x; x = (x - 1)&S) ret += cnt_sta[x ^ max_sta];
        ret += cnt_sta[max_sta]; 
    }
    return ret;
}
LL ans;
void DFS(int u) {
    Max = n;
    dfs_size(u, -1);
    dfs_root(u, -1, u);
    int rt = root;
    ans += cal(rt, 0);
    vis[rt] = 1;
    for (int i = head[rt]; ~i; i = E[i].nxt) {
        int v = E[i].v;
        if (vis[v]) continue;
        ans -= cal(v, Sta[a[rt]]);
        DFS(v);
    }
}
int main() {
    for (int i = 0; i < 11; i++) Sta[i] = 1 << i;
    
    while (~scanf("%d%d", &n, &k)) {
        init();
        max_sta = Sta[k] - 1;
        for (int i = 1; i <= n; i++) scanf("%d", &a[i]), a[i]--;
        for (int i = 1; i < n; i++) {
            int u, v;
            scanf("%d%d", &u, &v);
            add(u, v); add(v, u);
        }
        if (k == 1) {
            printf("%lld\n", (LL)n * n);
            continue;
        }
        memset(vis, 0, sizeof(vis));
        ans = 0;
        DFS(1);
        printf("%lld\n", ans);
    }
    return 0;
}