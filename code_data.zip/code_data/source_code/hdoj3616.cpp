// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int S, N, M;
typedef struct state{
    int s, n, m; 
    int step; 
}state;
queue<state> q;
bool vis[105][105][105];
bool End(int a, int b, int c){
    if((a == b && c == 0) || (a == c && b == 0) || (b == c && a == 0)){
        return true;
    }
    else
        return false;
}
int bfs(){
    memset(vis, 0, sizeof(vis));
    while(!q.empty()) q.pop();
    state start;
    start.s = S, start.n = 0, start.m = 0, start.step = 0;
    vis[S][0][0] = true;
    
    q.push(start);
    while(!q.empty()){
        state current, next;
        int s, n, m, step; 
        current = q.front();
        s = current.s, n = current.n, m = current.m, step = current.step;
        
        if(End(s, n, m)){ 
            
            return step;
        }
        next.step = step+1;
        if(s > 0){ 
            if(s > N-n){ 
                next.s = s-(N-n);
                next.n = N;
                next.m = m;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = 0;
                next.n = n+s;
                next.m = m;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            if(s > M-m){ 
                next.s = s-(M-m);
                next.n = n;
                next.m = M;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = 0;
                next.n = n;
                next.m = m+s;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
        }
        if(n > 0){ 
            if(n > S-s){ 
                next.s = S;
                next.n = n - (S-s);
                next.m = m;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = s+n;
                next.n = 0;
                next.m = m;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            if(n > M-m){ 
                next.s = s;
                next.n = n - (M-m);
                next.m = M;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = s;
                next.n = 0;
                next.m = m+n;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
        }
        if(m > 0){ 
            if(m > S-s){ 
                next.s = S;
                next.n = n;
                next.m = m - (S-s);
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = s+m;
                next.n = n;
                next.m = 0;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            if(m > N-n){ 
                next.s = s;
                next.n = N;
                next.m = m - (N-n);
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
            else{ 
                next.s = s;
                next.n = n+m;
                next.m = 0;
                if(vis[next.s][next.n][next.m] == false){
                    vis[next.s][next.n][next.m] = true;
                    
                    q.push(next);
                }
            }
        }
        q.pop();
    }
    return 0;
}
int main(){
    while(~scanf("%d%d%d", &S, &N, &M)){
        if(!S && !N && !M) break;
        if(S & 1) printf("NO\n");
        else{
            int ans = bfs();
            if(!ans) printf("NO\n");
            else printf("%d\n", ans);
        }
    }
    return 0;
}