// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 2000+10;
const int MAXM =1e5+10;
const int inf =0x3f3f3f3f;
struct Ee{
    int from,to,val,nexts;
}ee[MAXM];
int hd[MAXN],tp;
int n,m;
void It(){
    memset(hd,-1,sizeof(hd));
    tp=0;
}
void addee(int a,int b,int c){
    Ee e={a,b,c,hd[a]};
    ee[tp]=e;hd[a]=tp++;
}
void input(){
    int a,b,c;
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&a,&b,&c);
        addee(a,b,c);
        addee(b,a,c);
    }
}
int vis[MAXN],dis[MAXN];
int re[MAXN];   
void spfa(){
    queue<int>Q;
    memset(dis,0x3f,sizeof(dis));
    memset(vis,0,sizeof(vis));
    memset(re,0,sizeof(re));
    vis[1]=1;dis[1]=0;Q.push(1);
    while(!Q.empty()){
        int now=Q.front();Q.pop();vis[now]=0;
        for(int i=hd[now];i!=-1;i=ee[i].nexts){
            Ee e=ee[i];
            if(dis[e.to]>dis[now]+e.val){
                dis[e.to]=dis[now]+e.val;
                re[e.to]=re[now]+1;   
                if(!vis[e.to]){
                    vis[e.to]=1;
                    Q.push(e.to);
                }
            }else if(dis[e.to]==dis[now]+e.val){
                re[e.to]=min(re[e.to],re[now]+1);  
            }
        }
    }
}
struct Edge {
    int from,to,cap,flow,nexts;     
}edge[MAXM];
int head[MAXN],top;
void init(){
    memset(head,-1,sizeof(head));
    top=0;
}
void addedge(int a,int b,int c){
    Edge e={a,b,c,0,head[a]};
    edge[top]=e;head[a]=top++;
    e={b,a,0,0,head[b]};
    edge[top]=e;head[b]=top++;
}
void getmap(){   
    for(int i=1;i<=n;i++){
        for(int j=hd[i];j!=-1;j=ee[j].nexts){
            Ee e=ee[j];
            if(dis[i]+e.val==dis[e.to]) 
            addedge(i,e.to,1);
        }
    }
}
int cur[MAXN];
bool bfs(int st,int ed){
    queue<int>Q;
    memset(dis,-1,sizeof(dis));
    memset(vis,0,sizeof(vis));
    Q.push(st);vis[st]=1;dis[st]=1;
    while(!Q.empty()){
        int now=Q.front();Q.pop();
        for(int i=head[now];i!=-1;i=edge[i].nexts){
            Edge e=edge[i];
            if(!vis[e.to]&&e.cap-e.flow>0){
                dis[e.to]=dis[now]+1;
                vis[e.to]=1;
                if(e.to==ed) return 1;
                Q.push(e.to);
            }
        }
    }
    return 0;
}
int dfs(int now,int a,int ed){
    if(now==ed||a==0) return a;
    int f,flow=0;
    for(int& i=cur[now];i!=-1;i=edge[i].nexts){
        Edge &e=edge[i];
        if(dis[e.to]==dis[now]+1&&((f=dfs(e.to,min(e.cap-e.flow,a),ed))>0 )){
            e.flow+=f;
            flow+=f;
            edge[i^1].flow-=f;
            a-=f;
            if(a==0) break;
        }
    }
    return flow;
}
int max_flow(int le,int ri){
    int maxflow=0;
    while(bfs(le,ri)){
        memcpy(cur,head,sizeof(head));
        maxflow+=dfs(le,inf,ri);
    }
    return maxflow;
}
int main(){
    while(~scanf("%d%d",&n,&m)){
        init();
        It();
        input();
        spfa();
        getmap();
        printf("%d %d\n",max_flow(1,n),m-re[n]);
    }
    return 0;
}