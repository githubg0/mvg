// Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Iteration
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define INF 0xfffffff
#define MAXN 105
int d[MAXN];
int w[MAXN][MAXN];
int v[MAXN];
int n;
void dj(int s){
	memset(v, 0, sizeof(v));
	for(int i = 0; i < n; i++)
		d[i] = ( i == s ? 0 : INF );
	for(int i = 0; i < n; i++){
		int x, m = INF;
		for(int y = 0; y < n; y++)
			if( !v[y] && d[y] <= m )
				m = d[x=y];
		v[x] = 1;
		for(int y = 0; y < n; y++)
			if( w[x][y] != -1 && d[y] > d[x] + w[x][y])
				d[y] = d[x] + w[x][y];
	}
}
int s2i(char* str){
	if (str[0] == 'x') return -1;
	int ret = 0;
	while (*str)
		ret = ret * 10 + (*str++) - '0';
	return ret;
}
int main(){
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			w[i][j] = -1;
	char input[40];
	for(int i = 0; i < n; i++){
		w[i][i] = 0;
		for(int j = 0; j < i; j++){
			scanf("%s", input);
			w[i][j] = w[j][i] = s2i(input);
		}
	}
	dj(0);
	int output = -1;
	for(int i = 1; i < n; i++)
		if( d[i] > output ) output = d[i];
	printf("%d\n", output);
	return 0;
}