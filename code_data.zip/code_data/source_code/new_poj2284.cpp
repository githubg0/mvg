// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Depth First Search (DFS)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define cle(a) memset(a,0,sizeof(a))
#define inf(a) memset(a,0x3f,sizeof(a))
#define ll long long
#define Rep(i,a,n) for(int i=a;i<=n;i++)
using namespace std;
const int INF = ( 2e9 ) + 2;
const ll maxn =  1e3+10;
const int maxm = maxn;
int p[maxn],l[maxn];
struct Dinic
{
    struct edge
    {
        int from,to,c;
        edge(int getu,int getv,int getc)
        {
            from=getu;
            to=getv;
            c=getc;
        }
    };
    int s,t,n;
    int d[maxn];
    int cur[maxn];
    vector<edge> e;
    vector<int> g[maxn];
    void addedge(int u,int v,int c)
    {
        e.push_back(edge(u,v,c));
        e.push_back(edge(v,u,0));
        int m=e.size();
        g[u].push_back(m-2);
        g[v].push_back(m-1);
    }
    void init()
    {
        e.clear();
        for(int i=0; i<=maxn; i++)
            g[i].clear();
    }
    bool bfs()
    {
        queue<int> q;
        q.push(s);
        memset(d,0,sizeof(d));
        d[s]=1;
        while(!q.empty())
        {
            int u=q.front();
            q.pop();
            for(int i=0; i<g[u].size(); i++)
            {
                int v=e[g[u][i]].to;
                int c=e[g[u][i]].c;
                if(!d[v]&&c)
                {
                    d[v]=d[u]+1;
                    q.push(v);
                }
            }
        }
        return d[t];
    }
    int dfs(int u,int maxf,int t)
    {
        if(u==t)return maxf;
        int ret=0;
        for(int &i=cur[u]; i<g[u].size(); i++)
        {
            int c=e[g[u][i]].c;
            int v=e[g[u][i]].to;
            int f;
            if(d[u]+1==d[v]&&c)
            {
                f=dfs(v,min(maxf-ret,c),t);
                e[g[u][i]].c-=f;
                e[g[u][i]^1].c+=f;
                ret+=f;
                if(ret==maxf)return ret;
            }
        }
        return ret;
    }
    int maxflow(int s,int t)
    {
        this->s=s;
        this->t=t;
        int flow=0;
        while(bfs())
        {
            memset(cur,0,sizeof(cur));
            int temp=dfs(s,INF,t);
            flow+=temp;
        }
        return flow;
    }
} dinic;
int main()
{
    int n,m;
    while(~scanf("%d%d",&m,&n))
    {
        dinic.init();
        memset(l,0,sizeof(l));
        for(int i=1;i<=m;i++)
            scanf("%d",&p[i]);
        for(int i=1;i<=n;i++)
        {
            int t,v,nd;
            scanf("%d",&t);
            while(t--)
            {
                scanf("%d",&v);
                if(l[v]==0)
                dinic.addedge(l[v],i,p[v]);
                else
                dinic.addedge(l[v],i,INF);
                l[v]=i;
            }
            scanf("%d",&nd);
            dinic.addedge(i,n+1,nd);
        }
        int ans=dinic.maxflow(0,n+1);
        printf("%d\n",ans);
    }
}