// Basic Algorithm->Breadth First Search (BFS),Data Structure->Queue,Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=5050;
int n,m;
int digit[10];
bool flag[maxn];
struct Node
{
    int digit;
    int r;
    int pre;
} Q[maxn];
int BFS()
{
    memset(flag,0,sizeof(flag));
    int front=0,tail=1;
    Q[front].digit=0;
    Q[front].r=0;
    Q[front].pre=-1;
    while(front<tail)
    {
        Node node=Q[front];
        int r=node.r;
        for(int i=0; i<m; i++)
        {
            int nr=(r*10+digit[i])%n;
            if(!flag[nr] && (node.pre!=-1 || digit[i]!=0))
            {
                flag[nr]=true;
                node.r=nr;
                node.digit=digit[i];
                node.pre=front;
                Q[tail++]=node;
                if(nr==0) return tail-1;
            }
        }
        ++front;
    }
    return -1;
}
void print(int ans)
{
    if(ans>0)
    {
        print(Q[ans].pre);
        cout<<Q[ans].digit;
    }
}
int main()
{
    while(cin>>n)
    {
        cin>>m;
        for(int i=0; i<m; i++)
            cin>>digit[i];
        sort(digit,digit+m);
        if(n==0)
        {
            puts("0");
            continue;
        }
        int ans=BFS();
        if(ans==-1) puts("0");
        else
        {
            print(ans);
            puts("");
        }
    }
    return 0;
}