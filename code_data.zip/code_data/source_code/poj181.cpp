// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int i,j,k,t,n,m,len[100],bandmax,pricemin,total,pricesum,pricet;
float ans;
bool jump,gone=true;
struct device{
    int band;
    int price;
}group[100][100],tmp,st[10000];
int cmp(const void*a,const void*b){
    return ((device*)b)->band - ((device*)a)->band;
}
int cmpp(const void*a,const void*b){
    return ((device*)a)->price-((device*)b)->price;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        memset(group,-1,sizeof(group));
        memset(len,0,sizeof(len));
        memset(st,0,sizeof(st));
        total=0;
        ans=0.0;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            for(scanf("%d",&m),j=0;j<m;len[i]++,j++,total++)scanf("%d%d",&group[i][j].band,&group[i][j].price),st[total]=group[i][j];
            qsort(group[i],len[i],sizeof(device),cmpp);
        }
        qsort(st,total,sizeof(device),cmp);
        for(k=0;k<total;k++){
            jump=true;
            gone=false;
            bandmax=st[k].band;
            pricesum=0;
            for(i=0;i<n;i++){
                jump=true;
                pricet=0;
                for(j=0;j<len[i];j++){
                    if(group[i][j].band>=bandmax){
                        pricet=group[i][j].price;
                        jump=false;break;
                    }
                }
                if(jump){gone=true;break;}
                pricesum+=pricet;
            }
            if(gone)continue;
            ans=(ans<(float)bandmax/pricesum?(float)bandmax/pricesum:ans);
        }
        printf("%.3f\n",ans);
    }
    return 0;
}