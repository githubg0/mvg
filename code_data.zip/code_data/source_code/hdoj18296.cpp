// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:1024000000,1024000000")
using namespace std;
const long long  maxn=50010;
const long long inf=1000000000000000000;
struct edge
{
    long long  to,nxt;
}edge[maxn*2];
long long  head[maxn],tot;
long long  ee[maxn];
long long  top[maxn],fa[maxn],deep[maxn],num[maxn],p[maxn],fp[maxn],son[maxn],pos;
void init()
{
    tot=0;
    memset(head,-1,sizeof(head));
    pos=0;
    memset(son,-1,sizeof(son));
}
void add_edge(long long  u,long long  v)
{
    edge[tot].to=v;
    edge[tot].nxt=head[u];
    head[u]=tot++;
}
void dfs1(long long  u,long long  pre,long long  d) 
{
    deep[u] = d;
    fa[u] = pre;
    num[u] = 1;
    for(long long  i = head[u];i != -1;i = edge[i].nxt)
    {
        long long  v = edge[i].to;
        if(v != pre)
        {
            dfs1(v,u,d+1);
            num[u] += num[v];
            if(son[u] == -1 || num[v] > num[son[u]])
                son[u] = v;
        }
    }
}
void getpos(long long  u,long long  sp)
{
    top[u]=sp;
    p[u]=++pos;
    fp[p[u]]=u;
    if(son[u] == -1) return;
    getpos(son[u],sp);
    for(long long  i=head[u];i!=-1;i=edge[i].nxt)
    {
        long long  v=edge[i].to;
        if(v!=son[u]&&v!=fa[u])
            getpos(v,v);
    }
}
struct Node
{
    long long  l,r;
    long long  lazy;
    long long  minprice,maxprice,maxprofit0,maxprofit1;
}segtree[maxn*4];
void push_up(long long  i)
{
    segtree[i].minprice=min(segtree[i<<1].minprice,segtree[i<<1|1].minprice);
    segtree[i].maxprice=max(segtree[i<<1].maxprice,segtree[i<<1|1].maxprice);
    segtree[i].maxprofit0=max(segtree[i<<1].maxprofit0,segtree[i<<1|1].maxprofit0);
    segtree[i].maxprofit0=max(segtree[i].maxprofit0,segtree[i<<1|1].maxprice-segtree[i<<1].minprice);
    segtree[i].maxprofit1=max(segtree[i<<1].maxprofit1,segtree[i<<1|1].maxprofit1);
    segtree[i].maxprofit1=max(segtree[i].maxprofit1,segtree[i<<1].maxprice-segtree[i<<1|1].minprice);
}
void push_down(long long  i)
{
    if(segtree[i].lazy)
    {
        segtree[i<<1].maxprice+=segtree[i].lazy;
        segtree[i<<1].minprice+=segtree[i].lazy;
        segtree[i<<1].lazy+=segtree[i].lazy;
        segtree[i<<1|1].maxprice+=segtree[i].lazy;
        segtree[i<<1|1].minprice+=segtree[i].lazy;
        segtree[i<<1|1].lazy+=segtree[i].lazy;
        segtree[i].lazy=0;
    }
}
void build(long long  i,long long  l,long long  r)
{
    segtree[i].l=l;
    segtree[i].r=r;
    segtree[i].lazy=0;
    if(l==r)
    {
        segtree[i].minprice=segtree[i].maxprice=ee[fp[l]];
        segtree[i].maxprofit0=segtree[i].maxprofit1=0;
        return;
    }
    long long  mid=(l+r)/2;
    build(i<<1,l,mid);
    build(i<<1|1,mid+1,r);
    push_up(i);
}
void update(long long  i,long long  l,long long  r,long long  val)
{
    if(segtree[i].l==l&&segtree[i].r==r)
    {
        segtree[i].lazy+=val;
        segtree[i].maxprice+=val;
        segtree[i].minprice+=val;
        return ;
    }
    long long  mid=(segtree[i].l+segtree[i].r)/2;
    push_down(i);
    if(l>mid)
    {
        update(i<<1|1,l,r,val);
    }
    else if(mid>=r)
    {
        update(i<<1,l,r,val);
    }
    else
    {
        update(i<<1,l,mid,val);
        update(i<<1|1,mid+1,r,val);
    }
    push_up(i);
}
long long  query(long long  i,long long  l,long long  r,long long  &Min,long long  &Max,long long  op)
{
    if(segtree[i].l==l&&segtree[i].r==r)
    {
        Min=segtree[i].minprice;
        Max=segtree[i].maxprice;
        if(op==0)
        {
            return segtree[i].maxprofit0;
        }
        else
            return segtree[i].maxprofit1;
    }
    push_down(i);
    long long  mid=(segtree[i].l+segtree[i].r)/2;
    if(l>mid)
    {
        return query(i<<1|1,l,r,Min,Max,op);
    }
    else if(mid>=r)
    {
        return query(i<<1,l,r,Min,Max,op);
    }
    else
    {
        long long  tmp;
        long long  lmax,lmin,rmax,rmin;
        tmp=max(query(i<<1,l,mid,lmin,lmax,op),query(i<<1|1,mid+1,r,rmin,rmax,op));
        Min=min(lmin,rmin);
        Max=max(lmax,rmax);
        if(op==0)
        {
            tmp=max(tmp,rmax-lmin);
        }
        else
        {
            tmp=max(tmp,lmax-rmin);
        }
        return tmp;
    }
}
void findd2(long long u,long long v,long long val) 
{
    long long f1 = top[u], f2 = top[v];
    while(f1 != f2)
    {
        if(deep[f1] < deep[f2])
        {
            swap(f1,f2);
            swap(u,v);
        }
        update(1,p[f1],p[u],val);
        u = fa[f1];
        f1 = top[u];
    }
    if(deep[u] > deep[v]) swap(u,v);
    update(1,p[u],p[v],val);
}
long long  findd(long long  u,long long  v,long long  val)
{
    long long  f1 = top[u], f2 = top[v];
    long long  lmin=inf,lmax=0,rmin=inf,rmax=0;
    long long  tmin,tmax;
    long long  tmp=0;
    while(f1 != f2)
    {
        if(deep[f1] > deep[f2])
        {
            tmp=max(query(1,p[f1],p[u],tmin,tmax,1),tmp);
            tmp=max(tmp,tmax-lmin);
            lmin=min(lmin,tmin);
            lmax=max(lmax,tmax);
           
            u = fa[f1];
            f1 = top[u];
        }
        else
        {
            tmp=max(query(1,p[f2],p[v],tmin,tmax,0),tmp);
            tmp=max(tmp,rmax-tmin);
            rmin=min(rmin,tmin);
            rmax=max(rmax,tmax);
            
            v = fa[f2];
            f2 = top[v];
        }
    }
    if(deep[u] < deep[v])
    {
        tmp=max(tmp,query(1,p[u],p[v],tmin,tmax,0));
        
    }
    else
    {
        tmp=max(tmp,query(1,p[v],p[u],tmin,tmax,1));
        
    }
    tmp = max(tmp, rmax - tmin);
    tmp = max(tmp, tmax - lmin);
    tmp = max(tmp, rmax - lmin);
    return tmp;
}
int  main ()
{
    long long  t;
    scanf("%lld",&t);
    while(t--)
    {
        long long  n;
        scanf("%lld",&n);
        init();
        for(long long  i = 1; i <= n; i++)
            scanf("%lld",&ee[i]);
        for(long long  i = 1; i <= n-1; i++)
        {
            long long  s, e;
            scanf("%lld%lld",&s,&e);
            add_edge(s, e);
            add_edge(e, s);
        }
        dfs1(1, 0, 0);
        getpos(1, 1);
        build(1, 1, pos);
        long long  Q;
        scanf("%lld",&Q);
        while(Q--)
        {
            long long  x, y, z;
            scanf("%lld%lld%lld",&x,&y,&z);
            printf("%lld\n",findd(x,y,z));
            findd2(x,y,z);
        }
    }
    return 0;
}