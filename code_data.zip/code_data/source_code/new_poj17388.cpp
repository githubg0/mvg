// Dynamic Programming->Monotone Queue,Dynamic Programming->Tree-Based Dynamic Programming
#include<cmath>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define re register int
using namespace std;
inline int read(){
	int x=0,w=1;
	char ch=getchar();
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+ch-48,ch=getchar();
	return x*w;
}
const int MAXN=1e6+200;
struct edge {
    int to,next,w;
} edges[MAXN*2];
int tot,dis[MAXN];
int head[MAXN];
void add_edge(int u,int v,int w) {
    edges[tot].to=v;
    edges[tot].w=w;
    edges[tot].next = head[u];
    head[u] = tot++;
}
int dist[MAXN][3];  
int longest[MAXN];
int dfs1(int u,int fa) {
    if(dist[u][0]>=0) return dist[u][0];
    dist[u][0]=dist[u][1]=dist[u][2]=longest[u]=0;
    for(re i=head[u];i!=-1;i=edges[i].next) {
        int v=edges[i].to;
        if(v==fa) continue;
        if(dist[u][0]<dfs1(v,u)+edges[i].w) {
            longest[u]=v;
            dist[u][1]=max(dist[u][1],dist[u][0]);
            dist[u][0]=dfs1(v,u)+edges[i].w;
        }
        else if(dist[u][1]<dfs1(v,u)+edges[i].w)
            dist[u][1]=max(dist[u][1],dfs1(v,u)+edges[i].w);
    }
    return dist[u][0];
}
void dfs2(int u,int fa) {
    for(int i=head[u];i!=-1;i=edges[i].next) {
        int v = edges[i].to;
        if(v==fa)continue;
        if(v==longest[u]) dist[v][2]=max(dist[u][2],dist[u][1])+edges[i].w;
        else dist[v][2]=max(dist[u][2],dist[u][0])+edges[i].w;
        dfs2(v,u);
    }
}
int finish(int n,int M){
    if(n <= 0) return n;
    if(M < 0) return 0;
    deque<int> qmax,qmin;           
    deque<int> idmax,idmin;         
    int ans=0;
    int left=1,right=1;
    while(right <= n){
    
		while(!qmax.empty() && dis[right] >= qmax.back()) qmax.pop_back(), idmax.pop_back();
		qmax.push_back(dis[right]); idmax.push_back(right); 
		while(!qmin.empty() && dis[right] <= qmin.back()) qmin.pop_back(), idmin.pop_back();
		qmin.push_back(dis[right]); idmin.push_back(right);
		while(qmax.front()-qmin.front() > M && left<right){  
			left++;                  
			while(idmax.front() < left) idmax.pop_front(), qmax.pop_front();
			while(idmin.front() < left) idmin.pop_front(), qmin.pop_front();
		}
		ans = max(ans,right-left+1);
		right++;
	}
		return ans;
}
int main() {
    int n,m;
    while(scanf("%d%d",&n,&m)==2&&n) {
        tot=0;
        memset(dist,-1,sizeof(dist));
        memset(head,-1,sizeof(head));
        memset(longest,-1,sizeof(longest));
        for(int i=2; i<=n; i++) {
            int v,w;
            scanf("%d%d",&v,&w);
            add_edge(i,v,w);
            add_edge(v,i,w);
        }
        dfs1(1,-1);
        dfs2(1,-1);
        for(int i=1;i<=n;i++) dis[i]=max(dist[i][0],dist[i][2]);
        printf("%d\n",finish(n,m));
    }
    return 0;
}