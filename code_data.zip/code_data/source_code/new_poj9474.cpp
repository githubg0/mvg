// Sorting->Quick Sort,Dynamic Programming->Priority Queue
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
using namespace std;
struct node
{
    int s,v;
};
bool cmp(node a,node b)
{
    if(a.s==b.s)
        return a.v<b.v;
    return a.s<b.s;
}
node a[100005];
int l[100005];  
int r[100005];  
int main()
{
    int n,c,f;
    scanf("%d %d %d",&n,&c,&f);
    for(int i=0;i<c;i++)
        scanf("%d %d",&a[i].s,&a[i].v);
    sort(a,a+c,cmp);
    priority_queue<int> q1;
    priority_queue<int> q2;
    int sum=0;
    for(int i=0;i<n/2;i++)
    {
        sum+=a[i].v;
        q1.push(a[i].v);
    }
    l[n/2]=sum;
    for(int i=n/2;i<c-n/2;i++)
    {
        if(a[i].v<q1.top())
        {
            sum-=q1.top();
            q1.pop();
            q1.push(a[i].v);
            sum+=a[i].v;
        }
        l[i+1]=sum;
    }
    sum=0;
    for(int i=c-1;i>c-1-n/2;i--)
    {
        sum+=a[i].v;
        q2.push(a[i].v);
    }
    r[c-1-n/2]=sum;
    for(int i=c-1-n/2;i>n/2;i--)
    {
        if(a[i].v<q2.top())
        {
            sum-=q2.top();
            q2.pop();
            q2.push(a[i].v);
            sum+=a[i].v;
        }
        r[i-1]=sum;
    }
    int MIN=-1;
    for(int i=n/2;i<c-n/2;i++)
    {
        if(l[i]+r[i]+a[i].v>f)  
            continue;
        MIN=max(MIN,a[i].s);    
    }
    printf("%d\n",MIN);
    return 0;
}