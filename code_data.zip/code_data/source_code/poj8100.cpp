// Math and Computational Geometry->Inclusion–Exclusion Principle,Math and Computational Geometry->Probability / Counting / Combinatorics
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define N 11234
int n,m;
long long a[N],b[N],pri[N],flag[N];
void init()
{
    for(long long i=4;i<N;i++)
        b[i] = i*(i-1)*(i-2)*(i-3)/24;
}
void solve(int now)
{
    int cnt=0;
    for(int i=2;i*i<=now;i++)
        if(now%i==0)
        {
            pri[cnt++]=i;
            while(now>1&&now%i==0) now/=i;
        }
    if(now!=1) pri[cnt++] = now;
    for(int i=1;i<(1<<cnt);i++)
    {
        int mark=-1,temp=1;
        for(int j=0;j<cnt;j++)
            if(i&(1<<j))
                mark=-mark,temp*=pri[j];
        a[temp]++;
        flag[temp]=mark;
    }
}
int main()
{
    int i,j,k,kk,t,x,y,z;
    init();
    while(scanf("%d",&n)!=EOF&&n)
    {
        memset(a,0,sizeof(a));
        for(i=0;i<n;i++)
        {
            scanf("%d",&t);
            solve(t);
        }
        long long sum=0;
        for(i=1;i<N;i++)
            if(a[i])
            {
                if(flag[i]==1)
                    sum+=b[a[i]];
                else if(flag[i]==-1)
                    sum-=b[a[i]];
            }
        printf("%lld\n",b[n]-sum);
    }
    return 0;
}