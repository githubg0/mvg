// Data Structure->Disjoint Set Union (DSU)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=110000;
int father[maxn],enemy[maxn],n,m;
int find(int x){
    if(father[x]!=x){
        father[x]=find(father[x]);
    }
    return father[x];
}
void combine(int x,int y){
    int a=find(x),b=find(y);
    father[b]=a;
}
void solve(){
    char ch;
    int a,b;
    while(m-- >0){
        getchar();
        scanf("%c%d%d",&ch,&a,&b);
        
        if(ch=='D'){
            if(enemy[a]!=-1) combine(enemy[a],b);
            if(enemy[b]!=-1) combine(enemy[b],a);
            enemy[a]=b;
            enemy[b]=a;
        }else{
            if(enemy[a]==-1 || enemy[b]==-1 )  printf("Not sure yet.\n");
            else{
                if(find(a)==find(b)) printf("In the same gang.\n");
                else if(find(enemy[a])==find(b) || find(a)==find(enemy[b]) ) printf("In different gangs.\n");
                else printf("Not sure yet.\n");
            }
        }
    }
}
int main(){
    int t;
    scanf("%d",&t);
    while(t-- >0){
        scanf("%d%d",&n,&m);
        for(int i=0;i<=n;i++){
            father[i]=i;
            enemy[i]=-1;
        }
        solve();
    }
    return 0;
}