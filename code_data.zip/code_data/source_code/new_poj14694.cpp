// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>  
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
  
  
  
  
using namespace std; 
const int lim=100005;    
int dirx[2]={1,-1};
int flag[lim]; 
int N,K; 
struct point  
{  
    int x;  
    int step;  
};  
void bfs(); 
bool judge(point p)
{
    if(p.x<0 || p.x>100000 || p.step>flag[p.x])
    {
        return false;
    }
    return true;
}
int main ()  
{  
    
    
    while(~scanf("%d%d",&N,&K))
    {
        if(N==K)
         {
            cout<<0<<endl;
            continue ;
         } 
        memset(flag,0X7F, sizeof(flag));  
        bfs();  
    }
        return 0; 
}  
void bfs()  
{  
    int i;   
    point node, t;  
        flag[N]=0;
    node.x=N;   
    node.step=0;
    queue<point> q;  
    while(!q.empty())
    {
        q.pop();
    }
    q.push(node);  
    while(!q.empty())
    {  
        node=q.front();  
        q.pop();  
        for(i=0; i<3; i++)  
        {  
            t=node;
            if(i==2)
            {
               t.x*=2;
            }
            else
            {
                t.x+=dirx[i];
            }
            t.step=node.step+1;
            if(!judge(t))continue;
            if(t.x==K)  
            {  
                    cout<<t.step<<endl;
                    return ;
                     
            } 
            flag[t.x]=t.step; 
            q.push(t);  
        }  
    }  
}