// Basic Algorithm->Greedy Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int s,d;
int flag=0;
int a[15],p[5];
int sum()
{
	int i,q=0;
	for(i=0;i<5;i++)
	{
		q+=a[i];
	}
	return q;
}
void dfs(int depth)
{
	int i;
	if(flag) return;
	if(depth==5)
	{
		if(sum()<0)
		flag=1;
		return;
	}
	for(i=0;i<2;i++)
	{
		a[depth]=p[i];
		dfs(depth+1);
		if(flag) break;
	}
}
int main ()
{
	while (scanf("%d%d",&s,&d)==2)
	{
		flag=0;
		p[0]=s;
		p[1]=-d;
		dfs(0);
		int temp=0;
		
		for(int i=5;i<12;i++)
			a[i]=a[i-5];
		for(int i=0;i<12;i++)
			temp+=a[i];
		if(temp>0)
		printf("%d\n",temp);
		else printf("Deficit\n");
	}
	return 0;
}