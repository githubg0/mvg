// Data Structure->Hashing
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node{
	int key;
	int v[6];
	int next;
	
	
	node(){}
	
	node(int _key, int *a, int _next){
		key = _key;
		for(int i = 0; i < 6; i++)
			v[i] = a[i];
		next = _next;
	}
};
const int maxn = 100005;
const int mod = 100007;
int n;
int list[mod];
node c[maxn*2];
int cnt;
int a[6];
void shift(){
	int t = a[0];
	for(int i = 0; i < 5; i++)
		a[i] = a[i+1];
	a[5] = t;
}
void reverse(){
	for(int i = 0; i < 3; i++){
		int  t = a[i];
		a[i] = a[6-i-1];
		a[6-i-1] = t;
	}
}
int hash_key(){
	int sum = 0;
	for(int i = 0; i < 6; i++){
		sum += a[i];
	}
	return sum;
}
void hash_insert(int key, int i){
	int index = key % mod;
	c[i] = node(key,a,list[index]);
	list[index] = i;
}
bool hash_find(int key){
	int index = key % mod;
	for(int i = list[index]; i != -1; i = c[i].next){
		if(c[i].key == key){
			bool f = true;
			for(int j = 0; j < 6; j++){
				if(a[j] != c[i].v[j]){
					f = false; break;
				}
			}
			if(f) return true;
		}
	}
	return false;
}
int main(){
		bool f = false;
		scanf("%d",&n);
		cnt = 0;
		for(int i = 0; i < mod; i++) list[i] = -1;
		
		for(int i = 0; i < n; i++){
			
			for(int j = 0; j < 6; j++)
				scanf("%d",&a[j]);
				
			if(!f){
				
				for(int i = 0; i < 6; i++){
					if(hash_find(hash_key())){
						f = true; break;
					}
					shift();
				}
				if(!f) {
					hash_insert(hash_key(),cnt++);
					reverse();
					hash_insert(hash_key(),cnt++);
				}
				
				 
			}
		}
		puts(f?"Twin snowflakes found.":"No two snowflakes are alike.");
	
	return 0;
}