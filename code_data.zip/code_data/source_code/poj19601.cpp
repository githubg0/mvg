// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define eps 1e-8
#define pi acos(-1.0)
#define inf 1<<30
#define pb push_back
#define lc(x) (x << 1)
#define rc(x) (x << 1 | 1)
#define lowbit(x) (x & (-x))
#define ll long long
int T,n,maxs;
int d[100100];
long long m,k;
bool check(ll ti){
    ll sum=m*ti,tmp;
    if (k==1) return d[0]<=ti;
    for (int i=0; i<n; i++){
        if (d[i]-ti<=0) return true;
        tmp=(d[i]-ti)/(k-1);
        if (((d[i]-ti)%(k-1))!=0) tmp+=1;
        if (tmp>ti) return false;
        sum-=tmp;
        if (sum<0) return false;
    }
    return true;
}
void solve(){
    ll lo=0, hi=maxs+10, mid;
    while (lo+1<hi){
        mid = (lo+hi)>>1;
        if (check(mid)) hi = mid;
        else lo = mid;
    }
    if (check(lo)) cout <<lo <<endl;
    else if (check(mid)) cout <<mid <<endl;
    else if (check(hi)) cout <<hi<<endl;
}
int main(){
    scanf("%d",&T);
    while (T--){
        scanf("%d",&n);
        maxs=-1;
        for (int i=0; i<n; i++) {scanf("%d",&d[i]); maxs=max(maxs,d[i]);}
        sort(d,d+n,greater<int>());
        cin>>m>>k;
        solve();
    }
    return 0;
}