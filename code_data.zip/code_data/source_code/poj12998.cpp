// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
int dp[(1<<13)][13][13];
ll mp[(1<<13)][13][13];
int num[13];
int vis[13][13];
int n,m;
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n>>m;
        for(int i=0;i<n;i++)
            cin>>num[i];
        memset(vis,0,sizeof(vis));
        for(int i=0;i<m;i++)
        {
            int u,v;
            cin>>u>>v;
            u--,v--;
            vis[u][v]=vis[v][u]=1;
        }
        if(n==1)
        {
            cout<<num[0]<<" 1"<<endl;
            continue;
        }
        memset(dp,-1,sizeof(dp));
        memset(mp,0,sizeof(mp));
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(vis[i][j]&&i!=j)
                {
                    dp[(1<<i)|(1<<j)][i][j]=num[i]+num[j]+num[i]*num[j];
                    mp[(1<<i)|(1<<j)][i][j]=1;
                }
            }
        }
        int tol=(1<<n);
        for(int i=0;i<tol;i++)
        {
            for(int j=0;j<n;j++)
            {
                if((i&(1<<j))!=0)
                {
                    for(int k=0;k<n;k++)
                    {
                        if(vis[j][k]&&j!=k&&(i&(1<<k))!=0&&dp[i][j][k]!=-1)
                        {
                            for(int l=0;l<n;l++)
                            {
                                if((i&(1<<l))==0&&vis[k][l]&&l!=j&&l!=k)
                                {
                                    int t=dp[i][j][k]+num[l]+num[k]*num[l];
                                    if(vis[j][l])
                                        t+=num[j]*num[k]*num[l];
                                    if(dp[(i|(1<<l))][k][l]<t)
                                    {
                                        dp[(i|(1<<l))][k][l]=t;
                                        mp[(i|(1<<l))][k][l]=mp[i][j][k];
                                    }
                                    else if(dp[(i|(1<<l))][k][l]==t)
                                    {
                                        mp[(i|(1<<l))][k][l]+=mp[i][j][k];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        int ans=0;
        long long res=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i!=j&&vis[i][j])
                {
                    if(ans<dp[(tol-1)][i][j])
                    {
                        ans=dp[(tol-1)][i][j];
                        res=mp[(tol-1)][i][j];
                    }
                    else if(ans==dp[(tol-1)][i][j])
                    {
                        res+=mp[(tol-1)][i][j];
                    }
                }
            }
        }
        cout<<ans<<' '<<res/2<<endl;
    }
    return 0;
}