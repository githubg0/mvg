// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int  cmp[16][16]= {0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,1,0,2,1,2,1,3,2,2,1,3,2,3,2,4,3,1,2,0,1,2,3,1,2,2,3,1,2,3,4,2,3,2,1,1,0,3,2,2,1,3,2,2,1,4,3,3,2,1,2,2,3,0,1,1,2,2,3,3,4,1,2,2,3,2,1,3,2,1,0,2,1,3,2,4,3,2,1,3,2,2,3,1,2,1,2,0,1,3,4,2,3,2,3,1,2,3,2,2,1,2,1,1,0,4,3,3,2,3,2,2,1,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,2,1,3,2,3,2,4,3,1,0,2,1,2,1,3,2,2,3,1,2,3,4,2,3,1,2,0,1,2,3,1,2,3,2,2,1,4,3,3,2,2,1,1,0,3,2,2,1,2,3,3,4,1,2,2,3,1,2,2,3,0,1,1,2,3,2,4,3,2,1,3,2,2,1,3,2,1,0,2,1,3,4,2,3,2,3,1,2,2,3,1,2,1,2,0,1,4,3,3,2,3,2,2,1,3,2,2,1,2,1,1,0};;
char p[1000005][10];
int ddd(int q,int w)
{
    int a,b,s=0;
    for(int i=0; i<5; i++)
    {
        char x = p[q][i];
        char y = p[w][i];
        if(isdigit(x))a=x-'0';
        else a=x-'A'+10;
        if(isdigit(y))b=y-'0';
        else b=y-'A'+10;
        s += cmp[a][b];
    }
    return s;
}
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        int N;
        cin>>N;
        int minn=0xfffffff;
        for(int i=0; i<N; i++)
            cin>>p[i];
        srand((unsigned)time(NULL));
        for(int i=1; i<=100000; i++)
        {
            int a=rand()%N;
            int b=rand()%N;
            if(a==b)continue;
            int tmp=ddd(a,b);
            minn=tmp>minn?minn:tmp;
        }
        cout<<minn<<endl;
    }
    return 0;
}