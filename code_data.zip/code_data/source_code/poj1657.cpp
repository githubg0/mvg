// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,p;
int dp[3005][3005],h[3005],num[3005],ls[3005];
struct f
{
int now,v,son;
}tree[10005];
void build(int fa,int son,int cost)
{
tree[p].now=son;
tree[p].son=h[fa];
tree[p].v=cost;
h[fa]=p++;
}
void csh()
{
for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
        dp[i][j]=-9999999;
}
void dfs(int now)
{
for(int i=h[now];i!=-1;i=tree[i].son)
    {
    int to=tree[i].now;
    dfs(to);
    for(int j=0;j<=num[now];j++)
        ls[j]=dp[now][j];
    for(int j=0;j<=num[now];j++)
        for(int k=1;k<=num[to];k++)
            dp[now][j+k]=max(dp[now][j+k],ls[j]+dp[to][k]-tree[i].v);
    num[now]+=num[to];
    }
}
int main()
{
int k,a,c;
while(cin>>n>>m)
    {
    p=0;
    memset(h,-1,sizeof(h));
    for(int i=1;i<=n-m;i++)
        {
        scanf("%d",&k);
        num[i]=0;
        while(k--)
            {
            scanf("%d%d",&a,&c);
            build(i,a,c);
            }
        }
    csh();
    for(int i=n-m+1;i<=n;i++)
        {
        scanf("%d",&dp[i][1]);
        num[i]=1;
        }
    dfs(1);
    for(int i=m;i>=0;i--)
        if(dp[1][i]>=0)
            {
            cout<<i<<endl;
            break;
            }
    }
return 0;
}