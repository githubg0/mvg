// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 1111
using namespace std;
int tot,n,m;
int s,l,r,u,d;
char g[N][N];
bool ok(int x,int y)
{
    return (x>=0 && x<n && y>=0 && y<m && g[x][y]=='#');
}
void dfs(int x,int y)
{
    s++;
    l=min(y,l); u=min(u,x);
    r=max(y,r); d=max(d,x);
    g[x][y]='.';
    for(int i=-1;i<=1;i++)  
        for(int j=-1;j<=1;j++)
            if(ok(x+i,y+j)) dfs(x+i,y+j);
    return ;
}
int main()
{
    while(scanf("%d%d",&n,&m)==2)
    {
        if(n==0 && m==0)
            break;
        for(int i=0;i<n;i++)
            scanf("%s",g[i]);
        int tot=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(g[i][j]=='#')
                {
                    s=0;
                    l=r=j;
                    u=d=i;
                    dfs(i,j);
                    if(s==(r-l+1)*(d-u+1))
                        tot++;
                    else i=n,j=m,tot=-1; 
                }
            }
        }
        if(tot<0) printf("Bad placement.\n");
        else printf("There are %d ships.\n",tot);
    }
    return 0;
}