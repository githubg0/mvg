// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=110;
int n,K;
struct Edge
{
    int to,next;
}edge[maxn*maxn];
int Adj[maxn],Size;
void init()
{
    memset(Adj,-1,sizeof(Adj)); Size=0;
}
void add_edge(int u,int v)
{
    edge[Size].to=v; edge[Size].next=Adj[u]; Adj[u]=Size++;
}
int linker[maxn];
bool used[maxn];
bool dfs(int u)
{
    for(int i=Adj[u];~i;i=edge[i].next)
    {
        int v=edge[i].to;
        if(!used[v])
        {
            used[v]=true;
            if(linker[v]==-1||dfs(linker[v]))
            {
                linker[v]=u;
                return true;
            }
        }
    }
    return false;
}
int hungary()
{
    int res=0;
    memset(linker,-1,sizeof(linker));
    for(int u=1;u<=n;u++)
    {
        memset(used,false,sizeof(used));
        if(dfs(u)) res++;
    }
    return res;
}
int a[maxn];
int main()
{
    int T_T;
    scanf("%d",&T_T);
    while(T_T--)
    {
        scanf("%d%d",&n,&K);
        init();
        for(int i=1;i<=n;i++)
        {
            scanf("%d",a+i);
            for(int j=0;a[i]+j*K<=n;j++)
            {
                int v=a[i]+j*K;
                add_edge(i,v);
            }
        }
        int pp=hungary();
        
        if(pp==n) puts("Jerry");
        else puts("Tom");
    }
    return 0;
}