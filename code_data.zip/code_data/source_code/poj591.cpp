// Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define Pr pair<int,int>
#define fread(ch) freopen(ch,"r",stdin)
#define fwrite(ch) freopen(ch,"w",stdout)
using namespace std;
const int INF = 0x3f3f3f3f;
const int msz = 10000;
const int mod = 1e9+7;
const double eps = 1e-8;
const int maxn = 5123456;
struct Node
{
    int next[26],fail,cnt;
} nd[maxn];
bool vis[6666];
int pos[6666];
int id[6666];
char str[maxn];
char ps[maxn];
int len,tp;
int NewNode()
{
    memset(nd[tp].next,0,sizeof(nd[tp].next));
    nd[tp].fail = nd[tp].cnt = 0;
    return tp++;
}
void Add(int root,int c)
{
    int k;
    while(str[len])
    {
        k = str[len]-'A';
        if(!nd[root].next[k]) nd[root].next[k] = NewNode();
        root = nd[root].next[k];
        len++;
    }
    if(!nd[root].cnt) id[c] = nd[root].cnt = c;
    else id[c] = nd[root].cnt;
}
void Build_Fail(int root)
{
    queue <int> q;
    q.push(root);
    int f;
    while(!q.empty())
    {
        root = q.front();
        
        q.pop();
        for(int i = 0; i < 26; ++i)
        {
            if(!nd[root].next[i]) continue;
            if(root) 
            {
                f = nd[root].fail;
                while(f && !nd[f].next[i]) f = nd[f].fail;
                nd[nd[root].next[i]].fail = nd[f].next[i]? nd[f].next[i]: f;
            }
            q.push(nd[root].next[i]);
        }
    }
}
int Search(int root,char *str,int len,int id,int f)
{
    
    
    
    int ans = 0,k;
    for(int i = 0; i < len; ++i)
    {
        k = str[i]-'A';
        while(root && !nd[root].next[k]) root = nd[root].fail;
        if(nd[root].next[k]) root = nd[root].next[k];
        else continue;
        if(f) vis[nd[root].cnt] = f;
        else
        {
            for(int j = root; j; j = nd[j].fail)
            {
                if(nd[j].cnt != id) vis[nd[j].cnt] = f;
            }
        }
    }
    return ans;
}
bool IsChar(char ch)
{
    return 'A' <= ch && ch <= 'Z';
}
void read(char *str)
{
    char ch;
    int pos = 0;
    while((ch = getchar()) && ch == '\n' || ch == EOF || ch == '\r' || ch == ' ');
    while(ch && ch != '\n' && ch != EOF && ch != '\r')
    {
        if(IsChar(ch))
        {
            str[pos++] = ch;
            ch = getchar();
            continue;
        }
        int cnt = 0;
        ch = getchar();
        while(!IsChar(ch))
        {
            cnt = cnt*10+ch-'0';
            ch = getchar();
        }
        while(cnt--) str[pos++] = ch;
        ch = getchar();
        ch = getchar();
    }
    str[pos] = 0;
}
int main()
{
    
    
    int t,n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        len = 0;
        tp = 0;
        int root = NewNode();
        for(int i = 1; i <= n; ++i)
        {
            pos[i] = len;
            read(str+len);
            Add(root,i);
        }
        pos[n+1] = len;
        read(ps);
        Build_Fail(root);
        
        
        memset(vis,0,sizeof(vis));
        Search(root,ps,strlen(ps),0,1);
        for(int i = 1; i <= n; ++i)
        {
            
            if(id[i] == i && vis[i]) Search(root,str+pos[i],pos[i+1]-pos[i],id[i],0);
        }
        int ans = 0;
        for(int i = 1; i <= n; ++i)
            ans += vis[i];
        printf("%d\n",ans);
    }
    return 0;
}