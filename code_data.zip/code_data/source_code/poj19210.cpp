// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MP make_pair
#define D(x) cout<<#x<<" = "<<x<<"  "
#define E cout<<endl
using namespace std;
typedef pair<int,int> pii;
const int mxn = 5e5;
const int INF = 0x3f3f3f3f;
int n,a[mxn];
struct Node{
    int l,r; pii d;
} pool[mxn*4];
void update(int x){
    pool[x].d=min(pool[x*2].d,pool[x*2+1].d);
}
void build(int x,int l,int r){
    Node &t=pool[x];
    t.l=l; t.r=r; t.d=MP(INF,-1);
    if(l!=r){
        int mid=(l+r)>>1;
        build(x*2,l,mid); 
        build(x*2+1,mid+1,r);
    }
}
void insert(int x,int d,int tim){
    Node &t=pool[x];
    if(t.l==t.r){ t.d=MP(d,tim); }
    else{
        int mid=(t.l+t.r)>>1;
        if(d<=mid) insert(x*2,d,tim);
        else insert(x*2+1,d,tim);
        update(x);
    }
}
pii query(int x,int ql,int qr){
    Node &t=pool[x]; 
    if(ql<=t.l && t.r<=qr){ return t.d; }
    else{
        int mid=(t.l+t.r)>>1;
        if(qr<=mid) return query(x*2,ql,qr);
        else if(ql>mid) return query(x*2+1,ql,qr);
        else return min(query(x*2,ql,qr),query(x*2+1,ql,qr));
    }
}
void baoli(int d){
    int mn=INF, pos=-1;
    for(int i=n;i>=1;i--){
        if(a[i]%d<mn){ mn=a[i]%d; pos=i; }
    }
    printf("%d\n",pos);
}
void solve(int d){
    int mn=INF, pos=-1;
    for(int i=0;i<=mxn;i+=d){
        pii x=query(1,i,min(mxn,i+d-1));
        if(x.second!=-1){
            if(x.first%d<mn || (x.first%d==mn && x.second>pos)){
                mn=x.first%d; pos=x.second;
            }
        }
    }
    printf("%d\n",pos);
}
int main(){
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    int T,d,cas=0; char op[5];
    while(scanf("%d",&T)!=EOF && T){
        if(cas) puts("");
        printf("Case %d:\n",++cas);
        n=0; build(1,1,mxn);
        for(int i=1;i<=T;i++){
            scanf("%s%d",op,&d);
            if(op[0]=='A'){
                if(d<=10000) baoli(d);
                else solve(d);
            }
            else{
                a[++n]=d;
                insert(1,d,n);
            }
        }
    }
}