// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int nMax=205;
const int inf=10000000;
int mat[nMax][nMax],vis[nMax],dist[nMax],N,M,S,T,cnt,num;
char mon[nMax][33];
int dij(int s,int t)
{
    memset(vis,0,sizeof(vis));
    for(int i=0;i<N;i++) dist[i]=(i==s?inf:0);
    for(int i=0;i<N-1;i++)
    {
        int d=0,u;
        for(int j=0;j<N;j++)
            if(!vis[j]&&dist[j]>d) d=dist[u=j];
        vis[u]=1;
        for(int j=0;j<N;j++)
            if(!vis[j]) dist[j]=max(min(dist[u],mat[u][j]),dist[j]);
    }
    return dist[t];
}
int get(char s[])
{
    int u=-1;
    for(int i=0;i<num;i++) if(!strcmp(s,mon[i])) u=i;
    return u;
}
int main()
{
    while(scanf("%d%d",&N,&M)&&N&&M)
    {
        cnt++; num=0;
        memset(mat,0,sizeof(mat));
        char s1[35],s2[35];
        for(int i=0;i<M;i++)
        {
            int u=-1,v=-1,d;
            scanf("%s%s%d",s1,s2,&d);
            u=get(s1);
            if(u==-1)
            {
                u=num++;strcpy(mon[u],s1);
            }
            v=get(s2);
            if(v==-1)
            {
                v=num++;strcpy(mon[v],s2);
            }
            mat[u][v]=mat[v][u]=d;
        }
        scanf("%s%s",s1,s2);
        S=get(s1); T=get(s2);
        printf("Scenario #%d\n%d tons\n\n",cnt,dij(S,T));
    }
    return 0;
}