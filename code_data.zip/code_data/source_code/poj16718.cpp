// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Dinic's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1100;
const int maxm=50100;
const int oo=1000000001;
struct Edge
{
	int obj,flow;
	Edge *Next,*rev;
} e[(maxm+maxn)<<1];
Edge *head[maxn<<1];
Edge *nhead[maxn<<1];
int cur=-1;
int In[maxn];
int Out[maxn];
int level[maxn<<1];
int vis[maxn<<1];
int que[maxn<<1];
int he,ta;
int temp1[maxn];
int temp2[maxn];
int n,m;
int s,t;
void Add(int x,int y,int z)
{
	cur++;
	e[cur].obj=y;
	e[cur].flow=z;
	e[cur].Next=head[x];
	e[cur].rev=&e[cur+1];
	head[x]=e+cur;
	cur++;
	e[cur].obj=x;
	e[cur].flow=0;
	e[cur].Next=head[y];
	e[cur].rev=&e[cur-1];
	head[y]=e+cur;
}
bool Bfs()
{
	memset(level,-1,sizeof(level));
	memset(vis,false,sizeof(vis));
	for (int i=s; i<=t; i++) nhead[i]=head[i];
	he=0,ta=1;
	que[1]=s;
	level[s]=1;
	vis[s]=true;
	while (he<ta)
	{
		int node=que[ ++he ];
		Edge *p=head[node];
		while (p)
		{
			int son=p->obj;
			if ( !vis[son] && p->flow )
			{
				que[ ++ta ]=son;
				level[son]=level[node]+1;
				vis[son]=true;
			}
			p=p->Next;
		}
	}
	
	
	
	return vis[t];
}
int Dfs(int node,int maxf)
{
	int nowf=0,nextf;
	if ( node==t || !maxf ) return maxf;
	Edge *p=nhead[node];
	while (p)
	{
		if ( p->flow && level[node]+1==level[ p->obj ] )
		{
			nextf=Dfs(p->obj, min(maxf,p->flow) );
			p->flow-=nextf;
			p->rev->flow+=nextf;
			nowf+=nextf;
			maxf-=nextf;
			if (maxf) nhead[node]=p;
		}
		p=p->Next;
	}
	if (maxf) level[node]=-1;
	return nowf;
}
int Dinic()
{
	int max_flow=0;
	while ( Bfs() )
	{
		max_flow+=Dfs(s,oo);
		
	}
	return max_flow;
}
int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++) scanf("%d",&In[i]);
	for (int i=1; i<=n; i++) scanf("%d",&Out[i]);
	s=0,t=(n<<1)+1;
	for (int i=s; i<=t; i++) head[i]=NULL;
	for (int i=1; i<=n; i++) Add(s,i,Out[i]);
	for (int i=n+1; i<t; i++) Add(i,t,In[i-n]);
	for (int i=1; i<=m; i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		Add(x,n+y,oo);
	}
	int ans=Dinic();
	printf("%d\n",ans);
	int ans1=0;
	for (int i=1; i<=n; i++) if (!vis[i]) temp1[ ++ans1 ]=i;
	int ans2=0;
	for (int i=n+1; i<t; i++) if (vis[i]) temp2[ ++ans2 ]=i-n;
	printf("%d\n",ans1+ans2);
	for (int i=1; i<=ans1; i++) printf("%d -\n",temp1[i]);
	for (int i=1; i<=ans2; i++) printf("%d +\n",temp2[i]);
	return 0;
}