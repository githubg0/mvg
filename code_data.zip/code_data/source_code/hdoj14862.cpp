// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=22000;
const int INF=0x3f3f3f3f;
int Adj[maxn],Size;
struct E
{
	int to,next,len;
}Edge[maxn];
void init()
{
	Size=0;
	memset(Adj,-1,sizeof(Adj));
}
void Add_Edge(int u,int v,int w)
{
	Edge[Size].to=v;
	Edge[Size].len=w;
	Edge[Size].next=Adj[u];
	Adj[u]=Size++;
}
int n,dp[maxn][3];
void dfs1(int f,int u)
{
    int biggest=0,bigger=0;
    for(int i=Adj[u];~i;i=Edge[i].next)
    {
        int v=Edge[i].to;
        int w=Edge[i].len;
        if(v==f) continue;
        dfs1(u,v);
        int temp=dp[v][0]+w;
        if(temp>=biggest)
        {
            bigger=biggest;
            biggest=temp;
        }
        else if(temp>bigger)
        {
            bigger=temp;
        }
    }
    dp[u][0]=biggest;
    dp[u][1]=bigger;
}
void dfs2(int f,int u)
{
    for(int i=Adj[u];~i;i=Edge[i].next)
    {
        int v=Edge[i].to;
        int w=Edge[i].len;
        if(v==f) continue;
        dp[v][2]=max(dp[u][2],(dp[v][0]+w==dp[u][0])?dp[u][1]:dp[u][0]) + w ;
        dfs2(u,v);
    }
}
int main()
{
while(scanf("%d",&n)!=EOF)
{
	init();
	for(int i=2;i<=n;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		Add_Edge(i,a,b);
		Add_Edge(a,i,b);
	}
	memset(dp,0,sizeof(dp));
    dfs1(-1,1);
    dfs2(-1,1);
	for(int i=1;i<=n;i++)
    {
        printf("%d\n",max(dp[i][0],dp[i][2]));
    }
}
	return 0;
}