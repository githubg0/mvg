// Data Structure->Balanced Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define F(i,j,n) for(int i=j;i<=n;i++)
#define D(i,j,n) for(int i=j;i>=n;i--)
#define LL long long
#define MAXN 50005
#define pa pair<int,int>
#define INF 1000000000
using namespace std;
int n,m,x,tot=0,rt=0,l[MAXN],r[MAXN],rnd[MAXN],v[MAXN];
char op;
bool f[MAXN];
stack<int> st;
inline int read()
{
	int ret=0,flag=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') flag=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret*flag;
}
inline void rturn(int &k)
{
	int tmp=l[k];
	l[k]=r[tmp];r[tmp]=k;
	k=tmp;
}
inline void lturn(int &k)
{
	int tmp=r[k];
	r[k]=l[tmp];l[tmp]=k;
	k=tmp;
}
inline void ins(int &k,int x)
{
	if (!k){k=++tot;v[k]=x;l[k]=r[k]=0;rnd[k]=rand();return;}
	if (x<v[k]) {ins(l[k],x);if (rnd[l[k]]<rnd[k]) rturn(k);}
	else {ins(r[k],x);if (rnd[r[k]]<rnd[k]) lturn(k);}
}
inline void del(int &k,int x)
{
	if (v[k]==x)
	{
		if (!l[k]||!r[k]) k=l[k]+r[k];
		else if (rnd[l[k]]<rnd[r[k]]) {rturn(k);del(k,x);}
		else {lturn(k);del(k,x);}
		return;
	}
	if (x<v[k]) del(l[k],x);
	else del(r[k],x);
}
inline int pre(int k,int x)
{
	if (!k) return 0;
	else if (x<=v[k]) return pre(l[k],x);
	else {int tmp=pre(r[k],x);return tmp==0?v[k]:tmp;}
}
inline int suc(int k,int x)
{
	if (!k) return n+1;
	if (x>=v[k]) return suc(r[k],x);
	else {int tmp=suc(l[k],x);return tmp==n+1?v[k]:tmp;}
}
inline int getans(int x)
{
	if (f[x]) return 0;
	return suc(rt,x)-pre(rt,x)-1;
}
int main()
{
	memset(f,false,sizeof(f));
	n=read();m=read();
	while (m--)
	{
		op=getchar();while (op<'A'||op>'Z') op=getchar();
		if (op=='D') {x=read();f[x]=true;st.push(x);ins(rt,x);}
		else if (op=='Q') {x=read();printf("%d\n",getans(x));}
		else {del(rt,st.top());f[st.top()]=false;st.pop();}
	}
}