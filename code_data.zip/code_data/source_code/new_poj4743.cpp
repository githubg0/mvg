// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char ch[10][10];
int maptt1[10][10];
int n;
int ans;
int flag=1;
int check(int row,int clo)
{
    if(row==0)
        return 1;
    else{
        for(int i=row-1;i>=0;i--){
            if(maptt1[i][clo]==-1)
                return 1;
            else if(maptt1[i][clo]==1)
                return 0;
        }
    }
    return 1;
}
void dfs(int x,int y)
{
	if(y==n){
        if(x+1==n){
            int tmp=0;
            for(int i=0;i<n;i++){
                for(int j=0;j<n;j++){
                    if(maptt1[i][j]==1)
                        tmp++;
                }
            }
            ans=max(ans,tmp);
            return;
        }
        else{
            flag=1;
            dfs(x+1,0);
        }
	}
	else{
        if(ch[x][y]=='.'){
            if(flag&&check(x,y)){
                maptt1[x][y]=1;
                flag=0;
                dfs(x,y+1);
                maptt1[x][y]=0;
                flag=1;
                dfs(x,y+1);
            }
            else
                dfs(x,y+1);
        }
        else{
            flag=1;
            dfs(x,y+1);
        }
	}
	return;
}
int main(){
	while(scanf("%d",&n)==1&&n){
		memset(ch,0,sizeof(ch));
		memset(maptt1,0,sizeof(maptt1));
		ans=-1;
		for(int i=0;i<n;i++){
			scanf("%s",ch[i]);
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(ch[i][j]=='X')
					maptt1[i][j]=-1;
			}
		}
		flag=1;
        dfs(0,0);
		printf("%d\n",ans);
	}
	return 0;
}