// Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int grow_cow2(int year)
{
    if (year < 4)
    return year;
    else
    {
        int i, sum = year;
        for (i = 3; i < year; i++)
        {
            sum += grow_cow2(year - i);
        }
        return sum;
    }
}
int grow_cow(int year)
{
     if (year < 5)
    return year;
    else
    {
        int i, sum = year;
        for (i = 4; i < year; i++)
        {
            sum += grow_cow2(year - i);
        }
        return sum;
    }
}
int main()
{
    int n;
    while (scanf("%d", &n) && n)
    {
        printf("%d\n", grow_cow(n));
    }
    return 0;
}