// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 
using namespace std;
struct node
{
    char st,ed;
}a[101000];
int cnt = 0;
bool isok;
bool used[101000];
void DFS(int pos)
{ 
    if(a[pos].ed=='m')
    { 
        isok=true; 
        return; 
    } 
    for(int i=0;i<cnt;++i)
    { 
        if(used[i]||a[i].st!=a[pos].ed)continue; 
        used[i]=true; 
        DFS(i); 
        used[i]=false; 
        if(isok)return; 
    } 
} 
int main() 
{ 
    string str; 
    while(cin>>str)
    { 
        cnt = 0; 
        while(str[0]!='0')
        { 
            a[cnt].st = str[0];
            a[cnt].ed = str[str.size()-1];
            cnt++;
            cin>>str; 
        } 
        memset(used,0,sizeof(used)); 
        isok=false; 
        for(int i=0;i<cnt;++i)
        { 
            if(a[i].st!='b')continue; 
            used[i]=1; 
            DFS(i); 
        } 
        printf(isok ? "Yes.\n" : "No.\n");
    } 
    return 0; 
}