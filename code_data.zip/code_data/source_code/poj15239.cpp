// Data Structure->Disjoint Set Union (DSU),Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int p[520000],q[520000];
int top;
struct node
{
    int flag;
    struct node *next[27];
}*head;
node *newnode()
{
    int i;
    node *p=new node;
    p->flag=0;
    for(i=0; i<27; i++)
        p->next[i]=NULL;
    return p;
}
int zdsh(node *head,char *s)
{
    int i;
    node *p= head;
    int l=strlen(s);
    for(i=0; i<l; i++)
    {
        int k=s[i]-'a';
        if(p->next[k]==NULL)
            p->next[k]=newnode();
        p=p->next[k];
    }
    if(p->flag==0)
        p->flag=top++;
    return p->flag;
}
int Find(int x)
{
    int r=x,i=x,j;
    while(r!=p[r])
        r=p[r];
    while(i!=r)
    {
        j=p[i];
        p[i]=r;
        i=j;
    }
    return r;
}
void Search(int x,int y)
{
    int xx,yy;
    xx=Find(x);
    yy=Find(y);
    if(xx!=yy)
        p[xx]=yy;
}
int main()
{
    char s1[11],s2[11];
    int i,n;
    memset(q,0,sizeof(q));
    head=newnode();
    for(i=0; i<=520000; i++)
        p[i]=i;
    top=1;
    while(~scanf("%s %s",s1,s2))
    {
        int k1=zdsh(head,s1);
        int k2=zdsh(head,s2);
        q[k1]++;
        q[k2]++;
        Search(k1,k2);
    }
    for(i=2; i<top; i++)
        if(Find(i)!=Find(1))
            break;
    if(i<top)
        printf("Impossible\n");
    else
    {
        int s=0;
        for(i=1; i<top; i++)
            if(q[i]%2)
                s++;
        if(s==0||s==2)
            printf("Possible\n");
        else
            printf("Impossible\n");
    }
    return 0;
}