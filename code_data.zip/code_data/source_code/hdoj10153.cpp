// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn  = 100005;
int n,mod;
int ans[maxn];
double dp[maxn];
int prime[3005];
int notprime[3005];
void inti()
{
    memset(notprime,0,sizeof(notprime));
    for(int i = 2;i < 3005; i++) {
        if(!notprime[i]) {
            prime[++prime[0]] = i;
            for(int j = i*i;j < 3005; j += i) {
                notprime[j] = true;
            }
        }
    }
}
int main()
{
    
    inti();
    while(scanf("%d%d",&n,&mod) != EOF) {
        for(int i = 0;i <= n; i++) {
            dp[i] = 0;
            ans[i] = 1;
        }
        for(int i = 1;i <= prime[0] && prime[i] <= n; i++) {
            for(int j = n;j >= prime[i]; j++) { 
                for(int k = prime[i];k <= j; k *= prime[i]) {
                    if(dp[j-k] + log(k) > dp[j]) {
                        dp[j] = dp[j-k] + log(k);
                        ans[j] = (ans[j-k]*k)%mod;
                    }
                }
            }
        }
        printf("%d\n",ans[n]);
    }
    return 0;
}