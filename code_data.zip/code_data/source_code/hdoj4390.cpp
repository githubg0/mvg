// Data Structure->Disjoint Set Union (DSU),Graph Algorithm->Euler Circuit / Euler Path
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int pre[1010];
int find(int x)
{
	int r=x;
	while(r!=pre[r])
	{
		r=pre[r];
	}
	return r;
}
void join(int x,int y)
{
	int fx=find(x),fy=find(y);
	if(fx!=fy)
	pre[fx]=fy;
}
int main()
{
	int n,m,q[1010];
	while(scanf("%d",&n)&&n)
	{
		scanf("%d",&m);
		for(int i=1;i<=n;i++)
		{
			pre[i]=i;
			q[i]=0;
		}
		for(int i=1;i<=m;i++)
		{
			int a,b;
			scanf("%d%d",&a,&b);
			join(a,b);
			q[a]++;
			q[b]++;
		}
		int ans=0,sum=0;
		for(int i=1;i<=n;i++)
		{
			if(pre[i]==i)
			ans++;
		}
		if(ans==1)
		{
			for(int i=1;i<=n;i++)
			{
				if(q[i]%2==0)
				sum++;
			}
			if(sum==n)
			printf("1\n");
			else
			printf("0\n");
		}
		else
		printf("0\n");
	}
	return 0;
}