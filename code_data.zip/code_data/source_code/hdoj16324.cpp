// Basic Algorithm->Recurrence,Math and Computational Geometry->Fermat's Little Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int N = 2;
typedef long long LL;
const LL MOD = 1000000007;
struct Matrix{
	LL ary[N][N];
	void init() { memset(ary, 0, sizeof(ary)); }
	Matrix() {init();};
};
const Matrix operator*(const Matrix & A, const Matrix & B) {
	Matrix t;
	for (int i = 0; i < N; ++i)
		for (int j = 0; j < N; ++j) {
			for (int k = 0; k < N; ++k)
				t.ary[i][j] += A.ary[i][k] * B.ary[k][j];
			t.ary[i][j] %= (MOD - 1);
		}
	return t;
}
const Matrix get_matrix(LL n) {
	Matrix ans, tmp;
	ans.ary[0][0] = ans.ary[1][1] = 1;
	tmp.ary[0][0] = tmp.ary[0][1] = tmp.ary[1][0] = 1;
	while (n) {
		if (n & 1)
			ans = ans * tmp;
		tmp = tmp * tmp;
		n >>= 1;
	}
	return ans;
}
LL quick_pow(LL a, LL b) {
	LL ans = 1, tmp = a;
	while (b) {
		if (b & 1)
			ans = (ans * tmp) % MOD;
		tmp = (tmp * tmp) % MOD;
		b >>= 1;
	}
	return ans;
}
int main() {
	LL a, b, n;
	while (~scanf("%lld%lld%lld", &a, &b, &n)) {
		if (n == 0) {
			printf("%lld\n", a % MOD);
			continue;
		}
		Matrix mt = get_matrix(n - 1);
		LL A = quick_pow((a % (MOD - 1)), mt.ary[0][1]) % MOD;
		LL B = quick_pow((b % (MOD - 1)), mt.ary[0][0]) % MOD;
		LL ans = (A * B) % MOD;
		printf("%lld\n", ans);
	}
	return 0;
}