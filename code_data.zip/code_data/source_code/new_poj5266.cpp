// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Strongly Connected Components,Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 10010
using namespace std;
int n,m;
vector<int>g[maxn];
vector<int>rg[maxn];
vector<int>vs;
bool vis[maxn];
int rec[maxn];
int ans[maxn];
void add(int f,int t)
{
    g[f].push_back(t);
    rg[t].push_back(f);
}
void dfs(int v)
{
    vis[v]=true;
    for(int i=0;i<g[v].size();++i)
        if(!vis[g[v][i]])
            dfs(g[v][i]);
    vs.push_back(v);
}
void rdfs(int v,int k)
{
    vis[v]=true;
    rec[v]=k;
    for(int i=0;i<rg[v].size();++i)
        if(!vis[rg[v][i]])
            rdfs(rg[v][i],k);
}
void scc()
{
    memset(vis,false,sizeof(vis));
    vs.clear();
    for(int i=1;i<=n;++i)
    {
        if(!vis[i])
            dfs(i);
    }
    memset(vis,false,sizeof(vis));
    int k=0;
    for(int i=vs.size()-1;i>=0;--i)
    {
        if(!vis[vs[i]])
        {
            rdfs(vs[i],k);
            k++;
        }
    }
}
int main()
{
    int a,b;
    while(~scanf("%d%d",&n,&m))
    {
        for(int i=0;i<=n;++i)
        {
            g[i].clear();
            rg[i].clear();
        }
        memset(rec,0,sizeof(rec));
        memset(ans,0,sizeof(ans));
        while(m--)
        {
            scanf("%d%d",&a,&b);
            add(a,b);
        }
        scc();
        for(int i=1;i<=n;++i)
            ans[rec[i]]++;
        int num=0;
        for(int i=0;i<=n;++i)
            if(ans[i]>=2)
                num++;
        printf("%d\n",num);
    }
    return 0;
}