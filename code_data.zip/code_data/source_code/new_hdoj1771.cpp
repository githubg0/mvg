// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Euler Circuit / Euler Path,Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int vis[1200];
vector<int >G[1200];
void dfs(int u){
    vis[u]=1;
    int v=G[u].size();
    for(int i=0;i<v;i++){
        int t=G[u][i];
        if(!vis[t]) dfs(t);
    }
}
int main(){
    int n,m,a,b;
    while(scanf("%d",&n)!=EOF&&n) {
        scanf("%d",&m);
        memset(vis,0,sizeof(vis));
        for(int i=0;i<m;i++){
            scanf("%d%d",&a,&b);
            G[a].push_back(b);
            G[b].push_back(a);
        }
        int cnt=0;
        for(int i=1;i<=n;i++)
            if(!vis[i]){
                cnt++;
                if(cnt>1) break;
                dfs(i);
            }
        int ans=0;
        for(int i=1;i<=n;i++)
            if(G[i].size()%2==1)
        { ans=1; break; }
        if(ans==0&&cnt==1) cout<<1<<endl;
        else cout<<0<<endl;
        for(int i=1;i<=n;i++)
            G[i].clear();
    }
    return 0;
}