// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 1e5 + 10;
int N;
char s[maxn];
ll a[maxn];
int cnt;
int main()
{
    int T;
    scanf("%d",&T);
    for(int j = 1; j <= T; j++)
    {
        scanf("%s",s);
        int N = strlen(s);
        ll sum = 0;
        int last = 0;
        cnt = 1;
        memset(a,0,sizeof(a));
        for(int i = 0; i < N; i++)
        {
            if(s[i] == s[last])
            {
                a[cnt]++;
            }
            else
            {
                cnt++;
                last = i;
                i--;
            }
        }
        for(int i = 1; i <= cnt; i++)
        {
            sum += a[i]*a[i];
        }
        ll Max = sum;
        ll ans1,ans2;
        for(int i = 1; i <= cnt; i++)
        {
            if(i == 1)
            {
                if(cnt == 2)
                {
                    ans1 = sum - a[1]*a[1] - a[2]*a[2];
                    ans1 += (a[1] - 1)*(a[1] - 1) + (a[2] + 1)*(a[2] + 1);
                    Max = max(Max,ans1);
                    ans2 = sum - a[1]*a[1] - a[2]*a[2];
                    ans2 += (a[1] + 1)*(a[1] + 1) + (a[2] - 1)*(a[2] - 1);
                    Max = max(Max,ans2);
                }
                else if(cnt > 2)
                {
                    ans1 = sum - a[1]*a[1] - a[2]*a[2];
                    ans1 += (a[1] - 1)*(a[1] - 1) + (a[2] + 1)*(a[2] + 1);
                    Max = max(Max,ans1);
                    if(a[2] == 1)
                    {
                        ans2 = sum - a[1]*a[1] - a[2]*a[2] - a[3]*a[3];
                        ans2 += (a[1] + a[2] + a[3])*(a[1] + a[2] + a[3]);
                        Max = max(Max,ans2);
                    }
                    else
                    {
                        ans2 = sum - a[1]*a[1] - a[2]*a[2];
                        ans2 += (a[1] + 1)*(a[1] + 1) + (a[2] - 1)*(a[2] - 1);
                        Max = max(Max,ans2);
                    }
                }
            }
            else if(i == cnt)
            {
                if(cnt == 2)
                {
                    ans1 = sum - a[cnt]*a[cnt] - a[cnt - 1]*a[cnt - 1];
                    ans1 += (a[cnt] - 1)*(a[cnt] - 1) + (a[cnt - 1] + 1)*(a[cnt - 1] + 1);
                    Max = max(Max,ans1);
                    ll ans2 = sum - a[cnt]*a[cnt] - a[cnt - 1]*a[cnt - 1];
                    ans2 += (a[cnt] + 1)*(a[cnt] + 1) + (a[cnt - 1] - 1)*(a[cnt - 1] - 1);
                    Max = max(Max,ans2);
                }
                else if(cnt > 2)
                {
                    ans1 = sum - a[cnt]*a[cnt] - a[cnt - 1]*a[cnt - 1];
                    ans1 += (a[cnt] - 1)*(a[cnt] - 1) + (a[cnt - 1] + 1)*(a[cnt - 1] + 1);
                    Max = max(Max,ans1);
                    if(a[cnt - 1] == 1)
                    {
                        ll ans2 = sum - a[cnt]*a[cnt] - a[cnt - 1]*a[cnt - 1] - a[cnt - 2]*a[cnt - 2];
                        ans2 += (a[cnt] + a[cnt - 1] + a[cnt - 2])*(a[cnt] + a[cnt - 1] + a[cnt - 2]);
                        Max = max(ans2,Max);
                    }
                    else
                    {
                        ll ans2 = sum - a[cnt]*a[cnt] - a[cnt - 1]*a[cnt - 1];
                        ans2 += (a[cnt] + 1)*(a[cnt] + 1) + (a[cnt - 1] - 1)*(a[cnt - 1] - 1);
                        Max = max(Max,ans2);
                    }
                }
            }
            else
            {
                ans1 = sum - a[i]*a[i] - a[i + 1]*a[i + 1];
                ans1 += (a[i] + 1)*(a[i] + 1) + (a[i + 1] - 1)*(a[i + 1] - 1);
                Max = max(Max,ans1);
                ans1 = sum - a[i]*a[i] - a[i + 1]*a[i + 1];
                ans1 += (a[i] - 1)*(a[i] - 1) + (a[i + 1] + 1)*(a[i + 1] + 1);
                Max = max(Max,ans1);
                if(a[i + 1] == 1&&i + 2 <= cnt)
                {
                    ans1 = sum - a[i]*a[i] - a[i + 1]*a[i + 1] - a[i + 2]*a[i + 2];
                    ans1 += (a[i] + a[i + 1] + a[i + 2])*(a[i] + a[i + 1] + a[i + 2]);
                    Max = max(Max,ans1);
                }
            }
        }
        printf("Case #%d: %lld\n",j,Max);
    }
    return 0;
}