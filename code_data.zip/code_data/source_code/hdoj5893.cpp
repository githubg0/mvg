// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 9999999
using namespace std;
const int maxn=110;
int maptt1[maxn][maxn];
int dist[maxn][maxn];
int ans;
void floyd(int n){
	for(int k=1;k<=n;++k){
		for(int i=1;i<k;++i){
			for(int j=i+1;j<k;++j){
				ans=min(ans,dist[i][j]+maptt1[i][k]+maptt1[k][j]);
			}
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
			}
		}
	}
}
int main()
{
	int n,m,i,j,k;
	while(scanf("%d%d",&n,&m)!=EOF){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				maptt1[i][j]=dist[i][j]=inf;
			}
		}
		int a,b,c;
		for(i=0;i<m;++i){
			scanf("%d%d%d",&a,&b,&c);
			if(maptt1[a][b]>c){
				maptt1[a][b]=maptt1[b][a]=c;
				dist[a][b]=dist[b][a]=c;
			}
		}
		ans=inf;
		floyd(n);
		if(ans<inf){
			printf("%d\n",ans);
		}
		else {
			printf("It's impossible.\n");
		}
	}
	return 0;
}