// Basic Algorithm->Recursion,Data Structure->Queue,Dynamic Programming->Tree-Based Dynamic Programming,Basic Algorithm->Depth First Search (DFS)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define all(x) (x).begin(), (x).end()
#define for0(a, n) for (int (a) = 0; (a) < (n); (a)++)
#define for1(a, n) for (int (a) = 1; (a) <= (n); (a)++)
#define LEFT(x)   (x<<1)
#define ysk(x)  (1<<(x))
typedef long long ll;
typedef pair<int, int> pii;
const int INF =0x3f3f3f3f;
const int maxn=1000000    ;
ll lest[maxn+10],sec[maxn+10];
int plest[maxn+10],psec[maxn+10],n,m;
int fir[maxn+10],nex[2*maxn+10];
int nedge;
struct Edge
{
    int to; ll w;
    Edge(){}
    Edge(int to,ll w):to(to),w(w){}
}edges[2*maxn+10];
void update(int x,int y,ll val)
{
       if( val>=lest[x])
       {
           sec[x]=lest[x];
           psec[x]=plest[x];
           lest[x]=val;
           plest[x]=y;
       }
       else if(val>=sec[x])
       {
            sec[x]=val;
            psec[x]=y;
       }
}
void dfs(int x,int fa)
{
   lest[x]=sec[x]=0;
   plest[x]=psec[x]=-1;
   for(int i=fir[x];~i ;i=nex[i])
   {
       Edge & e=edges[i];
       int y=e.to;if(y==fa)  continue;
       ll w=e.w;
       dfs( y,x);
       update(x,y,lest[y]+w);
   }
}
void dfs2(int x,int fa,ll dis)
{
    if(~fa)
    {
        ll ret= plest[fa]==x?sec[fa] :lest[fa];
        update(x,fa,dis+ret);
    }
    for(int i=fir[x];~i ;i=nex[i])
    {
        Edge &e=edges[i];
       int y=e.to;if(y==fa) continue;
       ll w=e.w;
       dfs2(y,x,w);
    }
}
void init()
{
    nedge=0;
   memset(fir,-1,(n+1)*sizeof fir[0]);
}
inline void add_edge(int x,int y,ll w)
{
     edges[nedge]=Edge(y,w);
     nex[nedge]=fir[x];
     fir[x]=nedge++;
}
int qs[maxn+10],ql[maxn+10];
int solve()
{
    int ans=0;
    int front_s=0,rear_s=0,front_l=0,rear_l=0;
    int le=1;
    for(int i=1;i<=n;i++)
    {
        while( front_s<rear_s&&lest[qs[rear_s-1]]>=lest[i]  )  rear_s--;
        qs[rear_s++ ]=i;
        while( front_l<rear_l&&lest[ql[rear_l-1]]<=lest[i]  )  rear_l--;
        ql[rear_l++ ]=i;
        while( lest[ql[front_l]]-lest[qs[front_s]]>m )
        {
            if(qs[front_s]==le)  front_s++;
            if(ql[front_l]==le)  front_l++;
            le++;
        }
        ans=max(ans,i-le+1);
    }
    return ans;
}
int main()
{
    int x;ll w;
    scanf("%d%d",&n,&m);
    {
        init();
        for(int i=2;i<=n;i++)
        {
           scanf("%d%lld",&x,&w);
           add_edge(x,i,w);
           add_edge(i,x,w);
        }
        dfs(1,-1);
        dfs2(1,-1,0);
       printf("%d\n",solve());
    }
    return 0;
}