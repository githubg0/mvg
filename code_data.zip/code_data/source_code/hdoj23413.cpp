// Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=200;
struct Node
{   string s;
     int first;
     int second;
}node[maxn];
struct DP
{   int cost;
    int pre;
    int date;
}dp[1<<20];
void output(int n)
{   if(n==0)return;
    int sta=n^dp[n].pre;
     sta>>=1;
     int pos=0;
     while(sta)
     {  sta>>=1;
         pos++;
     }
     output(dp[n].pre);
      cout<<node[pos].s<<endl;
}
int main()
{  int m;
   int t;
    scanf("%d",&t);
    while(t--)
    {   cin>>m;
       memset(dp,0,sizeof(dp));
       for(int i=0;i<m;i++)
       {   cin>>node[i].s;
           cin>>node[i].first;
           cin>>node[i].second;
       }
     int all=(1<<m)-1;
     bool vis[(1<<m)];
     memset(vis,false,sizeof(vis));
     vis[0]=true;
     for(int i=0;i<all;i++)
     {   for(int j=0;j<m;j++)
          {    if(!(i&(1<<j)))
              {   int dat=dp[i].date+node[j].second;
                 int cos=dat-node[j].first;
                 if(cos<0) cos=0;
                 int status=i|(1<<j);
                 dp[status].date=dat;
                  cos+=dp[i].cost;
                 if(!vis[status])
                 {   vis[status]=true;
                    dp[status].cost=cos;
                    dp[status].pre=i;
                 }
                  if(vis[status]&&dp[status].cost>cos)
                  {  dp[status].cost=cos;
                     dp[status].pre=i;
                  }
              }
          }
     }
 cout<<dp[all].cost<<endl;
    output(all);
    }
    return 0;
}