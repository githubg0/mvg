// Data Structure->Binary Indexed Tree (BIT)
/* POJ2828 Buy Tickets */
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 2e5;
int a[N + 1], n;
int b[N + 1], c[N + 1], d[N + 1];
int lowbit(int i)
{
    return i & -i;
}
void update(int i, int v) 
{
    while(i <= n) {
        a[i] += v;
        i += lowbit(i);
    }
}
int sum(int i)      
{
    int sum = 0;
    while(i > 0) {
        sum += a[i];
        i -= lowbit(i);
    }
    return sum;
}
int getk(int sum)   
{
    int p=0, s=0;
    for (int i = 20; i >= 0; i--) {
        p += (1 << i);
        if (p > n || s + a[p] >= sum)
            p -= (1 << i);
        else
            s += a[p];
    }
    return p + 1;
}
int main()
{
    while(~scanf("%d", &n)) {
        memset(a, 0, sizeof(a));
        for(int i = 1; i <= n; i++) {
            update(i, 1);
            scanf("%d%d", &b[i], &c[i]);
        }
        for(int i = n; i >= 1; i--) {
            int t = getk(b[i] + 1);
            d[t] = i;
            update(t, -1);
        }
        for(int i = 1; i <= n; i++)
            printf("%d%c", c[d[i]], (i == n) ? '\n' : ' ');
    }
    return 0;
}