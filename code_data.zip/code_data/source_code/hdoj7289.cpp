// Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int MAXO = 4;
const int MOD = 1024;
template <typename T>
struct Matrix {
    T e[MAXO][MAXO];
    int o;
    Matrix(int x) { memset(e, 0, sizeof(e)); o = x; }
    Matrix operator*(const Matrix& one) {
        Matrix res(o);
        for (int i = 0; i < o; i++) {
            for (int j = 0; j < o; j++) {
                for (int k = 0; k < o; k++)
                    res.e[i][j] += e[i][k] * one.e[k][j];
                res.e[i][j] %= MOD;
            }
        }
        return res;
    }
    Matrix operator*=(const Matrix& one) { return *this = *this * one; }
};
template <typename T>
T QuickPower(T radix, int exp) {
    T res = radix;
    exp--;
    while (exp) {
        if (exp & 1) res *= radix;
        exp >>= 1;
        radix *= radix;
    }
    return res;
}
int n;
Matrix<int> radix(2);
int main() {
    int tot_case;
    scanf("%d", &tot_case);
    while (tot_case--) {
        
        scanf("%d", &n);
        
        radix.e[0][0] = 5;
        radix.e[0][1] = 2;
        radix.e[1][0] = 12;
        radix.e[1][1] = 5;
        Matrix<int> ans = QuickPower(radix, n - 1);
        
        int x_n = (5 * ans.e[0][0] + 2 * ans.e[1][0]) % MOD;
        printf("%d\n", (x_n * 2 - 1) % MOD);
    }
    return 0;
}