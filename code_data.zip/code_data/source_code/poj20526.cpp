// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct cup
{
	int x, y;
	int step;
	int flag;
	cup *pre;
};
queue<cup>Q;
stack<int>R;
int a, b, e;
int vis[117][117]={0};
int ans;
void BFS(int x, int y)
{
	cup c;
	cup t[317];
	c.x = 0, c.y = 0;
	c.flag = 0;
	c.pre = NULL;
	c.step = 0;
	Q.push(c);
	vis[x][y] = 1;
	int count = -1;
	while(!Q.empty())
	{
		count++;
		t[count] = Q.front();
		Q.pop();
		for(int i = 1; i <= 6; i++)
		{
			switch(i)
			{
				case 1:						
					c.x = a;
					c.y = t[count].y;
					c.flag = 1;
					break;
				case 2:						
					c.x = t[count].x;
					c.y = b;
					c.flag = 2;
					break;
				case 3:						
					c.x = 0;
					c.y = t[count].y;
					c.flag = 3;
					break;
				case 4:						
					c.x = t[count].x;
					c.y = 0;
					c.flag = 4;
					break;
				case 5:						
					if(t[count].x > b-t[count].y)
					{
						c.x = t[count].x-(b-t[count].y);
						c.y = b;
					}
					else
					{
						c.x = 0;
						c.y = t[count].y+t[count].x;
					}
					c.flag = 5;
					break;
				case 6:						
					if(t[count].y > a-t[count].x)
					{
						c.y = t[count].y - (a-t[count].x);
						c.x = a;
					}
					else
					{
						c.x = t[count].x+t[count].y;
						c.y = 0;
					}
					c.flag = 6;
					break;
			}
			if(vis[c.x][c.y])
				continue;
			vis[c.x][c.y] = 1;
			c.step = t[count].step+1;
			c.pre = &t[count];
			if(c.x == e || c.y == e)
			{
				ans = c.step;
				while(c.pre)
				{
					R.push(c.flag);
					c = *c.pre;
				}
				return;
			}
			Q.push(c);
		}
	}
}
void print()
{
	while(!R.empty())
	{
		int i = R.top();
		R.pop();
		switch(i)
		{
			case 1:cout<<"FILL(1)"<<endl;break;
			case 2:cout<<"FILL(2)"<<endl;break;
			case 3:cout<<"DROP(1)"<<endl;break;
			case 4:cout<<"DROP(2)"<<endl;break;
			case 5:cout<<"POUR(1,2)"<<endl;break;
			case 6:cout<<"POUR(2,1)"<<endl;break;
		}
	}
}
int main()
{
	cin >>a>>b>>e;
	BFS(0,0);
	if(ans == 0)
		cout<<"impossible"<<endl;
	else
	{
		cout<<ans<<endl;
		print();
	}
	return 0;
}