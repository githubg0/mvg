// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int direct[4][2]={
  {-1,0},{1,0},{0,-1},{0,1}
};
void bfs(int i,int j,int index);
void dfs(int index,int time,int total_value);
bool accessable(int x,int y);
char point[55][55];
int shortest_path[15][15];
bool visited[55][55];
int dfs_times[15];
int T;
int W,H,L,M;
int jewels[15];
int max_value=-1;
int sum_value=0;
int main(){
  scanf("%d",&T);
  int _case=1;
  for(_case=1;_case<=T;_case++){
    scanf("%d%d%d%d",&W,&H,&L,&M);
    sum_value=0;
    for(int i=0;i<M;i++) {
      scanf("%d",&jewels[i+1]);
      sum_value+=jewels[i+1];
    }
    for(int i=0;i<H;i++){
      getchar();
      for(int j=0;j<W;j++){
        scanf("%c",&point[i][j]);
      }
    }
    jewels[0]=jewels[M+1]=0;
    
    for(int i=0;i<=M+1;i++){
      for(int j=0;j<=M+1;j++){
        shortest_path[i][j]=-1;
      }
    }
    for(int i=0;i<H;i++){
      for(int j=0;j<W;j++){
        if(point[i][j]=='@'){
          
          bfs(i,j,0);
        }else if(point[i][j]>='A'&&point[i][j]<='J'){
          bfs(i,j,point[i][j]-'A'+1);
        }
      }
    }
    
    for(int i=0;i<=M+1;i++) dfs_times[i]=0;
    max_value=-1;
    dfs(0,0,0);
    printf("Case %d:\n",_case);
    if(max_value!=-1)
      printf("The best score is %d.\n",max_value);
    else
      printf("Impossible\n");
    if(_case!=T) printf("\n");
  }
}
void bfs(int x,int y,int index){
  
  
  deque<int> q;
  int step[55][55];
  for(int i=0;i<H;i++){
    for(int j=0;j<W;j++){
      visited[i][j]=false;
    }
  }
  q.clear();
  q.push_back(x*W+y);
  step[x][y]=0;
  visited[x][y]=true;
  shortest_path[index][index]=0;
  while(!q.empty()){
    int p=q.front();
    int current_x=p/W;
    int current_y=p%W;
    
    q.pop_front();
    for(int i=0;i<4;i++){
      int next_x=current_x+direct[i][0],next_y=current_y+direct[i][1];
      if(accessable(next_x,next_y)){
        
        visited[next_x][next_y]=true;
        step[next_x][next_y]=step[current_x][current_y]+1;
        if(point[next_x][next_y]=='<') shortest_path[index][M+1]=step[next_x][next_y];
        else if(point[next_x][next_y]>='A'&& point[next_x][next_y]<='J'){
          int target=point[next_x][next_y]-'A'+1;
          shortest_path[index][target]=step[next_x][next_y];
        }
        else if(point[next_x][next_y]=='@')
            shortest_path[index][0]=step[next_x][next_y];
        int _next=next_x*W+next_y;
        q.push_back(_next);
      }else
        continue;
    }
  }
}
void dfs(int index,int time,int total_value){
    
    if(max_value==sum_value) {
      return;
    }
    if(time>L) return;
    dfs_times[index]++;
    if(index==M+1){
        
        if(total_value>max_value) max_value=total_value;
        dfs_times[index]--;
        return;
    }
    
    for(int i=0;i<=M+1;i++){
        if(i==index) continue;
        else{
          if(dfs_times[i]==0 && shortest_path[index][i]>0){
            dfs(i,time+shortest_path[index][i],total_value+jewels[i]);
            if(max_value==sum_value) {
              return;
            }
          }
        }
    }
    dfs_times[index]--;
    return;
}
bool accessable(int x,int y){
  if( x<0 || x>=H || y<0 || y>=W || visited[x][y] || point[x][y]=='*' ){
    return false;
  }
  else
    return true;
}