// Basic Algorithm->Recursion,Basic Algorithm->Memorization,Basic Algorithm->Prune and Search,Basic Algorithm->Depth First Search (DFS)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 1e9
int n,m,dp[205][205],ex,ey,ans;
char ma[205][205];
bool vis[205][205];
const int dx[4]={0,0,1,-1};
const int dy[4]={1,-1,0,0};
void dfs(int x,int y)
{
	if(dp[x][y]>=dp[ex][ey]) return;
	for(int i=0;i<4;++i)
	{
		int xx=x+dx[i];
		int yy=y+dy[i];
		if(ma[xx][yy]=='#'||vis[xx][yy]) continue;
		if(ma[xx][yy]=='x')
		{
			if(dp[xx][yy]==-1||dp[xx][yy]>dp[x][y]+2)
				dp[xx][yy]=dp[x][y]+2;
			else continue;
		}
		else if(ma[xx][yy]=='a')
		{
			if(dp[xx][yy]==-1||dp[xx][yy]>dp[x][y]+1)
				dp[xx][yy]=dp[x][y]+1;
			return;
		}
		else if(ma[xx][yy]=='.')
		{
			if(dp[xx][yy]==-1||dp[xx][yy]>dp[x][y]+1)
				dp[xx][yy]=dp[x][y]+1;
			else continue;
		}
		vis[xx][yy]=true;
		dfs(xx,yy);
		vis[xx][yy]=false;
	}
}
int main()
{
	ios::sync_with_stdio(false);
	int sx,sy;
	while(cin>>n>>m)
	{
		memset(ma,'#',sizeof(ma));
		memset(vis,0,sizeof(vis));
		ex=ey=-1;
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
			{
				dp[i][j]=-1;
				cin>>ma[i][j];
				if(ma[i][j]=='r')
				{
					sx=i;
					sy=j;
				}
				if(ma[i][j]=='a')
				{
					ex=i;
					ey=j;
					dp[i][j]=INF;
				}
			}
		if(ex==-01&&ey==-1)
		{
			cout<<"Poor ANGEL has to stay in the prison all his life."<<endl;
			continue;
		}
		dp[sx][sy]=0;
		dfs(sx,sy);
		if(dp[ex][ey]!=INF)
			cout<<dp[ex][ey]<<endl;
		else
			cout<<"Poor ANGEL has to stay in the prison all his life."<<endl;
	}
	
	return 0;
}