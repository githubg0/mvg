// Basic Algorithm->Ternary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define UP(i,l,h) for(int i=l;i<h;i++)
#define DOWN(i,h,l) for(int i=h-1;i>=l;i--)
#define W(a) while(a)
#define INF 0x3f3f3f3f
#define LL long long
#define MAXN 1010
#define EPS 1e-10
#define PI acos(double(-1))
using namespace std;
double s;
double getv(double r){
        double l=s/PI/r-r;
        double h=sqrt(l*l-r*r);
        double v=PI*r*r*h/3;
        return v;
}
double gethigh(double r){
    double l=s/PI/r-r;
    double h=sqrt(l*l-r*r);
    return h;
}
int main()
{
    W(~scanf("%lf",&s)){
        double low=0,high=sqrt(s/2/PI);
        W(high-low>EPS){
            double mid=(low+high)/2;
            double mmid=(mid+high)/2;
            if(getv(mid)>getv(mmid)){
                high=mmid;
            }else{
                low=mid;
            }
        }
        printf("%.2f\n",getv(low));
        printf("%.2f\n",gethigh(low));
        printf("%.2f\n",low);
    }
    return 0;
}