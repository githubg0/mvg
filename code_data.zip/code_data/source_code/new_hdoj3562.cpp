// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Depth First Search (DFS)
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define Del(a,b) memset(a,b,sizeof(a))
const int N = 10200;
const int inf = 0x3f3f3f3f;
int n,m;
struct Node
{
    int from,to,cap,flow;
};
vector<int> v[N];
vector<Node> e;
int vis[N];  
int cur[N];
void add_Node(int from,int to,int cap)
{
    e.push_back((Node)
    {
        from,to,cap,0
    });
    e.push_back((Node)
    {
        to,from,0,0
    });
    int tmp=e.size();
    v[from].push_back(tmp-2);
    v[to].push_back(tmp-1);
}
bool bfs(int s,int t)
{
    Del(vis,-1);
    queue<int> q;
    q.push(s);
    vis[s] = 0;
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        for(int i=0; i<v[x].size(); i++)
        {
            Node tmp = e[v[x][i]];
            if(vis[tmp.to]<0 && tmp.cap>tmp.flow)  
            {
                vis[tmp.to]=vis[x]+1;
                q.push(tmp.to);
            }
        }
    }
    if(vis[t]>0)
        return true;
    return false;
}
int dfs(int o,int f,int t)
{
    if(o==t || f==0)  
        return f;
    int a = 0,ans=0;
    for(int &i=cur[o]; i<v[o].size(); i++) 
    {
        Node &tmp = e[v[o][i]];
        if(vis[tmp.to]==(vis[o]+1) && (a = dfs(tmp.to,min(f,tmp.cap-tmp.flow),t))>0)
        {
            tmp.flow+=a;
            e[v[o][i]^1].flow-=a; 
            ans+=a;
            f-=a;
            if(f==0)  
                break;
        }
    }
    return ans;  
}
int dinci(int s,int t)
{
    int ans=0;
    while(bfs(s,t))
    {
        Del(cur,0);
        int tm=dfs(s,inf,t);
        ans+=tm;
    }
    return ans;
}
int solve(int i,int j)
{
    int ans=1;
    if(i>1)
        ans*=2;
    if(j>1)
        ans*=2;
    if(i<n)
        ans*=2;
    if(j<m)
        ans*=2;
    return ans;
}
int id(int i,int j)
{
    return (i-1)*m+j;
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d",&n,&m);
        int s=0,t=m*n+1,x,sum=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                x=solve(i,j);
                sum+=x;
                if((i+j)%2)
                {
                    add_Node(s,id(i,j),x);
                    if(i>1)
                        add_Node(id(i,j),id(i-1,j),inf);
                    if(j>1)
                        add_Node(id(i,j),id(i,j-1),inf);
                    if(i<n)
                        add_Node(id(i,j),id(i+1,j),inf);
                    if(j<m)
                        add_Node(id(i,j),id(i,j+1),inf);
                }
                else
                    add_Node(id(i,j),t,x);
            }
        }
        printf("%d\n",sum-dinci(s,t));
        for(int i=0;i<=t;i++)
            v[i].clear();
        e.clear();
    }
    return 0;
}