// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define clr(a,v) memset(a,v,sizeof a)
#define rep(i,s,t) for(int i=s;i<t;i++)
const int MAXN=1010;
int maptt1[MAXN][MAXN],cnt[MAXN];
int vis[MAXN],x[MAXN],y[MAXN];
int a[MAXN],b[MAXN];
int c[MAXN],d[MAXN];
int n,m;
inline bool ok(int a,int b,int c,int d){
	return (a==c&&b==d);
} 
inline bool Cover(int i,int j){
	int x_1=a[i],y_1=b[i];
	int x_2=a[i]+1,y_2=b[i];
	int x_3=c[j],y_3=d[j];
	int x_4=c[j],y_4=d[j]+1;
	if(ok(x_1,y_1,x_3,y_3) || ok(x_1,y_1,x_4,y_4)) return 1;
	if(ok(x_2,y_2,x_3,y_3) || ok(x_2,y_2,x_4,y_4)) return 1;
	return 0;
}
inline bool dfs(int now){
	rep(i,0,cnt[now]){
		int v=maptt1[now][i];
		if(!vis[v]){
			vis[v]=1;
			if(y[v]==-1 || dfs(y[v])){
				x[now]=v;
				y[v]=now;
				return 1;
			}
		}
	}
	return 0;
}
 
inline int match(){
	clr(x,-1);clr(y,-1);
	int ans=0;
	rep(i,0,n){
		clr(vis,0);
		if(dfs(i)) ans++;
	}
	return ans;
}
int main(){
	while(cin>>n>>m){
		if(n==0 && m==0) break;
		rep(i,0,n) cin>>a[i]>>b[i];
		rep(i,0,m) cin>>c[i]>>d[i];
		clr(cnt,0);
		rep(i,0,n){
			rep(j,0,m){
				if(Cover(i,j)){
					maptt1[i][cnt[i]++]=j;
				}
			}
		}
		cout<<n+m-match()<<endl;
	}
	return 0;
}