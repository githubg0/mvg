// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;   
const int MAX=205;  
const int INF=2100000000;  
bool vis[MAX];
int dis[MAX],n,tmp,ans=-1;
struct edge{
    int to;
    int w;
    edge(int a=0,int b=0):to(a),w(b) {}
};
vector<edge>E[MAX];
void add(int from,int to,int w){
    E[from].push_back(edge(to,w));
}
void spfa(){
    queue<int> q;
    q.push(1);
    vis[1]=true;
    int from,to;
    while(!q.empty()){
        from=q.front();
        q.pop();
        vis[from]=false;
        for(int i=0;i<E[from].size();i++){
            to=E[from][i].to;           if(dis[to]>dis[from]+E[from][i].w){
                dis[to]=dis[from]+E[from][i].w;
                if(!vis[to]){
                    vis[to]=true;
                    q.push(to);
                }
            }
        }
    }
}
int main(){  
    freopen("i.txt","r",stdin);
    cin>>n;
    for(int i=2;i<=n;i++)dis[i]=INF,vis[i]=false;
    char str[50];
    int power[10]={1,10,100,1000,10000,100000,1000000,10000000,100000000,1000000000},len;
    for(int i=2;i<=n;i++){
        for(int j=1;j<i;j++){
            scanf("%s",str);
            tmp=0,len=0;
            if(str[0]!='x') {
                len=strlen(str);
                for(int k=len-1;k>=0;k--)tmp+=power[len-1-k]*(str[k]-'0');
                add(i,j,tmp);
                add(j,i,tmp);
           }
        }
    }
    spfa();
    for(int i=2;i<=n;i++) ans=ans>dis[i]?ans:dis[i];
    cout<<ans<<endl;
    return 0;  
}