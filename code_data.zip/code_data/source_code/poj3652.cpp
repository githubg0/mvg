// Basic Algorithm->Recursion,Basic Algorithm->Breadth First Search (BFS),Data Structure->Link List,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
	int dis;
	int v;
};
bool flag[10005];
vector<node>maptt1[10005];
int maxx;
int bfs(int s)
{
	int i,id;
	node k1,k2;
	queue<node>q;
	k1.v=s;
	k1.dis=0;
	q.push(k1);
	flag[s]=true;
	while(!q.empty())
	{
		k2=q.front();
		q.pop();
		for(i=0;i<maptt1[k2.v].size();i++)
		{
			k1=maptt1[k2.v][i];
			if(!flag[k1.v])
			{
				flag[k1.v]=true;
				k1.dis=k2.dis+maptt1[k2.v][i].dis;
				if(k1.dis>maxx)
				{
					maxx=k1.dis;
					id=k1.v;
				}
				q.push(k1);
			}
		}
	}
	return id;
}
int main()
{
	int a,b,l,k;
	node p;
	while(scanf("%d%d%d",&a,&b,&l)!=EOF)
	{
		p.v=b;
		p.dis=l;
		maptt1[a].push_back(p);
		p.v=a;
		maptt1[b].push_back(p);
	}
	memset(flag,0,sizeof(flag));
	maxx=0;
	k=bfs(1);
	memset(flag,0,sizeof(flag));
	maxx=0;
	k=bfs(k);
	printf("%d/n",maxx);
	return 0;
}