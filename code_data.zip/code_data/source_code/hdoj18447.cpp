// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define L(x) (x<<1)
#define R(x) (x<<1|1)
#define MID(x,y) ((x+y)>>1)
#define eps 1e-8
typedef __int64_t ll;
const int mod=1e9+7;
using namespace std;
#define N 100007
int a[N],n;
int dpmin[N][25],dpmax[N][25];
int k;
inline bool judge(int le,int ri)
{
    int kk=log2((ri-le+1)*1.0);
    int mi=min(dpmin[le][kk],dpmin[ri-(1<<kk)+1][kk]);
    int ma=max(dpmax[le][kk],dpmax[ri-(1<<kk)+1][kk]);
    return ma-mi<k;
}
int main()
{
    int i,j,t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&k);
        for(i=1;i<=n;i++)
            scanf("%d",&a[i]);
        for(i=1;i<=n;i++)
            dpmin[i][0]=dpmax[i][0]=a[i];
        for(j=1;(1<<j)<=n;j++)
            for(i=1;i+(1<<j)-1<=n;i++)
            {
                int p=1<<(j-1);
                dpmin[i][j]=min(dpmin[i][j-1],dpmin[i+p][j-1]);
                dpmax[i][j]=max(dpmax[i][j-1],dpmax[i+p][j-1]);
            }
         __int64_t ans=0;
         int le,ri,p;
         for(i=1;i<=n;i++)
         {
             le=i;
             ri=n;
             while(le<=ri)
             {
                 int mid=(le+ri)>>1;
                 if(judge(i,mid))
                 {
                     p=mid;
                     le=mid+1;
                 }
                 else
                    ri=mid-1;
             }
             ans+=p-i+1;
         }
         printf("%I64d\n",ans);
    }
    return 0;
}