// Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int D[100001];
int binarysearch(int low,int high,int m)
{
	int mid;
	mid=(low+high)/2;
	while(low<=high)
	{
		if(D[mid]<m&&D[mid+1]>=m)
			return mid;
		else
			if(D[mid]<m)
				low=mid+1;
			else
				high=mid-1;
		mid=(low+high)/2;
	} 
	return mid;
}   
int main()
{
	int a[100001];
	int n,i,j,k,len;
	while(cin>>n)
	{
		for(i=1;i<=n;++i)
			cin>>a[i];
		D[1]=a[1];
		len=1;
		for(i=2;i<=n;i++)
		{
			if(a[i]>D[len])
			{
				len++;
				D[len]=a[i];
			}
			else
			{
				j=binarysearch(1,len,a[i]);
				k=j+1;
				D[k]=a[i];
			} 
		}  
	cout<<len<<endl;  
}
	return 0;
}