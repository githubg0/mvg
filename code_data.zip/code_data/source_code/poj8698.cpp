// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char a[1005][1005];
int fx[8]={-1,1,0,0,1,-1,1,-1};
int fy[8]={0,0,1,-1,1,-1,-1,1};
int maxnx;
int maxny;
int minnx;
int minny;
int n,m;
int Dfs(int x,int y)
{
    maxnx=max(maxnx,x);
    maxny=max(maxny,y);
    a[x][y]='.';
    int sum=1;
    for(int i=0;i<8;i++)
    {
        int yy=y+fy[i];
        int xx=x+fx[i];
        if(xx>=0&&xx<n&&yy>=0&&yy<m&&a[xx][yy]=='#')
        {
            sum+=Dfs(xx,yy);
        }
    }
    return sum;
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        if(n==0&&m==0)break;
        for(int i=0;i<n;i++)
        {
            scanf("%s",a[i]);
        }
        int ans=0;
        int flag=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(a[i][j]=='#')
                {
                    maxnx=i;maxny=j;
                    minnx=i;minny=j;
                    int sum=Dfs(i,j);
                    if(sum==(maxnx-minnx+1)*(maxny-minny+1))
                    ans++;
                    else
                    {
                        flag=1;break;
                    }
                }
            }
            if(flag==1)break;
        }
        if(flag==1)printf("Bad placement.\n");
        else printf("There are %d ships.\n",ans);
    }
}