// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 9999999
#define M 1007
#define MIN(a,b) a>b?b:a;
using namespace std;
int cow[M][21],cap[21],s,t,nn;
struct E
{
    int v,w,next;
}edg[500000];
int dis[2000],gap[2000],head[2000],nodes;
int sourse,sink,n,m;
void addedge(int u,int v,int w)
{
    edg[nodes].v=v;
    edg[nodes].w=w;
    edg[nodes].next=head[u];
    head[u]=nodes++;
    edg[nodes].v=u;
    edg[nodes].w=0;
    edg[nodes].next=head[v];
    head[v]=nodes++;
}
int dfs(int src,int aug)
{
    if(src==sink)return aug;
    int left=aug,mindis=nn;
    for(int j=head[src];j!=-1;j=edg[j].next)
    {
        int v=edg[j].v;
        if(edg[j].w)
        {
           if(dis[v]+1==dis[src])
           {
               int minn=MIN(left,edg[j].w);
               minn=dfs(v,minn);
               edg[j].w-=minn;
               edg[j^1].w+=minn;
               left-=minn;
               if(dis[sourse]>=nn)return aug-left;
               if(left==0)break;
           }
           if(dis[v]<mindis)
           mindis=dis[v];
        }
    }
        if(left==aug)
        {
            if(!(--gap[dis[src]]))dis[sourse]=nn;
            dis[src]=mindis+1;
            gap[dis[src]]++;
        }
        return aug-left;
}
int sap(int s,int e)
{
    int ans=0;
    nn=e+1;
    memset(dis,0,sizeof(dis));
    memset(gap,0,sizeof(gap));
    gap[0]=nn;
    sourse=s;
    sink=e;
    while(dis[sourse]<nn)
    ans+=dfs(sourse,inf);
    return ans;
}
bool build(int mid)
{
    for(int start=1;start<=m-mid+1;start++)
    {
        nodes=0;
        s=0,t=n+m+1;
        memset(head,-1,sizeof(head));
        for(int i=1;i<=n;i++)
        {
            addedge(s,i,1);
            for(int j=start;j<=start+mid-1;j++)
                addedge(i,n+cow[i][j],1);
        }
        for(int i=1;i<=m;i++)addedge(n+i,t,cap[i]);
        if(sap(s,t)==n)return true;
    }
    return false;
}
int solve()
{
    int l=1,r=m,mid,ans=-1;
    while(l<=r)
    {
        mid=(l+r)>>1;
        if(build(mid)){ans=mid;r=mid-1;}
        else l=mid+1;
    }
    return ans;
}
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                scanf("%d",&cow[i][j]);
        for(int i=1;i<=m;i++)
            scanf("%d",&cap[i]);
        int ans=solve();
        printf("%d\n",ans);
    }
    return 0;
}