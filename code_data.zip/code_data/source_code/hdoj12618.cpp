// Data Structure->Stack,Basic Algorithm->Recursion,Graph Algorithm->Strongly Connected Components,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 100001;
vector <int> e[N], scce[N];
int dfn[N], low[N];
int stacktt1[N], stop;     
bool instack[N];
int timer, sccn;        
int belong[N];
bool vis[N];
int dp[N];              
int w[N];               
int n, m;
void InitRead();
void DataProcess();
void Tarjan(int x);
void Dfs(int x);
int main()
{
    while (~scanf("%d %d", &n, &m))
    {
        InitRead();
        DataProcess();
    }
    return 0;
}
void InitRead()
{
    stop = timer = sccn = 0;
    memset(dfn, 0, sizeof(dfn));
    memset(instack, false, sizeof(instack));
    memset(dp, 0, sizeof(dp));
    memset(vis, false, sizeof(vis));
    for (int i=1; i<=n; ++i)
    {
        e[i].clear();
        scce[i].clear();
    }
    int a, b;
    for (int i=0; i<m; ++i)
    {
        scanf("%d %d", &a, &b);
        e[a].push_back(b);
    }
    return;
}
void DataProcess()
{
    for (int i=1; i<=n; ++i)
    {
        if (!dfn[i]) Tarjan(i);
    }
    for (int i=1; i<=n; ++i)    
    {
        int size = e[i].size();
        for (int j=0; j<size; ++j)
        {
            if (belong[i] != belong[e[i][j]])
            {
                scce[belong[i]].push_back(belong[e[i][j]]);
            }
        }
    }
    int ans = 0;
    for (int i=1; i<=sccn; ++i)
    {
        if (!vis[i])
        {
            Dfs(i);
            ans = max(ans, dp[i]);
        }
    }
    printf("%d\n", ans);
    return;
}
void Tarjan(int x)
{
    int y;
    dfn[x] = low[x] = ++timer;
    stacktt1[stop++] = x;
    instack[x] = true;
    int size = e[x].size();
    for (int i=0; i<size; ++i)
    {
        y = e[x][i];
        if (!dfn[y])
        {
            Tarjan(y);
            low[x] = min(low[x], low[y]);
        }
        else if (instack[y])
        {
            low[x] = min(low[x], dfn[y]);
        }
    }
    if (dfn[x] == low[x])
    {
        sccn++;
        int temp = 0;
        do
        {
            y = stacktt1[--stop];
            instack[y] = false;
            belong[y] = sccn;
            temp++;
        } while (x != y);
        w[sccn] = temp;
    }
    return;
}
void Dfs(int x)
{
    int size = scce[x].size();
    if (0 == size) dp[x] = w[x];
    for (int i=0; i<size; ++i)
    {
        if (!vis[scce[x][i]])
        {
            Dfs(scce[x][i]);
        }
        dp[x] = max(dp[x], dp[scce[x][i]] + w[x]);
    }
    vis[x] = true;
    return;
}