// Basic Algorithm->Iteration
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

char* Reverse(char s[])
{
    int i = 0, j = strlen(s) - 1;
    char temp;
    while(i < strlen(s) / 2)
    {
        temp = s[i];
        s[i] = s[j];
        s[j] = temp;
        i++;
        j--;
    }
    return s;
}
char* Add(char a[], char b[])
{
    int i, j;
    char* sum = new char[1001];
    
    Reverse(a);
    Reverse(b);
    
    sum[0] = '0';
    for(i = 0; i < strlen(a) && i < strlen(b); i++)
    {
        sum[i + 1] = '0';
        sum[i + 2] = 0;
        sum[i] += (a[i] - '0') + (b[i] - '0');
        if(sum[i] > '9')
        {
            sum[i] -= 10;
            sum[i + 1] ++;
        }
    }
    
    if(strlen(a) > strlen(b))
    {
        for(i = strlen(b); i < strlen(a); i++)
        {
            sum[i + 1] = '0';
            sum[i + 2] = 0;
            sum[i] += (a[i] - '0');
            if(sum[i] > '9')
            {
                sum[i] -= 10;
                sum[i + 1] ++;
            }
        }
    }
    
    else if(strlen(b) > strlen(a))
    {
        for(i = strlen(a); i < strlen(b); i++)
        {
            sum[i + 1] = '0';
            sum[i + 2] = 0;
            sum[i] += (b[i] - '0');
            if(sum[i] > '9')
            {
                sum[i] -= 10;
                sum[i + 1] ++;
            }
        }
    }
    
    Reverse(sum);
    
    
    Reverse(a);
    Reverse(b);
    
    
    while(*sum == '0')
    {
        sum += 1;
    }
    return sum;
}