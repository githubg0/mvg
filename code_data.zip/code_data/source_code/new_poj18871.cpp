// Data Structure->Hashing
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int snow[6];
    int pos;
};
int head[99991];
node hashtable[100000+10];
int cnt=0;
int main()
{
    int n,i,j,a[6],k,t;
    while (scanf("%d",&n)==1)
    {
        bool flag=true;
        for (i=0;i<99991;i++)
            head[i]=-1;
        for (i=0; i<n; i++)
        {
            hashtable[i].pos=-1;
        }
        for (i=0; i<n; i++)
        {
            scanf("%d%d%d%d%d%d",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5]);
            if (flag)
            {
                sort(a,a+6);
                k=(a[0]+a[1]+a[2]+a[3]+a[4]+a[5])%99991;
                for (t=head[k]; t!=-1; t=hashtable[t].pos)
                {
                    if (hashtable[t].snow[0]==a[0])
                    {
                        if (hashtable[t].snow[1]==a[1])
                        {
                            if (hashtable[t].snow[2]==a[2])
                            {
                                if (hashtable[t].snow[3]==a[3])
                                {
                                    if (hashtable[t].snow[4]==a[4])
                                    {
                                        if (hashtable[t].snow[5]==a[5])
                                        {
                                            flag=false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                for (j=0; j<6; j++)
                {
                    hashtable[cnt].snow[j]=a[j];
                }
                hashtable[cnt].pos=head[k];
                head[k]=cnt;
                cnt++;
            }
        }
        if (flag)
            printf("No two snowflakes are alike.\n");
        else
            printf("Twin snowflakes found.\n");
    }
    return 0;
}