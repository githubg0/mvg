// Basic Algorithm->Prune and Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char str[5][5];
int X,Y,chess;
bool check(int x,int y){
    int tot=0;
    
    for(int i=0;i<4;i++)
        if(str[x][i]=='o') tot++;
        else if(str[x][i]=='x') tot--;
    if(tot==4||tot==-4) return true;
    tot=0;
    
    for(int i=0;i<4;i++)
        if(str[i][y]=='o') tot++;
        else if(str[i][y]=='x') tot--;
    if(tot==4||tot==-4) return true;
    tot=0;
    
    for(int i=0;i<4;i++)
        if(str[i][i]=='o') tot++;
        else if(str[i][i]=='x') tot--;
    if(tot==4||tot==-4) return true;
    tot=0;
    
    for(int i=0;i<4;i++)
        if(str[i][3-i]=='o') tot++;
        else if(str[i][3-i]=='x') tot--;
    if(tot==4||tot==-4) return true;
    return false;
}
int MinSearch(int x,int y);
int MaxSearch(int x,int y);
int MaxSearch(int x,int y){
    
    if(check(x,y)) return -1;
    
    if(chess==16) return 0;
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++)
            if(str[i][j]=='.'){
                str[i][j]='x';chess++;
                int tmp=MinSearch(i,j);
                str[i][j]='.';chess--;
                
                if(tmp == 1) return 1;
            }
    return -1;
}
int MinSearch(int x,int y){
    
    if(check(x,y)) return 1;
    
    if(chess==16) return 0;
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++)
            if(str[i][j]=='.'){
                str[i][j]='o';chess++;
                int tmp=MaxSearch(i,j);
                str[i][j]='.';chess--;
                
                if(tmp == -1 || tmp == 0) return -1;
            }
    return 1;
}
bool slove(){
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++)
            
            if(str[i][j]=='.'){
                str[i][j]='x';chess++;
                int tmp = MinSearch(i,j);
                str[i][j]='.';chess--;
                if(tmp == 1){
                    X=i;
                    Y=j;
                    return true;
                }
            }
    return false;
}
int main(){
    char ch[5];
    while(scanf("%s",ch)!=EOF&&ch[0]!='$'){
        chess=0;
        for(int i=0;i<4;i++){
            scanf("%s",str[i]);
            for(int j=0;j<4;j++)
                chess+=str[i][j]!='.';
        }
        
        if(chess<=4){
            printf("#####\n");
            continue;
        }
        if(slove()) printf("(%d,%d)\n",X,Y);
        else printf("#####\n");
    }
    return 0;
}