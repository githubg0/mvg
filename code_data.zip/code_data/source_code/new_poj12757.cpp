// Data Structure->Stack,Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Iteration,Graph Algorithm->Lowest Common Ancestor (LCA),Basic Algorithm->Recursion
#include<algorithm>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct Node{
    int v,next;
}Edge[400010];
int ed,head[200010];
int pre[100010],low[100010],isb[100010],f[100010];
int step;
int n,m,bridge;
void init(){
    bridge=ed=step=0;
    for(int i=1;i<=n;i++){
       isb[i]=head[i]=low[i]=pre[i]=0;
    }
}
void add(int x,int y){
    ed++;
    Edge[ed].v=y; Edge[ed].next=head[x]; head[x]=ed;
}
void dfs(int u,int fa){          
    pre[u]=low[u]=++step;
    for(int i=head[u];i;i=Edge[i].next){
        int v=Edge[i].v;
        if(!pre[v]){
            f[v]=u;
            dfs(v,u);
            low[u]=min(low[v],low[u]);
            if(low[v]>pre[u]){
                bridge++;
                isb[v]=1;
            }
        }
        else if(pre[v]<pre[u] && v!=fa){
            low[u]=min(pre[v],low[u]);
        }
    }
}
void lca(int u,int v){                 
    while(pre[u]>pre[v]){
        if(isb[u]){
            isb[u]=0;
            bridge--;
        }
        u=f[u];
    }
    while(pre[v]>pre[u]){
        if(isb[v]){
            isb[v]=0;
            bridge--;
        }
        v=f[v];
    }
    while(u!=v){
        if(isb[u]){
            isb[u]=0;
            bridge--;
        }
        if(isb[v]){
            isb[v]=0;
            bridge--;
        }
        u=f[u];
        v=f[v];
    }
}
int main(){
    int cas=1;
    while(scanf("%d%d",&n,&m)!=EOF){
        if(n==0 && m==0)
            break;
        init();
        while(m--){
            int x,y;
            scanf("%d%d",&x,&y);
            add(x,y);
            add(y,x);
        }
        for(int i=1;i<=n;i++){
            if(!pre[i]){
                dfs(i,-1);
            }
        }
        scanf("%d",&m);
        printf("Case %d:\n",cas++);
        while(m--){
            int x,y;
            scanf("%d%d",&x,&y);
            lca(x,y);
            printf("%d\n",bridge);
        }
        printf("\n");
    }
    return 0;
}