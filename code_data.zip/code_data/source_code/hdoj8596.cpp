// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1002;
int root[maxn],f[maxn];
int i,j,k,n,m,tot;
int Find(int x){
    int i = x,k;
    int r = x;
    while (r!=root[r]) r = root[r];
    while (root[i]!=r) {
        k = root[i];
        root[i] = r;
        i = k;
    }
    return r;
}
void join(int x , int y){
   int fx = Find(x), fy = Find(y);
   if (fx != fy) root[fx] = fy;
}
void init(){
    for (i=1; i<=n; i++) root[i] = i;
    cin >> m;
    for (j=1; j<=m; j++) {
        cin >> i >> k;
        join(i,k);
    }
}
int main(){
    std::ios::sync_with_stdio(false);
    while (cin >> n && n){
        init();
        tot = 0;
        for (i=1; i<=n; i++) f[i] = 0;
        for (i=1; i<=n; i++) f[Find(i)] = 1;
        for (i=1; i<=n; i++) if (f[i]) tot ++;
        cout << tot-1 << endl;
    }
    return 0;
}