// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int maptt1[305][305],vis[305][305];
int enx,eny,size,bex,bey;
int dx[]={1,1,-1,-1,2,2,-2,-2};
int dy[]={2,-2,2,-2,1,-1,1,-1};
void bfs()
{
  int vx,vy,tx,ty,i;
  queue<int> q;
  memset(maptt1,0,sizeof(maptt1));
  memset(vis,0,sizeof(vis));
  vis[bex][bey]=1;
  q.push(bex);
  q.push(bey);
  while(!q.empty())
  {
    vx=q.front();q.pop();
    vy=q.front();q.pop();
    if(vx==enx&&vy==eny) break;
    for(i=0;i<8;i++)
    {
      tx=vx+dx[i];ty=vy+dy[i];
      if(!vis[tx][ty]&&
         tx<size&&tx>=0&&ty>=0&&ty<size)
      {
        vis[tx][ty]=1;
        q.push(tx);q.push(ty);
        maptt1[tx][ty]=maptt1[vx][vy]+1;
      }
    }
  }
}
int main()
{
  int n;
  scanf("%d",&n);
  while(n--)
  {
    scanf("%d",&size);
    scanf("%d%d%d%d",&bex,&bey,&enx,&eny);
    bfs();
    printf("%d\n",maptt1[enx][eny]);
  }
  return 0;
}