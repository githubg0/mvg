// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 3000001
#define MAX(a,b) a>b?a:b
#define LL long long
#define fab(a) ((a)>0?(a):-(a))
using namespace std;
int num[MAXN];
int v[MAXN],a[MAXN];
int n,bz,k;
void dfs(int k)
{
	if(bz)
	return;
	if(k==4)
	{
		if((a[1]-a[2])==a[3])
		{
			bz=1;
			return;
		}
		return;
	}
	for(int i=0;i<n;i++)
	{
		if(!v[i])
		{
			a[k]=num[i];
			v[i]=1;
			dfs(k+1);
			if(bz)
			return;
			v[i]=0;
		}
	}
}
int main()
{
	while(scanf("%d",&n)!=EOF)
	{
		for(int i=0;i<n;i++)
		scanf("%d",&num[i]);
		memset(v,0,sizeof(v));
		bz=0;
		dfs(1);
		if(bz)
		printf("YES\n");
		else
		printf("NO\n");
	}
	return 0;
}