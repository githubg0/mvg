// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define max(a,b) ((a>b)?(a):(b))
using namespace std;
const int Max=101;
int MAX,Num;
int a[Max][Max],d[Max][Max];
int N,M,K;
int exam(int x,int y){
	int X[2]={-1,1};
	int Y[2]={-1,1};
		for(int j=0;j<2;j++){
		   if(d[x][y+Y[j]]==0&&a[x][y+Y[j]]==1){
   			d[x][y+Y[j]]=1;
	        Num++;
   			exam(x,y+Y[j]);
   		}
     }
   		for(int j=0;j<2;j++){
		   if(d[x+X[j]][y]==0&&a[x+X[j]][y]==1){
   			d[x+X[j]][y]=1;
   		    Num++;
   			exam(x+X[j],y);
   		}
    }
    return 0;
}
int main(){
	int b[Max],c[Max];
	while(scanf("%d%d%d",&N,&M,&K)!=EOF){
		memset(a,0,sizeof(a));
		memset(d,0,sizeof(d));
		MAX=0;
		for(int i=0;i<K;i++){
			int m,n;
			scanf("%d%d",&m,&n);
			b[i]=m-1;c[i]=n-1;
			a[m-1][n-1]=1;
		}
		for(int j=0;j<K;j++){
			Num=1;
			d[b[j]][c[j]]=1;
			exam(b[j],c[j]);
	        MAX=max(MAX,Num);
			memset(d,0,sizeof(d));
		}
		printf("%d\n",MAX);
	}
	return 0;
}