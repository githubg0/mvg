// Data Structure->Segment Tree,Basic Algorithm->Discretization,Basic Algorithm->Recurrence,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define Max 16000
int dp[Max];
int num[Max][Max/100];
int number[Max];
int point[Max][Max/100];
int n;
int main(){
	scanf("%d",&n);
	memset(dp,0,sizeof(dp));
	bool trag=true;
	int pivot=1,index=1,i,j,k,a,b;
	scanf("%d%d",&a,&b);
	point[1][1]=a;
	num[1][1]=0;
    dp[0]++;
	int yy=b;
    for(i=1;i<n;i++){
		scanf("%d%d",&a,&b);
	    if(b==yy && trag){
			point[pivot][++index]=a;
			num[pivot][index]=num[pivot][index-1]+1;
			dp[num[pivot][index]]++;
		}
		else if(b>yy){
			yy=b;
			number[pivot]=index;
			pivot++;
			index=1;
			point[pivot][index]=a;
			num[pivot][index]=0;
			int Sum=0;
			for(j=1;j<pivot;j++)
				for(k=number[j];k>=1;k--)
					if(point[j][k]<=a){
						Sum+=(num[j][k]+1);
						break;
					}
			dp[Sum]++;
			trag=false;
		}
		else if(!trag && b==yy){
			point[pivot][++index]=a;
			num[pivot][index]=num[pivot][index-1]+1;
			int Sum=num[pivot][index];
			for(j=1;j<pivot;j++)
				for(k=number[j];k>=1;k--)
					if(point[j][k]<=a){
						Sum+=(num[j][k]+1);
						break;
					}
			dp[Sum]++;
		}
	}
	for(i=0;i<n;i++)
		printf("%d\n",dp[i]);
    return 0;
}