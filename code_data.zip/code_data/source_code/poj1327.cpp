// Data Structure->Stack,Data Structure->Queue,Graph Algorithm->Bellman-Ford Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
#define MAXN 23
#define memset0(a) memset(a,0,sizeof(a))
int N, FIRE;
struct It
{
    int base, dis[MAXN], edge[MAXN];
    bool operator<(It &b)const
    {
        return dis[FIRE] < b.dis[FIRE];
    }
}its[MAXN];
int graph[MAXN][MAXN];
queue<int>q;
stack<int>stk;
bool inq[MAXN];
void fun()
{
    for (int p = 1; p <= N; p++)
        for (int i = 1; i <= N; i++) {
            int a;
            scanf("%d", &a);
            graph[p][i] = a != -1 ? a : INF;
        }
    scanf("%d", &FIRE);
    int cnt = 0;
    for (; ~scanf("%d", &its[cnt].base); cnt++) {
        for (int i = 1; i <= N; i++)
            its[cnt].dis[i] = INF;
        its[cnt].dis[its[cnt].base] = 0;
        q.push(its[cnt].base);
        while (!q.empty()) {
            int a = q.front();
            q.pop();
            inq[a] = 0;
            for (int p = 1; p <= N; p++)
                if (its[cnt].dis[p] > its[cnt].dis[a] + graph[a][p]) {
                    its[cnt].dis[p] = its[cnt].dis[a] + graph[a][p];
                    its[cnt].edge[p] = a;
                    if (!inq[p]) {
                        q.push(p);
                        inq[p] = 1;
                    }
                }
        }
    }
    sort(its, its + cnt);
    for (int p = 0; p < cnt; p++) {
        printf("%d\t%d\t%d\t", its[p].base, FIRE, its[p].dis[FIRE]);
        int pos = FIRE;
        while (pos != its[p].base) {
            stk.push(its[p].edge[pos]);
            pos = its[p].edge[pos];
        }
        while (!stk.empty()) {
            printf("%d\t", stk.top());
            stk.pop();
        }
        printf("%d\n", FIRE);
    }
}
int main(void)
{
    
    
    scanf("%d", &N);
    printf("Org\tDest\tTime\tPath\n");
    fun();
}