// Data Structure->Segment Tree,Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 100005
#define inf 0x3f3f3f3f
typedef long long LL;
int sum[maxn<<2],col[maxn<<2],ll[maxn<<2],rr[maxn<<2];
inline void pushup(int i){
    sum[i]=sum[i<<1]|sum[i<<1|1];
}
inline void pushdown(int i){
    if(col[i]){
        col[i<<1]=col[i<<1|1]=col[i];
        sum[i<<1]=col[i];
        sum[i<<1|1]=col[i];
        col[i]=0;
    }
}
void build(int l,int r,int i){
    ll[i]=l;
    rr[i]=r;
    col[i]=1;
    if(l==r)return;
    int m=(ll[i]+rr[i])>>1,ls=i<<1,rs=ls|1;
    build(l,m,ls);
    build(m+1,r,rs);
    pushup(i);
}
void update(int l,int r,int v,int i){
    if(l<=ll[i]&&rr[i]<=r){
        col[i]=1<<(v-1);
        sum[i]=col[i];
        return ;
    }
    pushdown(i);
    int m=(ll[i]+rr[i])>>1,ls=i<<1,rs=ls|1;
    if(l<=m)update(l,r,v,ls);
    if(m<r)update(l,r,v,rs);
    pushup(i);
}
int query(int l,int r,int i){
    if(l<=ll[i]&&rr[i]<=r){
        return sum[i];
    }
    pushdown(i);
    int m=(ll[i]+rr[i])>>1,ls=i<<1,rs=ls|1;
    int ans=0;
    if(l<=m)ans=ans|query(l,r,ls);
    if(m<r)ans=ans|query(l,r,rs);
    return ans;
}
int main()
{
    int l,t,o,a,b,c;
    char q[2];
    
    while(~scanf("%d%d%d",&l,&t,&o)){
        build(1,l,1);
        for(int i=0;i<o;i++){
            scanf("%s%d%d",q,&a,&b);
            if(a>b)swap(a,b);
            if(q[0]=='C'){
                scanf("%d",&c);
                update(a,b,c,1);
            }
            else {
                int res=query(a,b,1);
                int ans=0;
                while(res){
                    if(res&1)ans++;
                    res=res>>1;
                }
                printf("%d\n",ans);
            }
        }
    }
}