// Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int zhi;
    int whe;
};
int n;
int cmp(node a,node b)
{
    return a.zhi<b.zhi;
}
int c[500050];
node a[500050];
int lowbit(int x)
{
    return x&(-x);
}
long long  sum(int x)
{
    long long sum=0;
    for(int i=x;i>=1;i-=lowbit(i))
    {
        sum+=c[i];
    }
    return sum;
}
void add(int x)
{
    for(int i=x;i<=n;i+=lowbit(i))
    {
        c[i]+=1;
    }
}
int cmpp(node a,node b)
{
    return a.whe<b.whe;
}
int main(){
while(~scanf("%d",&n))
{
    if(n==0)
        break;
    memset(c,0,sizeof(c));
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i].zhi);
        a[i].whe=i;
    }
    sort(a+1,a+1+n,cmp);
    for(int i=1;i<=n;i++)
    {
        a[i].zhi=i;
    }
    sort(a+1,a+1+n,cmpp);
    long long ans=0;
    for(int i=n;i>=1;i--)
    {
        long long summ=sum(a[i].zhi);
        add(a[i].zhi);
        ans+=summ;
    }
    printf("%I64d\n",ans);
}
}