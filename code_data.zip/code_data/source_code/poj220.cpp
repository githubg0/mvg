// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define NUM 101
struct Node
{
	int id;
	int pos[4];
	int neighbor[4][2];
	int used;
};
int nodeNum;
int max1[4];
int min1[4];
struct Node node[NUM];
int FindIndex(int);
void dfs(int);
int IsSymmetric();
int IsOneComponent();
int ComputeVolum();
int main()
{
	int testNum;
	int i,j;
	int isOneComponent;
	int isSymmetric;
	
	scanf("%d", &testNum);
	while(testNum--)
	{
		
		scanf("%d", &nodeNum);
		memset(node,0,sizeof(struct Node)*NUM);
		memset(max1,0,sizeof(max1));
		memset(min1,0,sizeof(min1));
		for(i=0; i<nodeNum; i++)
		{
			scanf("%d", &node[i].id);
			for(j=0; j<4; j++)
			{
				scanf("%d %d", &node[i].neighbor[j][0], &node[i].neighbor[j][1]);
				node[i].pos[j] = 0;
			}
			node[i].used = 0;
		}
		dfs(0);
		isSymmetric = IsSymmetric();
		isOneComponent = IsOneComponent();
		if(isSymmetric==0 || isOneComponent==0)
			printf("Inconsistent\n");
		else
			printf("%d\n", ComputeVolum());
	}	
	return 0;
}
int FindIndex(int id)
{
	int i;
	for(i=0; i<nodeNum; i++)
	{
		if(node[i].id==id)
			return i;
	}
	return 0;
}
void dfs(int k)
{
	int next;
	int i,j,s;
	if(node[k].used==1)
		return;
	node[k].used = 1;
	for(i=0; i<4; i++)
	{
		for(j=0; j<2; j++)
		{
			if(node[k].neighbor[i][j])
			{
				next = FindIndex(node[k].neighbor[i][j]);
				if(node[next].used == 1)
					continue;
				for(s=0; s<4; s++)
				{
					node[next].pos[s] = node[k].pos[s];
				}
				if(j==0)
				{
					node[next].pos[i]++;
					if(node[next].pos[i] > max1[i])
						max1[i] = node[next].pos[i];
				}
				else
				{
					node[next].pos[i]--;
					if(node[next].pos[i] < min1[i])
						min1[i] = node[next].pos[i];
				}
				dfs(next);
			}
		}
	}
}
int IsSymmetric()
{
	int next;
	int i,j,k;
	for(i=0; i<nodeNum; i++)
	{
		for(j=0; j<4; j++)
		{
			for(k=0; k<2; k++)
			{
				if(node[i].neighbor[j][k])
				{
					next = FindIndex(node[i].neighbor[j][k]);
					if((k==0&&node[next].neighbor[j][1]!=node[i].id)||(k==1&&node[next].neighbor[j][0]!=node[i].id))
						return 0;
				}
			}
		}
	}
	return 1;
}
int IsOneComponent()
{
	int i;
	for(i=0; i<nodeNum;i++)
	{
		if(node[i].used == 0)
			return 0;
	}
	return 1;
}
int ComputeVolum()
{
	int volum=1;
	int i;
	for(i=0; i<4; i++)
	{
		volum *= (max1[i]-min1[i]+1);
	}
	return volum;
}