// Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int T;
const int maxn=3010;
int N;
int A[maxn];
int B[maxn];
int X;
int K;
int C;
int mat[maxn][maxn];
int newmat[maxn][maxn];
long long ans;
void solve()
{
    deque<int>que;
    for(int i=1;i<=N;i++)
    {
        while(!que.empty()) que.pop_back();
        for(int j=1;j<=K;j++)
        {
            while(!que.empty()&&mat[i][que.front()]<mat[i][j]) que.pop_front();
            que.push_front(j);
        }
        newmat[i][K]=mat[i][que.back()];
        for(int j=K+1;j<=N;j++)
        {
            while(!que.empty()&&mat[i][que.front()]<mat[i][j]) que.pop_front();
            while(!que.empty()&&j-que.back()+1>K) que.pop_back();
            que.push_front(j);
            newmat[i][j]=mat[i][que.back()];
        }
    }
    for(int j=K;j<=N;j++)
    {
        while(!que.empty()) que.pop_back();
        for(int i=1;i<=K;i++)
        {
            while(!que.empty()&&newmat[que.front()][j]<newmat[i][j]) que.pop_front();
            que.push_front(i);
        }
        ans+=newmat[que.back()][j];
        for(int i=K+1;i<=N;i++)
        {
            while(!que.empty()&&newmat[que.front()][j]<newmat[i][j]) que.pop_front();
            while(!que.empty()&&i-que.back()+1>K) que.pop_back();
            que.push_front(i);
            ans+=newmat[que.back()][j];
        }
    }
}
int main()
{
    freopen("D-large-practice.in","r",stdin);
    freopen("output.txt","w",stdout);
    scanf("%d",&T);
    for(int ca=1;ca<=T;ca++)
    {
        memset(A,0,sizeof(A));
        memset(B,0,sizeof(B));
        memset(mat,0,sizeof(mat));
        memset(newmat,0,sizeof(newmat));
        ans=0;
        scanf("%d %d %d %d",&N,&K,&C,&X);
        for(int i=1;i<=N;i++)
        {
            scanf("%d",&A[i]);
        }
        for(int i=1;i<=N;i++)
        {
            scanf("%d",&B[i]);
        }
        for(int i=1;i<=N;i++)
        {
            for(int j=1;j<=N;j++)
            {
                mat[i][j]=(A[i]%X)*(i%X)+(B[j]%X)*(j%X)+C%X;
                mat[i][j]%=X;
            }
        }
        solve();
        printf("Case #%d: %lld\n",ca,ans);
    }
    return 0;
}