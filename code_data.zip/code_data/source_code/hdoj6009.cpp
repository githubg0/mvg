// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxlen = 70;
bool hanoi(int n , int start[],int end1[],int zhongjian[]){
	if(zhongjian[0] == n){
		return 0;
	}else if(start[0] == n){
		return hanoi(n-1,start+1,zhongjian,end1);
	}else if(end1[0] == n){
		return hanoi(n-1,zhongjian,end1+1,start);
	}
	return 1;
}
int main(){
	int t,a[maxlen],b[maxlen],c[maxlen];
	scanf("%d",&t);
	while(t--){
		int n,m,p,q;
		scanf("%d",&n);
		int i;
		scanf("%d",&m);
		for(i = 0 ; i < m ; ++i){
			scanf("%d",&a[i]);
		}
		scanf("%d",&p);
		for(i = 0 ; i < p ; ++i){
			scanf("%d",&b[i]);
		}
		scanf("%d",&q);
		for(i = 0 ; i < q ; ++i){
			scanf("%d",&c[i]);
		}
		a[m]=b[p]=c[q] = -1;
		if(hanoi(n,a,c,b)){
			cout<<"true"<<endl;
		}else{
			cout<<"false"<<endl;
		}
	}
}