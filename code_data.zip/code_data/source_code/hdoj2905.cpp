// Basic Algorithm->Arbitrary-Precision Arithmetic
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double PI = 3.141592653589793;
struct point
{
    double x, y;
}p[5];
double dis(point a , point b)
{
     return sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));
}
point Interesection(point u1,point u2,point v1,point v2)
{
         point ans = u1;
    double t = ((u1.x - v1.x) * (v1.y - v2.y) - (u1.y - v1.y) * (v1.x - v2.x)) /
               ((u1.x - u2.x) * (v1.y - v2.y) - (u1.y - u2.y) * (v1.x - v2.x));
    ans.x += (u2.x - u1.x) * t;
    ans.y += (u2.y - u1.y) * t;
    return ans;    
}
point Circum(point a , point b , point c)
{
     point ua,ub,va,vb;           
    ua.x = ( a.x + b.x ) / 2;
    ua.y = ( a.y + b.y ) / 2;
    ub.x = ua.x - a.y + b.y;
    ub.y = ua.y + a.x - b.x;
    va.x = ( a.x + c.x ) / 2;
    va.y = ( a.y + c.y ) / 2;
    vb.x = va.x - a.y + c.y;
    vb.y = va.y + a.x - c.x;
      return Interesection(ua,ub,va,vb);
}
int main()
{
    while (scanf("%lf%lf%lf%lf%lf%lf", &p[0].x, &p[0].y, &p[1].x, &p[1].y, &p[2].x, &p[2].y) != EOF){
        point o = Circum(p[0], p[1], p[2]);
        double r = dis(p[0], o);
        printf("%.2lf\n", 2 * PI * r);
    }
    return 0;
}