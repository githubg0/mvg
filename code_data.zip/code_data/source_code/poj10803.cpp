// Basic Algorithm->Iteration
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    double x,y,z;
};
ostream& operator << (ostream& ot,node x)
{
    ot<<'('<<x.x<<','<<x.y<<','<<x.z<<')';
    return ot;
}
double sqr(double x,double y)
{
    return (x-y)*(x-y);
}
double dis(node a,node b)
{
    return sqrt(sqr(a.x,b.x)+sqr(a.y,b.y)+sqr(a.z,b.z));
}
int n;
const int maxn=110;
node rec[maxn];
inline double ac(int tms,node ans,double rxo,double step) 
{
    double s=dis(ans,rec[0]);
    while(tms--)
    {
        int maxi=0;
        s=dis(ans,rec[0]);
        for(int i=1;i<n;i++)
        {
            double tem=dis(ans,rec[i]);
            if(tem>s)
            {
                s=tem;
                maxi=i;
            }
        }
        ans.x+=rxo*(rec[maxi].x-ans.x);
        ans.y+=rxo*(rec[maxi].y-ans.y);
        ans.z+=rxo*(rec[maxi].z-ans.z);
        rxo*=step;
    }
    return s;
}
int main()
{
    ios::sync_with_stdio(0);
    while(cin>>n&&n)
    {
        node pp;
        pp.x=0;
        pp.y=0;
        pp.z=0;
        for(int i=0;i<n;i++)
        {
            cin>>rec[i].x>>rec[i].y>>rec[i].z;
            pp.x+=rec[i].y;
            pp.y+=rec[i].y;
            pp.z+=rec[i].z;
        }
        pp.x/=n;
        pp.y/=n;
        pp.z/=n;
        double res=ac(30000,pp,0.5,0.9803125);
        cout<<fixed<<setprecision(5)<<res<<'\n';
    }
    return  0;
}