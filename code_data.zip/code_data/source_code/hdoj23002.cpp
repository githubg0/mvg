// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 100010
using namespace std;
int n;
int d[MAXN];
int st[MAXN*2];
int p[MAXN*2];
int len;
void manacher()
{
    int MaxId=0,id;
    for(int i=0; i<len; i++)
    {
        if(MaxId>i)
            p[i]=min(p[2*id-i],MaxId-i);
        else
            p[i]=1;
        while(st[i+p[i]]==st[i-p[i]])
            p[i]++;
        if(p[i]+i>MaxId)
        {
            id=i;
            MaxId=p[i]+i;
        }
    }
}
int main()
{
    int T;
    scanf("%d",&T);
    for(int t=1; t<=T; t++)
    {
        scanf("%d",&n);
        for(int i = 0; i <= 2*n+1; i++)
            p[i] =0;
        len = 0;
        st[len++]= -2;
        st[len++]= -1;
        for(int i=1; i<=n; ++i)
        {
            scanf("%d",&st[len++]);
            st[len++] = -1;
        }
        st[len] = 0;
        manacher();
        int maxans=1;
        for(int i = 3; i < len; i+=2)
            for(int j = maxans; j <= p[i]; j+=2)
            {
                if(p[j+i-1] >= j)
                    maxans = j;
            }
            printf("Case #%d: %d\n",t,(maxans)/2*3);
    }
    return 0;
}