// Sorting->Merge Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct Node{
    long long num;
    int index;
}a[500010];
int b[500010];
int n;
int cmp(Node t1,Node t2){
    if(t1.num==t2.num)
        return t1.index>t2.index;
    return t1.num>t2.num;
}
int lowbit(int x){
    return x&-x;
}
int sum(int x){
    int s=0;
    while(x){
        s+=b[x];
        x-=lowbit(x);
    }
    return s;
}
void add(int x){
    while(x<=n){
        b[x]++;
        x+=lowbit(x);
    }
}
int main(){
    while(cin>>n,n){
        long long result=0;
        for(int i=1;i<=n;i++){
            cin>>a[i].num;
            a[i].index=i;
        }
        sort(a+1,a+1+n,cmp);
        memset(b,0,sizeof(b));
        for(int i=1;i<=n;i++){
            add(a[i].index);
            result+=sum(a[i].index);
        }
        cout<<result-n<<endl;
    }
    return 0;
}