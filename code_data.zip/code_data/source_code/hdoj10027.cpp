// Basic Algorithm->Recurrence,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1200;
char table[15][maxn][maxn];
void draw(int id,int x,int y,int n){
    for(int i = x;i < x + (n>>2)+1;i++){
        for(int j = y;j < y + (n>>2);j++){
            if(i == x || i == x+(n>>2))
                table[id][i][j] = '*';
            else{
                if(j == y || j == y + (n>>2)-1)
                    table[id][i][j] = '*';
                else
                    table[id][i][j] = ' ';
            }
        }
    }
}
void draw1(int id,int x,int y,int n){
    for(int i = x;i < x+n;i++){
        for(int j = y;j < y+n;j++){
            if(i == x || i == x+n-1)
                table[id][i][j] = '*';
            else{
                if(j == y || j == y+n-1)
                    table[id][i][j] = '*';
                else
                    table[id][i][j] = ' ';
            }
        }
    }
    
}
void draw2(int id,int n){
    draw1(id,0,0,n);
    draw(id,n>>3,n>>3,n);
    draw(id,n>>3,(n>>3)*5, n);
    if(n != 8){
        for(int i = n;i >= n>>1;i--){
            for(int j = n>>2;j < (n>>2)*3;j++){
                table[id][i][j] = table[id-1][n-i-1][j-(n>>2)];
            }
        }
    }
}
int main(){
    int n;
    draw2(3, 8);
    draw1(3,4,2,4);
    for(int i = 4;i < 11;i++)
        draw2(i, 1<<i);
    while(~scanf("%d",&n)){
        if(n<8)break;
        int id = log2(n);
        for(int i = 0;i < n;i++){
            for(int j = 0;j < n;j++){
                printf("%c",table[id][i][j]);
            }
            printf("\n");
        }
        printf("\n");
    }
    return 0;
}