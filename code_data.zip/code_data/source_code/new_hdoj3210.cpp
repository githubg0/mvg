// Graph Algorithm->Prim's Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 65535
int a[105][105];
int v[105];  
int lowcost[105];  
int adj[105];      
int N;
void init(int N)
{
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N;j++)
        {
            if(i==j)
            {
                a[i][j]=0;
            }
            else
            {
                a[i][j]=INF;
            }
        }
    }
}
int prim()
{
    int i,j,mi;
    int ans=0;
    v[1]=1;      
    for(i=2;i<=N;i++)
    {
        lowcost[i]=a[1][i];
        adj[i]=1;       
    }
    int cnt=N-1;
    while(cnt--)
    {
        mi=INF;
        j=1;
        for(i=1;i<=N;i++)
        {
            if(!v[i]&&lowcost[i]<mi)  
            {
                mi=lowcost[i];
                j=i;
            }
        }
        ans+=a[j][adj[j]];   
        v[j]=1;        
        for(i=1;i<=N;i++)
        {
            if(!v[i]&&a[i][j]<lowcost[i])    
            {
                lowcost[i]=a[i][j];
                adj[i]=j;
            }
        }
    }
    return ans;
}
int main()
{
    int s,e,p,vi;
    while(scanf("%d",&N)!=EOF&&N)
    {
        init(N);       
        memset(v,0,sizeof(v));
        int num = N*(N-1)/2;
        for(int i=0;i<num;i++)
        {
            scanf("%d%d%d%d",&s,&e,&p,&vi);
            if(vi==1)
                a[e][s] = a[s][e] = 0;   
           else
                a[e][s] = a[s][e] = p;
        }
        int sum = prim();
        printf("%d\n",sum);
    }
    return 0;
}