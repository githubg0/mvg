// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 1e9
using namespace std;
const int maxnz = 10005;
int d[maxnz],max_d[maxnz];
int nz,nr,mz,id,mr;
vector<int> mp[maxnz];
void init()
{
    memset(max_d,0,sizeof(max_d));
    for(int i = 0;i < maxnz;i++)
        mp[i].clear();
}
queue<int> que;
void bfs(int s)
{
    memset(d,0,sizeof(d));
    while(que.size()) que.pop();
    d[s] = 1;
    que.push(s);
    while(que.size()){
        int u = que.front();
        que.pop();
        for(int i = 0;i < (int)mp[u].size();i++){
            int v = mp[u][i];
            if(!d[v]){
                d[v] = d[u] + 1;
                que.push(v);
            }
        }
    }
    for(int i = 1;i <= maxnz;i++){
        if(!d[i]) max_d[i] = INF;
        else      max_d[i] = max(max_d[i],d[i]);
    }
}
int main(void)
{
    int t;
    cin >> t;
    while(t--){
        init();
        cin >> nz >> nr;
        for(int i = 0;i < nz;i++){
            cin >> id >> mz;
            int temp;
            while(mz--){
                cin >> temp;
                mp[id].push_back(temp);
            }
        }
        for(int i = 0;i < nr;i++){
            cin >> mr;
            for(int j = 0;j < mr;j++){
                cin >> id;
                bfs(id);
            }
        }
        int dis = INF,ver;
        for(int i = 1;i < maxnz;i++){
            if(max_d[i] < dis){
                dis = max_d[i];
                ver = i;
            }
        }
        cout << dis << ' ' << ver << endl;
    }
    return 0;
}