// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int N = 21;
ll sum[N] = {1};
ll S[N][N];
void init()
{
  
    for(int i = 1; i <= N; i++)
    {
        sum[i] = sum[i-1]*i;
    }
    for(int i = 1; i <= N; i++)
    {
        S[i][0] = 0;
        S[i][i] = 1;
        for(int j = 1; j < i; j++)
        {
            S[i][j] = (i-1)*S[i-1][j]+S[i-1][j-1];
        }
    }
}
int main()
{
   
    int t, n, k;
    ll ans;
    init();
    scanf("%d", &t);
    while(t--)
    {
        scanf("%d%d", &n, &k);
        init();
        ans = 0;
        for(int i = 1; i <= k; i++)
        {
            ans+=(S[n][i] - S[n-1][i-1]);
        }
        printf("%.4lf\n", (double)ans/sum[n]);
    }
    return 0;
}