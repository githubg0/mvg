// Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int mod = 1000000007;
ll phi[1000005];
bool isprime[1000005];
int prime[1000005];
int tot,n;
void calc()
{
    phi[1]=0;
    for(int i=2;i<=1000000;i++)
    {
        if(!isprime[i]) 
        {
            prime[++tot]=i,phi[i]=i-1;
        }
        for(int j=1;prime[j]*i<=1000000;j++)
        {
            
            isprime[i*prime[j]]=1;
            if(i%prime[j]==0){
                phi[i*prime[j]]=phi[i]*prime[j];
                break;
            }
            else phi[i*prime[j]]=phi[i]*(prime[j]-1);
        }
    }
}
int cal(int x)
{
    int ans=x;
    for(int i=1;prime[i]*prime[i]<=x;i++)
    {
        
        if(x%prime[i]==0)
        {
            ans=ans/prime[i]*(prime[i]-1);
            while(x%prime[i]==0) x/=prime[i];
        }
    }
    if(x>1) ans=ans/x*(x-1);
    return ans;
}
int main()
{
    calc();
    
    while(scanf("%d",&n)!=EOF)
    {
        ll res=1;
        int dt;
        for(int i=1;i<=n;i++){
            scanf("%d",&dt);
            res=res*cal(dt);
            if(res>=mod) res%=mod;
        }
        printf("%d\n",(int) res);
    }
    return 0;
}