// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
#define INF 0x3f3f3f3f
#define eps 1e-5
#define pi acos(-1.0)
typedef long long ll;
const int maxn=100010;
const int maxm=400010;
struct Edge{
    int to,next,cap,flow;
    Edge(){};
    Edge(int _next,int _to,int _cap,int _flow){
        next=_next;to=_to;cap=_cap;flow=_flow;
    }
}edge[maxm];
int head[maxn],tol,gap[maxn],dep[maxn],cur[maxn];
void addedge(int u,int v,int flow){
    edge[tol]=Edge(head[u],v,flow,0);head[u]=tol++;
    edge[tol]=Edge(head[v],u,0,0);head[v]=tol++;
}
int Q[maxn];
void bfs(int start,int end1){
    memset(dep,-1,sizeof(dep));
    memset(gap,0,sizeof(gap));
    gap[0]++;int front=0,rear=0;
    dep[end1]=0;Q[rear++]=end1;
    while(front!=rear){
        int u=Q[front++];
        for(int i=head[u];i!=-1;i=edge[i].next){
            int v=edge[i].to;if(dep[v]==-1&&edge[i].cap)
                Q[rear++]=v,dep[v]=dep[u]+1,gap[dep[v]]++;
        }
    }
}
int S[maxn];
int sap(int start,int end1,int N){
    bfs(start,end1);
    memcpy(cur,head,sizeof(head));
    int top=0,u=start,ans=0;
    while(dep[start]<N){
        if(u==end1){
            int MIN=INF,id;
            for(int i=0;i<top;i++)
                if(MIN>edge[S[i]].cap-edge[S[i]].flow)
                    MIN=edge[S[i]].cap-edge[S[i]].flow,id=i;
            for(int i=0;i<top;i++)
                edge[S[i]].flow+=MIN,edge[S[i]^1].flow-=MIN;
            ans+=MIN,top=id,u=edge[S[top]^1].to;
            continue;
        }
        bool flag=0;int v;
        for(int i=cur[u];i!=-1;i=edge[i].next){
            v=edge[i].to;
            if(edge[i].cap-edge[i].flow&&dep[v]+1==dep[u]){
                flag=1;cur[u]=i;break;
            }
        }
        if(flag){
            S[top++]=cur[u];u=v;continue;
        }
        int MIN=N;
        for(int i=head[u];i!=-1;i=edge[i].next)
            if(edge[i].cap-edge[i].flow&&dep[edge[i].to]<MIN)
                MIN=dep[edge[i].to],cur[u]=i;
        if(--gap[dep[u]]==0)break;gap[dep[u]=MIN+1]++;
        if(u!=start)u=edge[S[--top]^1].to;
    }
    return ans;
}
int mark[maxn];
void dfs(int u){
	mark[u]=1;
	for(int i=head[u];i!=-1;i=edge[i].next){
		int v=edge[i].to;
		if(!mark[v]&&edge[i].cap-edge[i].flow)dfs(v);
	}
}
int main(){
	int i,j,k,m,n;
	while(~scanf("%d%d",&n,&m)){
		memset(head,-1,sizeof(head));tol=0;
		for( i=1;i<=n;i++){
			scanf("%d",&j);
			addedge(i+n,2*n+1,j);
		}
		for( i=1;i<=n;i++){
			scanf("%d",&j);
			addedge(0,i,j);
		}
		while(m--){
			scanf("%d%d",&i,&j);
			addedge(i,j+n,INF);
		}
		int cnt=sap(0,2*n+1,10*n);
		cout<<cnt<<endl;
		memset(mark,0,sizeof(mark));
		dfs(0);
		int ret=0;
		for( i=1;i<=n;i++){
			if(mark[i]==0)ret++;
			if(mark[i+n])ret++;
		}
		cout<<ret<<endl;
		for(i=1;i<=n;i++){
			if(mark[i]==0)cout<<i<<" -"<<endl;
			if(mark[i+n])cout<<i<<" +"<<endl;
		}
	}
}