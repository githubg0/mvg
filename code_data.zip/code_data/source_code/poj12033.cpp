// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

  
  
  
  
  
  
  
  
  
  
  
  
const int maxn=205;
int T;
char s1[maxn],s2[maxn],c[maxn*2];
int len1,len2,len;
bool f[maxn][maxn];
int main()  
{  
    scanf("%d",&T);
    int t=1;
    while(T--)
    {
        printf("Data set %d: ",t++);
        scanf("%s%s%s",s1+1,s2+1,c+1); 
        len1=strlen(s1+1);
        len2=strlen(s2+1);
        len=strlen(c+1);
        memset(f,0,sizeof f);
        for(int i=1;i<=len1;i++)
        {
            if(s1[i]==c[i])
            {
                f[i][0]=1;
            }
            else break;
        }
        for(int i=1;i<=len2;i++)
        {
            if(s2[i]==c[i])
            {
                f[0][i]=1;
            }
            else break;
        }
        for(int i=1;i<=len1;i++)
        {
            for(int j=1;j<=len2;j++)
            {
                if(s1[i]==c[i+j]&&f[i-1][j])
                {
                    f[i][j]=1;
                }
                if(s2[j]==c[i+j]&&f[i][j-1])
                {
                    f[i][j]=1;
                }
            }
        }
        if(f[len1][len2])
        printf("yes\n");
        else printf("no\n");
    }
    return 0;
}