// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX_N = 10 * 10 + 5;   
const int CLD_NUM = 4;           
typedef long long MATRIX[MAX_N][MAX_N];
MATRIX mat, mat1, mat2;
long long (*m1)[MAX_N], (*m2)[MAX_N];
class ACAutomaton
{
public:
    int  n;                          
    int  id['Z'+1];                  
    int  fail[MAX_N];                
    bool tag[MAX_N];                 
    int  trie[MAX_N][CLD_NUM];       
    void init()
    {
        id['A'] = 0;
        id['T'] = 1;
        id['C'] = 2;
        id['G'] = 3;
    }
    void reset()
    {
        memset(trie[0], -1, sizeof(trie[0]));
        tag[0] = false;
        n = 1;
    }
    
    void add(char *s)
    {
        int p = 0;
        while (*s)
        {
            int i = id[*s];
            if ( -1 == trie[p][i] )
            {
                memset(trie[n], -1, sizeof(trie[n]));
                tag[n] = false;
                trie[p][i] = n++;
            }
            p = trie[p][i];
            s++;
        }
        tag[p] = true;
    }
    
    void construct()
    {
        queue<int> Q;
        fail[0] = 0;
        for (int i = 0; i < CLD_NUM; i++)
        {
            if (-1 != trie[0][i])
            {
                fail[trie[0][i]] = 0;
                Q.push(trie[0][i]);
            }
            else
            {
                trie[0][i] = 0;    
            }
        }
        while ( !Q.empty() )
        {
            int u = Q.front();
            Q.pop();
            if (tag[fail[u]])
                tag[u] = true;         
            for (int i = 0; i < CLD_NUM; i++)
            {
                int &v = trie[u][i];
                if ( -1 != v )
                {
                    Q.push(v);
                    fail[v] = trie[fail[u]][i];
                }
                else
                {
                    v = trie[fail[u]][i];
                }
            }
        }
    }
    
    void buildMatrix()
    {
        memset(mat, 0, sizeof(mat));
        for (int i = 0; i < n; i++)
            for (int j = 0; j < CLD_NUM; j++)
                if ( !tag[i] && !tag[trie[i][j]] )  
                    mat[i][trie[i][j]]++;
    }
} AC;
void matrixMult(MATRIX t1, MATRIX t2, MATRIX res)
{
    for (int i = 0; i < AC.n; i++)
        for (int j = 0; j < AC.n; j++)
        {
            res[i][j] = 0;
            for (int k = 0; k < AC.n; k++)
            {
                res[i][j] += t1[i][k] * t2[k][j];
            }
            res[i][j] %= 100000;
        }
}
void matrixPower(int p)
{
    if (p == 1)
    {
        for (int i = 0; i < AC.n; i++)
            for (int j = 0; j < AC.n; j++)
                m2[i][j] = mat[i][j];
        return;
    }
    matrixPower(p/2);          
    matrixMult(m2, m2, m1);    
    if (p % 2)                 
        matrixMult(m1, mat, m2);
    else
        swap(m1, m2);
}
int main()
{
    int  n, m;
    char s[12];
    AC.init();
    cin >> m >> n;
    AC.reset();
    while ( m-- )
    {
        scanf("%s", s);
        AC.add(s);
    }
    AC.construct();
    AC.buildMatrix();
    m1 = mat1;
    m2 = mat2;
    matrixPower(n);
    int ans = 0;
    for (int i = 0; i < AC.n; i++)
        ans += m2[0][i];
    printf("%d\n", ans % 100000);
    return 0;
}