// Math and Computational Geometry->Inclusion–Exclusion Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ms(a,b) memset(a,b,sizeof(a))
using namespace std;
typedef long long LL;
const int maxn=5e4;
struct tnode{
    int x,y;
}p[maxn+5];
int a[maxn+5],b[maxn+5];
int lmin[maxn+5],rmin[maxn+5];
int s1[maxn+5],s2[maxn+5];
bool cmp(tnode aa,tnode bb)
{
	return aa.x<bb.x;
}
int query(int q[],int x)
{
	int ans=0;
	while(x>0)
    {
    	ans+=q[x];
    	x-=(x&(-x));
    }
	return ans;
}
void add(int q[],int x,int k)
{
	for(;x<=maxn;x+=(x&(-x)))b[x]+=k;
}
int main()
{
	int n,i,j,k;LL ans,sum1,sum2;
	while(~scanf("%d",&n))
    {
	    for(i=1;i<=n;i++)scanf("%d",&p[i].x),p[i].y=i;
	    if(n<4)
        {
	        printf("0\n");
	        continue;
        }
	    sort(p+1,p+1+n,cmp);
	    k = a[p[1].y] = 1;
	    for(i=2; i<=n; i++)
	        if(p[i].x == p[i-1].x) a[p[i].y] = k;
	        else a[p[i].y] = (++k);
	    for(ms(s1,0),i=1; i<=n; i++) s1[a[i]]++;
	    for(ms(b,0),i=1; i<=n; i++)
	        lmin[i] = query(b,a[i]-1),add(b,a[i],1);
	    for(ms(b,0),i=n; i>=1; i--)
	        rmin[i] = query(b,a[i]-1),add(b,a[i],1);
	    sum1 = sum2 = 0;
	    for(i=1; i<=n; i++) sum1 += lmin[i],sum2 += rmin[i];
	    ans = sum1*sum2;
    	for(ms(s2,0),i=1;i<=n;i++)
        {
	        ans -= lmin[i]*rmin[i];
	        ans -= (i-1-lmin[i]-s2[a[i]])*(n-i-rmin[i]-(s1[a[i]]-s2[a[i]]-1));
	        ans -= rmin[i]*(n-i-rmin[i]-(s1[a[i]]-s2[a[i]]-1));
	        ans -= lmin[i]*(i-1-lmin[i]-s2[a[i]]);
	        s2[a[i]]++;
        }
    	printf("%I64d\n",ans);
    }
	return 0;
}