// Data Structure->Link List,Data Structure->Trie
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int T,n,k;
struct pa{
    char s[15];
    int len;
};
bool cmp(pa a,pa b){
    return a.len>b.len;
}
struct trie{
    trie *next[15];
};
trie *root;
trie all_trie[1000000];
bool built(char *s,int len) {
    bool ok = true;
    trie *p = root, *q;
    for(int i=0;i<len;i++){
        int id = s[i]-'0';
        if(p->next[id]==NULL) {
            ok = false;
            q = &all_trie[k++];
            for(int j=0;j<10;j++) q->next[j] = NULL;
            p->next[id] = q;
            p = p->next[id];
        }
        else {
            p = p->next[id];
        }
    }
    return ok;
}
int main(){
    scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        pa s[10005];
        k = 0;
        bool ok = true;
        root = &all_trie[k++];
        for(int i=0;i<10;i++) root->next[i] = NULL;
        for(int i=0;i<n;i++){
            scanf("%s",s[i].s);
            s[i].len = strlen(s[i].s);
        } sort(s,s+n,cmp);
        for(int i=0;i<n;i++)
            if(built(s[i].s,s[i].len)) {
                ok = false; break;
            }
        if(ok) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}