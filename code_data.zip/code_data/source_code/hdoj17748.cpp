// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define lson (rt<<1),L,M
#define rson (rt<<1|1),M+1,R
#define M ((L+R)>>1)
#define cl(a,b) memset(a,b,sizeof(a));
#define LL long long
#define P pair<int,int>
#define X first
#define Y second
#define pb push_back
#define fread(zcc)  freopen(zcc,"r",stdin)
#define fwrite(zcc) freopen(zcc,"w",stdout)
using namespace std;
const int maxn=505;
const int inf=1<<28;
int d[maxn];
vector<int> G[maxn];
vector<int> ans;
bool topo(int n){
    priority_queue<int,vector<int>,greater<int> > q;
    for(int i=0;i<n;i++){
        if(d[i]==0)q.push(i);
    }
    int cnt=0;
    while(!q.empty()){
        int t=q.top();q.pop();
        ans.pb(t);
        cnt++;
        for(int i=0;i<G[t].size();i++){
            int v=G[t][i];
            if(--d[v]==0)q.push(v);
        }
    }
    return cnt==n;
}
int main(){
    int n,m;
    while(~scanf("%d%d",&n,&m)){
        for(int i=0;i<=n;i++){
            G[i].clear();
            d[i]=0;
        }
        for(int i=0;i<m;i++){
            int x,y;
            scanf("%d%d",&x,&y);
            x--;y--;
            G[x].pb(y);
            d[y]++;
        }
        ans.clear();
        topo(n);
        int N=ans.size();
        printf("%d",ans[0]+1);
        for(int i=1;i<N;i++){
            printf(" %d",ans[i]+1);
        }
        puts("");
    }
    return 0;
}