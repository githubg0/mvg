// Dynamic Programming->Priority Queue,Graph Algorithm->Dijkstra's Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 100 + 2;
int head[maxn],vis[maxn],k = 1,n,r,cost;
struct edge
{
    int v,w,next,len;
}e[maxn * maxn];
struct node
{
    int now,dis,co;
    bool operator < (const node &a) const
    {
        if(dis != a.dis) return dis > a.dis;
        return co > a.co;
    }
};
void adds(int u,int v,int len,int w)
{
    e[k].v = v;
    e[k].w = w;
    e[k].len = len;
    e[k].next = head[u];
    head[u] = k++;
}
priority_queue <node> q;
void dijkstra()
{
    node st;
    st.dis = 0;
    st.co = 0;
    st.now =  1;
    q.push(st);
    while(!q.empty())
    {
        node no = q.top();
        int u = no.now;
        q.pop();
        if(u == n)
        {
            printf("%d",no.dis);
            return;
        }
        for(int i = head[u]; i != -1; i = e[i].next)
        {
            int v = e[i].v;
            if(no.co + e[i].w <= cost)
            {
                node cs;
                cs.now = v;
                cs.dis = no.dis + e[i].len;
                cs.co = no.co + e[i].w;
                q.push(cs);
            }
        }
    }
    printf("-1");
}
int main()
{
    int a,b,c,d;
    scanf("%d%d%d",&cost,&n,&r);
    memset(head,-1,sizeof(head));
    for(int i = 1; i <= r; ++i)
    {
        scanf("%d%d%d%d",&a,&b,&c,&d);
        adds(a,b,c,d);
    }
    dijkstra();
    return 0;
}