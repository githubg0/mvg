// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1000+100;
int a[maxn],dp[maxn],pre[maxn];
bool vis[maxn];
int n,m,l;
void dfs(int x)
{
    if(x==0)
    return;
    vis[pre[x]]=1;
    dfs(x-a[pre[x]]);
}
int main()
{
    while(~scanf("%d%d",&m,&l)&&l+m)
    {
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
        {
             scanf("%d",&a[i]);
        }
        memset(dp,0,sizeof(dp));
        memset(vis,0,sizeof(vis));
        for(int i=1;i<=n;i++)
        {
            for(int j=m;j>=a[i];j--)
            {
                if(dp[j]<dp[j-a[i]]+a[i])
                {
                    dp[j]=dp[j-a[i]]+a[i];
                    pre[j]=i;
                }
            }
        }
        int ans=n;
        dfs(dp[m]);
        int sum=0;
        for(int i=1;i<=n;i++)
        {
            if(!vis[i])
            {
               ans--;
               sum+=a[i];
            }
        }
        if(sum<=l)
        {
        printf("%d",ans);
        for(int i=1;i<=n;i++)
        {
            if(vis[i])
            printf(" %d",i);
        }
        printf("\n");
        }
        else
        {
            printf("Impossible to distribute\n");
        }
    }
    return 0;
}