// Basic Algorithm->Memorization,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
long long s;
int to[2][2]={1,0,0,1},n;
long long dp[50][50];
char a[50][50];
long long  dfs(int x,int y){
    int flag=0;
    long long s=0;
    if(dp[x][y]!=-1)
        return dp[x][y];
    if(x==n-1&&y==n-1) 
        return 1; 
    if(a[x][y]=='0') {
        dp[x][y]=0; 
        return 0;
    }
    for(int i=0; i<2; i++){
        int tx=(a[x][y]-'0')*to[i][0]+x; 
        int ty=(a[x][y]-'0')*to[i][1]+y;
        if(tx>=0&&tx<n&&ty>=0&&ty<n){
            flag=1;
            s=s+dfs(tx,ty);
        }
    }
    if(flag==0)  
    {
        dp[x][y]=0;
        return dp[x][y];
    }
    else
    {
        dp[x][y]=s;
        return dp[x][y];
    }
}
int main(){
    while(~scanf("%d",&n)) {
        if(n==-1)
            break;
        s=0;
        for(int i=0; i<n; i++) 
            scanf("%s",a[i]);
        memset(dp,-1,sizeof(dp));
        printf("%lld\n",dfs(0,0)); 
    }
    return 0;
}