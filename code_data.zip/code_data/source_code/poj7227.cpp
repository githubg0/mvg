// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAXVEX 101
char maptt1[MAXVEX][MAXVEX];   
int dir[8][2] ={{1,0}, {-1,0}, {0,1}, {0, -1}, {1,1}, {-1,-1}, {1,-1}, {-1,1}};  
int m, n;   
void DFS(int i, int j)  
{
    int k;
    int x, y;
    for (k = 0; k < 8; k++)
    {
        x = i+dir[k][0];
        y = j+dir[k][1];
        if (x < 0 || x >= m || y < 0 || y >= n)
        {
            continue;
        }
        if (maptt1[x][y] == '@')
        {
            maptt1[x][y] = '*';
            DFS(x, y);
        }
    }
}
int main()
{
    int i, j;
    int num;
    while (scanf("%d%d", &m, &n), m)
    {
        num = 0;
        for (i = 0; i < m; i++)
        {
            scanf("%s", maptt1[i]);
        }
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (maptt1[i][j] == '@')
                {
                    maptt1[i][j] = '*';
                    num++;
                    DFS(i, j);
                }
            }
        }
        printf("%d\n", num);
    }
    return 0;
}