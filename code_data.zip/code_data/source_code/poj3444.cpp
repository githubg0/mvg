// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int ax[1005],t,n,pri,qua,ay[1005][1005],sum,az[1005][1005],b[1005],ans;
bool cmp(int a,int b)
{
    return a>b;
}
bool find(int n,int sum)
{
    int abs=sum;
    for (int i=1; i<ans; i++)
    {
        int mixn=1000000000;
        for (int j=0; j<ax[i]; j++)
        {
            if (mixn>ay[i][j]&&az[i][j]>=n)
                mixn=ay[i][j];
        }
        if (abs<0)
            break;
        abs-=mixn;
    }
    if (abs>=0)
        return true;
    else
        return false;
}
int main()
{
    char str1[21],str2[21];
    scanf("%d",&t);
    while (t--)
    {
        map<string,int> mp;
        mp.clear();
        scanf("%d%d",&n,&sum);
        memset(ax,0,sizeof(ax));
        memset(ay,0,sizeof(ay));
        memset(az,0,sizeof(az));
        ans=1;
        for (int i=0; i<n; i++)
        {
            scanf("%s %s %d %d",str1,str2,&pri,&qua);
            b[i]=qua;
            if (mp[str1]!=0)
            {
                ay[mp[str1]][ax[mp[str1]]]=pri;
                az[mp[str1]][ax[mp[str1]]]=qua;
                ax[mp[str1]]++;
            }
            else
            {
                mp[str1]=ans;
                ay[mp[str1]][ax[mp[str1]]]=pri;
                az[mp[str1]][ax[mp[str1]]]=qua;
                ans++;
                ax[mp[str1]]++;
            }
        }
        sort(b,b+n,cmp);
        if (find(b[0],sum))
        {
            printf("%d\n",b[0]);
            continue;
        }
        for (int i=1; i<n; i++)
        {
            if (b[i]==b[i-1])
                continue;
            else if (find(b[i],sum))
            {
                printf("%d\n",b[i]);
                break;
            }
        }
    }
    return 0;
}