// Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 1000005
const int INF = 0x3f3f3f3f;
using namespace std;
int n, c[N];
struct Node{
int id;
int num;
};
struct Node a[N];
__int64_t ans;
bool cmp(Node x, Node y)
{
    return x.num < y.num;
}
bool cmp2(Node x, Node y)
{
    return x.id < y.id;
}
int lowbit(int x)
{
    return x & (-x);
}
int query(int m)
{
    int sum = 0;
    while (m > 0)
    {
        sum += c[m];
        m -= lowbit(m);
    }
    return sum;
}
void add(int i, int x)
{
    while (i <= n)
    {
        c[i] += x;
        i += lowbit(i);
    }
}
int main()
{
    while(scanf("%d", &n) != EOF)
    {
        memset(c, 0, sizeof(c));
        for (int i = 1; i <= n; i++)
        {
            scanf("%d", &a[i].num);
            a[i].id = i;
        }
        sort(a+1, a+n+1, cmp);
        a[0].num = INF;
        for (int i = 1; i <= n; i++)
            if (a[i].num != a[i-1].num) a[i].num = i;
            else a[i].num = a[i-1].num;
        sort(a+1, a+n+1, cmp2);
        ans = 0;
        for (int i = 1; i <= n; i++)
        {
            add(a[i].num, 1);
            ans += query(n) - query(a[i].num);
        }
        printf("%I64d\n", ans);
   }
    return 0;
}