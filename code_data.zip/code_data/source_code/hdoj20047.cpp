// Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 150005
struct node{
    char str[205];
    int w,t;
    bool operator < (const node& x) const {
        if(w==x.w) return t>x.t;
        return w<x.w;
    }
}a[maxn],ans[maxn];
struct time{
    int t,people;
    bool operator < (const time& x) const {
        return t<x.t;
    }
}door[maxn];
int query[maxn];
int main()
{
    int k,m,q,T;
    freopen("in.txt","r",stdin);
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&k,&m,&q);
        for(int i=0;i<k;i++)
            scanf("%s%d",a[i].str,&a[i].w),a[i].t=i+1;
        for(int i=0;i<m;i++)
            scanf("%d%d",&door[i].t,&door[i].people);
        sort(door,door+m);
        for(int i=0;i<q;i++)
            scanf("%d",&query[i]);
        int now=0,pos=0;
        door[m].t=0x3f3f3f;
        priority_queue<node>pp;
        for(int i=0;i<k;i++){
            if(a[i].t<=door[now].t)
                pp.push(a[i]);
            else{
                while((door[now].people--)&&(!pp.empty()))
                    ans[pos++]=pp.top(),pp.pop();
                pp.push(a[i]);
                now++;
            }
        }
        while(!pp.empty()) ans[pos++]=pp.top(),pp.pop();
        for(int i=0;i<q;i++)
            printf("%s%c",ans[query[i]-1].str,i!=q-1?' ':'\n');
    }
    return 0;
}