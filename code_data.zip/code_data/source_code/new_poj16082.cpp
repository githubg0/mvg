// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int to,next,w;
} edge[210000];
int n,m,head[1005],dis[1005],sum[1005];
bool vis[1005];
bool SPFA()
{
    int i;
    queue <int> q;
    for(i=1;i<=n;i++)
    {
        q.push(i);
        vis[i]=true;
        sum[i]=1;
    }
    while(!q.empty())
    {
        int t=q.front();
        q.pop();
        int p=head[t];
        vis[t]=false;
        while(p!=-1)
        {
            if(dis[edge[p].to]>dis[t]+edge[p].w)
            {
                dis[edge[p].to]=dis[t]+edge[p].w;
                if(!vis[edge[p].to])
                {
                    q.push(edge[p].to);
                    sum[edge[p].to]++;
                    if(sum[edge[p].to]>n)
                    {
                        return false;
                    }
                    vis[edge[p].to]=true;
                }
            }
            p=edge[p].next;
        }
    }
    return true;
}
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        int i,x,y,w,cnt=0;
        char c;
        for(i=0; i<=n; i++)
        {
            head[i]=-1;
            dis[i]=0;
        }
        for(i=0; i<m; i++)
        {
            c=getchar();
            while(c!='P'&&c!='V')
            {
                c=getchar();
            }
            if(c=='P')
            {
                scanf("%d%d%d",&y,&x,&w);
                edge[cnt].to=y;
                edge[cnt].w=w;
                edge[cnt].next=head[x];
                head[x]=cnt;
                cnt++;
                edge[cnt].to=x;
                edge[cnt].w=-w;
                edge[cnt].next=head[y];
                head[y]=cnt;
                cnt++;
            }
            else if(c=='V')
            {
                scanf("%d%d",&x,&y);
                edge[cnt].to=y;
                edge[cnt].w=-1;
                edge[cnt].next=head[x];
                head[x]=cnt;
                cnt++;
            }
        }
        if(SPFA())
        {
            printf("Reliable\n");
        }
        else
        {
            printf("Unreliable\n");
        }
    }
    return 0;
}