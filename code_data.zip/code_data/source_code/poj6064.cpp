// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 1010
using namespace std;
struct node{
   int x;
   int y;
   int step;
};
int dx[4] = {1,0,-1,0};
int dy[4] = {0,1,0,-1};
char maptt1[maxn][maxn];
bool vis[maxn][maxn];
int a,b,n,m,ans;
void bfs(int xx,int yy)
{
    memset(vis,false,sizeof(vis));
    node now,next;
    queue<node > q;
    ans = 0;
    now.x = xx;
    now.y = yy;
    now.step = 0;
    vis[now.x][now.y] = true;
    q.push(now);
    while(!q.empty())
    {
        next = q.front();
        q.pop();
        for(int i = 0 ; i < 4 ; i++)
        {
            now.x = next.x + dx[i];
            now.y = next.y + dy[i];
            if(now.x >= 0 && now.x < m && now.y >= 0 && now.y < n && !vis[now.x][now.y] && maptt1[now.x][now.y] != '#')
            {
                vis[now.x][now.y] = true;
                now.step = next.step + 1;
                if(ans < now.step)
                {
                    ans = now.step;
                    a = now.x;
                    b = now.y;
                }
                q.push(now);
            }
        }
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int sx = 0,sy = 0;
        int falg = 0;
        sizeof(maptt1,'\0',sizeof(maptt1));
        scanf("%d%d",&n,&m);
        for(int i = 0; i < m ; i++)
            scanf("%s",maptt1[i]);
        for(int i = 0 ; i < n ; i++){
            for(int j = 0 ; j < m ; j++)
            {
                if(maptt1[i][j] == '.')
                {
                    sx = i;
                    sy = j;
                    falg = 1;
                    break;
                }
            }
            if(falg)
                break;
        }
        bfs(sx,sy);
        bfs(a,b);
        printf("Maximum rope length is %d.\n",ans);
    }
    return 0;
}