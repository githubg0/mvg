// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=100100;
typedef pair<int,int> pII;
struct Edge
{
    int to,next;
}edge[maxn*3];
pII bian[maxn*3];
int Adj[maxn],Size;
int n,m;
void init()
{
    Size=0;memset(Adj,-1,sizeof(Adj));
}
void Add_Edge(int u,int v)
{
    edge[Size].to=v;
    edge[Size].next=Adj[u];
    Adj[u]=Size++;
}
int Low[maxn],DFN[maxn],Stack[maxn],Belong[maxn],num[maxn];
int Index,top,scc;
bool Instack[maxn];
void tarjan(int u,int fa)
{
    int v;
    Low[u]=DFN[u]=++Index;
    Stack[top++]=u;
    Instack[u]=true;
    for(int i=Adj[u];~i;i=edge[i].next)
    {
        v=edge[i].to;
       
        if(!DFN[v])
        {
            tarjan(v,u);
            Low[u]=min(Low[u],Low[v]);
        }
        else if(Instack[v])
        {
            Low[u]=min(Low[u],DFN[v]);
        }
    }
    if(Low[u]==DFN[u])
    {
        scc++;
        do
        {
            v=Stack[--top];
            Instack[v]=false;
            num[scc]++;
            Belong[v]=scc;
        }while(v!=u);
    }
}
void solve()
{
    memset(DFN,0,sizeof(DFN));
    memset(Instack,0,sizeof(Instack));
    memset(num,0,sizeof(num));
    Index=scc=top=0;
    for(int i=1;i<=n;i++)
    {
        if(!DFN[i]) tarjan(i,i);
    }
}
Edge edge2[maxn*3];int Size2,Adj2[maxn];
void Add_Edge2(int u,int v)
{
    edge2[Size2].to=v;
    edge2[Size2].next=Adj2[u];
    Adj2[u]=Size2++;
}
void Rebuild()
{
    int a,b;
    Size2=0; memset(Adj2,-1,sizeof(Adj2));
    for(int i=0;i<m;i++)
    {
        a=bian[i].first; b=bian[i].second;
        if(Belong[a]==Belong[b]) continue;
        Add_Edge2(Belong[a],Belong[b]);
    }
}
int dp[maxn];
int dfs(int u)
{
    if(dp[u]) return dp[u];
    dp[u]=num[u];
    int mx=0;
    for(int i=Adj2[u];~i;i=edge2[i].next)
    {
        int v=edge2[i].to;
        mx=max(mx,dfs(v));
    }
    dp[u]=dp[u]+mx;
    return dp[u];
}
int doit()
{
    int ans=0;
    memset(dp,0,sizeof(dp));
    for(int i=1;i<=scc;i++)
    {
        if(!dp[i]) dp[i]=dfs(i);
    }
    for(int i=1;i<=scc;i++)
        ans=max(ans,dp[i]);
    return ans;
}
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        init();
        int a,b;
        for(int i=0;i<m;i++)
        {
            scanf("%d%d",&a,&b);
            Add_Edge(a,b);
            bian[i]=make_pair(a,b);
        }
        solve();
     
        Rebuild();
        printf("%d\n",doit());
    }
    return 0;
}