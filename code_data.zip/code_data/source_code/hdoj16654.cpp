// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 500020;
int Tree[maxn << 2], lazy[maxn << 2];
int t, n, m, k;
void Build(int l, int r, int rt)
{
	if(l == r)
	{
		Tree[rt] = 1;
		return ;
	}
	int m = (l + r) / 2;
	Build(l, m, rt << 1);
	Build(m + 1, r, rt << 1 | 1);
	Tree[rt] = Tree[rt << 1] + Tree[rt << 1 | 1];
}
void pushdown(int l, int r, int rt)
{
    if(lazy[rt] == -1)
        return ;
    int m = (l + r) / 2;
    lazy[rt << 1] = lazy[rt << 1 | 1] = lazy[rt];
    Tree[rt << 1] = lazy[rt] * (m - l + 1);
    Tree[rt << 1 | 1] = lazy[rt] * (r - m);
    lazy[rt] = -1;
}
void update(int L, int R, int val, int l, int r, int rt)
{
    if(l >= L && r <= R)
    {
        Tree[rt] = val * (r - l + 1);
        lazy[rt] = val;
        return ;
    }
    pushdown(l, r, rt);
    int m = (l + r) / 2;
    if(m >= L)
        update(L, R, val, l, m, rt << 1);
    if(m < R)
        update(L, R, val, m + 1, r, rt << 1 | 1);
    Tree[rt] = Tree[rt << 1] + Tree[rt << 1 | 1];
}
int query(int L, int R, int l, int r, int rt)
{
    if(l >= L && r <= R)
        return Tree[rt];
    pushdown(l, r, rt);
    int m = (l + r) / 2;
    int ans = 0;
    if(m >= L)
        ans += query(L, R, l, m, rt << 1);
    if(m < R)
        ans += query(L, R, m + 1, r, rt << 1 | 1);
    return ans;
}
int Bin(int s,int num)
{
	int l = s;
	int r = n;
	int ans = -1;
	while(l <= r)
	{
		int m = (l + r) / 2;
		int temp = query(s, m, 1, n, 1);
		if(temp == num)
		{
			ans = m;
			r = m - 1;
		}
		else
		{
			if(temp < num)
				l = m + 1;
			else
				r = m - 1;
		}
	}
	return ans;
}
int main()
{
    
	cin >> t;
	while(t--)
	{
		scanf("%d%d", &n, &m);
		Build(1, n, 1);
		memset(lazy, -1, sizeof(lazy));
		int a, b;
		for(int i = 1; i <= m; ++ i)
		{
			scanf("%d%d%d", &k, &a, &b);
			if(k == 1)
			{
				a++;
				int st = Bin(a, 1);
				if(st == -1)
				{
					cout << "Can not put any one." << endl;
				}
				else
				{
					int temp = query(st, n, 1, n, 1);
					if(temp <= b)
						b = temp;
					int ed = Bin(st, b);
					update(st, ed, 0, 1, n, 1);
					printf("%d %d\n", st - 1, ed - 1);
				}
			}
			else
			{
				a ++;
				b ++;
				int ans = query(a, b, 1, n, 1);
				update(a, b, 1, 1, n, 1);
				printf("%d\n", b - a + 1 - ans);
			}
		}
		printf("\n");
	}
	return 0;
}