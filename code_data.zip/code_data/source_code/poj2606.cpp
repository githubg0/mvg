// Data Structure->Trie
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char str[15];	
int strNum[15];	
void Trans()
{
	int i;
	for(i=0;i<strlen(str);i++)
		strNum[i]=str[i]-'A'+1;
}
void forceSearch(int len,int target)
{
	int i,j,k,l,m;	
	
	for(i=len-1;i>=0;i--)
		for(j=len-1;j>=0;j--)
		{
			if(j==i)
				continue;
			
			for(k=len-1;k>=0;k--)
			{
				if(k==i || k==j)
					continue;
				
				for(l=len-1;l>=0;l--)
				{
					if(l==i || l==j || l==k)
						continue;
					
					for(m=len-1;m>=0;m--)
					{
						if(m==i || m==j || m==k || m==l)
							continue;
						else if(strNum[i] - strNum[j]*strNum[j] + strNum[k]*strNum[k]*strNum[k] - strNum[l]*strNum[l]*strNum[l]*strNum[l] + strNum[m]*strNum[m]*strNum[m]*strNum[m]*strNum[m] == target)
						{
							printf("%c%c%c%c%c\n",strNum[i]-1+'A',strNum[j]-1+'A',strNum[k]-1+'A',strNum[l]-1+'A',strNum[m]-1+'A');
							return;
						}
					}
				}
			}
		}
		printf("no solution\n");
}
int main()
{
	int i;
	int target;
	while(scanf("%d%s",&target,str))
	{
		if(target==0 && strcmp(str,"END")==0)
			return 0;
		
		int len=strlen(str);		
		Trans();
		sort(strNum,strNum+len);
		
		
		
		
		forceSearch(len,target);
	}
	
	return 0;
}