// Graph Algorithm->Hungarian (KM) Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 550;
int uN, vN;  
int g[MAXN][MAXN];
int linker[MAXN];
bool used[MAXN];
struct node
{
	char sex[5];
	char music[101];
	char sport[101];
	int high;
}man[MAXN],woman[MAXN],now;
bool ok(node a, node b)
{
	if (abs(a.high - b.high)>40)
		return 0;
	if (strcmp(a.music, b.music) != 0)
		return 0;
	if (strcmp(a.sport, b.sport) == 0)
		return 0;
	return 1;
}
bool dfs(int u)
{
	int v;
	for (v = 0; v<vN; v++)
		if (g[u][v] && !used[v])
		{
		used[v] = true;
		if (linker[v] == -1 || dfs(linker[v]))
		{
			linker[v] = u;
			return true;
		}
		}
	return false;
}
int hungary()
{
	int res = 0;
	int u;
	memset(linker, -1, sizeof(linker));
	for (u = 0; u<uN; u++)
	{
		memset(used, 0, sizeof(used));
		if (dfs(u))  res++;
	}
	return res;
}
int main()
{
	int t,n;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d", &n);
		uN = vN = 0;
		memset(g, 0, sizeof(g));
		for (int i = 0; i < n; i++)
		{
			scanf("%d%s%s%s", &now.high, now.sex, now.music, now.sport);
			if (now.sex[0] == 'M')
				man[uN++] = now;
			else woman[vN++] = now;
		}
		for (int i = 0; i < uN; i++)
			for (int j = 0; j < vN; j++)
				if (ok(man[i], woman[j]))g[i][j] = 1;
		printf("%d\n", n - hungary());
	}
	return 0;
}