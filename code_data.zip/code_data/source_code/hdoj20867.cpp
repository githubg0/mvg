// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[1000003];
int b[10003];
int n,m;
void Getnext(int *p,int next[])
{
    int k=-1;
    int j=0;
    next[0]=-1;
    while(j<m)
    {
        if(p[j]==p[k]||k==-1)
        {
            ++j;
            ++k;
            if(p[j]!=p[k])
                next[j]=k;
            else
                next[j]=next[k];
        }
        else
            k=next[k];
    }
}
int KMPSearch(int *s,int *p,int next[])
{
    int i=0;
    int j=0;
    while(i<n&&j<m)
    {
        if(s[i]==p[j]||j==-1)
        {
            i++;
            j++;
        }
        else
            j=next[j];
    }
    if(j==m)
        return i-j+1;
    else
        return -1;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        for(int i=0; i<n; i++)
            scanf("%d",&a[i]);
        for(int i=0; i<m; i++)
            scanf("%d",&b[i]);
        int next[10003];
        memset(next,0,sizeof(next));
        Getnext(b,next);
        printf("%d\n",KMPSearch(a,b,next));
    }
}