// Sorting->Quick Sort,Data Structure->Segment Tree,Basic Algorithm->Discretization,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define lson l, mid, rt << 1
#define rson mid + 1, r, rt << 1 | 1
typedef long long ll;
typedef pair<int, int> P;
const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;
struct ST	{
	int sum[N<<2], col[N<<2];
	void push_up(int rt)	{
        sum[rt] = sum[rt<<1] + sum[rt<<1|1];
	}
	void push_down(int rt, int len)	{
		if (col[rt])	{
			col[rt<<1] += col[rt];
			col[rt<<1|1] += col[rt];
			sum[rt<<1] += col[rt] * (len - (len >> 1));
			sum[rt<<1|1] += col[rt] * (len >> 1);
			col[rt] = 0;
		}
	}
	void build(int l, int r, int rt)	{
		col[rt] = 0;	sum[rt] = 0;
		if (l == r)	return ;
		int mid = (l + r) >> 1;
		build (lson);	build (rson);
	}
	void updata(int ql, int qr, int l, int r, int rt)	{
		if (ql <= l && r <= qr)	{
			sum[rt] += (r - l + 1);	col[rt] += 1;	return ;
		}
		push_down (rt, r - l + 1);
		int mid = (l + r) >> 1;
		if (ql <= mid)	updata (ql, qr, lson);
		if (qr > mid)	updata (ql, qr, rson);
	}
	int query(int ql, int qr, int l, int r, int rt)	{
		if (ql <= l && r <= qr)	return sum[rt];
		push_down (rt, r - l + 1);
		int mid = (l + r) >> 1;
		if (ql <= mid)	return query (ql, qr, lson);
		if (qr > mid)	return query (ql, qr, rson);
	}
}st;
int x1[N], x2[N], q[N];
int X[N*3];
int my_binary_search(int l, int r, int key)	{
	while (l <= r)	{
		int mid = (l + r) >> 1;
		if (X[mid] == key)	return mid;
		if (X[mid] < key)	l = mid + 1;
		else	r = mid - 1;
	}
	return -1;
}
int main(void)	{
	int T, cas = 0;	scanf ("%d", &T);
	while (T--)	{
		int n, m;
		scanf ("%d%d", &n, &m);
		int tot = 0;
		for (int i=1; i<=n; ++i)	{
			scanf ("%d%d", &x1[i], &x2[i]);
			X[tot++] = x1[i];	X[tot++] = x2[i];
		}
		for (int i=1; i<=m; ++i)	{
			scanf ("%d", &q[i]);
			X[tot++] = q[i];
		}
		sort (X, X + tot);
		int k = 1;
		for (int i=1; i<tot; ++i)	{
			if (X[i] != X[i-1])	X[k++] = X[i];
		}
		st.build (0, k, 1);
		for (int ql, qr, i=1; i<=n; ++i)	{
			ql = lower_bound (X, X+k, x1[i]) - X;
			qr = lower_bound (X, X+k, x2[i]) - X;
			st.updata (ql, qr, 0, k, 1);
		}
		printf ("Case #%d:\n", ++cas);
		for (int p, i=1; i<=m; ++i)	{
			p = lower_bound (X, X+k, q[i]) - X;
			printf ("%d\n", st.query (p, p, 0, k, 1));
		}
	}
    return 0;
}