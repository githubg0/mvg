// Data Structure->Queue,Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main()
{
    int n,i,m,e,j;
    int a[1000],b[1000],c[1000],d[1000],f[1000];
    while(cin>>n)
    {
        a[0]=1;
        a[1]=1;
        a[2]=2;
        a[3]=4;
        if(n>=4)
        {
            b[0]=4;
            c[0]=2;
            d[0]=1;
            f[0]=1;
            m=0;
            for(i=4; i<=n; i++)
            {
                e=0;
                for(j=0; j<=m; j++)
                {
                    a[j]=b[j]+c[j]+d[j]+e;
                    e=a[j]/10000;
                    a[j]=a[j]%10000;
                    d[j]=f[j];
                    f[j]=c[j];
                    c[j]=b[j];
                    b[j]=a[j];
                }
                if(e>0)
                {
                    m++;
                    a[m]=e;
                    b[m]=a[m];
                    c[m]=0;
                    d[m]=0;
                    f[m]=0;
                }
            }
           
            printf("%d",a[m]);
           
            for(i=m-1; i>=0; i--)
                printf("%04d",a[i]);
            printf("\n");
        }
        else
            cout<<a[n]<<endl;
    }
    return 0;
}