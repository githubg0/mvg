// Basic Algorithm->Recursion,Data Structure->Disjoint Set Union (DSU),Graph Algorithm->Euler Circuit / Euler Path,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define m 45
#define n 1995
using namespace std;
int maxn,gra[m][n],cnt,len[m],road[n],vis[n],w;
void dfs(int x)
{
    for(int i=1; i<=maxn; i++)
    {
        if((gra[x][i])&&(!vis[i]))
        {
            vis[i]=1;
            dfs(gra[x][i]);
            road[++cnt]=i;
        }
    }
}
int main()
{
    int start,u,v;
    while(scanf("%d%d",&u,&v))
    {
        if(u==0&&v==0)break;
        cnt=0;
        maxn=0;
        start=min(u,v);
        scanf("%d",&w);
        memset(gra,0,sizeof(gra));
        memset(len,0,sizeof(len));
        memset(road,0,sizeof(road));
        memset(vis,0,sizeof(vis));
        gra[u][w]=v;
        gra[v][w]=u;
        len[u]++;
        len[v]++;
        maxn=max(maxn,v);
        while(scanf("%d%d",&u,&v))
        {
            if(u==0&&v==0)break;
            scanf("%d",&w);
            gra[u][w]=v;
            gra[v][w]=u;
            len[u]++;
            len[v]++;
            maxn=max(maxn,w);
        }
        int k=1;
        for(; k<45; k++)
            if(len[k]%2)
                break;
        if(k<45){
            printf("Round trip does not exist.\n");
            continue;
        }
        dfs(start);
        for(int i=cnt; i>0; i--)
            printf("%d\n",road[i]);
    }
}