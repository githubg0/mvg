// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL long long 
const int MAXN = 1e3+100;
const int inf = 0x3f3f3f3f;
const int MAXM = 1e6;
const double eps =1e-8;
double  mp[MAXN][MAXN],mst[MAXN][MAXN];
bool vis[MAXN],Inmst[MAXN][MAXN];
double  dis[MAXN];
int pre[MAXN];
double x[MAXN],y[MAXN];
double val[MAXN];
int n;
double getd(int a,int b){
    return  sqrt((x[a]-x[b])*(x[a]-x[b])+(y[a]-y[b])*(y[a]-y[b]));
}
void getmap(){
    for(int i=1;i<=n;i++)
        scanf("%lf%lf%lf",&x[i],&y[i],&val[i]);
    for(int i=1;i<=n;i++){
        mp[i][i]=0;
        for(int j=1;j<i;j++){
            mp[i][j]=mp[j][i]=getd(i,j);
        }
    }
}
void djk(){
    memset(mst,0,sizeof(mst));
    memset(Inmst,0,sizeof(Inmst));
    for(int i=1;i<=n;i++){
        vis[i]=0;
        dis[i]=mp[1][i];
        pre[i]=1;
    }
    vis[1]=1;dis[1]=0;
    double  mincost=0;int nexts;double minn;
    for(int i=2;i<=n;i++){
        minn=inf;nexts=-1;
        for(int j=1;j<=n;j++){
            if(!vis[j]&&dis[j]<minn){
                minn=dis[j];
                nexts=j;
            }
        }
        mincost+=minn;vis[nexts]=1;int fa=pre[nexts];
        Inmst[fa][nexts]=Inmst[nexts][fa]=1;
        for(int j=1;j<=n;j++){
            if(vis[j]&&j!=nexts) 
                mst[j][nexts]=mst[nexts][j]=max(mst[fa][j],dis[nexts]);
            if(!vis[j]&&dis[j]>mp[nexts][j]){
                dis[j]=mp[nexts][j];
                pre[j]=nexts;
            }
        }
    }
    double ans=0;
    double sum=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<i;j++){
            if(!Inmst[i][j]){
                sum=val[i]+val[j];
                ans=max(ans,sum*1.0/(mincost-mst[i][j]));
            }else if(Inmst[i][j]){ 
                sum=val[i]+val[j]; 
                ans=max(ans,sum*1.0/(mincost-mp[i][j]));
            }
        }
    }
    printf("%.2lf\n",ans);
}
int main(){
    int t;scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        getmap();
        djk();
    }
    return 0;
}