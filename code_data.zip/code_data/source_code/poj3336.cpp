// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char chessboard[10][10];
int row[10];
int col[10];
int n, k;
int sum;
void input() {
	memset(chessboard, 0, sizeof(chessboard));
	memset(row, 0, sizeof(row));
	memset(col, 0, sizeof(col));
	sum = 0;
	for (int i = 1; i <= n; ++i)
		cin >> chessboard[i];
}
void dfs(int step, int layer) {
	if (step == k) {
		sum++;
		return;
	}
	for (int i = layer + 1; i <= n; ++i) {
		for (int j = 0; j < n; ++j) {
			if (row[i] == 1 || col[j] == 1 || chessboard[i][j] != '#') 
				continue;
			else {
				row[i] = col[j] = 1;
				dfs(step + 1, i);
				row[i] = col[j] = 0;
			}
		}
	}
}
int main() {
	
	while (cin >> n >> k && (n + k > -2)) {
		input();
		dfs(0, 0);
		cout << sum << endl;
	}
	system("pause");
	return 0;
}