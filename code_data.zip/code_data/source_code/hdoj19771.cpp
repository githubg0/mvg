// Data Structure->Stack,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
typedef long long ll;
const int MOD = 1000000007;
int n, flag;
ll A[100005];
vector<int> G[100005];
ll dfs(int fa, int u)
{
    if(!flag) return 0;
    ll res = 1;
    int cnt = 0, cntleaf = 0; 
    for(int i = 0; i < G[u].size(); i++)
    {
        int v = G[u][i];
        if(v != fa)
        {
            ll temp = dfs(u, v);
            if(!flag) return 0;
            cnt++;
            if(G[v].size() == 1) cntleaf++;
            res = res * temp % MOD;
        }
    }
    if(cnt - cntleaf > 2)
    { 
        flag = 0; return 0;
    }
    if(cntleaf)
        res = res * A[cntleaf] % MOD;
    if(cnt - cntleaf) 
        res = res * 2 % MOD;
    return res;
}
int main()
{
    #ifdef LOCAL
    freopen("data.in", "r", stdin);
    #endif
    A[0] = 1; A[1] = 1;
    for(int i = 2; i <= 100000; i++)
        A[i] = A[i - 1] * i % MOD;
    int t, a, b;
    scanf("%d", &t);
    for(int cas = 1; cas <= t; cas++)
    {
        scanf("%d", &n);
        if(n == 1)
        {
            printf("Case #%d: 1\n", cas);
            continue;
        }
        for(int i = 0; i <= n; i++)
            G[i].clear();
        for(int i = 1; i < n; i++)
        {
            scanf("%d%d", &a, &b);
            G[a].push_back(b);
            G[b].push_back(a);
        }
        flag = 1;
        ll ans = dfs(-1, 1);
        if(flag)
            printf("Case #%d: %I64d\n", cas, ans * 2 % MOD); 
        else
            printf("Case #%d: 0\n", cas);
    }
    return 0;
}