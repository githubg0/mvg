// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define mod 1000000007
using namespace std;
char s[1000011];
int l, p[1000011], ans[1000001], tot, t;
void ycl() { 
    ans[0] = 0;
    ans[1] = 1;
    for (int i = 1, j = 0; i < l; i++) {
        while (j && s[i] != s[j])
            j = p[j];
        if (s[i] == s[j])
            j++;
        ans[i + 1] = ans[j] + 1; 
        p[i + 1] = j;
    }
}
long long answer() {
    long long sum = 1;
    for (int i = 1, j = 0; i < l; i++) {
        while (j && s[i] != s[j])
            j = p[j];
        if (s[i] == s[j])
            j++;
        while((j << 1) > (i + 1))
            j = p[j]; 
        sum = (sum * (long long)(ans[j] + 1)) % mod;
    }
    return sum;
}
int main() {
    scanf("%d", &t);
    for(int i = 1; i <= t; i++) {
        memset(p, 0, sizeof(p));
        scanf("%s", s);
        l = strlen(s);
        ycl();
        printf("%lld\n", answer());
    }
}