// Data Structure->Stack,Math and Computational Geometry->Greatest Common Divisor (GCD),Data Structure->Queue,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int GCD(int a,int b)
{
    if(b == 0)
        return a;
    return GCD(b,a%b);
}
int LCM(int a,int b)
{
    return a / GCD(a,b) * b;
}
int A[130],B[130];
int main()
{
    int N;
    while(~scanf("%d",&N) && N)
    {
        stack<int> Mins,FiveMins,Hours;
        queue<int> Balls;
        for(int i = 1; i <= N; ++i)
            Balls.push(i);
        int Cir = 24*60;
        int M;
        while(Cir--)
        {
            M = Balls.front();
            Balls.pop();
            if(Mins.size() == 4)
            {
                for(int i = 0; i < 4; ++i)
                {
                    Balls.push(Mins.top());
                    Mins.pop();
                }
                if(FiveMins.size() == 11)
                {
                    for(int i = 0; i < 11; ++i)
                    {
                        Balls.push(FiveMins.top());
                        FiveMins.pop();
                    }
                    if(Hours.size() == 11)
                    {
                        for(int i = 0; i < 11; ++i)
                        {
                            Balls.push(Hours.top());
                            Hours.pop();
                        }
                        Balls.push(M);
                    }
                    else
                        Hours.push(M);
                }
                else
                    FiveMins.push(M);
            }
            else
                Mins.push(M);
        }
        for(int i = 1; i <= N; ++i)
        {
            A[i] = Balls.front();
            Balls.pop();
        }
        for(int i = 1; i <= N; ++i)
            B[i] = 1;
        for(int i = 1; i <= N; ++i)
        {
            int AA = A[i];
            while(AA != i)
            {
                B[i]++;
                AA = A[AA];
            }
        }
        int Ans = 1;
        for(int i = 1; i <= N; ++i)
        {
            Ans = LCM(Ans, B[i]);
        }
        printf("%d balls cycle after %d days.\n",N,Ans);
    }
    return 0;
}