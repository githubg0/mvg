// Dynamic Programming->Priority Queue,Data Structure->Link List
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int P,N,M;
int Ai[10005]={};
priority_queue<int> QvQ;
priority_queue<int,vector<int>,greater<int> > QwQ;
void insert(const int&x)
{
	if(QwQ.empty()||QwQ.top()<x)QwQ.push(x);
	else QvQ.push(x);
	if(QwQ.size()>QvQ.size()+1)QvQ.push(QwQ.top()),QwQ.pop();
	if(QvQ.size()>QwQ.size()+1)QwQ.push(QvQ.top()),QvQ.pop();
}
int main()
{
	scanf("%d",&P);
	for(int cnm=1;cnm<=P;++cnm)
	{
		scanf("%d%d",&N,&M);
		printf("%d %d\n",N,M+1>>1);
		while(!QwQ.empty())QwQ.pop();
		while(!QvQ.empty())QvQ.pop();
		for(int pt=0,i=1;i<=M;++i)
		{
			scanf("%d",&Ai[i]);
			insert(Ai[i]);
			if(i&1)
			{
				if(QwQ.size()>QvQ.size())printf("%d ",QwQ.top());
				if(QvQ.size()>QwQ.size())printf("%d ",QvQ.top());
				if(++pt==10&&(i!=M))pt=0,putchar('\n');
			}
		}
		if(cnm<P)putchar('\n');
	}
    return 0;
}