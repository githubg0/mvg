// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
bool vis[21][21][1100];
int n,m,t;
char mp[21][21];
struct node
{
    int x,y,step,key;
};queue<node>Q;
int ch[][2]={{1,0},{-1,0},{0,-1},{0,1}};
void judge(node &tmp)
{
    int x=tmp.x,y=tmp.y,k=tmp.key;
    if(x>=0&&x<n&&y>=0&&y<m&&!vis[x][y][k]&&mp[x][y]!='*')
    {
        if(mp[x][y]>='A'&&mp[x][y]<='Z')
        {
            if(k&(1<<(mp[x][y]-'A')))
            {
                vis[x][y][k]=1;
                tmp.step++;
                Q.push(tmp);
            }
        }
        else if(mp[x][y]>='a'&&mp[x][y]<='z')
        {
            if(!(k&(1<<(mp[x][y]-'a'))))
            {
                tmp.key+=1<<(mp[x][y]-'a');
            }
            vis[x][y][k]=1;
            tmp.step++;
            Q.push(tmp);
         }
        else
        {
             vis[x][y][k]=1;
            tmp.step++;
            Q.push(tmp);
        }
    }
}
int BFS(int sx,int sy,int ex,int ey)
{
    memset(vis,0,sizeof(vis));
    while(!Q.empty())Q.pop();
    node now,tmp;
    now.x=sx,now.y=sy,now.step=now.key=0;
    vis[sx][sy][0]=1;
    Q.push(now);
    while(!Q.empty())
    {
        now=Q.front(),Q.pop();
        if(now.x==ex&&now.y==ey)
            return now.step;
        for(int i=0;i<4;i++)
        {
            tmp=now;
            tmp.x+=ch[i][0],tmp.y+=ch[i][1];
            judge(tmp);
        }
    }
    return t+1;
}
int main()
{
    int sx,sy,ex,ey;
    int ans;
    while(~scanf("%d%d%d",&n,&m,&t))
    {
        sx=ex=-1;ans=t+1;
        for(int i=0;i<n;i++)
        {
            scanf("%s",mp[i]);
            for(int j=0;j<m;j++)
            {
                if(mp[i][j]=='@')
                    sx=i,sy=j;
                else if(mp[i][j]=='^')
                    ex=i,ey=j;
            }
        }
        if(sx==-1||ex==-1)
            ans=t+1;
        else
            ans=BFS(sx,sy,ex,ey);
        if(ans>=t)
            printf("-1\n");
        else
            printf("%d\n",ans);
    }
    return 0;
}