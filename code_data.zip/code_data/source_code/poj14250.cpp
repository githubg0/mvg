// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
vector<int >T[250];
typedef struct mystruct{
	char name[105];
}DATA;
DATA emp[250];
int n;
int flag[250];
int dp[250][3],yes_or_no[250][3];
int gg;
int gg_special_0;
int max_num;
int find_max(int a,int b)
{
	return a>b?a:b;
}
void dfs(int u)
{
	flag[u]=1;
	dp[u][1]=1;
	if (T[u].size()==0)return;
	int i,son;
	for ( i = 0; i <T[u].size() ; i++)
	{
		son=T[u][i];
		if (!flag[T[u][i]])
		{
			dfs(son);
		}
		dp[u][0]+= find_max(dp[son][0],dp[son][1]);
		dp[u][1]+= dp[son][0];
		yes_or_no[u][1]+=yes_or_no[son][0];
		if (dp[son][0]==dp[son][1])yes_or_no[u][0]++;
		else if(dp[son][0]>dp[son][1])yes_or_no[u][0]+=yes_or_no[son][0];
		else yes_or_no[u][0]+=yes_or_no[son][1];
	}
	return ;
}
int main()
{
	int i,j,k,employee,boss;
	char temp[105];
	while ( scanf("%d",&n),n!=0)
	{
		for ( i = 1; i <=n ; i++)
		{
			T[i].clear();
		}
		gg=1;
		gg_special_0=1;
		max_num=0;
		memset(flag,0,sizeof(flag));
		memset(dp,0,sizeof(dp));
		memset(yes_or_no,0,sizeof(yes_or_no));
		
		scanf("%s",emp[1].name);
		k=2;
		for ( i = 2; i <=n ; i++)
		{
			scanf("%s",temp);
			for ( j = 1; j <k ; j++)
			{
				if (strcmp(temp,emp[j].name)==0)
				{
					break;
				}
			}
			if (j==k)
			{
				strcpy(emp[k].name,temp);
				employee=k;
				k++;
			}
			else
			{
				employee=j;
			}
			scanf("%s",temp);
			for ( j = 1; j <k ; j++)
			{
				if (strcmp(temp,emp[j].name)==0)
				{
					break;
				}
			}
			if (j==k)
			{
				strcpy(emp[k].name,temp);
				boss=k;
				k++;
			}
			else
			{
				boss=j;
			}
			T[boss].push_back(employee);
		}
		T[0].push_back(1);
		
		dfs(1);
		max_num=find_max(dp[1][1],dp[1][0]);
		
		printf("%d ",max_num);
		if(dp[1][1]==dp[1][0] || (dp[1][1]>dp[1][0] && yes_or_no[1][1]>0) || (dp[1][1]<dp[1][0] && yes_or_no[1][0]>0))printf("No\n");
		else printf("Yes\n");
	}
	return 0;
}