// Basic Algorithm->Arbitrary-Precision Arithmetic
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1 | 1
using namespace std;
const int maxn = 1005, maxe = 100005, inf = 1 << 29;
int n, m;
char a[maxn], b[maxn];
int na[maxn], nb[maxn];
void add() {
    int la = strlen(a), lb = strlen(b), lmax = max(la, lb);
    memset(na, 0, sizeof(na));
    memset(nb, 0, sizeof(nb));
    for(int i = 0; a[i]; i++)
        na[la - i - 1] = a[i] - '0';
    for(int i = 0; b[i]; i++)
        nb[lb - i - 1] = b[i] - '0';
    for(int i = 0; i < lmax; i++)
        na[i] += nb[i], na[i + 1] += na[i] / 10, na[i] %= 10;
    if(na[lmax])
        lmax++;
    for(int i = 0; i < lmax; i++)
        a[lmax - i - 1] = na[i] + '0';
    a[lmax] = '\0';
}
int main() {
    int t;
    scanf("%d", &t);
    for(int T = 1; T <= t; T++) {
        if(T != 1)
            printf("\n");
        scanf("%s", a);
        if(a[0] == '0') {
            printf("0\n");
            continue;
        }
        while(scanf("%s", b) && b[0] != '0')
            add();
        printf("%s\n", a);
    }
    return 0;
}