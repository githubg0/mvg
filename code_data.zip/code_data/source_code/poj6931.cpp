// Graph Algorithm->Kruskal's Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct path
{
    int x,y,w,flag;
}a[12102];
int f[12102];
int mst,n,m;
int cmp(path a,path b)
{
    return a.w<b.w;
}
void init()
{
    for(int i=0;i<=n;i++)
    {
        f[i]=i;
    }
}
int find(int x)
{
    return f[x] == x ? x : (f[x] = find(f[x]));
}
void merge(int a,int b)
{
    int A,B;
    A=find(a);
    B=find(b);
    if(A!=B)
    f[B]=A;
}
void kruskal()
{
    init();
    mst=0;
    for(int i=0;i<m;i++)
    {
        if(find(a[i].x)!=find(a[i].y))
        {
            merge(a[i].x,a[i].y);
            mst+=a[i].w;
            a[i].flag=1;
        }
    }
}
int  kruskal2()
{
    for(int i=0;i<m;i++)
    {
        if(a[i].flag==1)
        {
            init();
            int tmp=0;
            int k=0;
            for(int j=0;j<m;j++)
            {
                if(i==j)continue;
                if(find(a[j].x)!=find(a[j].y))
                {
                    merge(a[j].x,a[j].y);
                    tmp+=a[j].w;
                    k++;
                }
            }
            
            if(k!=n-1)continue;
            if(tmp==mst)return 1;
        }
    }
    return 0;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        for(int i=0;i<m;i++)
        {
            scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].w);
            a[i].flag=0;
        }
        sort(a,a+m,cmp);
        kruskal();
        if(kruskal2()==0)
        {
            printf("%d\n",mst);
        }
        else printf("Not Unique!\n");
    }
}