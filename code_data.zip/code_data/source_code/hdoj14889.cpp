// Math and Computational Geometry->Linear Matrix
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define rep(i,st,ed) for (int i=st;i<=ed;++i)
#define drp(i,st,ed) for (int i=st;i>=ed;--i)
const int N=200005;
struct Gay {
	int r[31];
	void ins(int x) {
		drp(i,30,0) if ((x>>i)&1) {
			if (!r[i]) {
				r[i]=x;
				return ;
			}
			x^=r[i];
		}
	}
	void get_max() {
		int res=0;
		drp(i,30,0) if ((res^r[i])>res) res^=r[i];
		printf("%d ", res);
		rep(i,0,30) if ((res^r[i])<res) {
			printf("%d\n", res^r[i]);
			return ;
		}
	}
} G;
int read() {
	int x=0,v=1; char ch=getchar();
	for (;ch<'0'||ch>'9';v=(ch=='-')?(-1):(v),ch=getchar());
	for (;ch<='9'&&ch>='0';x=x*10+ch-'0',ch=getchar());
	return x*v;
}
int main(void) {
	int n=read();
	rep(i,1,n) {
		int x=read();
		G.ins(x);
	}
	G.get_max();
	return 0;
}