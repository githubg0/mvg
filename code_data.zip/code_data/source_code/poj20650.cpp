// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 100 + 10;
const int maxm = 50 + 5;
const int INF = 0x3f3f3f3f;
struct Edge{
    int from, to, cap, flow;
    Edge(int u, int v, int c, int f) : from(u), to(v), cap(c), flow(f) {}
};
struct Dinic{
    int n, m, s, t;
    vector<Edge> edges;
    vector<int> G[maxn];
    bool vis[maxn];
    int d[maxn];
    int cur[maxn];
    void init(int n){
        this->n = n;
        edges.clear();
        for(int i = 0; i < n; ++i) G[i].clear();
    }
    void AddEdge(int from, int to, int cap){
        edges.push_back(Edge(from ,to, cap, 0));
        edges.push_back(Edge(to, from, 0, 0));
        m = edges.size();
        G[from].push_back(m - 2);
        G[to].push_back(m - 1);
    }
    bool BFS(){
        memset(vis, false, sizeof(vis));
        queue<int> Q;
        Q.push(s);
        d[s] = 0;
        vis[s] = 1;
        while(!Q.empty()){
            int x = Q.front(); Q.pop();
            for(int i = 0; i < G[x].size(); ++i){
                Edge & e = edges[G[x][i]];
                if(!vis[e.to] && e.cap > e.flow){
                    vis[e.to] = 1;
                    d[e.to] = d[x] + 1;
                    Q.push(e.to);
                }
            }
        }
        return vis[t];
    }
    int DFS(int x, int a){
        if(x == t || a == 0) return a;
        int flow = 0, f;
        for(int &i = cur[x]; i < G[x].size(); ++i){
            Edge &e = edges[G[x][i]];
            if(d[x] + 1 == d[e.to] && (f = DFS(e.to, min(a, e.cap - e.flow))) > 0){
                e.flow += f;
                edges[G[x][i]^1].flow -= f;
                flow += f;
                a -= f;
                if(a == 0) break;
            }
        }
        return flow;
    }
    void Maxflow(int s, int t){
        this->s = s; this->t = t;
        int flow = 0;
        while(BFS()){
            memset(cur, 0, sizeof(cur));
            flow += DFS(s, INF);
        }
        vector<Edge> re;
        int m = n / 2 - 1;
        for(int u = 1; u < n - 1; ++u){
            for(int i = 0; i < G[u].size(); ++i){
                Edge &e = edges[G[u][i]];
                if(e.to - e.from == m) continue;
                if(e.flow <= 0 || e.cap <= 0) continue;
                if(e.to == 0 || e.to == n - 1) continue;
                if(e.from == 0 || e.from == n - 1) continue;
                if(e.to > m) e.to -= m;
                if(e.from > m) e.from -= m;
                re.push_back(e);
            }
        }
        printf("%d %d\n", flow, re.size());
        for(int i = 0; i < re.size(); ++i){
            printf("%d %d %d\n", re[i].from, re[i].to, re[i].flow);
        }
    }
}solve;
int c[maxm];
int machine[maxm][2][maxn];
bool can(int *a ,int *b, int p){
    for(int k = 0; k < p; ++k, ++a, ++b){
        if(*b == 2) continue;
        if(*a != *b) return false;
    }
    return true;
}
int judge(int *a, int p){
    bool ok[2]; ok[0] = ok[1] = true;
    for(int k = 0; k < p; ++k, ++a)if(*a != 2){
        if(*a != 0) ok[0] = false;
        if(*a != 1) ok[1] = false;
    }
    if(ok[0]) return 1;
    else if(ok[1]) return -1;
    return 0;
}
void build(int p, int n){
    for(int i = n + 1; i <= n * 2; ++i){
        for(int j = 1; j <= n; ++j){
            bool ok = true;
            int *a = machine[i - n][1];
            int *b = machine[j][0];
            if(can(a, b, p)) solve.AddEdge(i, j, INF);
        }
    }
    for(int i = 1; i <= n; ++i){
        solve.AddEdge(i, i + n, c[i]);
        for(int j = n + 1; j <= 2 * n; ++j){
            bool ok = true;
            int *a = machine[i][0];
            int *b = machine[j - n][1];
            if(can(b, a, p)) solve.AddEdge(j, i, INF);
        }
    }
    for(int i = 1; i <= n; ++i){
        int *a = machine[i][0];
        int res = judge(a, p);
        if(res == 1) {
            solve.AddEdge(0, i, INF);
        }else if(res == -1){
            solve.AddEdge(2 * n + 1, i, INF);
        }
        a = machine[i][1];
        res = judge(a, p);
        if(res == 1) {
            solve.AddEdge(i + n, 0, INF);
        }else if(res == -1){
            solve.AddEdge(i + n, 2 * n + 1, INF);
        }
    }
}
int main()
{
    int p, n;
    scanf("%d %d", &p, &n);
    for(int i = 1; i <= n; ++i){
        scanf("%d", &c[i]);
        for(int j = 0; j < p; ++j)
            scanf("%d", &machine[i][0][j]);
        for(int j = 0; j < p; ++j)
            scanf("%d", &machine[i][1][j]);
    }
    solve.init(2 * n + 2);
    build(p, n);
    n = 2 * n + 1;
    solve.Maxflow(0, n);
    return 0;
}