// Basic Algorithm->Greedy Algorithm,Data Structure->Queue,Dynamic Programming->Priority Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define oo 1000000000
using namespace std;
struct node
{
       ll d,p;
       bool operator < (const node &x) const
       {
              return p>x.p;
       }
}r[100005];
ll n,m,b[100005];
priority_queue<node> myqueue;
bool cmp(node a,node b)
{
       return a.d<b.d;
}
int main()
{ 
       ll i,h,ans; 
       node p;
       while (~scanf("%I64d%I64d",&n,&m))
       {
              for (i=1;i<=n;i++) scanf("%I64d",&b[i]);
              for (i=1;i<=m;i++) scanf("%I64d",&r[i].d);
              for (i=1;i<=m;i++) scanf("%I64d",&r[i].p);
              sort(b+1,b+1+n);
              sort(r+1,r+1+m,cmp); 
              while (!myqueue.empty()) myqueue.pop();
              h=m;
              ans=0;
              for (i=n;i>=1;i--)
              {
                     while (h && r[h].d>=b[i]) myqueue.push(r[h]),h--;
                     if (myqueue.empty()) 
                     {
                             printf("No\n");
                             goto A;
                     }
                     p=myqueue.top();
                     myqueue.pop();
                     ans+=p.p;
              }
              printf("%I64d\n",ans); 
              A: ;
       }
       return 0;
}