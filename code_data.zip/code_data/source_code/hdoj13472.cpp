// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define Max 100010
int f;
struct node
{
	int tt;
	node *left;
	node *right;
	node(int k)
	{
		tt = k;
		left = NULL;
		right = NULL;
	}
};
node *insert(node *root,int k) 
{
	if(root==NULL)
	{
		node *pp = new node(k);
		return pp;
	}
	else
	{
		if(k<root->tt)
			root->left = insert(root->left,k);
		else root->right = insert(root->right,k);
		return root;
	}
}
void prodfs(node *root)   
{
	if(root==NULL)
		return ;
	if(!f)
	{
		printf("%d",root->tt);
		f=1;
	}
	else printf(" %d",root->tt);
	prodfs(root->left);
	prodfs(root->right);
}
int main()
{
	int i,j,n;
	while(~scanf("%d",&n))
	{
		node *root=NULL;
		int k;
		f=0;
		for(i=0;i<n;i++)
		{
			scanf("%d",&k);
			root = insert(root,k);
		}
		prodfs(root);
		printf("\n");
	}
	return 0;
}