// Graph Algorithm->Steiner Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
using namespace std;
struct node{int x,y,z;};
int n,m,tot,p1,p2,sx,sy,flag[15][15],a[15][15],f[15][15][3010];
int px[4]={1,-1,0,0},py[4]={0,0,1,-1};
node Q[110],pre[15][15][3010];
void SPFA(int s)
{
    while (p1<p2)
    {
        p1++;int x1=Q[p1%(n*m)].x,y1=Q[p1%(n*m)].y;
        flag[x1][y1]=0;
        for (int i=0;i<4;i++)
        {
            int x2=x1+px[i],y2=y1+py[i];
            if (x2<1||x2>n||y2<1||y2>m) continue;
            if (f[x1][y1][s]+a[x2][y2]<f[x2][y2][s])
            {
                f[x2][y2][s]=f[x1][y1][s]+a[x2][y2];
                pre[x2][y2][s].x=x1;
                pre[x2][y2][s].y=y1;
                pre[x2][y2][s].z=s;
                if (!flag[x2][y2])
                {
                    flag[x2][y2]=1;
                    p2++;
                    Q[p2%(n*m)].x=x2;Q[p2%(n*m)].y=y2;
                }
            }
        }
    }
}
void DFS(int x,int y,int s)
{
    if (!pre[x][y][s].z) return; 
    flag[x][y]=1;
    DFS(pre[x][y][s].x,pre[x][y][s].y,pre[x][y][s].z);
    if (pre[x][y][s].x==x&&pre[x][y][s].y==y)
        DFS(pre[x][y][s].x,pre[x][y][s].y,s^pre[x][y][s].z);
}
int main()
{
    scanf("%d%d",&n,&m);
    memset(f,0x3f,sizeof(f));
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++)
        {
            scanf("%d",&a[i][j]);
            if (!a[i][j]){f[i][j][1<<tot]=0;tot++;}
        }
    for (int s=1;s<(1<<tot);s++)
    {
        for (int i=1;i<=n;i++)
            for (int j=1;j<=m;j++)
                for (int s1=s&(s-1);s1;s1=(s1-1)&s)
                if (f[i][j][s1]+f[i][j][s-s1]-a[i][j]<f[i][j][s])
                {
                    f[i][j][s]=f[i][j][s1]+f[i][j][s-s1]-a[i][j];
                    pre[i][j][s].x=i;pre[i][j][s].y=j;pre[i][j][s].z=s1;
                }
        p1=p2=-1;
        memset(flag,0,sizeof(flag));
        for (int i=1;i<=n;i++)
            for (int j=1;j<=m;j++) if (f[i][j][s]<INF)
            {
                p2++;
                Q[p2%(n*m)].x=i;Q[p2%(n*m)].y=j;flag[i][j]=1;
            }
        SPFA(s);
    }
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++) if (!a[i][j]){sx=i;sy=j;}
    printf("%d\n",f[sx][sy][(1<<tot)-1]);
    memset(flag,0,sizeof(flag));
    DFS(sx,sy,(1<<tot)-1);
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=m;j++)
        {
            if (a[i][j]==0) putchar('x');else
            if (flag[i][j]) putchar('o');else putchar('_');
        }
        puts("");
    }
}