// Data Structure->Stack,Data Structure->Queue,Dynamic Programming->Slope Optimization,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MP(x, y) make_pair(x, y)
typedef long long LL;
const int N = 1e5+5;
struct fs{
    LL fz, fm;
    fs(){fz = 0, fm = 1;};
    fs(LL fz2, LL fm2) : fz(fz2) , fm(fm2) {
        if(fm < 0){
            fz = -fz;
            fm = -fm;
        }
    }
    bool operator <(const fs &rhs) const{
        return fz * rhs.fm < fm * rhs.fz;
    }
    bool operator <(const LL rhs) const{
        return *this < fs(rhs, 1LL);
    }
};
int p[N], cnt;
struct edge{
    int v, w, nxt;
    edge(){}
    edge(int v, int w, int nxt) : v(v), w(w), nxt(nxt) {}
}E[N*2];
void addedge(int u, int v, int w){
    E[cnt].v = v, E[cnt].w = w, E[cnt].nxt = p[u], p[u] = cnt++;
}
void init(){
    memset(p, -1, sizeof(p)); cnt = 0;
}
void getmax(LL &x, LL y){
    if(y > x) x = y;
}
int head, tail;
LL ans, que[N], dp[N], sum[N]; 
LL P;
LL sqr(LL x){
    return x * x;
}
int getDP(int i, int j){
    return dp[j] + P + sqr(sum[i] - sum[j]);
}
fs getxl(int j, int k){ 
    return fs(dp[j] + sqr(sum[j]) - dp[k] - sqr(sum[k]), 2 * (sum[j] - sum[k]));
}
void dfs(int u, int fa, int len){
    sum[u] = sum[fa] + len;
    
    stack <pair <int, int> > stk;
    if(u != 1){
        while(tail - head >= 2 && getxl(que[head], que[head+1]) < sum[u]) stk.push(MP(0, que[head++]));
        dp[u] = getDP(u, que[head]);
        
        while(tail - head >= 2 && getxl(que[tail-1], u) < getxl(que[tail-2], que[tail-1])) stk.push(MP(2, que[--tail]));
    }
    que[tail++] = u;
    stk.push(MP(3, u));
    getmax(ans, dp[u]);
    for(int i = p[u]; ~i; i = E[i].nxt){
        int v = E[i].v, w = E[i].w;
        if(v == fa) continue;
        dfs(v, u, w);
    }
    while(!stk.empty()){
        int op = stk.top().first;
        int v = stk.top().second;
        stk.pop();
        if(op == 0) que[--head] = v;
        else if(op == 2) que[tail++] = v;
        else if(op == 3) tail--;
        else head++;
    }
}
int main(){
    int T, n;
    scanf("%d", &T);
    while(T--){
        scanf("%d%lld", &n, &P);
        init();
        memset(sum, 0, sizeof(sum));
        for(int i = 1; i < n; i++){
            int u, v, w;
            scanf("%d%d%d", &u, &v, &w);
            addedge(u, v, w);
            addedge(v, u, w);
        }
        ans = -1;
        head = tail = 0;
        dp[1] = -P;
        dfs(1, 0, 0);
        printf("%lld\n", ans);
    }
    return 0;
}