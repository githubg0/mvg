// Math and Computational Geometry->Inverse Element,Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
using namespace std;
int n,m;
ll c[2][100005];
int a[100005];
int lowbit(int x){
    return x&(-x);
}
void update(int p,int i,ll val){
    for(int x=i;x<=n;x+=lowbit(x))
        c[p][x]+=val;
}
ll getsum(int p,int i){
    ll sum=0;
    for(int x=i;x;x-=lowbit(x))
        sum+=c[p][x];
    return sum;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        update(0,i,a[i]);
        update(1,i,(ll)(n-i+1)*a[i]);
    }   
    for(int i=1;i<=m;i++)
    {
        char h[10];
        int x,y;
        scanf("%s",h);
        if(h[0]=='M'){
            scanf("%d%d",&x,&y);
            update(0,x,y-a[x]);
            update(1,x,(ll)(n-x+1)*(y-a[x])); 
            a[x]=y;
         }
         else {
            scanf("%d",&x);
            printf("%lld\n",getsum(1,x)-getsum(0,x)*(n-x));
         }
    }
    return 0;
}