// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL __int64_t
#define min(a,b) ((a)<(b)?(a):(b))
using namespace std;
const int maxn=10000+10;
const int inf=0x3f3f3f3f;
int l1,l2,l3,c1,c2,c3,n,s,e;
int dis[maxn];
int f[maxn];
int search(int de,int cm,int cost)
{
	int l=s,r=de,mid;
	while(r-l>0)
	{
		mid=l+(r-l)/2;
		if((dis[de]-dis[mid])<=cm) r=mid;
		else l=mid+1;
	}
	return f[r]+cost;
}
int main()
{
	while(~scanf("%d%d%d%d%d%d",&l1,&l2,&l3,&c1,&c2,&c3))
	{
		scanf("%d",&n);
		scanf("%d%d",&s,&e);
		int  tem;
		if(s>e)
		{
			tem=s;
			s=e;
			e=tem;
		}
		int i,j;
		for(i=2;i<=n;i++) scanf("%d",&dis[i]);
		f[s]=0;
		for(i=s+1;i<=e;i++)
		{
			f[i]=inf;
			f[i]=min(f[i],search(i,l1,c1));
			f[i]=min(f[i],search(i,l2,c2));
			f[i]=min(f[i],search(i,l3,c3));
		}
		printf("%d\n",f[e]);
	}
	return 0;
}