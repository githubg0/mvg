// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define FOR(i,x,y) for(int i=(x);i<=(y);i++)
#define DOR(i,x,y) for(int i=(x);i>=(y);i--)
#define N 20003
#define M 50003
typedef long long LL;
using namespace std;
template<const int maxn,const int maxm>struct Linked_list
{
    int head[maxn],to[maxm],nxt[maxm],tot;
    void clear(){memset(head,-1,sizeof(head));tot=0;}
    void add(int u,int v){to[++tot]=v,nxt[tot]=head[u];head[u]=tot;}
    #define EOR(i,G,u) for(int i=G.head[u];~i;i=G.nxt[i])
};
Linked_list<N,M>G;
int dfn[N],low[N],bel[N],stk[N],ind[N],oud[N];
int ord,n,m,B,tp,ans;
void tarjan(int u)
{
    dfn[u]=low[u]=++ord;
    stk[++tp]=u;
    EOR(i,G,u)
    {
        int v=G.to[i];
        if(!dfn[v])
        {
            tarjan(v);
            low[u]=min(low[u],low[v]);
        }else if(!bel[v])low[u]=min(low[u],dfn[v]);
    }
    if(dfn[u]==low[u])
    {
        B++;int v;
        do
        {
            v=stk[tp--];
            bel[v]=B;
        }while(u!=v);
    }
}
void clear()
{
    G.clear();
    memset(dfn,0,sizeof(dfn));
    memset(bel,0,sizeof(bel));
    memset(ind,0,sizeof(ind));
    memset(oud,0,sizeof(oud));
    ord=ans=B=tp=0;
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        clear();
        FOR(i,1,m)
        {
            int u,v;
            scanf("%d%d",&u,&v);
            G.add(u,v);
        }
        FOR(i,1,n)if(!dfn[i])tarjan(i);
        int I=0,O=0;
        FOR(u,1,n)
            EOR(i,G,u)
            {
                int v=G.to[i];
                if(bel[u]==bel[v])continue;
                oud[bel[u]]++,ind[bel[v]]++;
            }
        if(B==1)printf("0\n");
        else
        {
            FOR(i,1,B)
            {
                if(!ind[i])I++;
                if(!oud[i])O++;
            }
            printf("%d\n",max(I,O));
        }
    }
    return 0;
}