// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x7fffffff
#define eps 1e-6
#define LL long long
#define CLRi for(int i=0;i<n;i++)
#define CLRj for(int j=0;j<n;j++)
#define CLRk for(int k=0;k<n;k++)
#define debug puts("==fuck==");
#define acfun std::ios::sync_with_stdio(false)
#define Nmax 1001
#define Mmax 1001*1001
using namespace std;
int main()
{
    int n,m;
    while(scanf("%d%d",&n,&m),n||m)
    {
        int l,r;
        int mm=m<<1;
        int d=(int)sqrt(mm);
        while(d>0)
        {
            if(mm%d==0)
            {
                int tmp=(d-1)*d/2;
                if((m-tmp)%d==0)
                {
                    l=(m-tmp)/d;
                    r=l+d-1;
                printf("[%d,%d]\n",l,r);
                }
            }
            d--;
        }
        printf("\n");
    }
}