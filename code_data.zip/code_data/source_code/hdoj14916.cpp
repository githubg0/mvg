// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 10010;
const long long inf = 1e17;
typedef long long ll;
int cnt, head[maxn];
int n;
struct node
{
    ll l, r;
} a[maxn];
struct edge
{
    int to, nxt;
} e[maxn << 1];
void init()
{
    cnt = 0;
    memset(head, -1, sizeof(head));
    for (int i = 1; i <= n; i++)
    {
        a[i].l = 1, a[i].r = inf;
    }
}
void add(int u, int v)
{
    e[cnt].to = v;
    e[cnt].nxt = head[u];
    head[u] = cnt++;
}
bool dfs(int u, int fa)
{
    long long sl = 0;
    for (int i = head[u]; ~i; i = e[i].nxt)
    {
        int v = e[i].to;
        if (fa == v) continue;
        if (!dfs(v, u))
            return false;
        sl += a[v].l;
    }
    a[u].l = max(a[u].l, sl + 1);
    return a[u].l <= a[u].r;
}
int main()
{
    while (~scanf("%d", &n))
    {
        init();
        for (int i = 2; i <= n; i++)
        {
            int u;
            scanf("%d", &u);
            add(u, i);
            add(i, u);
        }
        int m;
        scanf("%d", &m);
        while (m--)
        {
            int u, num;
            char s;
            scanf("%d %c %d", &u, &s, &num);
            if (s == '=')
            {
                a[u].l = max(a[u].l, (ll)num);
                a[u].r = min(a[u].r, (ll)num);
            }
            if (s == '<')
            {
                a[u].r = min(a[u].r, (ll)(num - 1));
            }
            if (s == '>')
            {
                a[u].l = max(a[u].l, (ll)(num + 1));
            }
        }
        
        
        if (dfs(1, -1))
            puts("True");
        else
            puts("Lie");
    }
    return 0;
}