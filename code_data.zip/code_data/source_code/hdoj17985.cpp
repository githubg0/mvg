// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

const int N = 200;
using namespace std;
const int inf=0x3f3f3f3f;
#define Del(a,b) memset(a,b,sizeof(a))
struct Node
{
    int from,to,cap,flow;
};
vector <int> v[N];
vector<Node> e;
int vis[N],cur[N];
void add_Node(int from,int to,int cap)
{
    e.push_back((Node){from,to,cap,0});
    e.push_back((Node){to,from,0,0});
    int tmp=e.size();
    v[from].push_back(tmp-2);
    v[to].push_back(tmp-1);
}
bool bfs(int s,int t)
{
    Del(vis,-1);
    queue<int> q;
    q.push(s);
    vis[s] = 0;
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        for(int i=0;i<v[x].size();i++)
        {
            Node tmp = e[v[x][i]];
            if(vis[tmp.to]<0 && tmp.cap>tmp.flow)  
            {
                vis[tmp.to]=vis[x]+1;
                q.push(tmp.to);
            }
        }
    }
    if(vis[t]>0)
        return true;
    return false;
}
int dfs(int o,int f,int t)
{
    if(o==t || f==0)  
        return f;
    int a = 0,ans=0;
    for(int &i=cur[o];i<v[o].size();i++) 
    {
        Node &tmp = e[v[o][i]];
        if(vis[tmp.to]==(vis[o]+1) && (a = dfs(tmp.to,min(f,tmp.cap-tmp.flow),t))>0)
        {
            tmp.flow+=a;
            e[v[o][i]^1].flow-=a; 
            ans+=a;
            f-=a;
            if(f==0)  
                break;
        }
    }
    return ans;  
}
int dinci(int s,int t)
{
    int ans=0;
    while(bfs(s,t))
    {
        Del(cur,0);
        int tm=dfs(s,inf,t);
        ans+=tm;
    }
    return ans;
} void v_clear(int n)
{
    for(int i=0;i<=n;i++)
        v[i].clear();
    e.clear();
}
int main()
{
    
    int T;
    scanf("%d",&T);
    for(int cas=1;cas<=T;cas++)
    {
        int n,m,sum=0;
        scanf("%d%d",&n,&m);
        int s=0,t=n+m+1,x;
        for(int i=1;i<=n;i++)
            scanf("%d",&x),add_Node(s,i,x),sum+=x;
        for(int i=1;i<=m;i++)
            scanf("%d",&x),add_Node(n+i,t,x);
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&x);
            while(x--)
            {
                int tmp;
                scanf("%d",&tmp);
                add_Node(i,n+tmp+1,inf);
            }
        }
        for(int i=1;i<=m;i++)
        {
            for(int j=1;j<=m;j++)
            {
                scanf("%d",&x);
                if(x)
                    add_Node(n+i,n+j,inf);
            }
        }
        printf("Case #%d: %d\n",cas,sum-dinci(s,t));
        v_clear(t);
    }
    return 0;
}