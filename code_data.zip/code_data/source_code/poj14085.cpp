// Graph Algorithm->Kruskal's Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment (linker,"/STACK:102400000,102400000")
#define maxn 10105
#define MAXN 2005
#define mod 1000000009
#define INF 0x3f3f3f3f
#define pi acos(-1.0)
#define eps 1e-6
#define lson rt<<1,l,mid
#define rson rt<<1|1,mid+1,r
#define FRE(i,a,b)  for(i = a; i <= b; i++)
#define FREE(i,a,b) for(i = a; i >= b; i--)
#define FRL(i,a,b)  for(i = a; i < b; i++)
#define FRLL(i,a,b) for(i = a; i > b; i--)
#define mem(t, v)   memset ((t) , v, sizeof(t))
#define sf(n)       scanf("%d", &n)
#define sff(a,b)    scanf("%d %d", &a, &b)
#define sfff(a,b,c) scanf("%d %d %d", &a, &b, &c)
#define pf          printf
#define DBG         pf("Hi\n")
typedef long long ll;
using namespace std;
struct Edge{
    int u,v,w;
}edge[maxn];
int father[2222];
int n,m;
int cmp(Edge a,Edge b)
{
    return a.w<b.w;
}
int find_father(int x)
{
    if (x!=father[x])
        father[x]=find_father(father[x]);
    return father[x];
}
void Kruskal()
{
    int i;
    FRL(i,0,n+10)
        father[i]=i;
    int cnt=0;
    int ans=-1;
    FRL(i,0,m)
    {
        int fa=find_father(edge[i].u);
        int fb=find_father(edge[i].v);
        if (fa!=fb)
        {
            father[fa]=fb;
            ans=max(ans,edge[i].w);
            cnt++;
        }
        if (cnt==n-1) break;
    }
    pf("%d\n",ans);
}
int main()
{
    int i,j;
    while (~sff(n,m))
    {
        FRL(i,0,m)
            sfff(edge[i].u,edge[i].v,edge[i].w);
        sort(edge,edge+m,cmp);
        Kruskal();
    }
    return 0;
}