// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Maxn=1010;
const int Maxm=5010;
int n,m,size;
int first[Maxn],sum[Maxn],vis[Maxn];
double l,r,mid,dis[Maxn],num[Maxn];
struct shu{int to,next;double len;};
shu edge[Maxm<<1];
inline int get_int()
{
	int x=0,f=1;
	char c;
	for(c=getchar();(!isdigit(c))&&(c!='-');c=getchar());
	if(c=='-') f=-1,c=getchar();
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+c-'0';
	return x*f;
}
inline void build(int x,int y,int z)
{
	edge[++size].next=first[x];
	first[x]=size;
	edge[size].to=y,edge[size].len=z;
}
inline bool SPFA(int s)
{
	memset(vis,0,sizeof(vis));
	memset(sum,0,sizeof(sum));
	memset(dis,0x3f,sizeof(dis));
	queue<int>q;q.push(s),vis[s]=1,dis[s]=0;
	while(q.size())
	{
	  int p=q.front();q.pop();
	  for(int u=first[p];u;u=edge[u].next)
	  {
	    int to=edge[u].to;vis[to]=0;
	    if(dis[to]>dis[p]+edge[u].len*mid-num[p])
	    {
	      dis[to]=dis[p]+edge[u].len*mid-num[p];
	      if(!vis[to])
	  	  {
	  	    sum[to]++,vis[to]=1,q.push(to);
	  	    if(sum[to]>=n) return 1;
	      }
	    }
	  }
	}
	return 0;
}
inline bool check(double mid)
{
	for(int i=1;i<=n;i++) if(SPFA(i)) return 1;
	return 0;
}
inline void solve()
{
	l=0.0,r=100.0;
	while(r-l>=1e-3)
	{
	  mid=(l+r)/2;
	  if(check(mid)) l=mid;
	  else r=mid;
	}
}
int main()
{
	n=get_int(),m=get_int();
	for(int i=1;i<=n;i++) num[i]=get_int();
	for(int i=1;i<=m;i++)
	{
	  int x=get_int(),y=get_int(),z=get_int();
	  build(x,y,z);
	}
	solve();
	printf("%.2f",l);
	return 0;
}