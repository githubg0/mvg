// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
using namespace std;
const int maxn=1e5;
int n,m,r,t;
int f[maxn];
struct P
{
    int u,v,w;
    bool operator < (const P &a)const
    {
        return w>a.w;
    }
}p[maxn];
int Find(int x)
{
    if(f[x]==-1) return x;
    else return f[x]=Find(f[x]);
}
int Kruskal()
{
    int ans=0;
    sort(p+1,p+r+1);
    for(int i=1;i<=r;i++)
    {
        int a=Find(p[i].u);
        int b=Find(p[i].v+n);
        if(a!=b)
        {
            ans+=p[i].w;
            f[a]=b;
        }
    }
    return ans;
}
int main()
{
    scanf("%d",&t);
    while(t--)
    {
        memset(f,-1,sizeof(f));
        scanf("%d%d%d",&n,&m,&r);
        for(int i=1;i<=r;i++)
            scanf("%d%d%d",&p[i].u,&p[i].v,&p[i].w);
        printf("%d\n",(n+m)*10000-Kruskal());
    }
    return 0;
}