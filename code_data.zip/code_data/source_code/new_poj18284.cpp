// Dynamic Programming->Priority Queue,Graph Algorithm->Dijkstra's Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define forl(i,a,b)  for(int i=(a);i<(b);++i)
#define forle(i,a,b) for(int i=(a);i<=(b);++i)
#define forg(i,a,b)  for(int i=(a);i>(b);--i)
#define forge(i,a,b) for(int i=(a);i>=(b);--i)
#define mes(a,v)  memset(a, v, sizeof (a) );
#define cpy(a,b)  memcpy(a, b, sizeof (a) );
#define mesn(a, v, n) memset(a, v, (n)*sizeof((a)[0]))
#define cpyn(a, b, n) memcpy(a, v, (n)*sizeof((a)[0]))
const int maxn=2000;
const int maxe=2000000;
const int inf=200000000;
struct HeadNode
{
    int d,u;
    bool operator < (const HeadNode &r) const
    {
        return r.d<d;
    }
};
struct NodeEdges
{
    int to;
    int next;
    int w;
};
NodeEdges Edges[maxe];
int head[maxn],dist[maxn],dist1[maxn],u[maxe],v[maxe],w[maxe];
bool inque[maxn];
int n,x,m,Numedges;
void AddEdges(int u,int v,int w)
{
    Numedges++;
    Edges[Numedges].to=v;
    Edges[Numedges].w=w;
    Edges[Numedges].next=head[u];
    head[u]=Numedges;
}
void Dijktra(int s,int n)
{
    memset(dist,0,sizeof(dist));
    memset(inque,0,sizeof(inque));
    priority_queue<HeadNode>q;
    for(int i=1;i<=n;i++)   dist[i]=inf;
    dist[s]=0;
    q.push((HeadNode){dist[s],s});
    while(!q.empty())
    {
        HeadNode pi=q.top();
        q.pop();
        int u=pi.u;
        if(inque[u])    continue;
        inque[u]=true;
        for(int k=head[u];k!=-1;k=Edges[k].next)
        {
            if(dist[Edges[k].to]>Edges[k].w+pi.d)
            {
                dist[Edges[k].to]=Edges[k].w+pi.d;
                q.push((HeadNode){dist[Edges[k].to],Edges[k].to});
            }
        }
    }
}
int main()
{
    freopen("in.txt","r",stdin);
    while(scanf("%d%d%d",&n,&m,&x)==3)
    {
        Numedges=0;
        memset(Edges,0,sizeof(Edges));
        memset(head,-1,sizeof(head));
        memset(dist1,0,sizeof(dist1));
        memset(u,0,sizeof(u));
        memset(v,0,sizeof(v));
        memset(w,0,sizeof(w));
        for(int i=1;i<=m;i++)
        {
            scanf("%d%d%d",&u[i],&v[i],&w[i]);
            AddEdges(u[i],v[i],w[i]);
        }
        Dijktra(x,n);
        for(int i=1;i<=n;i++)   dist1[i]=dist[i];
        Numedges=0;
        memset(head,-1,sizeof(head));
        memset(Edges,0,sizeof(Edges));
        for(int i=1;i<=m;i++)
            AddEdges(v[i],u[i],w[i]);
        Dijktra(x,n);
        int Max_ans=-inf;
        for(int i=1;i<=n;i++)
            Max_ans=max(dist[i]+dist1[i],Max_ans);
        printf("%d\n",Max_ans);
    }
    return 0;
}