// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define maxn 20
#define inf 1000000005
int a[maxn],vis[maxn];
int min1=inf;
int n,b,sum;
int dfs(int a[],int m)
{
	int i,j,k;
	for(i=m;i<=n;i++)
	{
		if(vis[i]==0)
		{
			sum+=a[i];
			if(sum<b)
			{
				vis[i]=1;
				dfs(a,i+1);
				vis[i]=0;
				sum-=a[i];
			}
			else
			{
				if(sum<min1)min1=sum;
				sum-=a[i];
			}
		}
	}
	return min1;
}
int main()
{
	int i,j;
	int temp;
	scanf("%d%d",&n,&b);
	sum=0;
	memset(vis,0,sizeof(vis));
	for(i=1;i<=n;i++)scanf("%d",&a[i]);
	printf("%d\n",dfs(a,1)-b);
	return 0;
}