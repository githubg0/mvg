// Data Structure->Stack,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 1000010
#define LL long long
using namespace std;
int n, idc, l=0, r=0; 
int head[N], sum[N], vis[N], in[N], q[N<<4];
LL ans;
struct Edge{
    int to, nxt, w;
}ed[N<<1];
void adde(int u, int v, int w){
    ed[++idc].to = v;
    ed[idc].nxt = head[u];
    ed[idc].w = w;
    head[u] = idc;
}
void bfs(){
    q[r++] = 1;
    while(l < r){
        int u = q[l++]; vis[u] = 1;
        for(int k=head[u]; k; k=ed[k].nxt){
            int v = ed[k].to;
            if( vis[v] ) continue;
            in[u]++;
            q[r++] = v;
        }
    }
}
void work(){
    while(l < r){
        int u = q[l++]; sum[u] += 1; vis[u] = 1;
        for(int k=head[u]; k; k=ed[k].nxt){
            int v = ed[k].to;
            if( vis[v] ) continue;
            sum[v] += sum[u];
            ans += (LL)abs(n - 2 * sum[u]) * (LL)ed[k].w;
            if(--in[v] == 0) q[r++] = v;
        }
    }
}
int main(){
    freopen ("road.in", "r", stdin);
    freopen ("road.out", "w", stdout);
    scanf("%d", &n);
    for(int i=1; i<n; i++){
        int u, v, w; scanf("%d%d%d", &u, &v, &w);
        adde (u, v, w); adde (v, u, w);
    }
    bfs();
    
    memset(q, 0, sizeof(q));
    memset(vis, 0, sizeof(vis));
    l = r = 0;
    for(int i=1; i<=n; i++) if(in[i] == 0) q[r++] = i;
    work();
    cout << ans << endl;
    return 0;
}