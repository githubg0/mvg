// Data Structure->Suffix Array
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define rep(i,n) for(int i = 0; i < n; i++)
const int MAXSIZE = 1e5+200;
int rk[MAXSIZE], sa[MAXSIZE], height[MAXSIZE], wa[MAXSIZE], res[MAXSIZE];
int w[MAXSIZE];
int len;
int n;
void getSa(int up) {
	int *k = rk, *id = height, *r = res, *cnt = wa;
	rep(i, up) cnt[i] = 0;
	rep(i, len) cnt[k[i] = w[i]]++;
	rep(i, up) cnt[i + 1] += cnt[i];
	for (int i = len - 1; i >= 0; i--) {
		sa[--cnt[k[i]]] = i;
	}
	int d = 1, p = 0;
	while (p < len){
		for (int i = len - d; i < len; i++) id[p++] = i;
		rep(i, len)  if (sa[i] >= d) id[p++] = sa[i] - d;
		rep(i, len) r[i] = k[id[i]];
		rep(i, up) cnt[i] = 0;
		rep(i, len) cnt[r[i]]++;
		rep(i, up) cnt[i + 1] += cnt[i];
		for (int i = len - 1; i >= 0; i--) {
			sa[--cnt[r[i]]] = id[i];
		}
		swap(k, r);
		p = 0;
		k[sa[0]] = p++;
		rep(i, len - 1) {
			if (sa[i] + d < len && sa[i + 1] + d < len && r[sa[i]] == r[sa[i + 1]] && r[sa[i] + d] == r[sa[i + 1] + d])
				k[sa[i + 1]] = p - 1;
			else k[sa[i + 1]] = p++;
		}
		if (p >= len) return;
		d <<= 1, up = p, p = 0;
	}
}
void getHeight() {
	int i, k, h = 0;
	rep(i, len) rk[sa[i]] = i;
	rep(i, len) {
		if (rk[i] == 0)
			h = 0;
		else {
			k = sa[rk[i] - 1];
			if (h) h--;
			while (w[i + h] == w[k + h]) h++;
		}
		height[rk[i]] = h;
	}
}
void getSuffix() {
	int up = 126;
	getSa(up + 1);
	getHeight();
}
bool vis[105];
int belong[MAXSIZE];
int solve(){
    int l = 0, r =1000;
    while (l<=r){
        int mid = (l+r)>>1;
        bool flag = false;
        memset(vis,0,sizeof(vis));
        int k=1; 
        vis[sa[0]] = true;
        for (int i=1;i<len;++i){
            if (flag) break;
            if (height[i]>=mid){
                if (!vis[belong[sa[i]]]){
                    vis[belong[sa[i]]] = true;
                    k++;
                }
            }
            else{
                memset(vis,0,sizeof(vis));
                vis[belong[sa[i]]] = true;
                if (k>n/2) flag = true;
                k = 1;
            }
        }
        if (k>n/2) flag = true;
        if (flag) l = mid+1;
            else r = mid-1;
    }
    return r;
}
void print(int ans){
    memset(vis,0,sizeof(vis));
    int k=1;
    vis[sa[0]] = true;
    for (int i=1;i<len;++i){
        if (height[i]>=ans){
            if (!vis[belong[sa[i]]]){
                vis[belong[sa[i]]] = true;
                k++;
            }
        }
        else{
            memset(vis,0,sizeof(vis));
            if (k>n/2){
                for (int j=sa[i-1];j<sa[i-1]+ans;++j){
                    putchar(w[j]-101+'a');
                }
                putchar(10);
            }
            vis[belong[sa[i]]] = true;
            k = 1;
        }
    }
    if (k>n/2){
        for (int j=sa[len-1];j<sa[len-1]+ans;++j){
            putchar(w[j]-101+'a');
        }
        putchar(10);
    }
}
char temp[1005];
int main(){
    int m;
    scanf("%d",&n);
    while (n!=0){
        len = 0;
        for (int i=1;i<=n;++i){
            scanf("%s",temp);
            for (char* j=temp;*j;++j){
                belong[len] = i;
                w[len++] = *j-'a'+101;
            }
            belong[len] = i;
            w[len++] = i;
        }
        getSuffix();
        int ans = solve();
        
        if (ans) print(ans);
            else printf("?\n");
        scanf("%d",&n);
        putchar(10);
    }
    return 0;
}