// Graph Algorithm->Kruskal's Algorithm,Data Structure->Disjoint Set Union (DSU)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 10000
using namespace std;
struct node
{
    int first;
    int second;
    int len;
}temp[MAXN];
int pre[MAXN];
int findRoot(int x) 
{
     while(x!=pre[x])
        x=pre[x];
     return x;
}
bool cmp(node a,node b)
{
    return a.len<b.len;
}
int main()
{
    int p,r;
    while(~scanf("%d",&p) && p!=0)
    {
        scanf("%d",&r);
        int ans=0,cnt=0;
        int i;
        for(i=1;i<=p;++i)
            pre[i]=i;
        for(i=0;i<r;++i)
            scanf("%d %d %d",&temp[i].first,&temp[i].second,&temp[i].len);
        sort(temp,temp+r,cmp);
        for(i=0;i<r;++i)
        {
            if(cnt==p-1)
                break;
            else
            {
                if(findRoot(temp[i].first)!=findRoot(temp[i].second))
                {
                    pre[findRoot(temp[i].second)]=findRoot(temp[i].first);
                    cnt++;
                    ans+=temp[i].len;
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}