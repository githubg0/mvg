// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int maxn = 1010;
const int inf = 0x3f3f3f3f;
LL dis[maxn];
int head[maxn], edgecnt, n, p, q, s, t;
int cnt[maxn];
bool inq[maxn];
struct edge{
    int to,w,next;
    edge(){}
    edge(int to, int w, int next) : to(to), w(w), next(next) {}
}E[maxn*10];
void init(){
    edgecnt = 0;
    memset(head, -1, sizeof(head));
}
void add(int u, int v, int w){
    E[edgecnt].to = v, E[edgecnt].w = w, E[edgecnt].next = head[u], head[u] = edgecnt++;
}
bool spfa(){
    queue<int>que;
    for(int i=0; i<=n; i++) dis[i]=inf;
    memset(inq,0,sizeof(inq));
    memset(cnt,0,sizeof(cnt));
    dis[0]=0;
    que.push(0);
    inq[0]=1;
    for(int i=1; i<=n; i++){
        que.push(i);
        inq[i]=1;
    }
    while(!que.empty()){
        int u = que.front();
        que.pop();
        inq[u] = 0;
        for(int i=head[u]; ~i; i=E[i].next){
            int v = E[i].to;
            int w = E[i].w;
            if(dis[u] + 1LL*w < dis[v]){
                cnt[v]++;
                dis[v] = dis[u] + 1LL*w;
                if(cnt[v]>n) return false;
                if(!inq[v]){
                    inq[v]=1;
                    que.push(v);
                }
            }
        }
    }
    return 1;
}
int main()
{
    scanf("%d %d %d %d %d", &n, &p, &q, &s, &t);
    init();
    for(int i=0; i<=n; i++){
        if(i-p>=0) add(i,i-p,-s);
        if(i-q>=0) add(i-q,i,t);
    }
    if(spfa()){
        printf("Yes\n");
        printf("%lld", dis[1]);
        for(int i=2; i<=n; i++){
            printf(" %lld", dis[i]-dis[i-1]);
        }
        printf("\n");
    }
    else{
        printf("No\n");
    }
    return 0;
}