// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAX 100
#define inf 0x3f3f3f3f
using namespace std;
#define tree_size MAX*3
struct edge
{
    int a,b,stu;
}A[MAX];
int num[10];
int d[10];
int u[10];
int main()
{
   int t;
   scanf("%d",&t);
   while(t--)
   {
       int n,m;
       scanf("%d%d",&n,&m);
     
      
      memset(num,0,sizeof(num));
       for(int i=0;i<m;i++)
       {
           scanf("%d%d",&A[i].a,&A[i].b);
           num[A[i].a]++;
           num[A[i].b]++;
       }
       if(m%2||m>24||m==22)
       {
           printf("0\n");
           continue;
       }
       int flag=0;
       for(int i=1;i<=n;i++)
       {
           if(num[i]%2)
            {
                flag=1;
                break;
            }
       }
       if(flag)
       {
           printf("0\n");
            continue;
       }
       if(m==24)
       {
           flag=0;
           for(int i=1;i<=8;i++)
           {
               if(num[i]!=6)
               {
                   flag=1;
                   break;
               }
           }
           if(!flag)
           {
               printf("2648\n");
               continue;
           }
           else
           {
               printf("0\n");
                continue;
           }
        }
       int s=pow(2.0,m)-1;
       int ans=0;
       for(int i=0;i<=s;i++)
       {
           memset(u,0,sizeof(u));
           memset(d,0,sizeof(d));
           int temp=i;
           for(int j=0;j<m;j++)
            {
                if(temp%2==0)
                    A[j].stu=0;
                else
                    A[j].stu=1;
                temp/=2;
            }
            for(int k=0;k<m;k++)
            {
                if(A[k].stu==0)
                {
                    d[A[k].a]++;
                    d[A[k].b]++;
                }
                else
                {
                        u[A[k].a]++;
                    u[A[k].b]++;
                }
            }
            ans++;
            for(int j=1;j<=n;j++)
            {
                if(d[j]!=u[j])
                {
                    ans--;
                    break;
                }
            }
       }
       printf("%d\n",ans);
   }
    return 0;
}