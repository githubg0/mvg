// Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int dix[4]={0,0,1,-1};
int diy[4]={1,-1,0,0};
char maptt1[505][505];
int vis[505][505];
struct node{
    int x;
    int y;
    int time;
    friend bool operator<(node a,node b)
    {
        return a.time>b.time; 
    }
};
int n,m,q; 
priority_queue<node>que;
void bfs()
{
    while(!que.empty())
    {
        node u=que.top();
        que.pop();
        if(u.x==1||u.x==n||u.y==1||u.y==m)
        {
            cout<<u.time+1<<endl;
            return;
        }
        for(int i=0;i<4;i++)
        {
            int x=u.x+dix[i];
            int y=u.y+diy[i];
            if(maptt1[x][y]!='#'&&vis[x][y]==0&&x>=1&&x<=n&&y>=1&&y<=m)
            {
                if(maptt1[x][y]=='.')
                {
                    node v;
                    v.x=x;
                    v.y=y;
                    v.time=u.time+1;
                    vis[x][y]=1;
                    que.push(v);
                }
                else if(maptt1[x][y]=='@')
                {
                    node v;
                    v.x=x;
                    v.y=y;
                    v.time=u.time+1+q;
                    vis[x][y]=1;
                    que.push(v);
                }
            }
        }
     } 
}
int main(void)
{
    int T;
    cin>>T;
    while(T--)
    {
        while(!que.empty())
        que.pop();
        memset(vis,0,sizeof(vis));
        cin>>n>>m>>q;
        getchar();
        for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        {
            cin>>maptt1[i][j];
            if(maptt1[i][j]=='S')
            {
                node u;
                u.x=i;
                u.y=j;
                u.time=0;
                que.push(u);
            }
        }
        bfs();
    }
    return 0;
}