// Basic Algorithm->Recursion,Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Memorization,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int vis[600005], a[25], p2[25], cnt, ans[25];
int ch(int x, int d){   
    x|=p2[d-2];
    for(int i=d+1; i<=20; i++){
        if(x&p2[i-2-d])x|=p2[i-2];
    }
    return x;
}
bool dfs(int x){
    if(vis[x]){
        if(vis[x]==1)return true;
        else return false;
    }
    for(int i=0; i<19; i++){
        if(!(x&p2[i])){
                if(!dfs(ch(x, i+2))){
                    vis[x]=1;
                    return true;
                }
        }
    }
    vis[x]=-1;
    return false;
}
int main(){
    
    int n, i, cas=1, t;
    memset(vis, 0, sizeof(vis));
    p2[0]=1;
    for(i=1; i<20; i++)
    p2[i]=p2[i-1]*2;
    while(scanf("%d", &n)&&n){
        cnt=0;
        t=p2[19]-1;
        printf("Test Case #%d\n", cas++);
        for(i=0; i<n; i++){
            scanf("%d", &a[i]);
            t^=p2[a[i]-2];
        }
        for(i=0; i<n; i++){
            if(!dfs(ch(t, a[i]))){
                ans[cnt++]=a[i];
            }
        }
        if(cnt){
            printf("The winning moves are:");
            for(i=0; i<cnt; i++)
            printf(" %d", ans[i]);
            printf("\n\n");
        }
        else printf("There's no winning move.\n\n");
    }
    return 0;
}