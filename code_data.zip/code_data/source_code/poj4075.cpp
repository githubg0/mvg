// Data Structure->Segment Tree,Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1e5+5;
struct node{
	int l,r,value;
}tree[maxn<<2];
void build(int m,int l,int r)
{
	tree[m].l=l;
	tree[m].r=r;
	tree[m].value=0;
	if(l==r)
		return;
	int mid=(l+r)>>1;
	build(m<<1,l,mid);
	build(m<<1|1,mid+1,r);
}
void updata(int m,int x)
{
	if(tree[m].l==tree[m].r)
	{
		tree[m].value++;
		return;
	}
	int mid=(tree[m].l+tree[m].r)>>1;
	if(x<=mid) updata(m<<1,x);
	else updata(m<<1|1,x);
	tree[m].value++;
}
int query(int m,int l,int r)
{
	if(l>r)return 0;
	if(tree[m].l==l&&tree[m].r==r)
		return tree[m].value;
	int mid=(tree[m].l+tree[m].r)>>1;
	int temp;
	if(r<=mid)temp=query(m<<1,l,r);
	else if(l>mid) temp=query(m<<1|1,l,r);
	else temp=query(m<<1,l,mid)+query(m<<1|1,mid+1,r);
	return temp;
}
int main()
{
	int n,a[5005];
	while(cin>>n&&n)
	{
		int cnt=0;
		build(1,0,n+1);
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
			cnt+=query(1,a[i]+1,n+1);
			updata(1,a[i]);
		}
		cout<<cnt<<endl;
	}
}