// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define outstars cout << "***********************" << endl;
#define clr(a,b) memset(a,b,sizeof(a))
#define lson l , mid  , rt << 1
#define rson mid + 1 , r , rt << 1 | 1
#define mk make_pair
#define FOR(i , x , n) for(int i = (x) ; i < (n) ; i++)
#define FORR(i , x , n) for(int i = (x) ; i <= (n) ; i++)
#define REP(i , x , n) for(int i = (x) ; i > (n) ; i--)
#define REPP(i ,x , n) for(int i = (x) ; i >= (n) ; i--)
const int MAXN = 15 + 5;
const int MAXS = 10000 + 50;
const int sigma_size = 26;
const long long LLMAX = 0x7fffffffffffffffLL;
const long long LLMIN = 0x8000000000000000LL;
const int INF = 0x7fffffff;
const int IMIN = 0x80000000;
const int inf = 1 << 30;
#define eps 1e-10
const long long MOD = 1000000000 + 7;
const int mod = 10007;
typedef long long LL;
const double PI = acos(-1.0);
typedef double D;
typedef pair<int , int> pii;
typedef vector<int> vec;
typedef vector<vec> mat;
#define Bug(s) cout << "s = " << s << endl;
double add(double a , double b)
{
    if(abs(a + b) < eps * (abs(a) + abs(b)))return 0;
    return a + b;
}
struct P
{
    double x , y;
    P(){}
    P(double x , double y) : x(x) , y(y){}
    P operator + (P p)
    {
        return P(add(x , p.x) , add(y , p.y));
    }
    P operator - (P p)
    {
        return P(add(x , - p.x) , add(y , - p.y));
    }
    P operator * (double d)
    {
        return P(x * d , y * d);
    }
    double dot(P p)
    {
        return add(x * p.x  , y * p.y);
    }
    double det(P p)
    {
        return add(x * p.y , - y * p.x);
    }
};
bool on_seg(P p1 , P p2 , P q)
{
    return (p1 - q).det(p2 - q) == 0 && (p1 - q).dot(p2 - q) <= 0;
}
P intersection(P p1 , P p2 , P q1 , P q2)
{
    return p1 + (p2 - p1) * ((q2 - q1).det(q1 - p1) / (q2 - q1).det(p2 - p1));
}
int n , m;
P p[MAXN] , q[MAXN];
int a[MAXS] , b[MAXS];
bool g[MAXN][MAXN];
void solve()
{
    for(int i = 0 ; i < n ;  i++)
    {
        g[i][i] = true;
        for(int j = 0 ; j < i ;  j++)
        {
            
            if((p[i] - q[i]).det(p[j] - q[j]) == 0)
            {
                
                g[i][j] = g[j][i] = on_seg(p[i] , q[i] , p[j])
                                    || on_seg(p[i] , q[i] , q[j])
                                    || on_seg(p[j] , q[j] , p[i])
                                    || on_seg(p[j] , q[j] , q[i]);
            }
            else
            {
                
                P r = intersection(p[i] , q[i] , p[j] , q[j]);
                g[i][j] = g[j][i] = on_seg(p[i] , q[i] , r) && on_seg(p[j] , q[j] , r);
            }
        }
        
        for(int k = 0 ; k < n ; k++)
        {
            for(int i = 0 ; i < n ; i++)
            {
                for(int j = 0 ; j < n ; j++)
                {
                    g[i][j] |= g[i][k] && g[k][j];
                }
            }
        }
    }
    for(int i = 0 ; i < m;  i++)
    {
        puts(g[a[i] - 1][b[i] - 1] ? "CONNECTED" : "NOT CONNECTED");
    }
}
int main()
{
    while(~scanf("%d" , &n) , n)
    {
        clr(g , 0);
        for(int i = 0 ; i < n ; i ++)
        {
            scanf("%lf%lf%lf%lf" , &p[i].x , &p[i].y , &q[i].x , &q[i].y);
        }
        int x , y;
        m = 0;
        while(scanf("%d%d" , &x , &y) , x || y)
        {
            a[m] = x , b[m] = y;
            m++;
        }
        solve();
    }
    return 0;
}