// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mst(a,b) memset((a),(b),sizeof(a))
#define f(i,a,b) for(int i=(a);i<(b);++i)
#define ll long long
const int maxn = 1005;
const int mod = 475;
const int INF = 0x0fffffff;
const double eps = 1e-6;
#define rush() int T;scanf("%d",&T);while(T--)
int c[maxn][maxn],cost[maxn][maxn];
int dis[maxn],w[maxn];
int n,m;
void Dijkstra(int v)
{
    bool vis[maxn];
    for(int i=0;i<n;i++)
    {
        dis[i]=c[v][i];
        vis[i]=0;
        w[i]=cost[v][i];
    }
    vis[v]=1;
    for(int i=1;i<n;i++)
    {
        int tmp=INF;
        int u=v;
        for(int j=0;j<n;j++)
        {
            if(!vis[j]&&dis[j]<tmp)
            {
                u=j;
                tmp=dis[j];
            }
        }
        vis[u]=1;
        for(int j=0;j<n;j++)
        {
            if(!vis[j]&&c[u][j]<INF)
            {
                int newdis=dis[u]+c[u][j];
                if(newdis<dis[j])
                {
                    dis[j]=newdis;
                    w[j]=w[u]+cost[u][j];
                }
                else if(newdis==dis[j]&&w[j]>w[u]+cost[u][j])
                    w[j]=w[u]+cost[u][j];
            }
        }
    }
}
int main()
{
    int a,b,x,p;
    int s,t;
    while(~scanf("%d%d",&n,&m)&&(n||m))
    {
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i==j)
                    c[i][j]=cost[i][j]=0;
                else c[i][j]=cost[i][j]=INF;
            }
        }
        for(int i=0;i<m;i++)
        {
            scanf("%d%d%d%d",&a,&b,&x,&p);
            a--,b--;
            if(x<c[a][b])
            {
                c[a][b]=c[b][a]=x;
                cost[a][b]=cost[b][a]=p;
            }
            if(x==c[a][b]&&cost[a][b]>p)
                cost[a][b]=cost[b][a]=p;
        }
        scanf("%d%d",&s,&t);
        s--,t--;
        Dijkstra(s);
        printf("%d %d\n",dis[t],w[t]);
    }
    return 0;
}