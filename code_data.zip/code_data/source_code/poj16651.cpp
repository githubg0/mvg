// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define mm0(a) memset(a,0,sizeof(a));
#define debug puts("It's ok here!")
using namespace std;
const int maxn=1e5+5;
const double eps=1e-8;
const double Inf=1e17;
struct Point{
    double x, y;
    Point(){}
    Point(double _x, double _y):x(_x), y(_y){}
    Point operator - (const Point &rhs)const{
        return Point(x-rhs.x,y-rhs.y);
    }
    Point operator + (const Point &rhs)const{
        return Point(x+rhs.x,y+rhs.y);
    }
};
typedef struct Point Vector;
struct line{
    Point s, t;
    line(){}
    line(double sx,double sy,double tx,double ty){s.x=sx; s.y=sy; t.x=tx; t.y=ty;}
    line(Point _s, Point _t):s(_s), t(_t){}
};
int dcmp(double x){
    if(fabs(x)<eps) return 0;
    return x<0?-1:1;
}
double cross(Vector A,Vector B){
    return A.x*B.y-A.y*B.x;
}
double cross(Point a,Point b,Point c){
    return (a.x-c.x)*(b.y-c.y)-(a.y-c.y)*(b.x-c.x);
}
bool crossleft(Point a,Point b,Point c){
    return cross(a, b, c)>0;
}
bool SegIntersection(line A, line B){
    double c1=cross(A.t-A.s,B.s-A.s), c2=cross(A.t-A.s,B.t-A.s);
    double c3=cross(B.t-B.s,A.s-B.s), c4=cross(B.t-B.s,A.t-B.s);
    return dcmp(c1)*dcmp(c2)<0&&dcmp(c3)*dcmp(c4)<0;
}
double dis(Point a,Point b){
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
line Seg[maxn];
vector<int> ans;
bool NoSegIntersection(int s,int n){
    for(int i=s+1;i<n;i++)
    if(SegIntersection(Seg[s],Seg[i]))
        return false;
    return true;
}
int main()
{
    double x1, x2, y1, y2;
    int T=0;
    int n;
    while(~scanf("%d",&n)&&n){
        for(int i=0;i<n;i++){
            scanf("%lf%lf%lf%lf",&x1,&y1,&x2,&y2);
            Seg[i]=line(x1,y1,x2,y2);
        }
        ans.clear();
        for(int i=n-1;i>=0;i--){
            if(NoSegIntersection(i,n)){
                ans.push_back(i+1);
            }
        }
        printf("Top sticks: ");
        for(int i=ans.size()-1;i>=0;i--){
            printf("%d",ans[i]);
            if(i) printf(", ");
            else printf(".\n");
        }
    }
    return 0;
}