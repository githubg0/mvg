// Basic Algorithm->Greedy Algorithm,Data Structure->Queue,Data Structure->Hashing,Dynamic Programming->Priority Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 101000;
struct Node
{
    int xi,yi;
};
Node mac[N];
Node pro[N];
int cmp(Node a,Node b)
{
    if(a.xi!=b.xi)
        return a.xi>b.xi;
    if(a.yi!=b.yi)
        return a.yi>b.yi;
}
int flag[120];
int main()
{
    int n,m;
    while(~scanf("%d%d",&n,&m))
    {
        for(int i=0;i<n;i++)
            scanf("%d%d",&mac[i].xi,&mac[i].yi);
        for(int i=0;i<m;i++)
            scanf("%d%d",&pro[i].xi,&pro[i].yi);
        sort(mac,mac+n,cmp);
        sort(pro,pro+m,cmp);
        memset(flag,0,sizeof(flag));
        int tmp=-1;
        long long ans=0,count=0;
        for(int i=0,j=0;i<m;i++)
        {
            while(j<n&&mac[j].xi>=pro[i].xi)
            {
                flag[mac[j].yi]++;
                j++;
            }
            for(int k=pro[i].yi;k<=100;k++)
            {
                if(flag[k])
                {
                    flag[k]--;
                    ans++;
                    count+=(pro[i].xi*500+pro[i].yi*2);
                    break;
                }
            }
        }
        printf("%I64d %I64d\n",ans,count);
    }
    return 0;
}