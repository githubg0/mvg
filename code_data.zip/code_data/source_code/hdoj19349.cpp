// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=400010;
struct edge{
    int from,to,cap,next;
}edge[N];
int cnt=0;
int head[N];
int dis[N];
int id[N];
int node;
void addedge(int u,int v,int w){
    edge[cnt].from=u;edge[cnt].to=v;edge[cnt].cap=w;
    edge[cnt].next=head[u];head[u]=cnt++;
}
struct ST{
    int dp[N][30];
    int Ver[N],R[N],first[N];
    int vis[N];
    int idnode;
    void init(){
        idnode=0;node=0;
        memset(vis,0, sizeof(vis));
    }
    void dfs(int u,int dep){
        id[u]=++node;
        Ver[++idnode]=u;first[node]=idnode;R[idnode]=dep;
        vis[u]=1;
        for(int i=head[u];i!=-1;i=edge[i].next){
            if(!vis[edge[i].to]){
                dis[edge[i].to]=dis[u]+edge[i].cap;
                dfs(edge[i].to,dep+1);
                Ver[++idnode]=u;R[idnode]=dep;
            }
        }
        
    }
    void RMQ_init(int n){
        for(int i=1;i<=n;i++)dp[i][0]=i;
        for(int j=1;(1<<j)<=n;j++){
            for(int i=1;i+(1<<(j-1))-1<=n;i++){
                int a=dp[i][j-1],b=dp[i+(1<<(j-1))][j-1];
                dp[i][j]=R[a]<R[b]?a:b;
            }
        }
    }
    int RMQ(int l,int r){
        int k=0;
        while((1<<(k+1))<=r-l+1)k++;
        int a=dp[l][k],b=dp[r-(1<<k)+1][k];
        return R[a]<R[b]?a:b;
    }
    int lca(int u,int v){
        int x=first[u],y=first[v];
        if(x>y)swap(x,y);
        int res=RMQ(x,y);
        return Ver[res];
    }
};
ST st;
set<int>S;
set<int>::iterator it;
void init(){
    cnt=0;
    memset(head,-1,sizeof(head));
    S.clear();
}
int findmax(int u){
    it = S.upper_bound(u);
    if(it==S.end()){
        return -1;
    }
    return *it;
}
int findmin(int u){
    it = S.lower_bound(u);
    if(it==S.begin())return -1;
    it--;
    return *it;
}
int main(){
    int T;
    int ica=1;
    scanf("%d",&T);
    while(T--){
        int n,q;
        init();
        scanf("%d%d",&n,&q);
        for(int i=0;i<n-1;i++){
            int u,v,w;
            scanf("%d%d%d",&u,&v,&w);
            addedge(u,v,w);
            addedge(v,u,w);
        }
        st.init();st.dfs(1,0);
        st.RMQ_init(st.idnode);
        int sum=0;
        printf("Case #%d:\n",ica++);
        while(q--){
            int kind,u;
            scanf("%d%d",&kind,&u);
            if(kind==1){
                it=S.find(id[u]);
                if(it==S.end()){
                    if(S.size()==0)sum=0;
                    else{
                        int x=findmin(id[u]);
                        int y=findmax(id[u]);
                        if(x==-1||y==-1){
                            if(x==-1){
                                x=y;
                                it=S.end();it--;
                                y=*it;
                            }
                            else if(y==-1){
                                y=x;
                                it=S.begin();
                                x=*it;
                            }
                        }
                        sum+=dis[u]-dis[st.lca(x,id[u])]-dis[st.lca(y,id[u])]+  dis[st.lca(x,y)];
                    }
                    S.insert(id[u]);
                }
                printf("%d\n",sum);
            }
            else {
                it=S.find(id[u]);
                if(it!=S.end()){
                    S.erase(id[u]);
                    if(S.size()!=0){
                        int x=findmin(id[u]);
                        int y=findmax(id[u]);
                        if(x==-1||y==-1){
                            if(x==-1){
                                x=y;
                                it=S.end();it--;
                                y=*it;
                            }
                            else if(y==-1){
                                y=x;
                                it=S.begin();
                                x=*it;
                            }
                        }
                        sum-=dis[u]-dis[st.lca(x,id[u])]-dis[st.lca(y,id[u])]+dis[st.lca(x,y)];
                    }
                    else sum=0;
                }
                printf("%d\n",sum);
            }
        }
    }
    return 0;
}