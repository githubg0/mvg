// Basic Algorithm->Depth First Search (DFS),Data Structure->AVL Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 500010
using namespace std;
int n,w[N],son[N][2],a[N],f[N],cnt,tail,q[N];
void dfs(int x){
	if(son[x][0])
	  dfs(son[x][0]);
	a[++cnt]=w[x];
	if(son[x][1])
	  dfs(son[x][1]);
}
int find(int x)
{
	int l=1,r=tail;
	while(l<=r){
		int mid=(l+r)/2;
		if(x>=q[mid]) l=mid+1;
		else r=mid-1;
	}
	return l;
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&w[i]);
	}
	for(int i=2;i<=n;i++){
		int fa,ch;
		scanf("%d%d",&fa,&ch);
		son[fa][ch]=i;
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	  a[i]=a[i]-i;
	for(int i=1;i<=n;i++){
		if(a[i]>=q[tail])
		  q[++tail]=a[i];
		else q[find(a[i])]=a[i];
	}
	printf("%d",n-tail);
}