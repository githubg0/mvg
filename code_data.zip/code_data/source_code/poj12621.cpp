// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
string s1[105];
string s2[105];
int dp[105][105];
int len1, len2;
void dfs(int i, int j)
{
    if (i == 0 || j == 0)
        return;
    if (s1[i] == s2[j])
    {
        dfs(i - 1, j - 1);
        cout << s1[i] << " ";
    }
    else
    {
        if (dp[i - 1][j] > dp[i][j - 1])
            dfs(i - 1, j);
        else
            dfs(i, j - 1);
    }
}
int main()
{
    string s;
    while (cin >> s)
    {
        len1 = 0;
        if (s != "#")
        {
            s1[++len1] = s;
            while (cin >> s&&s != "#")
                s1[++len1] = s;
        }
        len2 = 0;
        while (cin >> s&&s != "#")
            s2[++len2] = s;
        for (int i = 1; i <= len1; i++)
        {
            for (int j = 1; j <= len2; j++)
            {
                if (s1[i] == s2[j])
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                else
                    dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
        dfs(len1, len2);
        cout << endl;
    }
    return 0;
}