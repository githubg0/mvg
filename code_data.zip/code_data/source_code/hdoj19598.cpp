// Data Structure->Suffix Automata (SAM),Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef unsigned long long int LL;
const int CHAR=26,maxn=200100;
struct SAM_Node
{
	SAM_Node *fa,*next[CHAR];
	int len,id,pos;
	SAM_Node(){}
	SAM_Node(int _len)
	{
		fa=0; len=_len;
		memset(next,0,sizeof(next));
	}
};
SAM_Node SAM_node[maxn],*SAM_root,*SAM_last;
int SAM_size;
SAM_Node *newSAM_Node(int len)
{
	SAM_node[SAM_size]=SAM_Node(len);
	SAM_node[SAM_size].id=SAM_size;
	return &SAM_node[SAM_size++];
}
SAM_Node *newSAM_Node(SAM_Node *p)
{
	SAM_node[SAM_size]=*p;
	SAM_node[SAM_size].id=SAM_size;
	return &SAM_node[SAM_size++];
}
void SAM_init()
{
	SAM_size=1;
	SAM_root=SAM_last=newSAM_Node(0);
	SAM_node[0].pos=0;
}
void SAM_add(int x,int len)
{
	SAM_Node *p=SAM_last,*np=newSAM_Node(p->len+1);
	np->pos=len; SAM_last=np;
	for(;p&&!p->next[x];p=p->fa)
		p->next[x]=np;
	if(!p)
	{
		np->fa=SAM_root; return ;
	}
	SAM_Node *q=p->next[x];
	if(q->len==p->len+1)
	{
		np->fa=q; return ;
	}
	SAM_Node *nq=newSAM_Node(q);
	nq->len=p->len+1;
	q->fa=nq; np->fa=nq;
	for(;p&&p->next[x]==q;p=p->fa)
		p->next[x]=nq;
}
int c[maxn],num[maxn];
SAM_Node* top[maxn];
void Count(char str[],int len)
{
	memset(c,0,sizeof(c));
	memset(num,0,sizeof(num));
	for(int i=0;i<SAM_size;i++) c[SAM_node[i].len]++;
	for(int i=1;i<=len;i++) c[i]+=c[i-1];
	for(int i=0;i<SAM_size;i++) top[--c[SAM_node[i].len]]=&SAM_node[i];
	SAM_Node *p=SAM_root;
	for(;p->len!=len;p=p->next[str[p->len]-'a']) num[p->id]=1;
	num[p->id]=1;
	for(int i=SAM_size-1;i>=0;i--)
	{
		p=top[i];
		if(p->fa)
		{
			SAM_Node *q=p->fa; num[q->id]+=num[p->id];
		}
	}
}
int len1,len2;
char str1[maxn],str2[maxn];
LL cum[maxn];
bool vis[maxn];
int dfs(int u)
{
	if(vis[u]) return num[u];
	vis[u]=true;
	int ret=1;
	for(int i=0;i<26;i++)
	{
		if(SAM_node[u].next[i])
		{
			ret+=dfs(SAM_node[u].next[i]->id);
		}
	}
	return num[u]=ret;
}
int main()
{
	
	
	int T_T;
	scanf("%d",&T_T);
	while(T_T--)
	{
		cin>>str1>>str2;
		len1=strlen(str1); len2=strlen(str2);
		SAM_init();
		for(int i=0;i<len2;i++)
			SAM_add(str2[i]-'a',i);
		memset(cum,0,sizeof(cum));
		memset(vis,false,sizeof(vis));
		dfs(1);
		LL ans=0;
		for(int i=0;i<26;i++)
		{
			if(SAM_node[1].next[i])
			{
				cum[i]=num[SAM_node[1].next[i]->id];
			}
		}
		SAM_init();
		for(int i=0;i<len1;i++) SAM_add(str1[i]-'a',i);
		for(int i=2;i<SAM_size;i++)
		{
			if(SAM_node[i].fa)
			{
				LL l=SAM_node[i].len-SAM_node[i].fa->len;
				for(int j=0;j<26;j++)
				{
					if(SAM_node[i].next[j]==0) ans+=l*cum[j];
				}
				ans+=l;
			}
		}
		cout<<ans+1<<endl;
	}
    return 0;
}