// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mst(a,b) memset((a),(b),sizeof(a))
#define rush() int T;scanf("%d",&T);while(T--)
typedef long long ll;
const int maxn = 200005;
const int mod = 20090717;
const int INF = 0x3f3f3f;
const double eps = 1e-9;
int n;
ll ans;
int num[maxn];
int sum[maxn];
int color[maxn];
vector<int>vec[maxn];
void dfs(int u,int from)
{
    int add=0;
    num[u]=1;
    for(int i=0;i<vec[u].size();i++)
    {
        int v=vec[u][i];
        if(v==from) continue;
        int pre=sum[color[u]];
        dfs(v,u);
        num[u]+=num[v];
        int temp=num[v]-(sum[color[u]]-pre);
        ans-=(ll)temp*(temp-1)/2;
        add+=temp;
    }
    sum[color[u]]+=add+1;
}
int main()
{
    int cas=1;
    int u,v;
    while(~scanf("%d",&n))
    {
        mst(num,0);
        mst(sum,0);
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&color[i]);
            vec[i].clear();
        }
        for(int i=1;i<n;i++)
        {
            scanf("%d%d",&u,&v);
            vec[u].push_back(v);
            vec[v].push_back(u);
        }
        ans=(ll)n*n*(n-1)/2;
        dfs(1,-1);
        for(int i=1;i<=n;i++)
        {
            int temp=n-sum[i];
            ans-=(ll)temp*(temp-1)/2;
        }
        printf("Case #%d: %I64d\n",cas++,ans);
    }
    return 0;
}