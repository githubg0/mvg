// Basic Algorithm->Recursion,Data Structure->Segment Tree,Basic Algorithm->Discretization,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
#define MAXN 402
#define memset0(a) memset(a,0,sizeof(a))
#define EPS 1e-8
struct Ln
{
    int l, r, y, f, n;
    bool operator<(const Ln &b)const
    {
        return y < b.y;
    }
}lns[42];
int N, M;
int hashx[42], L[MAXN], R[MAXN], c[MAXN], len[MAXN];
bool mk[22];
void build(int i, int l, int r)
{
    L[i] = l, R[i] = r;
    if (l + 1 != r) {
        build(i * 2, l, (l + r) / 2);
        build(i * 2 + 1, (l + r) / 2, r);
    }
}
void modify(int i, Ln &a)
{
    if (a.l == hashx[L[i]] && a.r == hashx[R[i]])
        c[i] += a.f;
    else if (a.l >= hashx[L[i * 2 + 1]])
        modify(i * 2 + 1, a);
    else if (a.r <= hashx[R[i * 2]])
        modify(i * 2, a);
    else {
        Ln b = a;
        b.r = hashx[R[i * 2]];
        modify(i * 2, b);
        b = a;
        b.l = hashx[L[i * 2 + 1]];
        modify(i * 2 + 1, b);
    }
    if (c[i])
        len[i] = hashx[R[i]] - hashx[L[i]];
    else
        len[i] = len[i * 2] + len[i * 2 + 1];
}
void fun()
{
    for (int p = 1; p <= N; p++) {
        int x1, y1, x2, y2;
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        lns[p].l = x1, lns[p].r = x2, lns[p].y = y1, lns[p].f = 1, lns[p].n = p, hashx[p] = x1;
        lns[N + p].l = x1, lns[N + p].r = x2, lns[N + p].y = y2, lns[N + p].f = -1, lns[N + p].n = p, hashx[N + p] = x2;
    }
    sort(lns + 1, lns + 2 * N + 1);
    sort(hashx + 1, hashx + 2 * N + 1);
    build(1, 1, unique(hashx + 1, hashx + 2 * N + 1) - hashx - 1);
    for (int p = 0; p < M; p++) {
        memset0(mk);
        int R, area = 0, lasty = 0;
        scanf("%d", &R);
        while (R--) {
            int a;
            scanf("%d", &a);
            mk[a] = 1;
        }
        bool f = 0;
        for (int i = 1; i <= 2 * N; i++)
            if (mk[lns[i].n]) {
                if (f)
                    area += len[1] * (lns[i].y - lasty);
                modify(1, lns[i]);
                lasty = lns[i].y;
                f = 1;
            }
        printf("Query %d: %d\n", p + 1, area);
    }
}
int main(void)
{
    
    
    int times = 0;
    while (~scanf("%d%d", &N, &M) && (N || M)) {
        printf("Case %d:\n", ++times);
        fun();
        printf("\n");
    }
}