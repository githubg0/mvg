// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 300 + 5;
int n;
bool vis[MAXN][MAXN];
int dx[] = {-2,-2,-1,-1,2,2,1,1};
int dy[] = {-1,1,-2,2,-1,1,-2,2};
struct node{
    int x;
    int y;
    int step;
}S,T;
void init(int n){
    for(int i=0; i<n; i++)
    for(int j=0; j<n; j++)
        vis[i][j] = false;
    vis[S.x][S.y] = true;
}
int BFS(){
    queue <node> Q;
    Q.push(S);
    while(!Q.empty()){
        node Now = Q.front();
        node New;
        Q.pop();
        for(int i=0; i<8; i++){
            New.x = Now.x + dx[i];
            New.y = Now.y + dy[i];
            if(New.x<0 || New.x>=n || New.y<0 || New.y>=n || vis[New.x][New.y]) continue;
            New.step = Now.step + 1;
            Q.push(New);
            vis[New.x][New.y] = true;
            if(New.x==T.x && New.y==T.y) return New.step;
        }
    }
    return 0;
}
int main(){
    int t;
    scanf("%d", &t);
    while(t--){
        scanf("%d", &n);
        scanf("%d%d%d%d", &S.x, &S.y, &T.x, &T.y);
        init(n);
        if(S.x==T.x && S.y==T.y) {printf("0\n"); continue;}
        printf("%d\n", BFS());
    }
    return 0;
}