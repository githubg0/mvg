// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char a[102];
char tmp[2];
string res;
int main()
{
    int tes,i,len,index;
    scanf("%d",&tes);
    while(tes--)
    {
        char p='9';  
        scanf("%s",a);
        res="";   
        len=strlen(a);
        for(i=0;i<len;i++)  
        {
            if(a[i]!='0'&&a[i]<=p)
            {
                p=a[i];
                index=i;
            }
        }
        tmp[0]=a[0],tmp[1]='\0';
        res=res+tmp;
        for(i=1;i<index;i++)  
        {
            tmp[0]=a[i],tmp[1]='\0';
            if(a[i]<=res[0]) res=tmp+res;
            else res=res+tmp;
        }
        if(index>0)
        {
            tmp[0]=a[index],tmp[1]='\0';  
            res=tmp+res;
        }
        for(i=index+1;i<len;i++)  
        {
            tmp[0]=a[i],tmp[1]='\0';
            res=res+tmp;
        }
        cout<<res<<endl;
    }
    return 0;
}