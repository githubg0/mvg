// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define el else
const int MAX_N = 1e5 + 10;
int fa[MAX_N];
bool vis[MAX_N];   
int get(int x) {
	if (fa[x] == x) {
		return x;
	}
	return fa[x] = get(fa[x]);
}
void joint(int x, int y) {
	int xx = get(x);
	int yy = get(y);
	if (xx != yy) {
		fa[xx] = yy;
	}
}
int main()
{
	int n, m;
	int f;
	int e = 0;
	int v = 0;   
	while (scanf("%d%d", &n, &m), n != -1 && m != -1) {
		if (n == 0 && m == 0) {
			puts("Yes");
			continue;
		}			
		f = 1, memset(vis, 0, sizeof(vis));
		vis[n] = 1, vis[m] = 1;
		iota(fa, fa + MAX_N, 0); 
		joint(n, m);
		e = 1;	      
		while (scanf("%d%d", &n, &m), n != 0 && m != 0) {
			if (get(n) == get(m)) {
				f = 0;
				continue;
			}
			else {
				joint(n, m);
				vis[n] = 1;
				vis[m] = 1;
				++e;
				
			}
		}
		
		v = 0;
		for (int i = 0; i < MAX_N; ++i) {
			if (vis[i])	++v;
		}       
		if (f == 1 && e == v - 1)puts("Yes");
		else puts("No");
	}
	return 0;
}