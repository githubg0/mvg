// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int n,k;
struct s{
	int	maptt1[50][50];
};
struct s fun(struct s a,struct s b)
{
	struct s tmp;
	int i,j,k;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			tmp.maptt1[i][j]=0;
			for(k=0;k<n;k++)
			{
				tmp.maptt1[i][j]+=a.maptt1[i][k]*b.maptt1[k][j];
				tmp.maptt1[i][j]%=9973;
			}
		}
	}
		return tmp;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int i,j,sum=0;
		scanf("%d%d",&n,&k);
		struct s p,m;
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			{
				scanf("%d",&m.maptt1[i][j]);
				if(i==j)
					p.maptt1[i][j]=1;
				else
					p.maptt1[i][j]=0;
			}
			while(k>1)
			{
				if(k%2)
				{
					k--;
					p=fun(p,m);
				}
				else
				{
					k/=2;
					m=fun(m,m);
				}
			}
			m=fun(m,p);
			for(i=0;i<n;i++)
				sum+=m.maptt1[i][i];
			printf("%d\n",sum%9973);
	}
}