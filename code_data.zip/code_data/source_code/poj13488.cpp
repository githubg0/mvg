// Graph Algorithm->Euler Circuit / Euler Path
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 1010
char ret[maxn][30];
struct edge
{
    int to;
    int next;
    char str[30];
} node[maxn];
int in[30],out[30];
int used[maxn];
int exist[30];
int p[30];
int adj[30];
int num_e,ret_e;
bool cmp(edge a,edge b)
{
    return strcmp(a.str,b.str)>0;
}
void init()
{
    for(int i=0; i<30; i++)
    {
        in[i]=0;
        out[i]=0;
        p[i]=-1;
        exist[i]=0;
        adj[i]=-1;
    }
    for(int i=0; i<maxn; i++)
        used[i]=0;
    num_e=0;
    ret_e=0;
}
int find_set(int u)
{
    if(p[u]>=0)
    {
        p[u]=find_set(p[u]);
        return p[u];
    }
    return u;
}
void union_set(int u,int v)
{
    int r1=find_set(u);
    int r2=find_set(v);
    if(r1==r2)return ;
    int n1=p[r1];
    int n2=p[r2];
    if(n1<n2)
    {
        p[r2]=r1;
        p[r1]+=n2;
    }
    else
    {
        p[r1]=r2;
        p[r2]+=n1;
    }
}
void Eular(int vertix,int idx)
{
    for(int i=adj[vertix]; i!=-1; i=node[i].next)
    {
        if(!used[i])
        {
            used[i]=1;
            Eular(node[i].to,i);
        }
    }
    if(0<=idx)
        strcpy(ret[ret_e++],node[idx].str);
}
int main()
{
    int cas,n;
    int start=0;
    cin>>cas;
    while(cas--)
    {
        init();
        cin>>n;
        getchar();
        for(int i=0; i<n; i++)
        {
            cin>>node[i].str;
        }
        sort(node,node+n,cmp);
        
        for(int i=0; i<n; i++)
        {
            int len=strlen(node[i].str);
            int u=node[i].str[0]-'a';
            int v=node[i].str[len-1]-'a';
            in[v]++;
            out[u]++;
            exist[v]=1;
            exist[u]=1;
            union_set(u,v);
            node[num_e].to=v;
            node[num_e].next=adj[u];
            adj[u]=num_e++;
        }
        int scc=0;
        int flag=0;
        
        for(int i=0; i<26; i++)
        {
            if(exist[i]&&0>p[i])
                scc++;
            if(scc>1)
            {
                cout<<"***"<<endl;
                flag=1;
                break;
            }
        }
        if(!flag)
        {
            int a=0;
            int b=0;
            start=-1;
            int j=0;
            
            for(int i=0; i<26; i++)
            {
                j++;
                if(exist[i]&&in[i]!=out[i])
                {
                    if(1==in[i]-out[i])
                        a++;
                    else if(1==out[i]-in[i])
                    {
                        b++;
                        start=i;
                    }
                    else
                        break;
                }
            }
            
            if(j<25)
            {
                cout<<"***"<<endl;
                continue;
            }
            else
            {
                if(!((0==a+b)||(1==a&&1==b)))
                {
                    cout<<"***"<<endl;
                    continue;
                }
                if(start==-1)
                {
                    int k=0;
                    for(k=0; k<26; k++)
                    {
                        if(out[k])
                            break;
                    }
                    start=k;
                }
                Eular(start,-1);
                cout<<ret[ret_e-1];
                for(int i=ret_e-2; i>=0; i--)
                    cout<<"."<<ret[i];
                cout<<endl;
            }
        }
    }
    return 0;
}