// Graph Algorithm->Steiner Tree,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
typedef unsigned long long ull;
#define fi first
#define se second
#define mp make_pair
#define pb push_back
const int maxn=65;
const int maxm=1<<10;
const int maxe=2015;
const int inf=0x3f3f3f3f;
const int seed=1e9+7;
int n,m,k,nn;
struct edge{int to,nxt,len;}e[maxe];
int head[maxn],tot;
void adde(int u,int v,int l){e[tot].to=v;e[tot].len=l;e[tot].nxt=head[u];head[u]=tot++;}
int d[maxn][maxm];
int dp[maxm];
int s[maxn];
void init(){
    tot=0;
    memset(head,-1,sizeof(head));
    memset(s,0,sizeof(s));
    scanf("%d%d%d",&n,&m,&k);
    nn=1<<(2*k);
    for(int i=1;i<=n;i++){
        for(int j=0;j<nn;j++)d[i][j]=inf;
    }
    int a,b,c;
    for(int i=0;i<m;i++){
        scanf("%d%d%d",&a,&b,&c);
        adde(a,b,c);adde(b,a,c);
    }
    for(int i=1;i<=k;i++){
        s[i]=1<<(i-1);d[i][s[i]]=0;
        s[n-i+1]=1<<(k+i-1);d[n-i+1][s[n-i+1]]=0;
    }
}
queue<pii> que;
bool inque[maxn][maxm];
inline bool check(int msk){
    int v1=0,v2=0;
    for(int i=0;i<k;i++)if(msk>>i&1)v1++;
    for(int i=k;i<2*k;i++)if(msk>>i&1)v2++;
    return v1==v2;
}
inline bool update(int x,int y,int w){
    if(w<d[x][y]){d[x][y]=w;return 1;}
    return 0;
}
void spfa(){
    while(!que.empty()){
        int x=que.front().fi,y=que.front().se;que.pop();
        for(int i=head[x];i!=-1;i=e[i].nxt){
            int v=e[i].to,w=e[i].len;
            if(update(v,y|s[v],d[x][y]+w)&&y==(y|s[v])&&!inque[v][y]){
                inque[v][y]=1;que.push(mp(v,y));
            }
        }
        inque[x][y]=0;
    }
}
void work(){
    for(int msk=0;msk<nn;msk++){
        for(int x=1;x<=n;x++){
            for(int i=(msk-1)&msk;i;i=(i-1)&msk){
                d[x][msk]=min(d[x][msk],d[x][i|s[x]]+d[x][(msk-i)|s[x]]);
            }
            if(d[x][msk]<inf){que.push(mp(x,msk));inque[x][msk]=1;}
        }
        spfa();
    }
}
int main(){
    int T;
    scanf("%d",&T);
    while(T--){
        init();
        work();
        for(int j=1;j<nn;j++){
            dp[j]=inf;
            for(int i=1;i<=n;i++)dp[j]=min(dp[j],d[i][j]);
        }
        for(int i=1;i<nn;i++){
            if(check(i)){
                for(int j=(i-1)&i;j;j=(j-1)&i){
                    if(check(j)){
                        dp[i]=min(dp[i],dp[j]+dp[i-j]);
                    }
                }
            }
        }
        if(dp[nn-1]>=inf)printf("No solution\n");
        else printf("%d\n",dp[nn-1]);
    }
    return 0;
}