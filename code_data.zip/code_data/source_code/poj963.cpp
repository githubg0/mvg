// Basic Algorithm->Recursion,Basic Algorithm->Memorization,Basic Algorithm->Recurrence,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define width 105
using namespace std;
int maps[width][width];
int dp[width][width];
int r,c;
int dfs(int x, int y)
{
    if(dp[x][y]!=0)
    {
        return dp[x][y];
    }
    else
    {
        dp[x][y]=1;
        for(int i=-1;i<=1;i++)
        {
            for(int j=-1;j<=1;j++)
            {
                if(i==0&&j!=0||i!=0&&j==0)
                {
                    int newx=x+i;
                    int newy=y+j;
                    if(newx>=0&&newx<r&&newy>=0&&newy<c)
                    {
                        if(maps[newx][newy]<maps[x][y])
                        {
                            dp[x][y]=max(dfs(newx,newy)+1,dp[x][y]);
                        }
                    }
                }
            }
        }
        return dp[x][y];
    }
}
int main()
{
    int ans=0;
    cin>>r>>c;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>maps[i][j];
        }
    }
    memset(dp,0,sizeof(dp));
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            if(dp[i][j]==0)
            {
                dfs(i,j);
            }
            if(dp[i][j]>ans)
            {
                ans=dp[i][j];
            }
        }
    }
    cout<<ans<<endl;
    return 0;
}