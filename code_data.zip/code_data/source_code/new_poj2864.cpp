// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,ans;
int h[11000],r[11000];
int mncos[11000];
void dfs(int k,int s,int v)
{
    if(k==m+1)
    {
        if(v==n)ans=min(ans,s);
        return ;
    }
    int u=min(int(double(sqrt(n-v))),r[k-1]-1);
    for(int i=u;i>=(m-k+1);i--)
    {
        if(2*(n-v)/i+s>=ans)continue;
        for(int j=(m-k+1);j<=min((n-v)/(i*i),h[k-1]-1);j++)
        {
            if(s+2*i*j+mncos[k+1]>=ans)break;
            if(v+i*i*j>n)break;
            r[k]=i;h[k]=j;
            if(k!=1)dfs(k+1,s+2*i*j,v+i*i*j);
            else dfs(k+1,s+2*i*j+i*i,v+i*i*j);
            r[k]=h[k]=0;
        }
    }
}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=m;i>=1;i--)mncos[i]=mncos[i+1]+2*(m-i+1)*(m-i+1);
    ans=999999999;r[0]=h[0]=999999999;
    dfs(1,0,0);
    if(ans==999999999)printf("0\n");
    else printf("%d\n",ans);
    return 0;
}