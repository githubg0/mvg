// Data Structure->Stack,Data Structure->Heap
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define N 50000
int n;
int w[N], h[N];
int wsum[N + 1] = {0};
int L[N], R[N];
int st[N], ps; 
long long solve()
{
    int i;
    
    ps = 0;
    for (i = 0; i < n; i++) {
        while (ps > 0 && h[st[ps - 1]] >= h[i]) ps--;
        L[i] = ps == 0 ? 0 : (st[ps - 1] + 1);
        st[ps++] = i;
    }
    
    ps = 0;
    for (i = n - 1; i >= 0; i--) {
        while (ps > 0 && h[st[ps - 1]] >= h[i]) ps--;
        R[i] = ps == 0 ? n : st[ps - 1];
        st[ps++] = i;
    }
    long long res = 0;  
    for (i = 0; i < n; i++)
        res = MAX(res, (long long) h[i] * (wsum[R[i]] - wsum[L[i]]));
    return res;
}
int main()
{
    int i;
    while (~scanf("%d", &n) && n != -1) {
        for (i = 0; i < n; i++) {
            scanf("%d%d", &w[i], &h[i]);
            wsum[i + 1] = wsum[i] + w[i];
        }
        printf("%lld\n", solve());
    }
    return 0;
}