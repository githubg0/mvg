// Data Structure->Stack,Data Structure->Disjoint Set Union (DSU),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define M 1000005
using namespace std;
void check_min(int &x,int y){if(x>y)x=y;}
struct E{
    int to,nx;
}edge[M<<1];
int tot,head[M];
void Addedge(int a,int b){
    edge[++tot].to=b;
    edge[tot].nx=head[a];
    head[a]=tot;
}
struct node{
    int d,Belong;
    bool operator <(const node &x)const{
        return d<x.d;
    }
    bool operator !=(const int &x)const{
        return Belong!=x;
    }
    void clear(){d=1e9;}
    void Print(){printf("this-->%d %d\n",d,Belong);}
}A[4];
int fa[M],Belong[M];
int mn_id[M],dp[M];
void dfs(int now){
    mn_id[now]=now;
    for(int i=head[now];i;i=edge[i].nx){
        int nxt=edge[i].to;
        if(nxt==fa[now])continue;
        fa[nxt]=now;
        if(now!=1)Belong[nxt]=Belong[now];
        dfs(nxt);
        check_min(mn_id[now],mn_id[nxt]);
    }
}
void redfs(int now,int pre){
    dp[now]=pre;
    int mn1=1e9,mn2=1e9;
    for(int i=head[now];i;i=edge[i].nx){
        int nxt=edge[i].to;
        if(nxt==fa[now])continue;
        check_min(dp[now],mn_id[nxt]);
        if(mn_id[nxt]<mn1)mn2=mn1,mn1=mn_id[nxt];
        else if(mn_id[nxt]<mn2)mn2=mn_id[nxt];
    }
    for(int i=head[now];i;i=edge[i].nx){
        int nxt=edge[i].to,nxtd;
        if(nxt==fa[now])continue;
        if(mn1==mn_id[nxt])nxtd=mn2;
        else nxtd=mn1;
        redfs(nxt,min(pre,nxtd));
    }
}
int n,m;
void Init(){
    tot=0;dp[1]=1e9;
    memset(head,0,sizeof(head));
}
int main(){
    while(~scanf("%d%d",&n,&m)){
		
        Init();
        for(int i=1;i<=n;i++)Belong[i]=i;
        for(int i=1;i<n;i++){
            int a,b;
            scanf("%d%d",&a,&b);
            Addedge(a,b);
            Addedge(b,a);
        }
        dfs(1);
        for(int i=1;i<=3;i++)A[i].clear();
        for(int i=head[1];i;i=edge[i].nx){
            int nxt=edge[i].to;
            redfs(nxt,1e9);
            node P;
            P.d=mn_id[nxt],P.Belong=nxt;
            if(P<A[1])A[3]=A[2],A[2]=A[1],A[1]=P;
            else if(P<A[2])A[3]=A[2],A[2]=P;
            else if(P<A[3])A[3]=P;
        }
        int ans=0;
        while(m--){
            int a,b;
            scanf("%d%d",&a,&b);
            a^=ans,b^=ans;
            if(a==b&&a==1){
            	puts("2");
            	continue;
			}
            if(Belong[a]==Belong[b]){
                puts("1");
                ans=1;
                continue;
            }
            ans=min(dp[a],dp[b]);
            a=Belong[a],b=Belong[b];
            if(A[1]!=a&&A[1]!=b)check_min(ans,A[1].d);
            else if(A[2]!=a&&A[2]!=b)check_min(ans,A[2].d);
            else if(A[3]!=a&&A[3]!=b)check_min(ans,A[3].d);
            printf("%d\n",ans);
        }
    }
    return 0;
}