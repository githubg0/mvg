// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node{
	int w,h;
};
node a[20001];
bool cmp(node a,node b){
	if(a.w!=b.w)return a.w<b.w;
	return a.h<b.h;
}
bool visit[20001];
int main()
{
	int t;
	scanf("%d",&t);
	
	while(t--)
	{
		int m;
		scanf("%d",&m);
		
		for(int i=0;i<m;i++)
		{
			scanf("%d %d",&a[i].w,&a[i].h);
			
		}
		sort(a,a+m,cmp);
		for(int i=0;i<m;i++)cout<<a[i].w<<" "<<a[i].h<<endl;
		memset(visit,0,sizeof(visit));
		int cnt=0;
		for(int i=0;i<m;i++)
		{
			if(visit[i])continue;
			int k=i;
			for(int j=0;j<m;j++)
			{
				if(visit[j])continue;
				if(a[k].w<a[j].w&&a[k].h<a[j].h){
					visit[j]=1;
					k=j;
				}
			}
			cnt++;
			visit[i]=1;
		}
		cout<<cnt<<endl;
	}
	return 0;
}