// Data Structure->Stack,Data Structure->Queue,Graph Algorithm->Strongly Connected Components,Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 550;
struct edg{
    int to;
    int v;
    edg(){}
    edg(int to,int v):to(to),v(v){}
};
vector<edg> edge[maxn];
vector<edg> dcc[maxn];
stack<int> S;
int dfn[maxn],low[maxn],_cnt;
int bel[maxn];
void init(){
    for(int i=0;i<maxn;i++){
        edge[i].clear();
        dcc[i].clear();
    }
    memset(dfn,-1,sizeof(dfn));
    memset(low,-1,sizeof(low));
    _cnt = 1;
    memset(bel,-1,sizeof(bel));
    while(S.empty()==false)
        S.pop();
}
#define iter vector<edg>::iterator
void dfs(int st){
    dfn[st] = low[st] = _cnt++;
    S.push(st);
    for(iter it = edge[st].begin();it != edge[st].end();it++){
        int x = it->to;
        if(dfn[x] == -1){
            dfs(x);
            low[st] = min(low[st],low[x]);
        }
        else if(bel[x] == -1){
            low[st] = min(low[st],dfn[x]);
        }
    }
    if(low[st] == dfn[st]){
        while(S.top()!=st){
            bel[S.top()] = st;
            S.pop();
        }
        S.pop();
        bel[st] = st;
    }
}
int Map[maxn][maxn];
bool vis[maxn];
queue<int> Q;
void spfa(int st,int *dis){
    memset(dis,0x3f,sizeof(dis));
    memset(vis,0,sizeof(vis));
    dis[st] = 0;
    while(Q.empty()==false)
        Q.pop();
    Q.push(st);
    vis[st] = true;
    dis[st] = 0;
    while(Q.empty()==false){
        st = Q.front();
        Q.pop();
        vis[st] = false;
        for(iter it = dcc[st].begin();it!=dcc[st].end();it++){
            int ed = it->to;
            int v = it->v;
            if(dis[ed] > dis[st] + v){
                dis[ed] = dis[st] + v;
                if(vis[ed] == false){
                    vis[ed] = true;
                    Q.push(ed);
                }
            }
        }
    }
}
void out(char *p,int *s,int n){
    printf("%s\t",p);
    for(int i=1;i<=n;i++)
        printf(i<n?"%d ":"%d\n",s[i]);
}
#define debug(a) out(#a,a,n)
void calMin(int n){
    memset(Map,0x3f,sizeof(Map));
    for(int i=1;i<=n;i++){
        for(iter it = edge[i].begin();it!=edge[i].end();it++){
            int st = bel[i];
            int ed = bel[it->to];
            int v = it->v;
            if(st != ed){
                dcc[st].push_back(edg(ed,v));
            }
        }
    }
    for(int i=1;i<=n;i++){
        if(i == bel[i]){
            spfa(i,Map[i]);
        }
    }
}
const int INF = 0x3f3f3f3f;
int main(){
    int n,m;
    while(~scanf("%d %d",&n,&m) && (n||m)){
        init();
        int x,y,v;
        while(m--){
            scanf("%d %d %d",&x,&y,&v);
            edge[x].push_back(edg(y,v));
        }
        for(int i=1;i<=n;i++){
            if(dfn[i] == -1){
                dfs(i);
            }
        }
        calMin(n);
        scanf("%d",&m);
        while(m--){
            scanf("%d %d",&x,&y);
            x = bel[x],y = bel[y];
            if(Map[x][y] == INF){
                puts("Nao e possivel entregar a carta");
            }
            else{
                printf("%d\n",Map[x][y]);
            }
        }
        puts("");
    }
    return 0;
}