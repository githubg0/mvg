// Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 10000+1
#define MOD 2008
#define LL long long
using namespace std;
struct Matrix
{
    int a[31][31];
};
Matrix day[MAXN];
int city;
Matrix muitl(Matrix x, Matrix y)
{
    Matrix z;
    memset(z.a, 0, sizeof(z.a));
    for(int i = 1; i <= city; i++)
    {
        for(int k = 1; k <= city; k++)
        {
            if(x.a[i][k] == 0) continue;
            for(int j = 1; j <= city; j++)
                z.a[i][j] = (z.a[i][j] + (x.a[i][k] * y.a[k][j])%MOD) % MOD;
        }
    }
    return z;
}
map<int, int> fp;
int main()
{
    int m;
    while(scanf("%d", &m) != EOF)
    {
        int s, e;
        city = 0;
        memset(day[1].a, 0, sizeof(day[1].a));
        fp.clear();
        for(int i = 0; i < m; i++)
        {
            scanf("%d%d", &s, &e);
            if(!fp[s])
                fp[s] = ++city;
            if(!fp[e])
                fp[e] = ++city;
            day[1].a[fp[s]][fp[e]]++;
        }
        for(int i = 2; i < MAXN; i++)
            day[i] = muitl(day[i-1], day[1]);
        int q, v1, v2, t1, t2;
        scanf("%d", &q);
        while(q--)
        {
            scanf("%d%d%d%d", &v1, &v2, &t1, &t2);
            if(!fp[v1] || !fp[v2])
                printf("0\n");
            else
            {
                LL ans = 0;
                int temp;
                if(t1 > t2)
                {
                    temp = t1;
                    t1 = t2;
                    t2 = temp;
                }
                for(int i = t1; i <= t2; i++)
                    ans += day[i].a[fp[v1]][fp[v2]], ans %= MOD;
                printf("%lld\n", ans);
            }
        }
    }
    return 0;
}