// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAX 1100
#define MAXL MAX*MAX
inline int read()
{
       int x=0,t=1;char ch=getchar();
       while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
       if(ch=='-'){t=-1;ch=getchar();}
       while(ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
       return x*t;
}
struct Line
{
       int u,v,dis;
}e[MAXL];
int f[MAX],cnt=0,N,M;
bool operator <(Line a,Line b)
{
       return a.dis>b.dis;
}
int getf(int x)
{
       return x==f[x]?x:f[x]=getf(f[x]);
}
void merge(int x,int y)
{
       int a=getf(x);
       int b=getf(y);
       f[a]=b;
}
int main()
{
       int T=read();
       for(int ttt=1;ttt<=T;++ttt)
       {
               N=read();M=read();
               for(int i=1;i<=M;++i)
                 e[i]=(Line){read(),read(),read()};
               sort(&e[1],&e[M+1]);
               for(int i=1;i<=N;++i)f[i]=i;
               cnt=0;
               for(int i=1;i<N;++i)
               {
                       int x,y;
                       do
                       {x=getf(e[++cnt].u),y=getf(e[cnt].v);}
                       while(x==y);
                       merge(x,y);
                       if(getf(1)==getf(N))
                       {
                              printf("Scenario #%d:\n%d\n\n",ttt,e[cnt].dis);
                              break; 
                       }
               }
       }
}