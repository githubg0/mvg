// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int ma=1000000;
int n,k,Map[ma+10];
struct node
{
    int step;
    int data;
} s1,s2;
queue<node>q;
int check(int x)
{
    if(x<0||x>=ma||Map[x]==1)
    {
        return 0;
    }
    else
        return 1;
}
int BFS(int x)
{
    s1.data=x;
    s1.step=0;
    Map[x]=1;
    q.push(s1);
    while(!q.empty())
    {
        s1=q.front();
        q.pop();
        if(s1.data==k)
            return s1.step;
        s2.data=s1.data+1;
        if(check(s2.data))
        {
            s2.step=s1.step+1;
            Map[s2.data]=1;
            q.push(s2);
        }
        s2.data=s1.data-1;
        if(check(s2.data))
        {
            s2.step=s1.step+1;
            Map[s2.data]=1;
            q.push(s2);
        }
        s2.data=s1.data*2;
        if(check(s2.data))
        {
            s2.step=s1.step+1;
            Map[s2.data]=1;
            q.push(s2);
        }
    }
    return -1;
}
int main()
{
    int ans;
    while(scanf("%d%d",&n,&k)!=EOF)
    {
        memset(Map,0,sizeof(Map));
        while(!q.empty()) q.pop();
        ans=BFS(n);
        printf("%d\n",ans);
    }
    return 0;
}