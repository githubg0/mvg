// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1e5 + 10;
int a[maxn];
int n,m;
bool is_(int d)
{
    int temp = a[1],cnt = 1;
    for(int i = 2; i <= n; i ++)
    {
        if(a[i] - temp >= d)
        {
            cnt ++;
            temp = a[i];
        }
    }
    if(cnt >= m)
    {
        return true;
    }
    return false;
}
int main()
{
    while( ~ scanf("%d%d",&n,&m))
    {
        for(int i = 1; i <= n; i ++)
            scanf("%d",&a[i]);
        sort(a+1,a+n+1);
        int l = 1,r = a[n] - a[1];
        int T = 60;
        while(T --)
        {
            int mid = (l + r) >> 1;
            if(is_(mid))
            {
                l = mid;
            }
            else r = mid;
        }
        cout << l << endl;
    }
    return 0;
}