// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define esp 1e-4
using namespace std;
int A, B, C;
int ans;
struct node
{
	int x, y;
	int fx, fy;
	string to;
	int step;
};
node chart[110][110];
bool vis[110][110];
int judge(int x, int y)
{
	if (x == C || y == C)
		return 1;
	else
		return 0;
}
void solve(int x, int y, int step)
{
	ans = step;
	cout << step << endl;
	string temp[10000];
	int time = 0;
	while (step--)
	{
		node kkk=chart[x][y];
		temp[time] = kkk.to;
		x = kkk.fx;
		y = kkk.fy;
		time++;
	}
	for (int i =ans - 1; i >= 0; i--)
	{
		cout << temp[i] << endl;
	}
	
}
void bfs()
{
	node temp;
	queue<node> q;
	temp.x = 0;
	temp.y = 0;
	temp.step = 0;
	vis[0][0] = true;
	q.push(temp);
	while (!q.empty())
	{
		node then;
		
		if (!vis[0][q.front().y])
		{
			then.fx = q.front().x;
			then.fy = q.front().y;
			then.to = "DROP(1)";
			then.x = 0;
			then.y = q.front().y;
			then.step = q.front().step + 1;
			vis[then.x][then.y] = true;
			chart[then.x][then.y].fx = q.front().x;
			chart[then.x][then.y].fy = q.front().y;
			chart[then.x][then.y].to = "DROP(1)";
			if (judge(then.x, then.y))
			{
				solve(then.x, then.y, then.step);
				break;
			}
			
			q.push(then);
		}
		
		if (!vis[q.front().x][0])
		{
			then.fx = q.front().x;
			then.fy = q.front().y;
			then.to = "DROP(2)";
			then.y = 0;
			then.x = q.front().x;
			then.step = q.front().step + 1;
			vis[then.x][then.y] = true;
			chart[then.x][then.y].fx = q.front().x;
			chart[then.x][then.y].fy = q.front().y;
			chart[then.x][then.y].to = "DROP(2)";
			if (judge(then.x, then.y))
			{
				solve(then.x, then.y, then.step);
				break;
			}
			
			q.push(then);
		}
		
		if (!vis[A][q.front().y])
		{
			then.fx = q.front().x;
			then.fy = q.front().y;
			then.to = "FILL(1)";
			then.x = A;
			then.y = q.front().y;
			then.step = q.front().step + 1;
			vis[then.x][then.y] = true;
			chart[then.x][then.y].fx = q.front().x;
			chart[then.x][then.y].fy = q.front().y;
			chart[then.x][then.y].to = "FILL(1)";
			if (judge(then.x, then.y))
			{
				solve(then.x, then.y, then.step);
				break;
			}
			
			q.push(then);
		}
		
		if (!vis[q.front().x][B])
		{
			then.fx = q.front().x;
			then.fy = q.front().y;
			then.to = "FILL(2)";
			then.x = q.front().x;
			then.y = B;
			then.step = q.front().step + 1;
			vis[then.x][then.y] = true;
			chart[then.x][then.y].fx = q.front().x;
			chart[then.x][then.y].fy = q.front().y;
			chart[then.x][then.y].to = "FILL(2)";
			if (judge(then.x, then.y))
			{
				solve(then.x, then.y, then.step);
				break;
			}
			
			q.push(then);
		}
		
		if (q.front().x + q.front().y <= B)
		{
			if (!vis[0][q.front().x + q.front().y])
			{
				then.fx = q.front().x;
				then.fy = q.front().y;
				then.step = q.front().step + 1;
				then.to = "POUR(1,2)";
				then.x = 0;
				then.y = q.front().x + q.front().y;
				vis[then.x][then.y] = true;
				chart[then.x][then.y].fx = q.front().x;
				chart[then.x][then.y].fy = q.front().y;
				chart[then.x][then.y].to = "POUR(1,2)";
				if (judge(then.x, then.y))
				{
					solve(then.x, then.y, then.step);
					break;
				}
				
				q.push(then);
			}
			
		}
		else
		{
			if (!vis[q.front().x + q.front().y - B][B])
			{
				then.fx = q.front().x;
				then.fy = q.front().y;
				then.step = q.front().step + 1;
				then.to = "POUR(1,2)";
				then.x = q.front().x + q.front().y - B;
				then.y = B;
				vis[then.x][then.y] = true;
				chart[then.x][then.y].fx = q.front().x;
				chart[then.x][then.y].fy = q.front().y;
				chart[then.x][then.y].to = "POUR(1,2)";
				if (judge(then.x, then.y))
				{
					solve(then.x, then.y, then.step);
					break;
				}
				
				q.push(then);
			}
			
		}
		
		if (q.front().x + q.front().y <= A)
		{
			if (!vis[q.front().x + q.front().y][0])
			{
				then.fx = q.front().x;
				then.fy = q.front().y;
				then.step = q.front().step + 1;
				then.to = "POUR(2,1)";
				then.x = q.front().x + q.front().y;
				then.y = 0;
				vis[then.x][then.y] = true;
				chart[then.x][then.y].fx = q.front().x;
				chart[then.x][then.y].fy = q.front().y;
				chart[then.x][then.y].to = "POUR(2,1)";
				if (judge(then.x, then.y))
				{
					solve(then.x, then.y, then.step);
					break;
				}
				
				q.push(then);
			}
			
		}
		else
		{
			if (!vis[A][q.front().x + q.front().y - A])
			{
				then.fx = q.front().x;
				then.fy = q.front().y;
				then.step = q.front().step + 1;
				then.to = "POUR(2,1)";
				then.x = A;
				then.y = q.front().x + q.front().y - A;
				vis[then.x][then.y] = true;
				chart[then.x][then.y].fx = q.front().x;
				chart[then.x][then.y].fy = q.front().y;
				chart[then.x][then.y].to = "POUR(2,1)";
				if (judge(then.x, then.y))
				{
					solve(then.x, then.y, then.step);
					break;
				}
				
				q.push(then);
			}
			
		}
		
		q.pop();
	}
}
int main()
{
	while (cin >> A >> B >> C)
	{
		memset(vis, 0, sizeof(vis));
		ans = -1;
		bfs();
		if (ans == -1)
		{
			cout << "impossible\n";
		}
	}
	
	return 0;
}