// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 20010;
vector<int> G[maxn];
int v;
int color[maxn]; 
bool vis[maxn];  
int sum,sum1;
bool dfs(int v,int c)
{
    sum++;
    if(c == 1)
        sum1++;
    color[v] = c;
    for(int i = 0 ; i < G[v].size() ; i++)
    {
        if(color[G[v][i]]) continue;
        dfs(G[v][i],-c);
    }
}
int main()
{
    int t,n,kcase = 1;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        memset(color,0,sizeof(color));
        memset(vis,false,sizeof(vis));
        for(int i = 1 ; i <= maxn ; i++)
            G[i].clear();
        int maxx = 0;
        int minn = maxn;
        for(int i = 0 ; i < n ; i++)
        {
             int x,y;
             scanf("%d%d",&x,&y);
             vis[x] = vis[y] = true;
             G[x].push_back(y);
             G[y].push_back(x);
             maxx = max(max(maxx,x),y);
             minn = min(min(minn,x),y);
        }
        int ans = 0;
        for(int i = minn ; i <= maxx ; i++)
        {
            if(!vis[i] || color[i] != 0) continue; 
            sum = sum1 = 0;
            dfs(i,1);
            ans += max(sum1,sum-sum1);
        }
        printf("Case %d: %d\n",kcase++,ans);
    }
    return 0;
}