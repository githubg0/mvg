// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<bits/stdc++.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 10005
using namespace std;
int tot,head[N],vet[N<<1],Next[N<<1],val[N<<1];
void add(int x,int y ,int z){
    tot++;
    vet[tot]=y;
    val[tot]=z;
    Next[tot]=head[x]; 
    head[x]=tot;
}
int d[N][3];
int c[N];
int dfs1(int u,int fa){
    if(d[u][0]>=0)return d[u][0];
    d[u][0]=d[u][1]=d[u][2]=c[u]=0; 
    for(int i=head[u];i;i=Next[i]){
        int v=vet[i];
        if(v==fa)continue;
        if(d[u][0]<dfs1(v,u)+val[i]){
            c[u]=v;
            d[u][1]=max(d[u][1],d[u][0]);
            d[u][0]=dfs1(v,u)+val[i];
        }
        else if(d[u][1]<dfs1(v,u)+val[i]) 
            d[u][1]=max(d[u][1],dfs1(v,u)+val[i]);
    }
    return d[u][0];
}
void dfs2(int u,int fa){
    for(int i=head[u];i;i=Next[i]){
        int v=vet[i];
        if(v==fa)continue;
        if(v==c[u])d[v][2]=max(d[u][2],d[u][1])+val[i];
        else d[v][2]=max(d[u][2],d[u][0])+val[i];
        dfs2(v,u);
    }
}
int main(){
    int n;
    while(~scanf("%d",&n)){
        tot=0;
        memset(d,-1,sizeof(d));
        memset(head,-1,sizeof(head));
        memset(c,-1,sizeof(c));
        for(int i=2;i<=n;i++){
            int v,w;
            scanf("%d%d",&v,&w);
            add(i,v,w);
            add(v,i,w);
        }
        dfs1(1,-1);
        dfs2(1,-1);
        for(int i=1;i<=n;i++)
            printf("%d\n",max(d[i][0],d[i][2]));
    }
    return 0;
}